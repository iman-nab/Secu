#!/bin/sh
set -e

DB_HOST=${DB_HOST:-db}
DB_PORT=${DB_PORT:-5432}
DB_SYNC_MODE=${DB_SYNC_MODE:-push}  # push | migrate

echo "[backend] waiting for postgres at ${DB_HOST}:${DB_PORT} ..."
until nc -z "$DB_HOST" "$DB_PORT" >/dev/null 2>&1; do
  sleep 1
done
echo "[backend] postgres is up"

echo "[backend] prisma generate"
npm run prisma:generate >/dev/null 2>&1 || true

if [ "$DB_SYNC_MODE" = "migrate" ]; then
  if [ -d "/app/prisma/migrations" ]; then
    echo "[backend] prisma migrate deploy"
    npx prisma migrate deploy
  fi
else
  echo "[backend] prisma db push (sync schema)"
  npx prisma db push --accept-data-loss
fi

# Seed (idempotent via upsert)
if [ -f "/app/prisma/seed.ts" ] || [ -f "/app/prisma/seed.js" ]; then
  echo "[backend] prisma seed"
  npm run prisma:seed || true
fi

echo "[backend] starting dev server"
exec npm run dev
