import { HttpError } from './http.js';

/**
 * Domain-specific errors to enable precise frontend messaging.
 * These extend HttpError so the global error handler can translate them
 * into the API envelope error shape: { message, code, details }.
 */

export class GeofenceError extends HttpError {
  constructor(distanceM: number, radiusM: number, thresholdM?: number) {
    super(
      403,
      'Outside geofence',
      'GEOFENCE_OUTSIDE',
      {
        distanceM,
        radiusM,
        ...(typeof thresholdM === 'number' ? { thresholdM } : {}),
      }
    );
  }
}

export class ShiftConflictError extends HttpError {
  constructor(details: {
    conflictShiftId: string;
    conflictStartAt: string;
    conflictEndAt: string;
  }) {
    super(409, 'Shift overlap', 'SHIFT_OVERLAP', details);
  }
}

export class AuthLockoutError extends HttpError {
  constructor(untilIso: string, retryAfterSeconds: number) {
    super(429, 'Too many attempts', 'LOCKED_OUT', { until: untilIso, retryAfterSeconds });
  }
}
