import { prisma } from '../db/prisma.js';

type IO = { to: (room: string) => { emit: (event: string, payload: any) => void } };

/**
 * Broadcast a shift-related realtime event to:
 * - admins room
 * - opdrachtgever room (client:<clientId>)
 * - assigned employees (user:<id>)
 */
export async function emitShiftEvent(io: IO | undefined, shiftId: string, payload: any) {
  if (!io) return;

  const shift = await prisma.shift.findUnique({
    where: { id: shiftId },
    select: {
      id: true,
      clientId: true,
      assignments: { select: { userId: true } },
    },
  });

  // If the shift doesn't exist (deleted), still notify admins so UI can refresh.
  io.to('admins').emit('notification', { ...payload, shiftId });

  if (!shift) return;

  if (shift.clientId) {
    io.to(`client:${shift.clientId}`).emit('notification', { ...payload, shiftId });
  }

  for (const a of shift.assignments) {
    io.to(`user:${a.userId}`).emit('notification', { ...payload, shiftId });
  }

  // Also notify subcontractors of assigned employees (so subcontractor portal stays in sync)
  try {
    const userIds = shift.assignments.map((a) => a.userId);
    if (userIds.length) {
      const subs = await prisma.user.findMany({
        where: { id: { in: userIds }, subcontractorId: { not: null } },
        select: { subcontractorId: true },
      });
      const uniqueSubs = Array.from(new Set(subs.map((s) => s.subcontractorId).filter(Boolean) as string[]));
      for (const sid of uniqueSubs) {
        io.to(`user:${sid}`).emit('notification', { ...payload, shiftId, scope: 'subcontractor' });
      }
    }
  } catch {
    // best-effort
  }
}
