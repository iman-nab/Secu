import { HttpError } from './http.js';

/**
 * Phase 1 password policy:
 * - minimum 12 characters
 * - at least 1 lowercase, 1 uppercase, 1 digit, 1 special character
 */
export function assertPasswordPolicy(password: string) {
  const errors: string[] = [];
  if (password.length < 12) errors.push('minLength');
  if (!/[a-z]/.test(password)) errors.push('lowercase');
  if (!/[A-Z]/.test(password)) errors.push('uppercase');
  if (!/[0-9]/.test(password)) errors.push('digit');
  if (!/[^A-Za-z0-9]/.test(password)) errors.push('special');

  if (errors.length) {
    throw new HttpError(400, 'Wachtwoord voldoet niet aan het beleid', 'WEAK_PASSWORD', { errors });
  }
}
