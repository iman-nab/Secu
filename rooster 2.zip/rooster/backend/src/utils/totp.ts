import crypto from 'crypto';
import { base32Decode, base32Encode } from './base32.js';

export function generateTotpSecret(): string {
  // 20 bytes -> 160-bit secret
  return base32Encode(crypto.randomBytes(20));
}

export function buildOtpAuthUrl(opts: { issuer: string; accountName: string; secret: string }) {
  const label = encodeURIComponent(`${opts.issuer}:${opts.accountName}`);
  const issuer = encodeURIComponent(opts.issuer);
  const secret = encodeURIComponent(opts.secret);
  return `otpauth://totp/${label}?secret=${secret}&issuer=${issuer}&algorithm=SHA1&digits=6&period=30`;
}

export function totpAt(secretBase32: string, counter: number): string {
  const key = base32Decode(secretBase32);
  const msg = Buffer.alloc(8);
  // big-endian counter
  msg.writeBigUInt64BE(BigInt(counter), 0);
  const hmac = crypto.createHmac('sha1', key).update(msg).digest();
  const offset = hmac[hmac.length - 1] & 0x0f;
  const code = ((hmac[offset] & 0x7f) << 24) |
    ((hmac[offset + 1] & 0xff) << 16) |
    ((hmac[offset + 2] & 0xff) << 8) |
    (hmac[offset + 3] & 0xff);
  const digits = 6;
  const str = (code % 10 ** digits).toString().padStart(digits, '0');
  return str;
}

export function verifyTotp(secretBase32: string, token: string, opts?: { window?: number; step?: number }) {
  const step = opts?.step ?? 30;
  const window = opts?.window ?? 1;
  const now = Math.floor(Date.now() / 1000);
  const counter = Math.floor(now / step);
  const cleaned = String(token || '').replace(/\s/g, '');
  for (let w = -window; w <= window; w++) {
    if (totpAt(secretBase32, counter + w) === cleaned) return true;
  }
  return false;
}
