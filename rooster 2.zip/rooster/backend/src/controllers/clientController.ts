import { prisma } from '../db/prisma.js';
import { HttpError } from '../utils/http.js';
import { logAudit } from '../services/auditService.js';

async function getClientIdOrThrow(userId: string) {
  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: { id: true, role: true, clientId: true },
  });
  if (!user) throw new HttpError(401, 'Not authenticated');
  if (!user.clientId) throw new HttpError(403, 'Client account is not linked to an opdrachtgever');
  return { clientId: user.clientId, user };
}

function parseDate(v: any): Date | undefined {
  if (!v) return undefined;
  const d = new Date(String(v));
  if (Number.isNaN(d.getTime())) return undefined;
  return d;
}

export async function incidentsAnalytics(req: any, res: any) {
  const { clientId } = await getClientIdOrThrow(req.user.id);

  const now = new Date();
  const start = parseDate(req.query.start) ?? new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
  const end = parseDate(req.query.end) ?? new Date(now.getTime() + 1 * 24 * 60 * 60 * 1000);
  const limit = Math.min(Math.max(Number(req.query.limit ?? 10), 1), 50);

  const groups = await prisma.shiftReportEvent.groupBy({
    by: ['label'],
    where: {
      kind: 'INCIDENT',
      checked: true,
      report: {
        shift: {
          clientId,
          isDeleted: false,
          startAt: { lt: end },
          endAt: { gt: start },
        },
      },
    },
    _count: { label: true },
    orderBy: { _count: { label: 'desc' } },
    take: limit,
  });

  const items = groups.map((g) => ({ label: g.label, count: (g as any)._count.label as number }));

  return res.json({
    start: start.toISOString(),
    end: end.toISOString(),
    items,
  });
}

export async function listRequests(req: any, res: any) {
  const { clientId } = await getClientIdOrThrow(req.user.id);

  const requests = await prisma.clientRequest.findMany({
    where: { clientId },
    orderBy: { createdAt: 'desc' },
    include: {
      createdBy: { select: { id: true, fullName: true, email: true } },
      handledBy: { select: { id: true, fullName: true, email: true } },
    },
  });

  return res.json({ requests });
}

export async function createRequest(req: any, res: any) {
  const { clientId } = await getClientIdOrThrow(req.user.id);

  const subject = String(req.body?.subject ?? '').trim();
  const message = String(req.body?.message ?? '').trim();

  if (!subject || subject.length < 3) throw new HttpError(400, 'subject is required');
  if (!message || message.length < 5) throw new HttpError(400, 'message is required');

  const created = await prisma.clientRequest.create({
    data: {
      clientId,
      createdById: req.user.id,
      subject,
      message,
      status: 'OPEN',
    },
    include: {
      createdBy: { select: { id: true, fullName: true, email: true } },
      handledBy: { select: { id: true, fullName: true, email: true } },
    },
  });

  // Audit trail (best-effort)
  await logAudit({
    actorId: req.user.id,
    action: 'CLIENT_REQUEST_CREATE',
    entity: 'ClientRequest',
    entityId: created.id,
    before: null,
    after: created,
  });

  return res.status(201).json(created);
}
