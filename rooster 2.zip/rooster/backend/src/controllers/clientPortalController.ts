import { prisma } from '../db/prisma.js';
import { HttpError } from '../utils/http.js';
import { emitShiftEvent } from '../utils/realtime.js';

async function getClientIdOrThrow(userId: string) {
  const user = await prisma.user.findUnique({ where: { id: userId }, select: { id: true, role: true, clientId: true, fullName: true, email: true } });
  if (!user) throw new HttpError(401, 'Not authenticated');
  if (!user.clientId) throw new HttpError(403, 'Client account is not linked to an opdrachtgever');
  return { clientId: user.clientId, user };
}

export async function me(req: any, res: any) {
  const { clientId, user } = await getClientIdOrThrow(req.user.id);
  const client = await prisma.client.findUnique({ where: { id: clientId }, select: { id: true, name: true, contactName: true, contactEmail: true } });
  return res.json({ user, client });
}

export async function listShifts(req: any, res: any) {
  const { clientId } = await getClientIdOrThrow(req.user.id);
  const start = req.query.start ? new Date(String(req.query.start)) : undefined;
  const end = req.query.end ? new Date(String(req.query.end)) : undefined;
  const where: any = { isDeleted: false, clientId };
  if (start && end && !Number.isNaN(start.getTime()) && !Number.isNaN(end.getTime())) {
    where.startAt = { lt: end };
    where.endAt = { gt: start };
  }

  const shifts = await prisma.shift.findMany({
    where,
    orderBy: { startAt: 'asc' },
    include: {
      location: true,
      client: true,
      assignments: { include: { user: { select: { id: true, fullName: true } } } },
      notes: {
        orderBy: [{ isPinned: 'desc' }, { pinnedAt: 'desc' }, { createdAt: 'desc' }],
        include: { author: { select: { id: true, fullName: true } } },
      },
    },
  });
  return res.json({ shifts });
}

export async function listShiftNotes(req: any, res: any) {
  const { clientId } = await getClientIdOrThrow(req.user.id);
  const shift = await prisma.shift.findUnique({ where: { id: String(req.params.id) }, select: { id: true, clientId: true } });
  if (!shift || shift.clientId !== clientId) throw new HttpError(404, 'Shift not found');
  const notes = await prisma.shiftNote.findMany({
    where: { shiftId: shift.id },
    orderBy: [{ isPinned: 'desc' }, { pinnedAt: 'desc' }, { createdAt: 'desc' }],
    include: { author: { select: { id: true, fullName: true } } },
  });
  return res.json({ notes });
}

export async function createShiftNote(req: any, res: any) {
  const { clientId } = await getClientIdOrThrow(req.user.id);
  const shiftId = String(req.params.id);
  const content = String(req.body?.content || '').trim();
  if (!content) throw new HttpError(400, 'content is required');
  const visibleToEmployees = req.body?.visibleToEmployees === false ? false : true;

  const shift = await prisma.shift.findUnique({ where: { id: shiftId }, select: { id: true, clientId: true } });
  if (!shift || shift.clientId !== clientId) throw new HttpError(404, 'Shift not found');

  const note = await prisma.shiftNote.create({
    data: { shiftId, authorId: req.user.id, content, visibleToEmployees },
    include: { author: { select: { id: true, fullName: true } } },
  });

  // Realtime update (admin + opdrachtgever + assigned employees)
  const io = req.app.locals.io;
  await emitShiftEvent(io, shiftId, {
    type: 'NOTE_CREATE',
    noteId: note.id,
    visibleToEmployees,
  });
  return res.status(201).json(note);
}
