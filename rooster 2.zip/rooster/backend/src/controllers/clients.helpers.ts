import { env } from '../config/env.js';

export function buildInviteLink(req: any, token: string) {
  const base = (env.APP_BASE_URL || `${req.protocol}://${req.get('host')}`).replace(/\/$/, '');
  // Standard invite acceptance route (frontend).
  return `${base}/signup/${token}`;
}
