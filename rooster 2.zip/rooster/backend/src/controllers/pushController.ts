import { z } from 'zod';
import type { Request, Response } from 'express';
import { getVapidPublicKey, upsertSubscription, deleteSubscription } from '../services/pushService.js';

export async function vapidPublicKey(_req: Request, res: Response) {
  res.json({ publicKey: getVapidPublicKey() });
}

const subscribeSchema = z.object({
  endpoint: z.string().min(1),
  keys: z.object({ p256dh: z.string().min(1), auth: z.string().min(1) }),
  userAgent: z.string().optional(),
});

export async function subscribe(req: any, res: Response) {
  const body = subscribeSchema.parse(req.body);
  await upsertSubscription({
    userId: req.user.id,
    endpoint: body.endpoint,
    p256dh: body.keys.p256dh,
    auth: body.keys.auth,
    userAgent: body.userAgent,
  });
  res.status(204).send();
}

const unsubscribeSchema = z.object({ endpoint: z.string().min(1) });

export async function unsubscribe(req: any, res: Response) {
  const body = unsubscribeSchema.parse(req.body);
  await deleteSubscription(req.user.id, body.endpoint);
  res.status(204).send();
}
