import { z } from 'zod';

export const dateRangeSchema = z.object({
  start: z.string().optional(),
  end: z.string().optional(),
});

export const createShiftSchema = z.object({
  title: z.string().min(2),
  description: z.string().optional(),
  type: z.string().min(1).optional().default('GENERAL'),
  requiredPassColor: z.enum(['GRAY','DARK_BLUE','LIGHT_BLUE','ORANGE','GREEN','BLACK']).optional().default('BLACK'),
  locationId: z.string().min(1),
  clientId: z.string().min(1).optional(),
  requiredWorkers: z.number().int().min(1).max(50).optional(),
  assigneeIds: z.array(z.string().min(1)).optional(),
  materials: z.array(z.object({ materialId: z.string().min(1), quantity: z.number().int().min(1).max(999).default(1) })).optional(),
  startAt: z.string().datetime(),
  endAt: z.string().datetime(),
  // Draft is kept for backwards compatibility, but the product no longer uses it.
  status: z.enum(['DRAFT', 'OPEN', 'ASSIGNED', 'COMPLETED', 'CANCELLED']).default('OPEN'),
});

export const updateShiftSchema = createShiftSchema.partial();


export const bulkWeekSchema = z.object({
  weekStart: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  locationId: z.string().min(1),
  clientId: z.string().min(1).optional(),
  repeatUntil: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
  // Entries in a week: dow 0-6 (Mon=1? we use 0=Sunday JS). We'll use 1-7? Keep 0-6 JS.
  entries: z.array(z.object({
    dow: z.number().int().min(0).max(6),
    title: z.string().min(2),
    type: z.string().min(1).optional().default('GENERAL'),
    requiredPassColor: z.enum(['GRAY','DARK_BLUE','LIGHT_BLUE','ORANGE','GREEN','BLACK']).optional().default('BLACK'),
    startTime: z.string().regex(/^\d{2}:\d{2}$/),
    endTime: z.string().regex(/^\d{2}:\d{2}$/),
    requiredWorkers: z.number().int().min(1).max(50).optional(),
    assigneeIds: z.array(z.string().min(1)).optional(),
  materials: z.array(z.object({ materialId: z.string().min(1), quantity: z.number().int().min(1).max(999).default(1) })).optional(),
    status: z.enum(['DRAFT', 'OPEN']).default('OPEN'),
  })).min(1),
  // Backwards-compatible: old UI used repeat.weeks. If provided, it is converted to a repeatUntil window.
  repeat: z.object({
    mode: z.enum(['none', 'weekly']).default('none'),
    weeks: z.number().int().min(1).max(52).optional(),
  }).optional(),
});

// Repeat a single shift weekly until a given date (inclusive).
export const repeatShiftSchema = z.object({
  // Base shift fields
  title: z.string().min(1),
  locationId: z.string().min(1),
  clientId: z.string().min(1).optional(),
  type: z.string().optional(),
  status: z.enum(['DRAFT', 'OPEN']).optional(),
  requiredWorkers: z.number().int().min(1).max(50).optional(),
  requiredPassColor: z.string().optional().nullable(),
  startAt: z.string().min(1),
  endAt: z.string().min(1),
  // Repeat
  repeatUntil: z.string().min(1), // date-only YYYY-MM-DD
  intervalWeeks: z.number().int().min(1).max(12).optional(),
  // Optional: assign immediately
  assigneeIds: z.array(z.string().min(1)).optional(),
});

export const requestSchema = z.object({}); // empty body

export const clockSchema = z.object({
  lat: z.number(),
  lng: z.number(),
  accuracyM: z.number(),
  // Optional: user-provided reason when outside geofence (business value)
  geoReason: z.string().max(200).optional().nullable(),
  // Optional: precomputed distance from frontend (for UI), backend will compute as source of truth.
  distanceM: z.number().int().optional(),
  // Optional: allow user to proceed when outside the geofence (soft-block UX)
  bypassGeofence: z.boolean().optional(),
});

export const reviewSchema = z.object({
  userId: z.string().min(1),
  approve: z.boolean(),
});

export const assignSchema = z.object({
  userId: z.string().min(1).optional(),
  userIds: z.array(z.string().min(1)).optional(),
});

export const pinNoteSchema = z.object({
  pinned: z.boolean(),
});
