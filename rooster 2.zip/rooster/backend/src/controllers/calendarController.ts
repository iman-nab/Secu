import type { Request, Response } from 'express';
import crypto from 'crypto';
import { prisma } from '../db/prisma.js';
import { env } from '../config/env.js';
import { HttpError } from '../utils/http.js';

function toICSDate(d: Date): string {
  // UTC format: YYYYMMDDTHHMMSSZ
  const yyyy = String(d.getUTCFullYear()).padStart(4, '0');
  const mm = String(d.getUTCMonth() + 1).padStart(2, '0');
  const dd = String(d.getUTCDate()).padStart(2, '0');
  const hh = String(d.getUTCHours()).padStart(2, '0');
  const mi = String(d.getUTCMinutes()).padStart(2, '0');
  const ss = String(d.getUTCSeconds()).padStart(2, '0');
  return `${yyyy}${mm}${dd}T${hh}${mi}${ss}Z`;
}

function icsEscape(s: string): string {
  // Escape characters per RFC5545: backslash, semicolon, comma, newline
  return s
    .replace(/\\/g, '\\\\')
    .replace(/\n/g, '\\n')
    .replace(/\r/g, '')
    .replace(/;/g, '\\;')
    .replace(/,/g, '\\,');
}

function buildBaseUrl(req: Request): string {
  // Prefer configured app URL (frontend), fall back to request host
  if (env.APP_BASE_URL) return env.APP_BASE_URL.replace(/\/$/, '');
  const proto = (req.headers['x-forwarded-proto'] as string) || req.protocol || 'http';
  const host = req.headers['x-forwarded-host'] || req.headers.host;
  return `${proto}://${host}`;
}

function generateToken(): string {
  return crypto.randomBytes(24).toString('hex');
}

export async function myCalendarToken(req: any, res: Response) {
  const userId = req.user.id as string;
  const user = await prisma.user.findUnique({ where: { id: userId }, select: { id: true, calendarToken: true } });
  if (!user) throw new HttpError(404, 'User not found');

  let token = user.calendarToken;
  if (!token) {
    // try a few times in case of rare collision
    for (let i = 0; i < 5; i++) {
      const candidate = generateToken();
      try {
        await prisma.user.update({ where: { id: userId }, data: { calendarToken: candidate } });
        token = candidate;
        break;
      } catch {
        // collision, retry
      }
    }
  }

  if (!token) throw new HttpError(500, 'Failed to generate calendar token');

  const base = buildBaseUrl(req);
  res.json({ token, url: `${base}/calendar/${token}.ics` });
}

export async function calendarIcs(req: Request, res: Response) {
  const token = req.params.token;
  if (!token) throw new HttpError(400, 'Missing token');

  const user = await prisma.user.findFirst({
    where: { calendarToken: token, isActive: true, status: 'ACTIVE' },
    select: { id: true, fullName: true },
  });
  if (!user) throw new HttpError(404, 'Not found');

  const now = new Date();
  const from = new Date(now);
  from.setDate(from.getDate() - 30);
  const to = new Date(now);
  to.setDate(to.getDate() + 180);

  const assignments = await prisma.shiftAssignment.findMany({
    where: {
      userId: user.id,
      status: 'APPROVED',
      shift: {
        isDeleted: false,
        status: { not: 'CANCELLED' },
        startAt: { gte: from },
        endAt: { lte: to },
      },
    },
    include: {
      shift: {
        include: {
          location: true,
          client: true,
        },
      },
    },
    orderBy: { shift: { startAt: 'asc' } },
  });

  const dtstamp = toICSDate(new Date());

  const lines: string[] = [];
  lines.push('BEGIN:VCALENDAR');
  lines.push('VERSION:2.0');
  lines.push('PRODID:-//Rooster//Shift Calendar//NL');
  lines.push('CALSCALE:GREGORIAN');
  lines.push('METHOD:PUBLISH');
  lines.push(`X-WR-CALNAME:${icsEscape('Rooster – Diensten')}`);
  lines.push(`X-WR-CALDESC:${icsEscape(`Diensten voor ${user.fullName}`)}`);

  for (const a of assignments) {
    const s = a.shift;
    const uid = `shift-${s.id}@rooster`;
    const summary = `${s.title}${s.location?.name ? ' • ' + s.location.name : ''}`;
    const descriptionParts: string[] = [];
    if (s.client?.name) descriptionParts.push(`Opdrachtgever: ${s.client.name}`);
    if (s.description) descriptionParts.push(s.description);
    const description = descriptionParts.join('\n');
    const location = s.location?.address ? `${s.location.name} – ${s.location.address}` : s.location?.name || '';

    lines.push('BEGIN:VEVENT');
    lines.push(`UID:${icsEscape(uid)}`);
    lines.push(`DTSTAMP:${dtstamp}`);
    lines.push(`DTSTART:${toICSDate(new Date(s.startAt))}`);
    lines.push(`DTEND:${toICSDate(new Date(s.endAt))}`);
    lines.push(`SUMMARY:${icsEscape(summary)}`);
    if (location) lines.push(`LOCATION:${icsEscape(location)}`);
    if (description) lines.push(`DESCRIPTION:${icsEscape(description)}`);
    lines.push('END:VEVENT');
  }

  lines.push('END:VCALENDAR');

  const body = lines.join('\r\n') + '\r\n';

  res.setHeader('Content-Type', 'text/calendar; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  res.send(body);
}
