import { z } from 'zod';
import * as Users from '../services/usersService.js';
import type { $Enums } from '@prisma/client';

import { logAudit } from '../services/auditService.js';
import { prisma } from '../db/prisma.js';
import { HttpError } from '../utils/http.js';

const createSchema = z.object({
  email: z.string().email(),
  fullName: z.string().min(2),
  role: z.enum(['ADMIN','EMPLOYEE','CLIENT','SUBCONTRACTOR']),
  password: z.string().min(8),
  clientId: z.string().cuid().optional(),
});

const updateSchema = z.object({
  fullName: z.string().min(2).optional(),
  role: z.enum(['ADMIN','EMPLOYEE','CLIENT','SUBCONTRACTOR']).optional(),
  clientId: z.string().cuid().nullable().optional(),
  isActive: z.boolean().optional(),
  password: z.string().min(8).optional(),
  passColor: z.enum(['GRAY','DARK_BLUE','LIGHT_BLUE','ORANGE','GREEN','BLACK']).nullable().optional(),
});

export async function list(req: any, res: any) {
  const pageRaw = req.query?.page;
  const pageSizeRaw = req.query?.pageSize;
  const q = typeof req.query?.q === 'string' ? req.query.q : undefined;
  const role = typeof req.query?.role === 'string' ? req.query.role : undefined;
  const excludeRole = typeof req.query?.excludeRole === 'string' ? req.query.excludeRole : undefined;
  const rolesRaw = typeof req.query?.roles === 'string' ? req.query.roles : undefined;
  const excludeRolesRaw = typeof req.query?.excludeRoles === 'string' ? req.query.excludeRoles : undefined;
  const includeLastWorked = String(req.query?.includeLastWorked ?? '').toLowerCase();
  const withLastWorked = includeLastWorked === '1' || includeLastWorked === 'true' || includeLastWorked === 'yes';

  const page = pageRaw ? Number(pageRaw) : undefined;
  const pageSize = pageSizeRaw ? Number(pageSizeRaw) : undefined;

  const wantsPaged = Number.isFinite(page as any) || Number.isFinite(pageSize as any) || !!q || !!role || !!excludeRole || !!rolesRaw || !!excludeRolesRaw;
  if (wantsPaged) {
    const roles = rolesRaw
      ? rolesRaw
          .split(',')
          .map((s) => s.trim())
          .filter(Boolean)
      : undefined;
    const excludeRoles = excludeRolesRaw
      ? excludeRolesRaw
          .split(',')
          .map((s) => s.trim())
          .filter(Boolean)
      : undefined;

    const result = await Users.listUsersPaged({
      page: Number.isFinite(page as any) ? (page as number) : 1,
      pageSize: Number.isFinite(pageSize as any) ? (pageSize as number) : 25,
      q,
      role: (role as any) || undefined,
      excludeRole: (excludeRole as any) || undefined,
      roles: (roles as any) || undefined,
      excludeRoles: (excludeRoles as any) || undefined,
      includeLastWorked: withLastWorked,
    });
    res.json({ users: result.items, totalCount: result.totalCount, page: Number(page ?? 1), pageSize: Number(pageSize ?? 25) });
    return;
  }

  const users = await Users.listUsers();
  res.json({ users });
}

export async function create(req: any, res: any) {
  if (req.user?.role !== 'ADMIN') throw new HttpError(403, 'Forbidden');
  const body = createSchema.parse(req.body);

  // Enforce opdrachtgever linkage for client portal users
  if (body.role === 'CLIENT' && !body.clientId) {
    throw new HttpError(400, 'clientId is required when role is CLIENT');
  }

  const user = await Users.createUser({
    email: body.email,
    fullName: body.fullName,
    password: body.password,
    role: body.role as $Enums.Role,
    clientId: body.clientId,
  });
  await logAudit({ actorId: req.user.id, action: 'USER_CREATE', entity: 'User', entityId: user.id, before: null, after: { id: user.id, email: user.email, fullName: user.fullName, role: user.role, isActive: user.isActive } });
  res.status(201).json({ user });
}

export async function update(req: any, res: any) {
  if (req.user?.role !== 'ADMIN') throw new HttpError(403, 'Forbidden');
  const body = updateSchema.parse(req.body);

  if (body.role === 'CLIENT' && body.clientId === undefined) {
    // If switching to CLIENT without specifying opdrachtgever, block it.
    throw new HttpError(400, 'clientId is required when role is CLIENT');
  }
  const before = await prisma.user.findUnique({ where: { id: req.params.id }, select: { id: true, email: true, fullName: true, role: true, isActive: true } });
  const user = await Users.updateUser(req.params.id, body as any);
  await logAudit({ actorId: req.user.id, action: 'USER_UPDATE', entity: 'User', entityId: user.id, before, after: { id: user.id, email: user.email, fullName: user.fullName, role: user.role, isActive: user.isActive } });
  res.json({ user });
}

export async function get(req: any, res: any) {
  const user = await Users.getUser(req.params.id);
  res.json({ user });
}

export async function reactivate(req: any, res: any) {
  if (req.user?.role !== 'ADMIN') throw new HttpError(403, 'Forbidden');

  const before = await prisma.user.findUnique({
    where: { id: req.params.id },
    select: { id: true, email: true, fullName: true, role: true, isActive: true },
  });
  if (!before) throw new HttpError(404, 'User not found');

  // Best-effort restore of the original email when the account was soft-deleted.
  // Soft-delete appends `.deleted.<ts>` to preserve uniqueness.
  let restoreEmail: string | undefined;
  const marker = '.deleted.';
  if (before.email.includes(marker)) {
    const candidate = before.email.split(marker)[0];
    const exists = await prisma.user.findUnique({ where: { email: candidate } });
    if (!exists || exists.id === before.id) restoreEmail = candidate;
  }

  const user = await Users.reactivateUser(req.params.id, {
    email: restoreEmail,
  });
  await logAudit({
    actorId: req.user.id,
    action: 'USER_REACTIVATE',
    entity: 'User',
    entityId: user.id,
    before,
    after: { id: user.id, email: user.email, fullName: user.fullName, role: user.role, isActive: user.isActive },
  });
  res.json({ user });
}


export async function remove(req: any, res: any) {
  if (req.user?.role !== 'ADMIN') throw new HttpError(403, 'Forbidden');
  const before = await prisma.user.findUnique({ where: { id: req.params.id }, select: { id: true, email: true, fullName: true, role: true, isActive: true } });
  const user = await Users.deleteUser(req.params.id);
  await logAudit({ actorId: req.user.id, action: 'USER_DELETE', entity: 'User', entityId: user.id, before, after: { id: user.id, email: user.email, fullName: user.fullName, role: user.role, isActive: user.isActive } });
  res.json({ user });
}

// -------------------- Admin security resets --------------------

export async function reset2FA(req: any, res: any) {
  if (req.user?.role !== 'ADMIN') throw new HttpError(403, 'Forbidden');

  const before = await prisma.user.findUnique({
    where: { id: req.params.id },
    select: { id: true, email: true, twoFactorEnabled: true },
  });
  if (!before) throw new HttpError(404, 'User not found');

  const user = await Users.reset2FA(req.params.id);
  await logAudit({
    actorId: req.user.id,
    action: 'ADMIN_RESET_2FA',
    entity: 'User',
    entityId: user.id,
    before,
    after: { id: user.id, twoFactorEnabled: user.twoFactorEnabled },
  });
  res.json({ user });
}

export async function resetPassword(req: any, res: any) {
  if (req.user?.role !== 'ADMIN') throw new HttpError(403, 'Forbidden');

  const before = await prisma.user.findUnique({
    where: { id: req.params.id },
    select: { id: true, email: true },
  });
  if (!before) throw new HttpError(404, 'User not found');

  const result = await Users.resetPassword(req.params.id);
  await logAudit({
    actorId: req.user.id,
    action: 'ADMIN_RESET_PASSWORD',
    entity: 'User',
    entityId: result.user.id,
    before,
    after: { id: result.user.id, passwordReset: true },
  });

  // Return temp password once so admin can share it with the user.
  res.json({ user: result.user, tempPassword: result.tempPassword });
}
