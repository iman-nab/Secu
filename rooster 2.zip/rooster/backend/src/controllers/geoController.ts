import type { Request, Response } from 'express';

// Simple proxy to OpenStreetMap Nominatim.
// Reason: browser requests can get rate-limited / blocked by missing User-Agent.
// This proxy sets sensible headers and keeps the frontend simple.

export async function geoSearch(req: Request, res: Response) {
  const q = String(req.query.q ?? '').trim();
  if (!q) return res.json({ results: [] });

  const url = new URL('https://nominatim.openstreetmap.org/search');
  url.searchParams.set('format', 'json');
  url.searchParams.set('limit', '5');
  url.searchParams.set('addressdetails', '1');
  url.searchParams.set('q', q);

  // Use globalThis.fetch so TS doesn't require DOM lib.
  const r = await (globalThis as any).fetch(url, {
    headers: {
      // Nominatim usage policy expects a valid User-Agent.
      // Put your actual domain/email here if you deploy publicly.
      'User-Agent': 'rooster-app/1.0 (https://example.com)',
      'Accept-Language': 'nl',
      Accept: 'application/json',
    },
  });

  if (!r.ok) {
    return res.status(502).json({ results: [], error: 'geocode_failed' });
  }

  const arr = (await r.json()) as any[];
  const results = (arr ?? []).map((x) => ({
    displayName: String(x.display_name ?? ''),
    lat: Number(x.lat),
    lon: Number(x.lon),
  }));

  return res.json({ results });
}

export async function geoReverse(req: Request, res: Response) {
  const lat = Number(req.query.lat);
  const lon = Number(req.query.lon);
  if (Number.isNaN(lat) || Number.isNaN(lon)) return res.status(400).json({ error: 'invalid_coords' });

  // Provider 1: OpenStreetMap Nominatim
  const url = new URL('https://nominatim.openstreetmap.org/reverse');
  url.searchParams.set('format', 'json');
  url.searchParams.set('addressdetails', '1');
  url.searchParams.set('lat', String(lat));
  url.searchParams.set('lon', String(lon));

  const headers = {
    // Nominatim usage policy expects a valid User-Agent.
    // Put your actual domain/email here when deploying publicly.
    'User-Agent': 'rooster-app/1.0 (admin@yourdomain.example)',
    'Accept-Language': 'nl',
    Accept: 'application/json',
  };

  let json: any = null;
  try {
    const r = await (globalThis as any).fetch(url, { headers });
    if (r.ok) json = await r.json();
  } catch {
    // ignore, try fallback
  }

  // Provider 2 (fallback): maps.co (OSM-based). Useful when Nominatim rate-limits.
  // This keeps the "Gebruik mijn locatie" button working more reliably.
  if (!json) {
    try {
      const u2 = new URL('https://geocode.maps.co/reverse');
      u2.searchParams.set('lat', String(lat));
      u2.searchParams.set('lon', String(lon));
      u2.searchParams.set('format', 'json');

      const r2 = await (globalThis as any).fetch(u2, { headers: { ...headers, 'User-Agent': 'rooster-app/1.0' } });
      if (r2.ok) json = await r2.json();
    } catch {
      // ignore
    }
  }

  if (!json) return res.status(502).json({ error: 'reverse_failed' });

  const addr = json?.address ?? {};

  const road = addr.road || addr.pedestrian || addr.cycleway || addr.footway || '';
  const houseNumber = addr.house_number || '';
  const postcode = addr.postcode || '';
  const city = addr.city || addr.town || addr.village || addr.municipality || addr.suburb || addr.county || '';

  const streetLine = [road, houseNumber].filter(Boolean).join(' ').trim();
  const displayName = String(json?.display_name ?? '');

  return res.json({
    displayName,
    street: streetLine,
    postcode,
    city,
  });
}
