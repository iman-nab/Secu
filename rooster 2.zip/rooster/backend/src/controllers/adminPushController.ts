import { z } from 'zod';
import type { Response } from 'express';
import { prisma } from '../db/prisma.js';
import { HttpError } from '../utils/http.js';
import { createUserNotification } from '../services/notificationsService.js';

const sendSchema = z.object({
  title: z.string().min(1).max(80).default('Rooster'),
  message: z.string().min(1).max(500),
  url: z.string().max(200).optional(),
  target: z.discriminatedUnion('type', [
    z.object({ type: z.literal('shift'), shiftId: z.string().min(1) }),
    z.object({ type: z.literal('passColor'), passColor: z.enum(['GRAY','DARK_BLUE','LIGHT_BLUE','ORANGE','GREEN','BLACK']) }),
    z.object({ type: z.literal('allEmployees') }),
  ]),
});

export async function send(req: any, res: Response) {
  const body = sendSchema.parse(req.body);
  const actorId = req.user.id as string;

  let recipientIds: string[] = [];

  if (body.target.type === 'shift') {
    const shift = await prisma.shift.findUnique({ where: { id: body.target.shiftId }, select: { id: true, isDeleted: true } });
    if (!shift || shift.isDeleted) throw new HttpError(404, 'Shift not found');

    const assignments = await prisma.shiftAssignment.findMany({
      where: { shiftId: body.target.shiftId, status: 'APPROVED', user: { isActive: true, status: 'ACTIVE' } },
      select: { userId: true },
    });
    recipientIds = assignments.map((a) => a.userId);

    // default URL to shift detail
    if (!body.url) (body as any).url = `/diensten/${body.target.shiftId}`;
  } else {
    // All employees
    if (body.target.type === 'allEmployees') {
      const users = await prisma.user.findMany({
        where: { role: 'EMPLOYEE', isActive: true, status: 'ACTIVE' },
        select: { id: true },
      });
      recipientIds = users.map((u) => u.id);

      if (!body.url) (body as any).url = '/open-diensten';
    } else {
    const users = await prisma.user.findMany({
      where: {
        role: 'EMPLOYEE',
        isActive: true,
        status: 'ACTIVE',
        passColor: body.target.passColor,
      },
      select: { id: true },
    });
    recipientIds = users.map((u) => u.id);

      if (!body.url) (body as any).url = '/open-diensten';

      // Extra business rule (relevant for your app):
      // GREEN is special but admin is targeting; allow.
    }
  }

  // Deduplicate
  recipientIds = Array.from(new Set(recipientIds));

  // Send notifications (creates Notification record + push)
  await Promise.all(
    recipientIds.map((rid) =>
      createUserNotification({
        recipientId: rid,
        senderId: actorId,
        type: 'ADMIN_PUSH',
        message: body.message,
        data: { title: body.title, url: body.url, target: body.target },
      }),
    ),
  );

  await prisma.auditLog.create({
    data: {
      actorId,
      action: 'PUSH_SENT',
      entity: 'PUSH',
      entityId:
        body.target.type === 'shift'
          ? body.target.shiftId
          : body.target.type === 'passColor'
            ? body.target.passColor
            : 'allEmployees',
      after: {
        title: body.title,
        message: body.message,
        url: body.url,
        target: body.target,
        recipients: recipientIds.length,
      },
    },
  });

  res.json({ sent: true, recipients: recipientIds.length });
}
