import * as Notifications from '../services/notificationsService.js';

export async function list(req: any, res: any) {
  const page = Math.max(1, Number(req.query?.page ?? 1));
  const pageSize = Math.max(1, Math.min(200, Number(req.query?.pageSize ?? 25)));
  const tabRaw = String(req.query?.tab ?? 'all').toLowerCase();
  const tab = tabRaw === 'action' ? 'action' : 'all';

  const result = await Notifications.listNotifications(req.user.id, { page, pageSize, tab });
  res.json({ notifications: result.items, totalCount: result.totalCount, page: result.page, pageSize: result.pageSize });
}

export async function markRead(req: any, res: any) {
  await Notifications.markRead(req.user.id, req.params.id);
  res.json({ ok: true });
}


export async function markAllRead(req: any, res: any) {
  await Notifications.markAllRead(req.user.id);
  res.json({ ok: true });
}

export async function unreadCount(req: any, res: any) {
  const count = await Notifications.countUnread(req.user.id);
  res.json({ count });
}
