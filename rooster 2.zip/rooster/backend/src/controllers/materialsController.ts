import { z } from 'zod';
import { prisma } from '../db/prisma.js';
import { HttpError } from '../utils/http.js';
import { createAdminNotification } from '../services/notificationsService.js';

const createSchema = z.object({
  name: z.string().min(2),
  description: z.string().optional(),
  stockQuantity: z.number().int().min(0).optional(),
});

const stockAdjustSchema = z.object({
  delta: z.number().int(),
  reason: z.string().min(2).max(500),
});

const createAssignmentSchema = z.object({
  materialId: z.string().cuid(),
  userId: z.string().cuid(),
  quantity: z.number().int().min(1).max(999),
  note: z.string().max(500).optional(),
});

const reportSchema = z.object({
  kind: z.enum(['LOST', 'DEFECT']),
  note: z.string().min(2).max(500).optional(),
});

function requireAdmin(req: any) {
  if (req.user?.role !== 'ADMIN') throw new HttpError(403, 'Forbidden');
}

async function logMaterialHistory(input: {
  materialId: string;
  actorId: string;
  action:
    | 'CREATE'
    | 'UPDATE'
    | 'STOCK_ADJUST'
    | 'ASSIGN'
    | 'RETURN'
    | 'LOST'
    | 'DEFECT'
    | 'DELETE';
  quantityDelta?: number;
  note?: string | null;
  userId?: string | null;
  assignmentId?: string | null;
}) {
  await prisma.materialHistory.create({
    data: {
      materialId: input.materialId,
      actorId: input.actorId,
      action: input.action as any,
      quantityDelta: input.quantityDelta ?? 0,
      note: input.note ?? null,
      userId: input.userId ?? null,
      assignmentId: input.assignmentId ?? null,
    },
  });
}

async function notifyAdmins(
  req: any,
  input: { type: string; message: string; data?: any },
) {
  // Persist in-app notification + optional push
  await createAdminNotification({
    type: input.type,
    message: input.message,
    data: input.data,
    senderId: req.user?.id,
  });

  // Realtime toast update for admins
  const io = (req.app as any)?.locals?.io;
  io?.to('admins')?.emit('notification', { type: input.type, ...(input.data ?? {}) });
}

/**
 * Materials catalog + inventory
 */

export async function list(req: any, res: any) {
  const q = typeof req.query?.q === 'string' ? req.query.q.trim() : '';
  const page = Math.max(1, Number(req.query?.page ?? 1));
  const pageSize = Math.max(1, Math.min(200, Number(req.query?.pageSize ?? 25)));
  const skip = (page - 1) * pageSize;

  const where: any = {
    isDeleted: false,
    ...(q
      ? {
          OR: [
            { name: { contains: q, mode: 'insensitive' } },
            { description: { contains: q, mode: 'insensitive' } },
          ],
        }
      : {}),
  };

  const [materials, totalCount] = await prisma.$transaction([
    prisma.material.findMany({
      where,
      orderBy: { name: 'asc' },
      skip,
      take: pageSize,
      select: {
        id: true,
        name: true,
        description: true,
        stockQuantity: true,
      },
    }),
    prisma.material.count({ where }),
  ]);

  res.json({ materials, totalCount, page, pageSize });
}

export async function create(req: any, res: any) {
  requireAdmin(req);
  const body = createSchema.parse(req.body);
  const material = await prisma.material.create({
    data: {
      name: body.name,
      description: body.description,
      stockQuantity: body.stockQuantity ?? 0,
    },
  });
  await logMaterialHistory({
    materialId: material.id,
    actorId: req.user.id,
    action: 'CREATE',
    quantityDelta: body.stockQuantity ?? 0,
    note: 'Material created',
  });

  await notifyAdmins(req, {
    type: 'MATERIAL_CREATED',
    message: `Materiaal aangemaakt: ${material.name}`,
    data: { materialId: material.id, name: material.name, url: '/admin' },
  });
  res.status(201).json({ material });
}

export async function update(req: any, res: any) {
  requireAdmin(req);
  const body = createSchema.partial().parse(req.body);
  const id = req.params.id;
  const existing = await prisma.material.findUnique({ where: { id } });
  if (!existing || existing.isDeleted) throw new HttpError(404, 'Not found');

  const material = await prisma.material.update({
    where: { id },
    data: {
      name: body.name,
      description: body.description,
      ...(typeof body.stockQuantity === 'number' ? { stockQuantity: body.stockQuantity } : {}),
    },
  });

  await logMaterialHistory({
    materialId: id,
    actorId: req.user.id,
    action: 'UPDATE',
    note: 'Material updated',
  });

  await notifyAdmins(req, {
    type: 'MATERIAL_UPDATED',
    message: `Materiaal gewijzigd: ${material.name}`,
    data: { materialId: material.id, name: material.name, url: '/admin' },
  });

  res.json({ material });
}

export async function adjustStock(req: any, res: any) {
  requireAdmin(req);
  const id = req.params.id;
  const body = stockAdjustSchema.parse(req.body);

  const existing = await prisma.material.findUnique({ where: { id } });
  if (!existing || existing.isDeleted) throw new HttpError(404, 'Not found');

  const next = existing.stockQuantity + body.delta;
  if (next < 0) throw new HttpError(400, 'INSUFFICIENT_STOCK');

  const material = await prisma.material.update({ where: { id }, data: { stockQuantity: next } });
  await logMaterialHistory({
    materialId: id,
    actorId: req.user.id,
    action: 'STOCK_ADJUST',
    quantityDelta: body.delta,
    note: body.reason,
  });

  await notifyAdmins(req, {
    type: 'MATERIAL_STOCK_CHANGED',
    message: `Voorraad aangepast (${body.delta > 0 ? '+' : ''}${body.delta}) voor ${material.name} → ${material.stockQuantity}`,
    data: {
      materialId: material.id,
      name: material.name,
      delta: body.delta,
      stockQuantity: material.stockQuantity,
      url: '/admin',
    },
  });

  // Low-stock signal
  if (material.stockQuantity <= 0) {
    await notifyAdmins(req, {
      type: 'MATERIAL_STOCK_EMPTY',
      message: `Voorraad op: ${material.name}`,
      data: { materialId: material.id, name: material.name, stockQuantity: material.stockQuantity, url: '/admin' },
    });
  } else if (material.stockQuantity < 5) {
    await notifyAdmins(req, {
      type: 'MATERIAL_STOCK_LOW',
      message: `Lage voorraad (${material.stockQuantity}) voor ${material.name}`,
      data: { materialId: material.id, name: material.name, stockQuantity: material.stockQuantity, url: '/admin' },
    });
  }

  res.json({ material });
}

export async function remove(req: any, res: any) {
  requireAdmin(req);
  const id = req.params.id;
  const force = String(req.query?.force ?? '') === '1';
  const existing = await prisma.material.findUnique({ where: { id } });
  if (!existing || existing.isDeleted) throw new HttpError(404, 'Not found');

  // Default: soft delete (keeps history). If force=1, hard delete and cascade.
  if (force) {
    await prisma.material.delete({ where: { id } });
    await notifyAdmins(req, {
      type: 'MATERIAL_DELETED',
      message: `Materiaal definitief verwijderd: ${existing.name}`,
      data: { materialId: id, name: existing.name, url: '/admin' },
    });
    return res.status(204).end();
  }

  await prisma.material.update({ where: { id }, data: { isDeleted: true, deletedAt: new Date() } });
  await logMaterialHistory({
    materialId: id,
    actorId: req.user.id,
    action: 'DELETE',
    note: 'Material soft-deleted',
  });

  await notifyAdmins(req, {
    type: 'MATERIAL_DELETED',
    message: `Materiaal verwijderd: ${existing.name}`,
    data: { materialId: id, name: existing.name, url: '/admin' },
  });

  res.status(204).end();
}

/**
 * Assignments
 */

export async function listAssignments(req: any, res: any) {
  requireAdmin(req);
  const { userId, materialId, status } = req.query as any;

  const assignments = await prisma.materialAssignment.findMany({
    where: {
      ...(userId ? { userId } : {}),
      ...(materialId ? { materialId } : {}),
      ...(status ? { status } : {}),
    },
    orderBy: { assignedAt: 'desc' },
    include: {
      material: { select: { id: true, name: true } },
      user: { select: { id: true, fullName: true, email: true } },
      createdBy: { select: { id: true, fullName: true } },
    },
  });

  res.json({ assignments });
}

export async function listMyAssignments(req: any, res: any) {
  const assignments = await prisma.materialAssignment.findMany({
    where: { userId: req.user.id, status: { in: ['ASSIGNED', 'LOST', 'DEFECT'] } },
    orderBy: { assignedAt: 'desc' },
    include: { material: { select: { id: true, name: true, description: true } } },
  });
  res.json({ assignments });
}

export async function createAssignment(req: any, res: any) {
  requireAdmin(req);
  const body = createAssignmentSchema.parse(req.body);

  const material = await prisma.material.findUnique({ where: { id: body.materialId } });
  if (!material || material.isDeleted) throw new HttpError(404, 'Material not found');
  if (material.stockQuantity < body.quantity) throw new HttpError(400, 'INSUFFICIENT_STOCK');

  const assignment = await prisma.$transaction(async (tx) => {
    // Transaction-safe stock decrement.
    // Prevents race conditions where multiple assignments could push stock below zero.
    const dec = await tx.material.updateMany({
      where: { id: body.materialId, isDeleted: false, stockQuantity: { gte: body.quantity } },
      data: { stockQuantity: { decrement: body.quantity } },
    });
    if (dec.count === 0) throw new HttpError(400, 'INSUFFICIENT_STOCK');

    const created = await tx.materialAssignment.create({
      data: {
        materialId: body.materialId,
        userId: body.userId,
        quantity: body.quantity,
        note: body.note ?? null,
        createdById: req.user.id,
      },
      include: {
        material: { select: { id: true, name: true } },
        user: { select: { id: true, fullName: true, email: true } },
      },
    });

    await tx.materialHistory.create({
      data: {
        materialId: body.materialId,
        actorId: req.user.id,
        userId: body.userId,
        assignmentId: created.id,
        action: 'ASSIGN' as any,
        quantityDelta: -body.quantity,
        note: body.note ?? 'Assigned',
      },
    });

    return created;
  });

  await notifyAdmins(req, {
    type: 'MATERIAL_ASSIGNED',
    message: `Uitgifte: ${assignment.material.name} ×${assignment.quantity} → ${assignment.user.fullName}`,
    data: { assignmentId: assignment.id, materialId: assignment.material.id, userId: assignment.user.id, url: '/admin' },
  });

  res.status(201).json({ assignment });
}

export async function returnAssignment(req: any, res: any) {
  requireAdmin(req);
  const id = req.params.id;
  const note = typeof req.body?.note === 'string' ? req.body.note : undefined;

  const existing = await prisma.materialAssignment.findUnique({ where: { id } });
  if (!existing) throw new HttpError(404, 'Not found');
  if (existing.status !== 'ASSIGNED') throw new HttpError(400, 'NOT_ASSIGNED');

  const assignment = await prisma.$transaction(async (tx) => {
    await tx.materialAssignment.update({
      where: { id },
      data: { status: 'RETURNED' as any, returnedAt: new Date(), updatedById: req.user.id },
    });

    // Return to stock
    await tx.material.update({
      where: { id: existing.materialId },
      data: { stockQuantity: { increment: existing.quantity } },
    });

    await tx.materialHistory.create({
      data: {
        materialId: existing.materialId,
        actorId: req.user.id,
        userId: existing.userId,
        assignmentId: existing.id,
        action: 'RETURN' as any,
        quantityDelta: existing.quantity,
        note: note ?? 'Returned',
      },
    });

    return tx.materialAssignment.findUnique({
      where: { id },
      include: { material: { select: { id: true, name: true } }, user: { select: { id: true, fullName: true } } },
    });
  });

  if (assignment) {
    await notifyAdmins(req, {
      type: 'MATERIAL_RETURNED',
      message: `Retour: ${(assignment as any).material?.name ?? 'Materiaal'} ×${existing.quantity} ← ${(assignment as any).user?.fullName ?? ''}`,
      data: { assignmentId: existing.id, materialId: existing.materialId, userId: existing.userId, url: '/admin' },
    });
  }

  res.json({ assignment });
}

export async function reportIssue(req: any, res: any) {
  const id = req.params.id;
  const body = reportSchema.parse(req.body);

  const existing = await prisma.materialAssignment.findUnique({ where: { id } });
  if (!existing) throw new HttpError(404, 'Not found');
  if (existing.userId !== req.user.id && req.user.role !== 'ADMIN') throw new HttpError(403, 'Forbidden');
  if (existing.status !== 'ASSIGNED') throw new HttpError(400, 'NOT_ASSIGNED');

  const nextStatus = body.kind;

  const assignment = await prisma.$transaction(async (tx) => {
    const updated = await tx.materialAssignment.update({
      where: { id },
      data: {
        status: nextStatus as any,
        returnedAt: new Date(),
        updatedById: req.user.id,
        note: body.note ?? existing.note,
      },
      include: { material: { select: { id: true, name: true } }, user: { select: { id: true, fullName: true } } },
    });

    await tx.materialHistory.create({
      data: {
        materialId: existing.materialId,
        actorId: req.user.id,
        userId: existing.userId,
        assignmentId: existing.id,
        action: nextStatus as any,
        quantityDelta: 0,
        note: body.note ?? (nextStatus === 'LOST' ? 'Reported lost' : 'Reported defect'),
      },
    });

    return updated;
  });

  await notifyAdmins(req, {
    type: nextStatus === 'LOST' ? 'MATERIAL_LOST' : 'MATERIAL_DEFECT',
    message:
      nextStatus === 'LOST'
        ? `Verlies gemeld: ${(assignment as any).material?.name ?? 'Materiaal'} (${(assignment as any).user?.fullName ?? ''})`
        : `Defect gemeld: ${(assignment as any).material?.name ?? 'Materiaal'} (${(assignment as any).user?.fullName ?? ''})`,
    data: { assignmentId: assignment.id, materialId: assignment.materialId, userId: assignment.userId, url: '/materials' },
  });

  res.json({ assignment });
}

export async function listHistory(req: any, res: any) {
  requireAdmin(req);
  const { materialId, userId } = req.query as any;

  const history = await prisma.materialHistory.findMany({
    where: {
      ...(materialId ? { materialId } : {}),
      ...(userId ? { userId } : {}),
    },
    orderBy: { createdAt: 'desc' },
    take: 200,
    include: {
      material: { select: { id: true, name: true } },
      actor: { select: { id: true, fullName: true } },
      user: { select: { id: true, fullName: true } },
    },
  });

  res.json({ history });
}
