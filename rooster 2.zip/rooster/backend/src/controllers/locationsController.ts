import { z } from 'zod';
import * as Locations from '../services/locationsService.js';
import { logAudit } from '../services/auditService.js';
import { prisma } from '../db/prisma.js';
import { HttpError } from '../utils/http.js';

const createSchema = z.object({
  name: z.string().min(2),
  address: z.string().min(2),
  latitude: z.number(),
  longitude: z.number(),
  radiusM: z.number().int().positive(),
});

const updateSchema = createSchema.partial();

export async function list(req: any, res: any) {
  const locations = await Locations.listLocations();
  res.json({ locations });
}

export async function create(req: any, res: any) {
  if (req.user.role !== 'ADMIN') throw new HttpError(403, 'Forbidden');
  const body = createSchema.parse(req.body);
  const location = await Locations.createLocation(body);

  await logAudit({ actorId: req.user.id, action: 'LOCATION_CREATE', entity: 'Location', entityId: location.id, before: null, after: location });
  res.status(201).json({ location });
}

export async function update(req: any, res: any) {
  if (req.user.role !== 'ADMIN') throw new HttpError(403, 'Forbidden');
  const body = updateSchema.parse(req.body);
  const before = await prisma.location.findUnique({ where: { id: req.params.id } });
  const location = await Locations.updateLocation(req.params.id, body);

  await logAudit({ actorId: req.user.id, action: 'LOCATION_UPDATE', entity: 'Location', entityId: location.id, before, after: location });
  res.json({ location });
}

export async function remove(req: any, res: any) {
  if (req.user.role !== 'ADMIN') throw new HttpError(403, 'Forbidden');
  const before = await prisma.location.findUnique({ where: { id: req.params.id } });
  const after = await Locations.deleteLocation(req.params.id);

  await logAudit({ actorId: req.user.id, action: 'LOCATION_DELETE', entity: 'Location', entityId: req.params.id, before, after });
  res.json({ ok: true });
}
