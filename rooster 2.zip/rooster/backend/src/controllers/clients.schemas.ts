import { z } from 'zod';

export const createSchema = z.object({
  name: z.string().min(2),
  contactName: z.string().optional(),
  contactEmail: z.string().email().optional(),
});

export const updateSchema = createSchema.partial();

export const onboardSchema = z.object({
  name: z.string().min(2),
  contactName: z.string().optional(),
  contactEmail: z.string().email().optional(),

  createPortalUser: z.boolean().default(true),
  portalEmail: z.string().email().optional(),
  portalFullName: z.string().min(2).optional(),
});

export const createPortalUserSchema = z.object({
  portalEmail: z.string().email().optional(),
  portalFullName: z.string().min(2).optional(),
});
