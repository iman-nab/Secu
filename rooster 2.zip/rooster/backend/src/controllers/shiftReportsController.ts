import { z } from 'zod';
import PDFDocument from 'pdfkit';
import { logAudit } from '../services/auditService.js';
import { prisma } from '../db/prisma.js';
import { HttpError } from '../utils/http.js';
import {
  DEFAULT_INCIDENTS,
  assertCanAccessShiftReport,
  getShiftReportOrNull,
  upsertShiftReport,
  ensureReportExists,
  addAttachment,
  getAttachmentWithData,
  deleteAttachment,
} from '../services/shiftReportsService.js';

const reportUpsertSchema = z.object({
  locationText: z.string().min(1),
  summary: z.string().optional().nullable(),
  incidents: z.array(z.object({
    label: z.string().min(1),
    checked: z.boolean().default(false),
    notes: z.string().optional().nullable(),
  })).default([]),
  actions: z.array(z.object({
    label: z.string().min(1),
    checked: z.boolean().default(false),
    notes: z.string().optional().nullable(),
    timeText: z.string().regex(/^\d{2}:\d{2}$/).optional().nullable(),
  })).default([]),
});

const attachmentCreateSchema = z.object({
  fileName: z.string().min(1),
  mimeType: z.string().min(1),
  base64: z.string().min(10),
});

function stripDataUrl(b64: string) {
  const m = b64.match(/^data:([^;]+);base64,(.*)$/);
  if (!m) return { mimeType: undefined as string | undefined, base64: b64 };
  return { mimeType: m[1], base64: m[2] };
}

export async function getReport(req: any, res: any) {
  const shiftId = String(req.params.id);
  const shift = await assertCanAccessShiftReport(req.user, shiftId, 'read');

  const existing = await getShiftReportOrNull(shiftId);

  if (!existing) {
    // Return a default template (frontend can PUT to create)
    return res.json({
      report: {
        id: null,
        shiftId,
        locationText: shift.location?.name ?? '',
        summary: null,
        incidents: DEFAULT_INCIDENTS.map((label) => ({ label, checked: false, notes: '', timeText: '' })),
        actions: [],
        attachments: [],
        createdAt: null,
        updatedAt: null,
      },
    });
  }

  const incidents = existing.events
    .filter((e) => e.kind === 'INCIDENT')
    .sort((a, b) => a.sortOrder - b.sortOrder)
    .map((e) => ({ label: e.label, checked: e.checked, notes: e.notes ?? '', timeText: (e as any).timeText ?? '' }));

  const actions = existing.events
    .filter((e) => e.kind === 'ACTION')
    .sort((a, b) => a.sortOrder - b.sortOrder)
    .map((e) => ({ label: e.label, checked: e.checked, notes: e.notes ?? '', timeText: (e as any).timeText ?? '' }));

  return res.json({
    report: {
      id: existing.id,
      shiftId,
      locationText: existing.locationText,
      summary: existing.summary,
      incidents: incidents.length ? incidents : DEFAULT_INCIDENTS.map((label) => ({ label, checked: false, notes: '', timeText: '' })),
      actions,
      attachments: existing.attachments,
      createdAt: existing.createdAt,
      updatedAt: existing.updatedAt,
    },
  });
}

export async function upsertReport(req: any, res: any) {
  const shiftId = String(req.params.id);
  const shift = await assertCanAccessShiftReport(req.user, shiftId, 'write');
  const body = reportUpsertSchema.parse(req.body ?? {});

  const before = await getShiftReportOrNull(shiftId);
  const { report, created } = await upsertShiftReport(shiftId, req.user.id, {
    locationText: body.locationText,
    summary: body.summary ?? null,
    incidents: body.incidents,
    actions: body.actions,
  });
  const after = await getShiftReportOrNull(shiftId);

  await logAudit({
    actorId: req.user.id,
    action: created ? 'SHIFT_REPORT_CREATE' : 'SHIFT_REPORT_UPDATE',
    entity: 'ShiftReport',
    entityId: report.id,
    before,
    after,
  });

  // Return normalized shape
  req.params.id = shiftId;
  return getReport(req, res);
}

export async function createAttachment(req: any, res: any) {
  const shiftId = String(req.params.id);
  const shift = await assertCanAccessShiftReport(req.user, shiftId, 'write');
  const body = attachmentCreateSchema.parse(req.body ?? {});

  const stripped = stripDataUrl(body.base64);
  const mimeType = stripped.mimeType ?? body.mimeType;

  const buf = Buffer.from(stripped.base64, 'base64');
  const maxBytes = 8 * 1024 * 1024; // 8MB
  if (buf.byteLength > maxBytes) throw new HttpError(413, 'File too large (max 8MB)');

  const report = await ensureReportExists(shiftId, req.user.id, shift.location?.name ?? '');
  const attachment = await addAttachment(report.id, req.user.id, {
    fileName: body.fileName,
    mimeType,
    data: buf,
  });

  await logAudit({
    actorId: req.user.id,
    action: 'SHIFT_REPORT_ATTACHMENT_ADD',
    entity: 'ShiftReport',
    entityId: report.id,
    before: null,
    after: { attachmentId: attachment.id, fileName: attachment.fileName, sizeBytes: attachment.sizeBytes },
  });

  return res.status(201).json({ attachment });
}

export async function downloadAttachment(req: any, res: any) {
  const shiftId = String(req.params.id);
  await assertCanAccessShiftReport(req.user, shiftId, 'read');

  const attachmentId = String(req.params.attachmentId);
  // Fetch the report first and then fetch the attachment scoped to that report.
  // This avoids a "fetch-then-check" pattern and guarantees ownership.
  const report = await prisma.shiftReport.findUnique({ where: { shiftId }, select: { id: true } });
  if (!report) throw new HttpError(404, 'Attachment not found');

  const a = await prisma.shiftReportAttachment.findFirst({
    where: { id: attachmentId, reportId: report.id },
  });
  if (!a) throw new HttpError(404, 'Attachment not found');

  res.setHeader('Content-Type', a.mimeType);
  res.setHeader('Content-Disposition', `attachment; filename="${a.fileName.replace(/\"/g, '')}"`);
  return res.send(Buffer.from(a.data));
}

export async function removeAttachment(req: any, res: any) {
  const shiftId = String(req.params.id);
  await assertCanAccessShiftReport(req.user, shiftId, 'write');

  const attachmentId = String(req.params.attachmentId);
  const existing = await getAttachmentWithData(attachmentId);
  if (!existing) throw new HttpError(404, 'Attachment not found');

  // Allow deletion by admin or uploader
  if (req.user.role !== 'ADMIN' && existing.uploadedById !== req.user.id) {
    throw new HttpError(403, 'Forbidden');
  }

  const report = await prisma.shiftReport.findUnique({ where: { shiftId }, select: { id: true } });
  if (!report || existing.reportId !== report.id) throw new HttpError(404, 'Attachment not found');

  await deleteAttachment(attachmentId);

  await logAudit({
    actorId: req.user.id,
    action: 'SHIFT_REPORT_ATTACHMENT_DELETE',
    entity: 'ShiftReport',
    entityId: report.id,
    before: { attachmentId: existing.id, fileName: existing.fileName },
    after: null,
  });

  return res.json({ ok: true });
}

export async function exportPdf(req: any, res: any) {
  const shiftId = String(req.params.id);
  await assertCanAccessShiftReport(req.user, shiftId, 'read');

  // Load a rich shift payload for a finance-/admin-friendly PDF.
  const shift = await prisma.shift.findUnique({
    where: { id: shiftId },
    include: {
      location: true,
      client: true,
      assignments: { include: { user: true } },
      extraCosts: true,
    },
  });
  if (!shift) throw new HttpError(404, 'Shift not found');
  const existing = await getShiftReportOrNull(shiftId);

  const report = existing
    ? {
        locationText: existing.locationText,
        summary: existing.summary ?? '',
        incidents: existing.events.filter((e) => e.kind === 'INCIDENT').sort((a, b) => a.sortOrder - b.sortOrder),
        actions: existing.events.filter((e) => e.kind === 'ACTION').sort((a, b) => a.sortOrder - b.sortOrder),
        attachments: existing.attachments,
      }
    : {
        locationText: shift.location?.name ?? '',
        summary: '',
        incidents: DEFAULT_INCIDENTS.map((l, idx) => ({ label: l, checked: false, notes: null, timeText: null, sortOrder: idx })),
        actions: [],
        attachments: [],
      };

  res.setHeader('Content-Type', 'application/pdf');
  const TZ = 'Europe/Amsterdam';
  const isoDate = (d: Date) => new Intl.DateTimeFormat('sv-SE', { timeZone: TZ, year: 'numeric', month: '2-digit', day: '2-digit' }).format(d);
  const slug = String(shift.title ?? 'dienst')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 40);
  res.setHeader('Content-Disposition', `attachment; filename="dienstenrapportage_${isoDate(shift.startAt)}_${slug || 'dienst'}_${shiftId}.pdf"`);

  // A4 with generous margins produces a much cleaner printable report.
  // Buffer pages so we can add "Pagina X van Y" at the end.
  const doc = new PDFDocument({ margin: 40, size: 'A4', bufferPages: true });
  doc.pipe(res);

  const dateOnly = (d: Date) => new Intl.DateTimeFormat('nl-NL', { timeZone: TZ, year: 'numeric', month: '2-digit', day: '2-digit' }).format(d);
  const timeOnly = (d: Date) => new Intl.DateTimeFormat('nl-NL', { timeZone: TZ, hour: '2-digit', minute: '2-digit', hour12: false }).format(d);
  const fmt = (d: Date) => `${dateOnly(d)} ${timeOnly(d)}`;
  const section = (t: string) => {
    doc.moveDown(0.35);
    doc.fontSize(13).fillColor('black').text(t);
    const x1 = doc.page.margins.left;
    const x2 = doc.page.width - doc.page.margins.right;
    doc.moveTo(x1, doc.y + 2).lineTo(x2, doc.y + 2).strokeColor('#E5E7EB').stroke();
    doc.strokeColor('black');
    doc.moveDown(0.35);
  };

  doc.fontSize(18).text('Dienstenrapportage (PDF)', { align: 'left' });
  doc.moveDown(0.25);
  doc.fontSize(10).fillColor('gray').text(`Datum: ${dateOnly(shift.startAt)}  •  Dienst-ID: ${shiftId}`);
  doc.fillColor('black');
  doc.moveDown(0.5);

  doc.fontSize(12).text(`Dienst: ${shift.title}`);
  doc.fontSize(11).fillColor('gray').text(
    `Klant: ${shift.client?.name ?? '-'}  •  Locatie: ${report.locationText || shift.location?.name || '-'}  •  Tijd: ${fmt(shift.startAt)} → ${fmt(shift.endAt)}`,
  );
  if (shift.location?.address) {
    doc.fontSize(10).fillColor('gray').text(`Adres: ${shift.location.address}`);
  }
  doc.fillColor('black');
  doc.moveDown(0.5);

  // Assigned workers
  section('Ingeplande medewerkers');
  const assigned = (shift.assignments ?? []).filter((a: any) => a.status === 'APPROVED');
  if (!assigned.length) {
    doc.fontSize(11).fillColor('gray').text('Geen medewerkers toegewezen.');
    doc.fillColor('black');
  } else {
    doc.fontSize(11);
    for (const a of assigned) {
      doc.text(`• ${a.user?.fullName ?? '-'} (${a.user?.email ?? ''})`);
    }
  }

  // Extra costs
  section('Extra kosten');
  const extra = shift.extraCosts ?? [];
  const eur = (cents: number) => (Number(cents || 0) / 100).toLocaleString('nl-NL', { style: 'currency', currency: 'EUR' });
  if (!extra.length) {
    doc.fontSize(11).fillColor('gray').text('Geen extra kosten.');
    doc.fillColor('black');
  } else {
    const total = extra.reduce((acc: number, e: any) => acc + Number(e.amountCents || 0), 0);
    doc.fontSize(11);
    for (const e of extra) {
      doc.text(`• ${e.description}: ${eur(Number(e.amountCents || 0))}`);
    }
    doc.moveDown(0.25);
    doc.fontSize(11).text(`Totaal extra kosten: ${eur(total)}`);
  }

  section('Incidenten');
  const incidentsChecked = report.incidents.filter((i: any) => i.checked);
  if (incidentsChecked.length === 0) {
    doc.fontSize(11).fillColor('gray').text('Geen incidenten aangevinkt.');
    doc.fillColor('black');
  } else {
    doc.fontSize(11);
    for (const it of incidentsChecked) {
      const time = (it as any).timeText ? `[${(it as any).timeText}] ` : '';
      doc.text(`• ${time}${it.label}${it.notes ? ` — ${it.notes}` : ''}`);
    }
  }

  section('Acties');

  if (!report.actions.length) {
    doc.fontSize(11).fillColor('gray').text('Geen acties.');
    doc.fillColor('black');
  } else {
    doc.fontSize(11);
    for (const a of report.actions) {
      doc.text(`${a.checked ? '☑' : '☐'} ${a.label}${a.notes ? ` — ${a.notes}` : ''}`);
    }
  }

  section('Opmerkingen');
  doc.fontSize(11).text(report.summary || '—');

  section('Bijlagen');
  if (!report.attachments.length) {
    doc.fontSize(11).fillColor('gray').text('Geen bijlagen.');
    doc.fillColor('black');
  } else {
    doc.fontSize(11);
    for (const at of report.attachments) {
      doc.text(`• ${at.fileName} (${Math.round((at.sizeBytes || 0) / 1024)} KB)`);
    }
  }

  // Page footers with total page count
  const rangePages = doc.bufferedPageRange();
  const totalPages = rangePages.count;
  for (let i = 0; i < totalPages; i++) {
    doc.switchToPage(i);
    const y = doc.page.height - 28;
    const w = doc.page.width - doc.page.margins.left - doc.page.margins.right;
    const x = doc.page.margins.left;
    doc.fontSize(8).fillColor('gray').text(`Pagina ${i + 1} van ${totalPages}`, x, y, { align: 'right', width: w });
    doc.fillColor('black');
  }
  doc.end();
}
