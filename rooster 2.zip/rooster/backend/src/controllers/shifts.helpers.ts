import { HttpError } from '../utils/http.js';

export function parseDateParam(value: string, opts?: { endOfDay?: boolean }) {
  const isDateOnly = /^\d{4}-\d{2}-\d{2}$/.test(value);
  if (isDateOnly) {
    const iso = opts?.endOfDay ? `${value}T23:59:59.999Z` : `${value}T00:00:00.000Z`;
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) throw new HttpError(400, `Invalid date: ${value}`);
    return d;
  }
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) throw new HttpError(400, `Invalid datetime: ${value}`);
  return d;
}
