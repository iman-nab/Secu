import { HttpError } from '../utils/http.js';
import {
  createMyAvailability,
  createMyAvailability as createAvailabilityForUser,
  deleteAvailability,
  listAvailabilityForUser,
  listMyAvailability,
  updateAvailability,
} from '../services/availabilityService.js';
import { prisma } from '../db/prisma.js';
import { logAudit } from '../services/auditService.js';

function parseDate(input: any, field: string) {
  const d = new Date(String(input));
  if (isNaN(d.getTime())) throw new HttpError(400, `Invalid ${field}`, 'VALIDATION_ERROR');
  return d;
}

export async function listMe(req: any, res: any) {
  const startAt = req.query.startAt ? parseDate(req.query.startAt, 'startAt') : undefined;
  const endAt = req.query.endAt ? parseDate(req.query.endAt, 'endAt') : undefined;
  const items = await listMyAvailability(req.user.id, { startAt, endAt });
  return res.json({ items });
}

export async function createMe(req: any, res: any) {
  const type = String(req.body?.type ?? '').trim();
  if (!['VACATION', 'SICK', 'UNAVAILABLE'].includes(type)) {
    throw new HttpError(400, 'Invalid type', 'VALIDATION_ERROR');
  }
  const startAt = parseDate(req.body?.startAt, 'startAt');
  const endAt = parseDate(req.body?.endAt, 'endAt');
  const note = req.body?.note ? String(req.body.note) : undefined;

  const created = await createMyAvailability(req.user.id, { type, startAt, endAt, note });
  return res.status(201).json(created);
}

export async function listUser(req: any, res: any) {
  const userId = String(req.params.userId);
  const startAt = req.query.startAt ? parseDate(req.query.startAt, 'startAt') : undefined;
  const endAt = req.query.endAt ? parseDate(req.query.endAt, 'endAt') : undefined;

  const items = await listAvailabilityForUser({ id: req.user.id, role: req.user.role }, userId, { startAt, endAt });
  return res.json({ items });
}

export async function updateOne(req: any, res: any) {
  const id = String(req.params.id);
  const before = await prisma.userAvailability.findUnique({ where: { id } });
  if (!before) throw new HttpError(404, 'Not found');
  const body = req.body ?? {};
  const update: any = {};
  if (body.type !== undefined) {
    const type = String(body.type).trim();
    if (!['VACATION', 'SICK', 'UNAVAILABLE'].includes(type)) {
      throw new HttpError(400, 'Invalid type', 'VALIDATION_ERROR');
    }
    update.type = type;
  }
  if (body.startAt !== undefined) update.startAt = parseDate(body.startAt, 'startAt');
  if (body.endAt !== undefined) update.endAt = parseDate(body.endAt, 'endAt');
  if (body.note !== undefined) update.note = body.note === null ? null : String(body.note);

  const updated = await updateAvailability({ id: req.user.id, role: req.user.role }, id, update);

  await logAudit({
    actorId: req.user.id,
    action: 'AVAILABILITY_UPDATE',
    entity: 'UserAvailability',
    entityId: id,
    before,
    after: updated,
  });
  return res.json(updated);
}

export async function deleteOne(req: any, res: any) {
  const id = String(req.params.id);
  const before = await prisma.userAvailability.findUnique({ where: { id } });
  if (!before) throw new HttpError(404, 'Not found');
  await deleteAvailability({ id: req.user.id, role: req.user.role }, id);

  await logAudit({
    actorId: req.user.id,
    action: 'AVAILABILITY_DELETE',
    entity: 'UserAvailability',
    entityId: id,
    before,
    after: null,
  });
  return res.json({ ok: true });
}

// Admin: create availability for any user
export async function createUser(req: any, res: any) {
  if (req.user.role !== 'ADMIN') throw new HttpError(403, 'Forbidden');
  const userId = String(req.params.userId);

  const type = String(req.body?.type ?? '').trim();
  if (!['VACATION', 'SICK', 'UNAVAILABLE'].includes(type)) {
    throw new HttpError(400, 'Invalid type', 'VALIDATION_ERROR');
  }
  const startAt = parseDate(req.body?.startAt, 'startAt');
  const endAt = parseDate(req.body?.endAt, 'endAt');
  const note = req.body?.note ? String(req.body.note) : undefined;

  const created = await createAvailabilityForUser(userId, { type, startAt, endAt, note });

  await logAudit({
    actorId: req.user.id,
    action: 'AVAILABILITY_CREATE',
    entity: 'UserAvailability',
    entityId: created.id,
    before: null,
    after: created,
  });

  return res.status(201).json(created);
}
