import PDFDocument from 'pdfkit';
import { prisma } from '../db/prisma.js';
import { HttpError } from '../utils/http.js';
import { logAudit } from '../services/auditService.js';

function parseISODateOnly(s: string): Date {
  // Accept YYYY-MM-DD
  const m = /^\d{4}-\d{2}-\d{2}$/.exec(s);
  if (!m) throw new HttpError(400, 'Invalid date format (expected YYYY-MM-DD)');
  const [y, mo, d] = s.split('-').map((x) => Number(x));
  return new Date(Date.UTC(y, mo - 1, d, 0, 0, 0, 0));
}

function startOfIsoWeek(d: Date): Date {
  const dt = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate(), 0, 0, 0, 0));
  const day = dt.getUTCDay(); // 0..6 (Sun..Sat)
  const diff = day === 0 ? -6 : 1 - day; // Monday start
  dt.setUTCDate(dt.getUTCDate() + diff);
  dt.setUTCHours(0, 0, 0, 0);
  return dt;
}

function addDays(d: Date, days: number) {
  const out = new Date(d);
  out.setUTCDate(out.getUTCDate() + days);
  return out;
}

async function getEmployeeIdsForSubcontractor(subcontractorId: string) {
  const users = await prisma.user.findMany({
    where: {
      subcontractorId,
      role: 'EMPLOYEE',
      status: { not: 'DELETED' },
      isActive: true,
    },
    select: { id: true },
  });
  return users.map((u) => u.id);
}

export async function me(req: any, res: any) {
  const user = await prisma.user.findUnique({
    where: { id: req.user.id },
    select: { id: true, email: true, fullName: true, role: true },
  });
  res.json({ user });
}

export async function listWorkers(req: any, res: any) {
  const workers = await prisma.user.findMany({
    where: {
      subcontractorId: req.user.id,
      role: 'EMPLOYEE',
      status: { not: 'DELETED' },
    },
    select: {
      id: true,
      fullName: true,
      email: true,
      phone: true,
      passColor: true,
      status: true,
      isActive: true,
      createdAt: true,
    },
    orderBy: { fullName: 'asc' },
  });
  res.json({ workers });
}

export async function updateWorkerPassColor(req: any, res: any) {
  const { id } = req.params;
  const passColor = String(req.body?.passColor || '');

  const allowed = ['GRAY','DARK_BLUE','LIGHT_BLUE','ORANGE','GREEN','BLACK'];
  if (!allowed.includes(passColor)) throw new HttpError(400, 'Invalid passColor');

  const worker = await prisma.user.findFirst({
    where: {
      id,
      subcontractorId: req.user.id,
      role: 'EMPLOYEE',
      status: { not: 'DELETED' },
    },
    select: { id: true, passColor: true, email: true },
  });

  if (!worker) throw new HttpError(404, 'Worker not found');

  const updated = await prisma.user.update({
    where: { id },
    data: { passColor: passColor as any },
    select: { id: true, fullName: true, email: true, passColor: true, status: true, isActive: true },
  });

  await logAudit({
    actorId: req.user.id,
    action: 'USER_PASSCOLOR_UPDATE',
    entity: 'User',
    entityId: id,
    before: { passColor: worker.passColor, email: worker.email },
    after: { passColor: updated.passColor, email: updated.email },
  });

  res.json({ user: updated });
}


export async function listShifts(req: any, res: any) {
  const start = req.query.start ? new Date(String(req.query.start)) : addDays(new Date(), -14);
  const end = req.query.end ? new Date(String(req.query.end)) : addDays(new Date(), 14);

  const shifts = await prisma.shift.findMany({
    where: {
      isDeleted: false,
      startAt: { lte: end },
      endAt: { gte: start },
      assignments: {
        some: {
          status: 'APPROVED',
          user: { subcontractorId: req.user.id },
        },
      },
    },
    include: {
      location: true,
      client: true,
      assignments: {
        where: { status: 'APPROVED' },
        include: { user: { select: { id: true, fullName: true, email: true } } },
      },
    },
    orderBy: { startAt: 'asc' },
  });

  res.json({ shifts });
}

export async function listReports(req: any, res: any) {
  const start = req.query.start ? new Date(String(req.query.start)) : addDays(new Date(), -30);
  const end = req.query.end ? new Date(String(req.query.end)) : addDays(new Date(), 30);

  const reports = await prisma.shiftReport.findMany({
    where: {
      shift: {
        isDeleted: false,
        startAt: { lte: end },
        endAt: { gte: start },
        assignments: {
          some: { status: 'APPROVED', user: { subcontractorId: req.user.id } },
        },
      },
    },
    include: {
      shift: { include: { location: true, client: true } },
      events: true,
      attachments: { select: { id: true, fileName: true, mimeType: true, sizeBytes: true, createdAt: true } },
    },
    orderBy: { updatedAt: 'desc' },
  });

  res.json({ reports });
}

export async function hours(req: any, res: any) {
  const start = req.query.start ? new Date(String(req.query.start)) : addDays(new Date(), -30);
  const end = req.query.end ? new Date(String(req.query.end)) : addDays(new Date(), 30);

  const employeeIds = await getEmployeeIdsForSubcontractor(req.user.id);
  if (employeeIds.length === 0) return res.json({ rows: [], totalMinutes: 0 });

  const entries = await prisma.timeEntry.findMany({
    where: {
      userId: { in: employeeIds },
      clockInAt: { lte: end },
      OR: [{ clockOutAt: { gte: start } }, { clockOutAt: null }],
    },
    include: { user: true, shift: { include: { location: true } } },
    orderBy: { clockInAt: 'asc' },
  });

  const clamp = (d: Date, min: Date, max: Date) => new Date(Math.min(max.getTime(), Math.max(min.getTime(), d.getTime())));
  const minutesBetween = (a: Date, b: Date) => Math.max(0, Math.round((b.getTime() - a.getTime()) / 60000));
  const now = new Date();

  const rows = entries.map((e: any) => {
    const rawEnd = e.clockOutAt ?? now;
    const effectiveStart = clamp(e.clockInAt, start, end);
    const effectiveEnd = clamp(rawEnd, start, end);
    const computedMinutesWorked = minutesBetween(effectiveStart, effectiveEnd);

    return {
      timeEntryId: e.id,
      userId: e.userId,
      userName: e.user.fullName,
      userEmail: e.user.email,
      shiftId: e.shiftId,
      shiftTitle: e.shift.title,
      locationName: e.shift.location.name,
      startAt: e.shift.startAt.toISOString(),
      endAt: e.shift.endAt.toISOString(),
      clockInAt: e.clockInAt.toISOString(),
      clockOutAt: e.clockOutAt ? e.clockOutAt.toISOString() : '',
      minutesWorked: (e.clockOutAt && e.minutesWorked > 0) ? e.minutesWorked : computedMinutesWorked,
    };
  });

  const totalMinutes = rows.reduce((acc: number, r: any) => acc + (Number(r.minutesWorked) || 0), 0);
  res.json({ rows, totalMinutes });
}

export async function weeklyExportPdf(req: any, res: any) {
  // Determine weekStart (Monday 00:00 UTC)
  const base = req.query.weekStart ? parseISODateOnly(String(req.query.weekStart)) : new Date();
  const weekStart = startOfIsoWeek(base);
  const weekEnd = addDays(weekStart, 7);

  // Quota: 1 per week
  const existing = await prisma.weeklyExportLog.findFirst({
    where: { subcontractorId: req.user.id, weekStart },
    select: { id: true, createdAt: true },
  });
  if (existing) {
    throw new HttpError(429, 'Deze week is de urenexport al gebruikt. Probeer het volgende week opnieuw.', 'EXPORT_QUOTA_REACHED');
  }

  const employeeIds = await getEmployeeIdsForSubcontractor(req.user.id);
  const entries = employeeIds.length
    ? await prisma.timeEntry.findMany({
        where: {
          userId: { in: employeeIds },
          clockInAt: { lte: weekEnd },
          OR: [{ clockOutAt: { gte: weekStart } }, { clockOutAt: null }],
        },
        include: { user: true, shift: { include: { location: true } } },
        orderBy: [{ userId: 'asc' }, { clockInAt: 'asc' }],
      })
    : [];

  // Create log entry BEFORE streaming (so retries don't double-generate). If PDF fails, still counts (quota).
  await prisma.weeklyExportLog.create({ data: { subcontractorId: req.user.id, weekStart } });
  await logAudit(req.user.id, "WEEKLY_EXPORT_CREATE", { userId: req.user.id, weekStart: weekStart.toISOString() });

  const sub = await prisma.user.findUnique({ where: { id: req.user.id }, select: { fullName: true, email: true } });

  res.setHeader('Content-Type', 'application/pdf');
  const weekIso = new Intl.DateTimeFormat('sv-SE', { timeZone: 'Europe/Amsterdam', year: 'numeric', month: '2-digit', day: '2-digit' }).format(weekStart);
  res.setHeader('Content-Disposition', `attachment; filename="urenexport_onderaannemer_week_${weekIso}.pdf"`);

  // A4 landscape makes the weekly export readable for finance/admin.
  const doc = new PDFDocument({ margin: 36, size: 'A4', layout: 'landscape', bufferPages: true });
  doc.pipe(res);

  const TZ = 'Europe/Amsterdam';
  const dateOnly = (d: Date) => new Intl.DateTimeFormat('nl-NL', { timeZone: TZ, year: 'numeric', month: '2-digit', day: '2-digit' }).format(d);
  const timeOnly = (d: Date) => new Intl.DateTimeFormat('nl-NL', { timeZone: TZ, hour: '2-digit', minute: '2-digit', hour12: false }).format(d);
  const fmt = (d: Date) => `${dateOnly(d)} ${timeOnly(d)}`;
  const section = (t: string) => {
    doc.moveDown(0.35);
    doc.fontSize(13).fillColor('black').text(t);
    const x1 = doc.page.margins.left;
    const x2 = doc.page.width - doc.page.margins.right;
    doc.moveTo(x1, doc.y + 2).lineTo(x2, doc.y + 2).strokeColor('#E5E7EB').stroke();
    doc.strokeColor('black');
    doc.moveDown(0.35);
  };

  doc.fontSize(18).text('Urenexport onderaannemer (week)', { align: 'left' });
  doc.moveDown(0.25);
  doc.fontSize(10).fillColor('gray').text(`Onderaannemer: ${sub?.fullName ?? '-'} (${sub?.email ?? '-'})`);
  doc.text(`Week: ${dateOnly(weekStart)} t/m ${dateOnly(addDays(weekEnd, -1))}`);
  doc.fillColor('black');
  doc.moveDown(0.5);

  if (!entries.length) {
    doc.fontSize(12).fillColor('gray').text('Geen uren geregistreerd in deze week.');
    const rangePages = doc.bufferedPageRange();
    const totalPages = rangePages.count;
    for (let i = 0; i < totalPages; i++) {
      doc.switchToPage(i);
      const y = doc.page.height - 28;
      const w = doc.page.width - doc.page.margins.left - doc.page.margins.right;
      const x = doc.page.margins.left;
      doc.fontSize(8).fillColor('gray').text(`Pagina ${i + 1} van ${totalPages}`, x, y, { align: 'right', width: w });
      doc.fillColor('black');
    }
    doc.end();
    return;
  }

  // Group by user
  const byUser = new Map<string, any[]>();
  for (const e of entries as any[]) {
    const list = byUser.get(e.userId) ?? [];
    list.push(e);
    byUser.set(e.userId, list);
  }

  const fmtOld = (iso: Date) => fmt(iso);
  const minutesBetween = (a: Date, b: Date) => Math.max(0, Math.round((b.getTime() - a.getTime()) / 60000));
  const clamp = (d: Date, min: Date, max: Date) => new Date(Math.min(max.getTime(), Math.max(min.getTime(), d.getTime())));
  const now = new Date();

  let grandTotalMin = 0;
  const perUserTotals: { fullName: string; email: string; minutes: number }[] = [];

  for (const [, list] of Array.from(byUser.entries()).sort((a, b) => a[0].localeCompare(b[0]))) {
    const first = list[0];
    doc.fontSize(14).text(first.user.fullName);
    doc.fontSize(10).fillColor('gray').text(first.user.email);
    doc.fillColor('black');
    doc.moveDown(0.25);

    // table header
    doc.fontSize(10).fillColor('gray').text('Dienst', { continued: true, width: 260 });
    doc.text('Locatie', { continued: true, width: 170 });
    doc.text('In', { continued: true, width: 95 });
    doc.text('Uit', { continued: true, width: 95 });
    doc.text('Uren', { align: 'right' });
    doc.fillColor('black');
    doc.moveDown(0.15);

    let totalMin = 0;
    for (const e of list) {
      const rawEnd = e.clockOutAt ? new Date(e.clockOutAt) : now;
      const effectiveStart = clamp(new Date(e.clockInAt), weekStart, weekEnd);
      const effectiveEnd = clamp(rawEnd, weekStart, weekEnd);
      const min = minutesBetween(effectiveStart, effectiveEnd);
      totalMin += min;

      const hours = Math.round((min / 60) * 100) / 100;
      const hoursNl = hours.toLocaleString('nl-NL', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

      // Wider columns + nicer formatting (landscape)
      doc.fontSize(9).text(String(e.shift.title).slice(0, 55), { continued: true, width: 260 });
      doc.text(String(e.shift.location.name).slice(0, 28), { continued: true, width: 170 });
      doc.text(fmtOld(effectiveStart), { continued: true, width: 95 });
      doc.text(e.clockOutAt ? fmtOld(effectiveEnd) : '-', { continued: true, width: 95 });
      doc.text(hoursNl, { align: 'right' });

      // subtle row separator
      const x1 = doc.page.margins.left;
      const x2 = doc.page.width - doc.page.margins.right;
      doc.moveTo(x1, doc.y + 2).lineTo(x2, doc.y + 2).strokeColor('#F3F4F6').stroke();
      doc.strokeColor('black');
    }

    grandTotalMin += totalMin;
    perUserTotals.push({ fullName: first.user.fullName, email: first.user.email, minutes: totalMin });
    doc.moveDown(0.25);
    doc.fontSize(11).text(`Totaal: ${(Math.round((totalMin / 60) * 100) / 100).toLocaleString('nl-NL', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} uur`);
    doc.moveDown();

    // Page break if near bottom
    if (doc.y > 520) doc.addPage();
  }

  // Summary page
  doc.addPage();
  doc.fontSize(16).text('Samenvatting', { align: 'left' });
  doc.moveDown(0.25);
  doc.fontSize(10).fillColor('gray').text(`Week: ${dateOnly(weekStart)} t/m ${dateOnly(addDays(weekEnd, -1))}`);
  doc.fillColor('black');
  doc.moveDown(0.5);

  perUserTotals.sort((a, b) => b.minutes - a.minutes);
  for (const u of perUserTotals) {
    doc.fontSize(11).text(`• ${u.fullName} (${u.email}) — ${(Math.round((u.minutes / 60) * 100) / 100).toLocaleString('nl-NL', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} uur`);
  }
  doc.moveDown(0.5);
  doc.fontSize(13).text(`Totaal alle werknemers: ${(Math.round((grandTotalMin / 60) * 100) / 100).toLocaleString('nl-NL', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} uur`);

  // Page footers with total page count
  const rangePages = doc.bufferedPageRange();
  const totalPages = rangePages.count;
  for (let i = 0; i < totalPages; i++) {
    doc.switchToPage(i);
    const y = doc.page.height - 28;
    const w = doc.page.width - doc.page.margins.left - doc.page.margins.right;
    const x = doc.page.margins.left;
    doc.fontSize(8).fillColor('gray').text(`Pagina ${i + 1} van ${totalPages}`, x, y, { align: 'right', width: w });
    doc.fillColor('black');
  }
  doc.end();
}
