import * as Reports from '../services/reportsService.js';
import { HttpError } from '../utils/http.js';
import { parseDateParam } from './reports.helpers.js';
import { reportSchema } from './reports.schemas.js';
import PDFDocument from 'pdfkit';
import { prisma } from '../db/prisma.js';

export async function hours(req: any, res: any) {
  const { start, end, userId: requestedUserId, clientId, subcontractorId, page, pageSize, rounding } = reportSchema.parse(req.query);

  const normalizedRequestedUserId = (requestedUserId && requestedUserId !== 'undefined' && requestedUserId !== 'all') ? requestedUserId : undefined;

  // Security: employees may only see their own hours
  const isAdmin = req.user?.role === 'ADMIN';
  const userId = isAdmin ? normalizedRequestedUserId : req.user.id;

  const startDate = parseDateParam(start);
  const endDate = parseDateParam(end, { endOfDay: true });

  // Consistent, human-friendly export filenames (used across CSV/XLSX/PDF)
  const TZ_EXPORT = 'Europe/Amsterdam';
  const fmtIsoDateExport = (d: Date) => new Intl.DateTimeFormat('sv-SE', { timeZone: TZ_EXPORT, year: 'numeric', month: '2-digit', day: '2-digit' }).format(d);
  const exportRange = `${fmtIsoDateExport(startDate)}_${fmtIsoDateExport(endDate)}`;
  const exportScopeBits: string[] = [];
  if (clientId && clientId !== 'undefined') exportScopeBits.push('klant');
  if (subcontractorId && subcontractorId !== 'undefined') exportScopeBits.push('onderaannemer');
  if (userId) exportScopeBits.push('medewerker');
  const exportScope = exportScopeBits.length ? `_${exportScopeBits.join('-')}` : '';
  const exportNameBase = `urenexport_${exportRange}${exportScope}`;

  // UI needs rates, but exports should keep rows compact.
  const report = await Reports.hoursReport(
    {
      start: startDate,
      end: endDate,
      userId,
      clientId: clientId && clientId !== 'undefined' ? clientId : undefined,
      subcontractorId: subcontractorId && subcontractorId !== 'undefined' ? subcontractorId : undefined,
      rounding: rounding ?? 'none',
      page: Number.isFinite(page as any) ? page : undefined,
      pageSize: Number.isFinite(pageSize as any) ? pageSize : undefined,
    },
    { includeRates: true },
  );

  // Server-side RBAC for rates:
  // - EMPLOYEE / SUBCONTRACTOR: may only see worker rates
  // - CLIENT: may only see employer (bill) rates
  // - ADMIN: may see both
  const role = String(req.user?.role ?? '');
  const canSeePay = role === 'ADMIN' || role === 'EMPLOYEE' || role === 'SUBCONTRACTOR';
  const canSeeBill = role === 'ADMIN' || role === 'CLIENT';

  const rows = Array.isArray((report as any).rows) ? (report as any).rows : [];
  (report as any).rows = rows.map((r: any) => {
    const out: any = { ...r };
    if (!canSeePay) {
      delete out.workerRateCents;
      delete out.workerAmountCents;
    }
    if (!canSeeBill) {
      delete out.employerRateCents;
      delete out.employerAmountCents;
    }
    return out;
  });

  // Also filter KPI fields server-side (never rely on UI-only hiding)
  const kpis = (report as any).kpis;
  if (kpis && typeof kpis === 'object') {
    if (!canSeePay) {
      delete (kpis as any).totalWorkerAmountCents;
      delete (kpis as any).avgWorkerRateCents;
    }
    if (!canSeeBill) {
      delete (kpis as any).totalEmployerAmountCents;
      delete (kpis as any).avgEmployerRateCents;
    }
  }

  (report as any).allowedRateViews = { pay: canSeePay, bill: canSeeBill };
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('Pragma', 'no-cache');
  res.json(report);
}

export async function exportHours(req: any, res: any) {
  if (req.user.role !== 'ADMIN') throw new HttpError(403, 'Forbidden');

  const { start, end, userId, clientId, subcontractorId, format, mode, rounding, includeRates } = reportSchema.parse(req.query);

  const startDate = parseDateParam(start);
  const endDate = parseDateParam(end, { endOfDay: true });

  // Consistent, human-friendly export filenames (used across CSV/XLSX/PDF)
  // Allow override via env for deployments, default to NL time.
  const TZ_EXPORT = process.env.TZ_EXPORT ?? 'Europe/Amsterdam';
  const fmtIsoDateExport = (d: Date) => new Intl.DateTimeFormat('sv-SE', { timeZone: TZ_EXPORT, year: 'numeric', month: '2-digit', day: '2-digit' }).format(d);
  const exportRange = `${fmtIsoDateExport(startDate)}_${fmtIsoDateExport(endDate)}`;
  const exportScopeBits: string[] = [];
  if (clientId && clientId !== 'undefined') exportScopeBits.push('klant');
  if (subcontractorId && subcontractorId !== 'undefined') exportScopeBits.push('onderaannemer');
  if (userId && userId !== 'undefined' && userId !== 'all') exportScopeBits.push('medewerker');
  const exportScope = exportScopeBits.length ? `_${exportScopeBits.join('-')}` : '';
  const exportNameBase = `urenexport_${exportRange}${exportScope}${mode ? `_${mode}` : ''}`;

  const roundingMode = rounding ?? 'none';
  const exportMode = mode ?? 'entries';

  const wantsRates = (() => {
    const v = String(includeRates ?? '').toLowerCase();
    if (v === '1' || v === 'true') return true;
    if (v === '0' || v === 'false') return false;
    // default: exports should be finance-friendly
    return true;
  })();

  // PDF export (entries mode).
  if ((format ?? 'csv') === 'pdf') {
    if (exportMode !== 'entries') {
      throw new HttpError(400, 'PDF export ondersteunt momenteel alleen mode=entries');
    }

    // For PDF, include rates to make the document useful for finance checks.
    const report = await Reports.hoursReport(
      {
        start: startDate,
        end: endDate,
        userId,
        clientId: clientId && clientId !== 'undefined' ? clientId : undefined,
        subcontractorId: subcontractorId && subcontractorId !== 'undefined' ? subcontractorId : undefined,
      },
      { includeRates: true },
    );

    const TZ = TZ_EXPORT;
    const fmtDate = (d: Date) => new Intl.DateTimeFormat('nl-NL', { timeZone: TZ, year: 'numeric', month: '2-digit', day: '2-digit' }).format(d);
    const fmtTime = (d: Date) => new Intl.DateTimeFormat('nl-NL', { timeZone: TZ, hour: '2-digit', minute: '2-digit', hour12: false }).format(d);

    const filename = `${exportNameBase}.pdf`;

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);

    // A4 landscape improves readability. Buffer pages so we can add "Pagina X van Y".
    const doc = new PDFDocument({ margin: 36, size: 'A4', layout: 'landscape', bufferPages: true });
    doc.pipe(res);
    const safeDate = (iso: string) => {
      try { return new Date(iso); } catch { return null; }
    };

    doc.fontSize(18).text('Urenexport', { align: 'left' });
    doc.moveDown(0.25);
    doc.fontSize(11).fillColor('gray').text(`Periode: ${fmtDate(startDate)} t/m ${fmtDate(endDate)}`);
    doc.fontSize(9).fillColor('gray').text(
      `Gegenereerd: ${new Intl.DateTimeFormat('nl-NL', { timeZone: TZ, dateStyle: 'medium', timeStyle: 'short' }).format(new Date())}`,
    );
    doc.fillColor('black');
    doc.moveDown(0.5);

    // Filters (friendly labels)
    const filters: string[] = [];
    try {
      if (clientId) {
        const c = await prisma.client.findUnique({ where: { id: clientId }, select: { name: true } });
        filters.push(`Klant: ${c?.name ?? clientId}`);
      }
      if (subcontractorId) {
        const s = await prisma.user.findUnique({ where: { id: subcontractorId }, select: { fullName: true, email: true } });
        filters.push(`Onderaannemer: ${s?.fullName ?? s?.email ?? subcontractorId}`);
      }
      if (userId) {
        const u = await prisma.user.findUnique({ where: { id: userId }, select: { fullName: true, email: true } });
        filters.push(`Medewerker: ${u?.fullName ?? u?.email ?? userId}`);
      }
    } catch {
      // best-effort
      if (clientId) filters.push(`Klant: ${clientId}`);
      if (subcontractorId) filters.push(`Onderaannemer: ${subcontractorId}`);
      if (userId) filters.push(`Medewerker: ${userId}`);
    }
    if (filters.length) {
      doc.fontSize(10).fillColor('gray').text(filters.join('  •  '));
      doc.fillColor('black');
      doc.moveDown(0.5);
    }

    const rows = (report.rows ?? []) as any[];
    if (rows.length === 0) {
      doc.fontSize(12).fillColor('gray').text('Geen uren gevonden.');
      doc.end();
      return;
    }

    const totalMinutesRows = rows.reduce((sum, r) => sum + Number(r.minutesWorked || 0), 0);

    const minutesToHours = (m: number) => Math.round(((Number(m) || 0) / 60) * 100) / 100;
    const hoursStr = (h: number) => (Number(h) || 0).toLocaleString('nl-NL', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    const eur = (cents: number) => (Number(cents || 0) / 100).toLocaleString('nl-NL', { style: 'currency', currency: 'EUR' });

    const sectionTitle = (t: string) => {
      doc.moveDown(0.25);
      doc.fontSize(12).fillColor('black').text(t);
      // underline across printable width
      const x1 = doc.page.margins.left;
      const x2 = doc.page.width - doc.page.margins.right;
      doc.moveTo(x1, doc.y + 2).lineTo(x2, doc.y + 2).strokeColor('#E5E7EB').stroke();
      doc.strokeColor('black');
      doc.moveDown(0.35);
    };

    // KPI block (top)
    const kpis = (report as any).kpis;
    if (kpis) {
      sectionTitle('KPI overzicht');
      doc.fontSize(10);
      doc.text(`Totale uren: ${minutesToHours(totalMinutesRows)} uur`);
      if (typeof kpis.totalWorkerAmountCents === 'number') doc.text(`Totaal uitbetaling: ${eur(kpis.totalWorkerAmountCents)}`);
      if (typeof kpis.totalEmployerAmountCents === 'number') doc.text(`Totaal facturatie: ${eur(kpis.totalEmployerAmountCents)}`);
      if (typeof kpis.avgWorkerRateCents === 'number') doc.text(`Gem. uitbetaling tarief: ${eur(kpis.avgWorkerRateCents)}`);
      if (typeof kpis.avgEmployerRateCents === 'number') doc.text(`Gem. facturatie tarief: ${eur(kpis.avgEmployerRateCents)}`);
      if (typeof (report as any).totalExtraCostsCents === 'number') {
        doc.text(`Totaal extra kosten (per dienst): ${eur(Number((report as any).totalExtraCostsCents || 0))}`);
      }
      doc.moveDown(0.25);
    }

    sectionTitle('Registraties');

    // Table layout (readable, finance-friendly)
    const pageX = doc.page.margins.left;
    const pageW = doc.page.width - doc.page.margins.left - doc.page.margins.right;

    const table = {
      x: pageX,
      y: doc.y,
      w: pageW,
      rowH: 18,
      headerH: 20,
      cols: [
        // Keep total width within A4 landscape printable width (~770pt with 36pt margins)
        { key: 'date', label: 'Datum', w: 60 },
        { key: 'who', label: 'Medewerker', w: 115 },
        { key: 'loc', label: 'Locatie', w: 95 },
        { key: 'shift', label: 'Dienst', w: 180 },
        { key: 'start', label: 'Start', w: 45 },
        { key: 'end', label: 'Eind', w: 45 },
        { key: 'hours', label: 'Uren', w: 45 },
        { key: 'pay', label: 'Uitbetaling', w: 70 },
        { key: 'bill', label: 'Facturatie', w: 70 },
        { key: 'extra', label: 'Extra', w: 45 },
      ] as Array<{ key: string; label: string; w: number }>,
    };

    const drawHeader = () => {
      // header background
      doc.save();
      doc.rect(table.x, table.y, table.w, table.headerH).fill('#F3F4F6');
      doc.restore();

      doc.fontSize(9).fillColor('#111827');
      let cx = table.x;
      for (const c of table.cols) {
        doc.text(c.label, cx + 4, table.y + 6, { width: c.w - 8, ellipsis: true });
        cx += c.w;
      }
      // header line
      doc.moveTo(table.x, table.y + table.headerH).lineTo(table.x + table.w, table.y + table.headerH).strokeColor('#E5E7EB').stroke();
      doc.strokeColor('black');
      doc.fillColor('black');
      table.y += table.headerH;
    };

    const cell = (text: string, x: number, y: number, w: number, h: number, opts?: any) => {
      doc.text(text ?? '', x + 4, y + 4, { width: w - 8, height: h - 8, ellipsis: true, ...opts });
    };

    const ensureSpace = (rowH: number) => {
      const bottom = doc.page.height - 52;
      if (table.y + rowH > bottom) {
        doc.addPage();
        table.y = doc.page.margins.top;
        drawHeader();
      }
    };

    // Draw table
    drawHeader();

    let totalMin = 0;
    rows.forEach((r: any, idx: number) => {
      totalMin += Number(r.minutesWorked || 0);

      const wrapKeys = new Set(['who', 'loc', 'shift']);

      const d = (() => {
        const dt = safeDate(r.clockInAt);
        return dt ? fmtDate(dt) : '—';
      })();
      const userName = String(r.userName ?? '').trim() || '—';
      const shiftTitle = String(r.shiftTitle ?? '').trim() || '—';
      const location = String(r.locationName ?? r.location ?? '').trim() || '—';
      const startT = (() => {
        const dt = safeDate(r.clockInAt);
        return dt ? fmtTime(dt) : '—';
      })();
      const endT = r.clockOutAt
        ? (() => {
            const dt = safeDate(r.clockOutAt);
            return dt ? fmtTime(dt) : '—';
          })()
        : '—';

      const hours = minutesToHours(r.minutesWorked || 0);
      const workerAmount = r.workerAmountCents != null ? eur(Number(r.workerAmountCents || 0)) : '—';
      const employerAmount = r.employerAmountCents != null ? eur(Number(r.employerAmountCents || 0)) : '—';
      const extra = eur(Number(r.shiftExtraCostsCents || 0));

      // Dynamic row height: wrap long names/titles instead of truncating with "..."
      let rowH = table.rowH;
      try {
        const wrapVals: Record<string, string> = {
          who: userName,
          loc: location,
          shift: shiftTitle,
        };
        for (const c of table.cols) {
          if (!wrapKeys.has(c.key)) continue;
          const v = String(wrapVals[c.key] ?? '—');
          const h = doc.heightOfString(v, { width: c.w - 8, align: 'left' }) + 8;
          rowH = Math.max(rowH, Math.ceil(h));
        }
      } catch {
        // best-effort
      }
      // Cap to keep PDF compact (max ~3 lines)
      rowH = Math.min(rowH, 54);

      ensureSpace(rowH);

      // zebra
      if (idx % 2 === 1) {
        doc.save();
        doc.rect(table.x, table.y, table.w, rowH).fill('#FAFAFA');
        doc.restore();
      }

      doc.fontSize(9).fillColor('#111827');
      let cx = table.x;
      const vals: Record<string, string> = {
        date: d,
        who: userName,
        loc: location,
        shift: shiftTitle,
        start: startT,
        end: endT,
        hours: hoursStr(hours),
        pay: workerAmount,
        bill: employerAmount,
        extra,
      };
      for (const c of table.cols) {
        const isMoney = c.key === 'pay' || c.key === 'bill' || c.key === 'extra';
        const shouldWrap = wrapKeys.has(c.key);
        cell(
          vals[c.key],
          cx,
          table.y,
          c.w,
          rowH,
          isMoney ? { align: 'right' } : shouldWrap ? { ellipsis: false } : undefined,
        );
        cx += c.w;
      }

      // row line
      doc.moveTo(table.x, table.y + rowH).lineTo(table.x + table.w, table.y + rowH).strokeColor('#F3F4F6').stroke();
      doc.strokeColor('black');
      table.y += rowH;
    });

    doc.moveDown(0.35);

    
    // --- Extra page: summaries + subtotals (per medewerker/klant + per locatie) ---
    doc.addPage();

    doc.fontSize(16).fillColor('black').text('Samenvatting', { align: 'left' });
    doc.moveDown(0.35);
    doc.fontSize(10).fillColor('gray').text('Overzicht per medewerker/klant en subtotals per medewerker en per locatie.');
    doc.fillColor('black');
    doc.moveDown(0.6);

    type Agg = { minutes: number; worker: number; employer: number; extra: number };
    const addAgg = (m: Map<string, Agg>, key: string, delta: Agg) => {
      const cur = m.get(key) ?? { minutes: 0, worker: 0, employer: 0, extra: 0 };
      m.set(key, {
        minutes: cur.minutes + (delta.minutes || 0),
        worker: cur.worker + (delta.worker || 0),
        employer: cur.employer + (delta.employer || 0),
        extra: cur.extra + (delta.extra || 0),
      });
    };

    const byUserClient = new Map<string, Agg>();
    const byUser = new Map<string, Agg>();
    const byClient = new Map<string, Agg>();
    const byLocation = new Map<string, Agg>();

    rows.forEach((r: any) => {
      const userName = String(r.userName ?? r.userFullName ?? r.userEmail ?? r.userId ?? 'Onbekend').trim() || 'Onbekend';
      const clientName = String(r.clientName ?? r.client ?? '').trim() || '—';
      const location = String(r.locationName ?? r.location ?? '').trim() || '—';
      const minutes = Number(r.minutesWorked || 0);
      const worker = Number(r.workerAmountCents || 0);
      const employer = Number(r.employerAmountCents || 0);
      const extra = Number(r.shiftExtraCostsCents || 0);

      addAgg(byUserClient, `${userName}|||${clientName}`, { minutes, worker, employer, extra });
      addAgg(byUser, userName, { minutes, worker, employer, extra });
      addAgg(byClient, clientName, { minutes, worker, employer, extra });
      addAgg(byLocation, location, { minutes, worker, employer, extra });
    });

    const renderTable = (
      title: string,
      cols: Array<{ key: string; label: string; w: number; align?: 'left' | 'right' }>,
      data: Array<Record<string, any>>,
      opts?: { maxRows?: number },
    ) => {
      sectionTitle(title);

      const startX = doc.page.margins.left;
      const tableW = cols.reduce((a, c) => a + c.w, 0);
      let y = doc.y;

      // header bg
      doc.rect(startX, y, tableW, 22).fill('#F3F4F6');
      doc.fillColor('#111827').fontSize(9);
      let cx = startX;
      for (const c of cols) {
        doc.text(c.label, cx + 4, y + 6, { width: c.w - 8, ellipsis: true, align: c.align ?? 'left' });
        cx += c.w;
      }
      doc.fillColor('black');
      y += 22;

      const rowH = 18;
      const bottom = doc.page.height - 52;
      const maxRows = opts?.maxRows ?? 9999;

      const safeAddPageIfNeeded = () => {
        if (y + rowH > bottom) {
          doc.addPage();
          y = doc.page.margins.top;
        }
      };

      const slice = data.slice(0, maxRows);
      for (const row of slice) {
        safeAddPageIfNeeded();
        cx = startX;
        doc.fontSize(9).fillColor('#111827');
        for (const c of cols) {
          const val = row[c.key] ?? '';
          doc.text(String(val), cx + 4, y + 4, { width: c.w - 8, ellipsis: true, align: c.align ?? 'left' });
          cx += c.w;
        }
        doc.moveTo(startX, y + rowH).lineTo(startX + tableW, y + rowH).strokeColor('#F3F4F6').stroke();
        doc.strokeColor('black');
        y += rowH;
      }

      doc.moveDown(0.6);
      // ensure doc.y tracks our local y
      doc.y = y;
    };

    const minutesToHoursStr = (m: number) => hoursStr(Math.round(((Number(m) || 0) / 60) * 100) / 100);

    // 1) Samenvatting per medewerker/klant
    const userClientRows = Array.from(byUserClient.entries())
      .map(([k, a]) => {
        const [user, client] = k.split('|||');
        return {
          medewerker: user,
          klant: client,
          uren: minutesToHoursStr(a.minutes),
          uitbetaling: eur(a.worker),
          facturatie: eur(a.employer),
        };
      })
      .sort((a, b) => Number(b.uren) - Number(a.uren));

    renderTable(
      'Samenvatting per medewerker/klant',
      [
        { key: 'medewerker', label: 'Medewerker', w: 220 },
        { key: 'klant', label: 'Klant', w: 220 },
        { key: 'uren', label: 'Uren', w: 70, align: 'right' },
        { key: 'uitbetaling', label: 'Uitbetaling', w: 120, align: 'right' },
        { key: 'facturatie', label: 'Facturatie', w: 120, align: 'right' },
      ],
      userClientRows,
      { maxRows: 60 },
    );

    // 2) Subtotaal per medewerker
    const userRows = Array.from(byUser.entries())
      .map(([user, a]) => ({
        medewerker: user,
        uren: minutesToHoursStr(a.minutes),
        uitbetaling: eur(a.worker),
        facturatie: eur(a.employer),
      }))
      .sort((a, b) => Number(b.uren) - Number(a.uren));

    renderTable(
      'Subtotaal per medewerker',
      [
        { key: 'medewerker', label: 'Medewerker', w: 300 },
        { key: 'uren', label: 'Uren', w: 80, align: 'right' },
        { key: 'uitbetaling', label: 'Uitbetaling', w: 140, align: 'right' },
        { key: 'facturatie', label: 'Facturatie', w: 140, align: 'right' },
      ],
      userRows,
      { maxRows: 80 },
    );

    // 3) Subtotaal per locatie
    const locRows = Array.from(byLocation.entries())
      .map(([loc, a]) => ({
        locatie: loc,
        uren: minutesToHoursStr(a.minutes),
        uitbetaling: eur(a.worker),
        facturatie: eur(a.employer),
      }))
      .sort((a, b) => Number(b.uren) - Number(a.uren));

    renderTable(
      'Subtotaal per locatie',
      [
        { key: 'locatie', label: 'Locatie', w: 300 },
        { key: 'uren', label: 'Uren', w: 80, align: 'right' },
        { key: 'uitbetaling', label: 'Uitbetaling', w: 140, align: 'right' },
        { key: 'facturatie', label: 'Facturatie', w: 140, align: 'right' },
      ],
      locRows,
      { maxRows: 80 },
    );

    sectionTitle('Totalen');
    doc.fontSize(12).text(`Totaal uren: ${hoursStr(minutesToHours(totalMin))} uur`);
    if (typeof (report as any).totalExtraCostsCents === 'number') {
      doc.text(`Totaal extra kosten (per dienst): ${eur(Number((report as any).totalExtraCostsCents || 0))}`);
    }

    // Footers with total page count (prevents orphan footer pages)
    const rangePages = doc.bufferedPageRange();
    const totalPages = rangePages.count;
    for (let i = 0; i < totalPages; i++) {
      doc.switchToPage(i);
      const y = doc.page.height - 28;
      const w = doc.page.width - doc.page.margins.left - doc.page.margins.right;
      const x = doc.page.margins.left;
      doc.fontSize(8).fillColor('gray').text(`Pagina ${i + 1} van ${totalPages}`, x, y, { align: 'right', width: w });
      doc.fillColor('black');
    }
    doc.end();
    return;
  }

  // Non-PDF exports: include rates by default for admin exports (makes the files actually usable).
  const report = await Reports.hoursReport(
    {
      start: startDate,
      end: endDate,
      userId,
      clientId: clientId && clientId !== 'undefined' ? clientId : undefined,
      subcontractorId: subcontractorId && subcontractorId !== 'undefined' ? subcontractorId : undefined,
    },
    { includeRates: wantsRates },
  );

  // Human-friendly export columns (keep machine-friendly cents columns too)
  const eur = (cents: number) => (Number(cents || 0) / 100).toLocaleString('nl-NL', { style: 'currency', currency: 'EUR' });
  const exportRows = (report.rows ?? []).map((r: any) => ({
    ...r,
    workerRateEurPerHour: (r.workerRateCents != null) ? eur(Number(r.workerRateCents || 0)) : '',
    employerRateEurPerHour: (r.employerRateCents != null) ? eur(Number(r.employerRateCents || 0)) : '',
    workerAmountEur: (r.workerAmountCents != null) ? eur(Number(r.workerAmountCents || 0)) : '',
    employerAmountEur: (r.employerAmountCents != null) ? eur(Number(r.employerAmountCents || 0)) : '',
    shiftExtraCostsEur: eur(Number(r.shiftExtraCostsCents || 0)),
  }));

  if ((format ?? 'csv') === 'xlsx') {
    const buf = await Reports.toXlsxBuffer(exportRows, { mode: exportMode, rounding: roundingMode });
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    const ext = 'xlsx';
    const modeSuffix = exportMode === 'entries' ? '' : `_${exportMode}`;
    res.setHeader('Content-Disposition', `attachment; filename="${exportNameBase}${modeSuffix}.${ext}"`);
    res.send(Buffer.from(buf));
    return;
  }

  // Use exportRows for all non-PDF exports so the EUR helper columns are present everywhere.
  const csv = exportMode === 'payroll'
    ? Reports.toPayrollCsv(exportRows as any, { rounding: roundingMode })
    : exportMode === 'summary'
      ? Reports.toSummaryCsv(exportRows as any, { rounding: roundingMode })
      : Reports.toCsv(exportRows, { delimiter: ';', includeBom: true });
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  {
    const ext = 'csv';
    const modeSuffix = exportMode === 'entries' ? '' : `_${exportMode}`;
    res.setHeader('Content-Disposition', `attachment; filename="${exportNameBase}${modeSuffix}.${ext}"`);
  }
  res.send(csv);
}
