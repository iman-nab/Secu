import * as Clients from '../services/clientsService.js';
import { logAudit } from '../services/auditService.js';
import { HttpError } from '../utils/http.js';
import * as Invites from '../services/inviteService.js';
import { prisma } from '../db/prisma.js';
import { sendClientInviteEmail } from '../services/mailerService.js';
import { buildInviteLink } from './clients.helpers.js';
import { createPortalUserSchema, createSchema, onboardSchema, updateSchema } from './clients.schemas.js';


export async function list(req: any, res: any) {
  if (req.user?.role !== 'ADMIN') throw new HttpError(403, 'Forbidden');
  const includeDeleted = String(req.query?.includeDeleted ?? '').toLowerCase();
  const withDeleted = includeDeleted === '1' || includeDeleted === 'true' || includeDeleted === 'yes';

  const pageRaw = req.query?.page;
  const pageSizeRaw = req.query?.pageSize;
  const q = typeof req.query?.q === 'string' ? req.query.q : undefined;
  const page = pageRaw ? Number(pageRaw) : undefined;
  const pageSize = pageSizeRaw ? Number(pageSizeRaw) : undefined;
  const wantsPaged = Number.isFinite(page as any) || Number.isFinite(pageSize as any) || !!q;

  if (wantsPaged) {
    const result = await Clients.listClientsPaged({
      includeDeleted: withDeleted,
      page: Number.isFinite(page as any) ? (page as number) : 1,
      pageSize: Number.isFinite(pageSize as any) ? (pageSize as number) : 25,
      q,
    });
    res.json({ data: result.items, totalCount: result.totalCount, page: Number(page ?? 1), pageSize: Number(pageSize ?? 25) });
    return;
  }

  const data = await Clients.listClients({ includeDeleted: withDeleted });
  res.json({ data });
}

export async function create(req: any, res: any) {
  if (req.user?.role !== 'ADMIN') throw new HttpError(403, 'Forbidden');
  const body = createSchema.parse(req.body);
  const created = await Clients.createClient(body);
  await logAudit(req.user.id, 'CLIENT_CREATE', { clientId: created.id, name: created.name });
  res.status(201).json(created);
}

export async function onboard(req: any, res: any) {
  if (req.user?.role !== 'ADMIN') throw new HttpError(403, 'Forbidden');

  const body = onboardSchema.parse(req.body);
  const createdClient = await Clients.createClient({
    name: body.name,
    contactName: body.contactName,
    contactEmail: body.contactEmail,
  });

  let portalUser: any = null;
  let invite: { token: string; expiresAt: Date } | null = null;

  if (body.createPortalUser) {
    const email = (body.portalEmail || body.contactEmail || '').trim();
    const fullName = (body.portalFullName || body.contactName || 'Opdrachtgever').trim();
    if (!email) throw new HttpError(400, 'portalEmail is required when createPortalUser=true');

    const createdInvite = await Invites.createInvite(
      { id: req.user.id, role: 'ADMIN' },
      {
        email,
        fullName,
        role: 'CLIENT',
        clientId: createdClient.id,
      },
    );

    const inviteLink = buildInviteLink(req, createdInvite.token);
    await sendClientInviteEmail({
      to: email,
      inviteLink,
      clientName: createdClient.name,
      expiresAt: createdInvite.expiresAt,
    });

    invite = { token: createdInvite.token, expiresAt: createdInvite.expiresAt };
    // Portal user will be created/updated when the invite is consumed.
    portalUser = null;

  }

  await logAudit(req.user.id, 'CLIENT_ONBOARD', {
    clientId: createdClient.id,
    createdPortalUser: Boolean(portalUser),
    portalUserId: portalUser?.id,
  });

  res.status(201).json({
    client: createdClient,
    portalUser,
    inviteToken: invite?.token ?? null,
    inviteExpiresAt: invite?.expiresAt ?? null,
    inviteLink: invite ? buildInviteLink(req, invite.token) : null,
  });
}

export async function update(req: any, res: any) {
  if (req.user?.role !== 'ADMIN') throw new HttpError(403, 'Forbidden');
  const body = updateSchema.parse(req.body);
  const updated = await Clients.updateClient(req.params.id, body);
  await logAudit(req.user.id, 'CLIENT_UPDATE', { clientId: updated.id });
  res.json(updated);
}

export async function remove(req: any, res: any) {
  if (req.user?.role !== 'ADMIN') throw new HttpError(403, 'Forbidden');
  const deleted = await Clients.softDeleteClient(req.params.id);
  await logAudit(req.user.id, 'CLIENT_DELETE', { clientId: deleted.id });
  res.status(204).send();
}

export async function createPortalUser(req: any, res: any) {
  if (req.user?.role !== 'ADMIN') throw new HttpError(403, 'Forbidden');

  const clientId = req.params.id;
  const body = createPortalUserSchema.parse(req.body ?? {});

  const client = await prisma.client.findFirst({
    where: { id: clientId, isDeleted: false },
    select: { id: true, name: true, contactName: true, contactEmail: true },
  });
  if (!client) throw new HttpError(404, 'Opdrachtgever not found');

  // Create an invite for the opdrachtgever portal user.
  // If a portal user already exists (active or inactive), the invite will function as a
  // secure admin-driven password reset / (re)activation.

  const portalUser = await prisma.user.findFirst({
    where: { clientId, role: 'CLIENT' },
    orderBy: { createdAt: 'desc' },
    select: { id: true, email: true, fullName: true, role: true, clientId: true, isActive: true, status: true, createdAt: true },
  });

  const email = (body.portalEmail || portalUser?.email || client.contactEmail || '').toLowerCase();
  const fullName = (body.portalFullName || portalUser?.fullName || client.contactName || client.name || 'Opdrachtgever').trim();
  if (!email) throw new HttpError(400, 'Geen portal email beschikbaar (vul contactEmail of portalEmail in).');

  const invite = await Invites.createInvite(
    { id: req.user.id, role: 'ADMIN' },
    { email, fullName, role: 'CLIENT', clientId: client.id },
  );

  await sendClientInviteEmail({
    to: email,
    inviteLink: buildInviteLink(req, invite.token),
    clientName: client.name,
    expiresAt: invite.expiresAt,
  });

  await logAudit(req.user.id, 'CLIENT_PORTAL_INVITE_CREATE', { clientId: client.id, userId: portalUser?.id ?? null });

  res.status(201).json({
    client,
    portalUser,
    inviteToken: invite.token,
    inviteExpiresAt: invite.expiresAt,
    inviteLink: buildInviteLink(req, invite.token),
  });
}

export async function regenerateInvite(req: any, res: any) {
  if (req.user?.role !== 'ADMIN') throw new HttpError(403, 'Forbidden');

  const clientId = req.params.id;

  const client = await prisma.client.findFirst({
    where: { id: clientId, isDeleted: false },
    select: { id: true, name: true, contactName: true, contactEmail: true },
  });
  if (!client) throw new HttpError(404, 'Opdrachtgever not found');
  // Create a new invite. If a portal user exists already, this acts as an admin-driven password reset.
  const portalUser = await prisma.user.findFirst({
    where: { clientId, role: 'CLIENT' },
    orderBy: { createdAt: 'desc' },
    select: { id: true, email: true, fullName: true, role: true, clientId: true, isActive: true, status: true, createdAt: true },
  });

  const email = (portalUser?.email || client.contactEmail || '').toLowerCase();
  const fullName = (portalUser?.fullName || client.contactName || client.name || 'Opdrachtgever').trim();
  if (!email) throw new HttpError(400, 'Geen portal email beschikbaar (vul contactEmail in).');

  const invite = await Invites.createInvite(
    { id: req.user.id, role: 'ADMIN' },
    { email, fullName, role: 'CLIENT', clientId: client.id },
  );

  await logAudit(req.user.id, 'CLIENT_PORTAL_INVITE_REGENERATE', { clientId, userId: portalUser?.id ?? null });

  await sendClientInviteEmail({
    to: email,
    inviteLink: buildInviteLink(req, invite.token),
    clientName: client.name,
    expiresAt: invite.expiresAt,
  });

  res.json({
    client,
    portalUser,
    inviteToken: invite.token,
    inviteExpiresAt: invite.expiresAt,
    inviteLink: buildInviteLink(req, invite.token),
  });
}
