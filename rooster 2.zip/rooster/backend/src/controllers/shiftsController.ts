import { z } from 'zod';
import {
  assignSchema,
  bulkWeekSchema,
  clockSchema,
  createShiftSchema,
  dateRangeSchema,
  pinNoteSchema,
  requestSchema,
  repeatShiftSchema,
  reviewSchema,
  updateShiftSchema,
} from './shifts.schemas.js';
import * as Shifts from '../services/shiftsService.js';
import * as Time from '../services/timeEntriesService.js';
import { logAudit } from '../services/auditService.js';
import { HttpError } from '../utils/http.js';
import { prisma } from '../db/prisma.js';
import { createAdminNotification, createUserNotification } from '../services/notificationsService.js';
import { emitShiftEvent } from '../utils/realtime.js';
import { parseDateParam } from './shifts.helpers.js';

export async function list(req: any, res: any) {
  const { start, end } = dateRangeSchema.parse(req.query);
  const range = start && end ? { start: parseDateParam(start), end: parseDateParam(end, { endOfDay: true }) } : undefined;

  const clientId = typeof req.query?.clientId === 'string' ? req.query.clientId : undefined;
  const locationId = typeof req.query?.locationId === 'string' ? req.query.locationId : undefined;
  const type = typeof req.query?.type === 'string' ? req.query.type : undefined;
  const passColor = typeof req.query?.passColor === 'string' ? req.query.passColor : undefined;

  const isAdmin = req.user.role === 'ADMIN';
  const includeDeleted = String(req.query?.includeDeleted ?? '').toLowerCase();
  const withDeleted = includeDeleted === '1' || includeDeleted === 'true' || includeDeleted === 'yes';

  const shifts = isAdmin
    ? await Shifts.listShiftsForAdmin(range, { includeDeleted: withDeleted, clientId, locationId, type, requiredPassColor: passColor })
    : await Shifts.listShiftsForUser(req.user.id, range);

  // Phase 7+: role-based visibility for rates
  // - EMPLOYEE/SUBCONTRACTOR: only workerRateCents
  // - CLIENT: only employerRateCents
  // - ADMIN: both
  const role = String(req.user?.role ?? '');
  for (const s of shifts as any[]) {
    // Treat legacy DRAFT as OPEN (UI no longer uses DRAFT)
    if (s?.status === 'DRAFT') s.status = 'OPEN';

    if (role === 'EMPLOYEE' || role === 'SUBCONTRACTOR') {
      delete (s as any).employerRateCents;
    }
    if (role === 'CLIENT') {
      delete (s as any).workerRateCents;
      // Clients can see billing-related extras (if shift belongs to them; enforced in get())
    }
  }

  res.json({ shifts });
}

// Lightweight calendar payload for Agenda/Week views.
// Returns only the fields needed to render events and show quick info.
export async function calendarSummary(req: any, res: any) {
  const { start, end } = dateRangeSchema.parse(req.query);
  const range = start && end ? { start: parseDateParam(start), end: parseDateParam(end, { endOfDay: true }) } : undefined;

  const clientId = typeof req.query?.clientId === 'string' ? req.query.clientId : undefined;
  const locationId = typeof req.query?.locationId === 'string' ? req.query.locationId : undefined;
  const type = typeof req.query?.type === 'string' ? req.query.type : undefined;
  const passColor = typeof req.query?.passColor === 'string' ? req.query.passColor : undefined;
  const assigneeId = typeof req.query?.assigneeId === 'string' ? String(req.query.assigneeId) : undefined;

  // Status filter: accept canonical enums and Dutch labels for convenience.
  const statusRaw = typeof req.query?.status === 'string' ? String(req.query.status).trim() : undefined;
  const statusMap: Record<string, string> = {
    open: 'OPEN',
    ingepland: 'ASSIGNED',
    assigned: 'ASSIGNED',
    afgerond: 'COMPLETED',
    completed: 'COMPLETED',
    geannuleerd: 'CANCELLED',
    cancelled: 'CANCELLED',
  };
  const status = statusRaw ? (statusMap[statusRaw.toLowerCase()] ?? statusRaw.toUpperCase()) : undefined;
  const statusFilter = status && ['OPEN', 'ASSIGNED', 'COMPLETED', 'CANCELLED', 'DRAFT'].includes(status) ? status : undefined;

  const isAdmin = req.user.role === 'ADMIN';
  const includeDeleted = String(req.query?.includeDeleted ?? '').toLowerCase();
  const withDeleted = includeDeleted === '1' || includeDeleted === 'true' || includeDeleted === 'yes';

  const pageRaw = req.query?.page;
  const pageSizeRaw = req.query?.pageSize;
  const q = typeof req.query?.q === 'string' ? String(req.query.q) : undefined;
  const page = pageRaw ? Number(pageRaw) : undefined;
  const pageSize = pageSizeRaw ? Number(pageSizeRaw) : undefined;
  const wantsPaged = Number.isFinite(page as any) || Number.isFinite(pageSize as any) || (q?.trim()?.length ?? 0) > 0;

  if (isAdmin && wantsPaged) {
    const pg = Number.isFinite(page as any) ? (page as number) : 1;
    const ps = Number.isFinite(pageSize as any) ? (pageSize as number) : 25;
    const result = await Shifts.listShiftsCalendarSummaryForAdminPaged(range, {
      includeDeleted: withDeleted,
      clientId,
      locationId,
      type,
      requiredPassColor: passColor,
      status: statusFilter,
      assigneeId,
      q: q?.trim() || undefined,
      page: pg,
      pageSize: ps,
    });

    const normalized = (result.items as any[]).map((s: any) => ({ ...s, status: s?.status === 'DRAFT' ? 'OPEN' : s?.status }));
    res.json({ shifts: normalized, totalCount: result.totalCount, page: pg, pageSize: ps });
    return;
  }

  const shifts = isAdmin
    ? await Shifts.listShiftsCalendarSummaryForAdmin(range, { includeDeleted: withDeleted, clientId, locationId, type, requiredPassColor: passColor, status: statusFilter, assigneeId })
    : await Shifts.listShiftsCalendarSummaryForUser(req.user.id, range);

  // Legacy: treat DRAFT as OPEN in calendar payloads
  const normalized = (shifts as any[]).map((s: any) => ({ ...s, status: s?.status === 'DRAFT' ? 'OPEN' : s?.status }));
  res.json({ shifts: normalized });
}

export async function openList(req: any, res: any) {
  const { start, end } = dateRangeSchema.parse(req.query);
  const range = start && end ? { start: parseDateParam(start), end: parseDateParam(end, { endOfDay: true }) } : undefined;
  const type = typeof req.query?.type === 'string' ? req.query.type : undefined;
  const locationId = typeof req.query?.locationId === 'string' ? req.query.locationId : undefined;
  const q = typeof req.query?.q === 'string' ? String(req.query.q) : undefined;
  const occupancyRaw = String(req.query?.occupancy ?? 'all').toLowerCase();
  const eligibilityRaw = String(req.query?.eligibility ?? 'all').toLowerCase();

  const occupancy = (occupancyRaw === 'free' || occupancyRaw === 'full') ? occupancyRaw : 'all';
  const eligibility = (eligibilityRaw === 'eligible' || eligibilityRaw === 'ineligible') ? eligibilityRaw : 'all';

  const pageRaw = req.query?.page;
  const pageSizeRaw = req.query?.pageSize;
  const page = pageRaw ? Number(pageRaw) : undefined;
  const pageSize = pageSizeRaw ? Number(pageSizeRaw) : undefined;
  const wantsPaged = Number.isFinite(page as any) || Number.isFinite(pageSize as any) || (q?.trim()?.length ?? 0) > 0;

  const all = await Shifts.listOpenShifts(
    { id: req.user.id, role: req.user.role },
    range,
    { type, locationId, occupancy, eligibility, q: q?.trim() || undefined }
  );

  if (!wantsPaged) {
    res.json({ shifts: all });
    return;
  }

  const pg = Number.isFinite(page as any) ? Math.max(1, (page as number)) : 1;
  const ps = Number.isFinite(pageSize as any) ? Math.min(100, Math.max(1, (pageSize as number))) : 25;
  const totalCount = (all as any[]).length;
  const offset = (pg - 1) * ps;
  const shifts = (all as any[]).slice(offset, offset + ps);
  res.json({ shifts, totalCount, page: pg, pageSize: ps });
}

export async function create(req: any, res: any) {
  if (req.user.role !== 'ADMIN') throw new HttpError(403, 'Forbidden');
  const body = createShiftSchema.parse(req.body);
  const { assigneeIds, materials, ...rest } = body as any;

  // Product model: new shifts are OPEN by default; treat legacy DRAFT as OPEN.
  const status = (rest.status === 'DRAFT') ? 'OPEN' : rest.status;

  const shift = await Shifts.createShift({
    ...rest,
    status,
    materials,
    startAt: new Date(body.startAt),
    endAt: new Date(body.endAt),
    createdById: req.user.id,
    titleUniqueness: 'throw',
  });

  // Optional: directly assign one or more employees to the shift.
  if (Array.isArray(assigneeIds) && assigneeIds.length > 0) {
    await Shifts.assignMultiple(shift.id, assigneeIds);
  }

  await logAudit({
    actorId: req.user.id,
    action: 'SHIFT_CREATE',
    entity: 'Shift',
    entityId: shift.id,
    before: null,
    after: shift,
  });
  res.status(201).json({ shift });
}

export async function bulkCreateWeek(req: any, res: any) {
  if (req.user?.role !== 'ADMIN') throw new HttpError(403, 'Forbidden');
  const body = bulkWeekSchema.parse(req.body);

  const baseDate = new Date(`${body.weekStart}T00:00:00.000`);

  // Determine repeat window.
  // Preferred: repeatUntil (date-only). If not provided but old repeat.weeks is, compute end date.
  let repeatUntil: Date | null = null;
  if (body.repeatUntil) {
    repeatUntil = new Date(`${body.repeatUntil}T23:59:59.999`);
  } else if (body.repeat?.mode === 'weekly') {
    const weeks = body.repeat.weeks ?? 1;
    const tmp = new Date(baseDate);
    tmp.setDate(tmp.getDate() + (weeks * 7) - 1);
    tmp.setHours(23, 59, 59, 999);
    repeatUntil = tmp;
  }

  const created: any[] = [];

  // For very large batches we chunk transactions to avoid long-held DB locks.
  // We still try to keep the overall operation "all-or-nothing" by cleaning up
  // previously created shifts if a later chunk fails.
  const CHUNK_WEEKS = 4;
  const CHUNK_THRESHOLD_WEEKS = 12;

  // Hard limit to prevent timeouts / spikes (2 years / 104 weeks)
  const MAX_WEEKS = 104;
  if (repeatUntil) {
    const maxUntil = new Date(baseDate);
    maxUntil.setDate(maxUntil.getDate() + MAX_WEEKS * 7);
    if (repeatUntil.getTime() > maxUntil.getTime()) {
      throw new HttpError(400, `Herhaling mag maximaal ${MAX_WEEKS} weken zijn (2 jaar).`, 'BULK_REPEAT_TOO_LONG', {
        maxWeeks: MAX_WEEKS,
      });
    }
  }

  // Figure out how many weeks we will generate.
  let totalWeeks = 1;
  if (repeatUntil) {
    const diffDays = Math.floor((repeatUntil.getTime() - baseDate.getTime()) / (24 * 60 * 60 * 1000));
    totalWeeks = Math.min(MAX_WEEKS, Math.floor(diffDays / 7) + 1);
  }

  const createdIds: string[] = [];

  const createWeeksRange = async (tx: any, wFrom: number, wToExclusive: number) => {
    const local: any[] = [];
    for (let w = wFrom; w < wToExclusive; w++) {
      const weekStart = new Date(baseDate);
      weekStart.setDate(weekStart.getDate() + w * 7);
      weekStart.setHours(0, 0, 0, 0);
      if (w > 0 && !repeatUntil) break;
      if (repeatUntil && weekStart.getTime() > repeatUntil.getTime()) break;

      for (const e of body.entries) {
        const day = new Date(weekStart);
        day.setDate(day.getDate() + e.dow);

        const [sh, sm] = e.startTime.split(':').map((x: string) => parseInt(x, 10));
        const [eh, em] = e.endTime.split(':').map((x: string) => parseInt(x, 10));

        const startAt = new Date(day);
        startAt.setHours(sh, sm, 0, 0);

        const endAt = new Date(day);
        endAt.setHours(eh, em, 0, 0);

        if (endAt <= startAt) endAt.setDate(endAt.getDate() + 1);
        if (repeatUntil && startAt.getTime() > repeatUntil.getTime()) continue;

        const shift = await Shifts.createShift(
          {
            title: e.title,
            description: undefined,
            type: (e as any).type ?? 'GENERAL',
            requiredPassColor: (e as any).requiredPassColor ?? 'BLACK',
            locationId: body.locationId,
            clientId: body.clientId,
            requiredWorkers: e.requiredWorkers,
            startAt,
            endAt,
            status: e.status === 'DRAFT' ? 'OPEN' : e.status,
            createdById: req.user.id,
            titleUniqueness: 'suffix',
          },
          tx,
        );

        if (Array.isArray(e.assigneeIds) && e.assigneeIds.length > 0) {
          await Shifts.assignMultiple(shift.id, e.assigneeIds, tx);
        }

        local.push(shift);
      }
    }
    return local;
  };

  try {
    if (totalWeeks <= CHUNK_THRESHOLD_WEEKS) {
      const createdInTx = await prisma.$transaction(async (tx) => createWeeksRange(tx, 0, totalWeeks));
      created.push(...createdInTx);
      createdIds.push(...createdInTx.map((s: any) => s.id));
    } else {
      // Chunked transactions with cleanup on failure (best-effort all-or-nothing)
      for (let w = 0; w < totalWeeks; w += CHUNK_WEEKS) {
        const createdChunk = await prisma.$transaction(async (tx) =>
          createWeeksRange(tx, w, Math.min(totalWeeks, w + CHUNK_WEEKS)),
        );
        created.push(...createdChunk);
        createdIds.push(...createdChunk.map((s: any) => s.id));
      }
    }
  } catch (err) {
    // Cleanup shifts created in earlier chunks.
    if (createdIds.length > 0) {
      try {
        await prisma.shift.deleteMany({ where: { id: { in: createdIds } } });
      } catch {
        // ignore cleanup failure (still bubble original error)
      }
    }
    throw err;
  }

  // Best-effort audit logging AFTER commit to avoid recording rolled-back shifts.
  // Log a SINGLE entry with the generation parameters (more useful than per-shift spam).
  if (created[0]?.id) {
    await logAudit({
      actorId: req.user.id,
      action: 'SHIFT_CREATE_BULK',
      entity: 'Shift',
      entityId: created[0].id,
      ipAddress: req.ip,
      userAgent: req.headers['user-agent'],
      after: {
        weekStart: body.weekStart,
        repeatUntil: body.repeatUntil ?? null,
        repeat: body.repeat ?? null,
        locationId: body.locationId,
        clientId: body.clientId ?? null,
        entryCount: body.entries.length,
        totalWeeks,
        createdCount: created.length,
      },
    });
  }

  res.status(201).json({ data: created, meta: { totalWeeks, createdCount: created.length } });
}

// Create a repeating weekly series for a single shift template.
// Used by the Admin "Herhalen" UI on shift creation.
export async function repeatWeekly(req: any, res: any) {
  if (req.user?.role !== 'ADMIN') throw new HttpError(403, 'Forbidden');
  const body = repeatShiftSchema.parse(req.body ?? {});

  const created = await Shifts.createWeeklyRepeatSeries({
    ...body,
    startAt: new Date(body.startAt),
    endAt: new Date(body.endAt),
    repeatUntil: new Date(`${body.repeatUntil}T23:59:59.999`),
    intervalWeeks: body.intervalWeeks ?? 1,
    createdById: req.user.id,
  });

  await logAudit(req.user.id, 'SHIFT_CREATE_REPEAT', {
    startAt: body.startAt,
    endAt: body.endAt,
    repeatUntil: body.repeatUntil,
    intervalWeeks: body.intervalWeeks ?? 1,
    locationId: body.locationId,
    clientId: body.clientId ?? null,
    requiredWorkers: body.requiredWorkers ?? null,
    requiredPassColor: body.requiredPassColor ?? null,
    createdCount: created.length,
  });

  res.status(201).json({ shifts: created });
}


export async function update(req: any, res: any) {
  if (req.user.role !== 'ADMIN') throw new HttpError(403, 'Forbidden');
  const body = updateShiftSchema.parse(req.body);

  // Product model: legacy DRAFT treated as OPEN
  const normalizedStatus = (body as any)?.status === 'DRAFT' ? 'OPEN' : (body as any)?.status;
  const before = await prisma.shift.findUnique({ where: { id: req.params.id } });
  const shift = await Shifts.updateShift(req.params.id, {
    ...body,
    ...(normalizedStatus !== undefined ? { status: normalizedStatus } : {}),
    ...(body.startAt ? { startAt: new Date(body.startAt) } : {}),
    ...(body.endAt ? { endAt: new Date(body.endAt) } : {}),
  });

  await logAudit({
    actorId: req.user.id,
    action: 'SHIFT_UPDATE',
    entity: 'Shift',
    entityId: shift.id,
    before,
    after: shift,
  });

  // Notify assigned employees (minimum viable)
  try {
    const assignments = await prisma.shiftAssignment.findMany({
      where: { shiftId: shift.id, status: 'APPROVED' },
      select: { userId: true },
    });

    if (assignments.length > 0) {
      const startChanged = body.startAt ? before?.startAt?.toISOString() !== new Date(body.startAt).toISOString() : false;
      const endChanged = body.endAt ? before?.endAt?.toISOString() !== new Date(body.endAt).toISOString() : false;
      const locationChanged = body.locationId ? before?.locationId !== body.locationId : false;
      const titleChanged = body.title ? before?.title !== body.title : false;
      const statusChanged = body.status ? before?.status !== body.status : false;

      const changed = startChanged || endChanged || locationChanged || titleChanged || statusChanged;
      if (changed) {
        const msg = `Dienst bijgewerkt: "${shift.title}". Check je planning.`;
        const io = req.app.locals.io;
        await Promise.all(
          assignments.map(async (a) => {
            await createUserNotification({
              recipientId: a.userId,
              type: 'SHIFT_UPDATED',
              senderId: req.user.id,
              message: msg,
              data: { shiftId: shift.id, url: `/diensten/${shift.id}` },
            });
            io?.to(`user:${a.userId}`)?.emit('notification', { type: 'SHIFT_UPDATED', shiftId: shift.id, userId: a.userId });
          }),
        );
      }
    }
  } catch {
    // best-effort
  }
  res.json({ shift });
}


// Phase 7: update shift rates (admin only)
const ratesSchema = z.object({
  employerRateCents: z.number().int().min(0).optional(),
  workerRateCents: z.number().int().min(0).optional(),
});

export async function updateRates(req: any, res: any) {
  if (req.user?.role !== 'ADMIN') throw new HttpError(403, 'Forbidden');
  const body = ratesSchema.parse(req.body ?? {});
  const before = await prisma.shift.findUnique({ where: { id: req.params.id } });
  if (!before || (before as any).isDeleted) throw new HttpError(404, 'Shift not found');
  if (before.status === 'CANCELLED') throw new HttpError(409, 'Dienst is geannuleerd (read-only).', 'SHIFT_LOCKED_CANCELLED');
  if (before.status === 'COMPLETED') throw new HttpError(409, 'Dienst is afgerond (completed).', 'SHIFT_LOCKED_COMPLETED');
  const shift = await prisma.shift.update({
    where: { id: req.params.id },
    data: {
      ...(body.employerRateCents !== undefined ? { employerRateCents: body.employerRateCents } : {}),
      ...(body.workerRateCents !== undefined ? { workerRateCents: body.workerRateCents } : {}),
    },
  });

  await logAudit({
    actorId: req.user.id,
    action: 'SHIFT_RATES_UPDATE',
    entity: 'Shift',
    entityId: shift.id,
    before,
    after: shift,
  });

  res.json({ shift });
}

const extraCostCreateSchema = z.object({
  description: z.string().min(1).max(200),
  amountCents: z.number().int().min(0),
});

export async function addExtraCost(req: any, res: any) {
  if (req.user?.role !== 'ADMIN') throw new HttpError(403, 'Forbidden');
  const body = extraCostCreateSchema.parse(req.body ?? {});

  const meta = await prisma.shift.findUnique({ where: { id: req.params.id }, select: { id: true, status: true, isDeleted: true } });
  if (!meta || meta.isDeleted) throw new HttpError(404, 'Shift not found');
  if (meta.status === 'CANCELLED') throw new HttpError(409, 'Dienst is geannuleerd (read-only).', 'SHIFT_LOCKED_CANCELLED');
  if (meta.status === 'COMPLETED') throw new HttpError(409, 'Dienst is afgerond (completed).', 'SHIFT_LOCKED_COMPLETED');

  const cost = await prisma.shiftExtraCost.create({
    data: {
      shiftId: req.params.id,
      description: body.description,
      amountCents: body.amountCents,
      createdById: req.user.id,
    },
  });

  // Shift-level readable audit log
  await logAudit({ actorId: req.user.id, action: 'SHIFT_EXTRA_COST_ADD', entity: 'Shift', entityId: req.params.id, before: null, after: cost });
  res.status(201).json({ cost });
}

const extraCostUpdateSchema = z.object({
  description: z.string().min(1).max(200).optional(),
  amountCents: z.number().int().min(0).optional(),
});

export async function updateExtraCost(req: any, res: any) {
  if (req.user?.role !== 'ADMIN') throw new HttpError(403, 'Forbidden');
  const body = extraCostUpdateSchema.parse(req.body ?? {});
  const meta = await prisma.shift.findUnique({ where: { id: req.params.id }, select: { id: true, status: true, isDeleted: true } });
  if (!meta || meta.isDeleted) throw new HttpError(404, 'Shift not found');
  if (meta.status === 'CANCELLED') throw new HttpError(409, 'Dienst is geannuleerd (read-only).', 'SHIFT_LOCKED_CANCELLED');
  if (meta.status === 'COMPLETED') throw new HttpError(409, 'Dienst is afgerond (completed).', 'SHIFT_LOCKED_COMPLETED');
  const before = await prisma.shiftExtraCost.findUnique({ where: { id: req.params.costId } });
  if (!before || before.shiftId !== req.params.id) throw new HttpError(404, 'Extra cost not found');

  const cost = await prisma.shiftExtraCost.update({
    where: { id: req.params.costId },
    data: {
      ...(body.description !== undefined ? { description: body.description } : {}),
      ...(body.amountCents !== undefined ? { amountCents: body.amountCents } : {}),
    },
  });

  // Shift-level readable audit log
  await logAudit({ actorId: req.user.id, action: 'SHIFT_EXTRA_COST_UPDATE', entity: 'Shift', entityId: req.params.id, before, after: cost });

  res.json({ cost });
}

export async function deleteExtraCost(req: any, res: any) {
  if (req.user?.role !== 'ADMIN') throw new HttpError(403, 'Forbidden');
  const meta = await prisma.shift.findUnique({ where: { id: req.params.id }, select: { id: true, status: true, isDeleted: true } });
  if (!meta || meta.isDeleted) throw new HttpError(404, 'Shift not found');
  if (meta.status === 'CANCELLED') throw new HttpError(409, 'Dienst is geannuleerd (read-only).', 'SHIFT_LOCKED_CANCELLED');
  if (meta.status === 'COMPLETED') throw new HttpError(409, 'Dienst is afgerond (completed).', 'SHIFT_LOCKED_COMPLETED');
  const before = await prisma.shiftExtraCost.findUnique({ where: { id: req.params.costId } });
  if (!before || before.shiftId !== req.params.id) throw new HttpError(404, 'Extra cost not found');
  await prisma.shiftExtraCost.delete({ where: { id: req.params.costId } });

  // Shift-level readable audit log
  await logAudit({ actorId: req.user.id, action: 'SHIFT_EXTRA_COST_DELETE', entity: 'Shift', entityId: req.params.id, before, after: null });
  res.json({ ok: true });
}

export async function remove(req: any, res: any) {
  if (req.user.role !== 'ADMIN') throw new HttpError(403, 'Forbidden');
  const before = await prisma.shift.findUnique({ where: { id: req.params.id } });
  const after = await Shifts.deleteShift(req.params.id);

  await logAudit({
    actorId: req.user.id,
    action: 'SHIFT_DELETE',
    entity: 'Shift',
    entityId: req.params.id,
    before,
    after,
  });

  // Notify assigned employees that the shift was cancelled
  try {
    const assignments = await prisma.shiftAssignment.findMany({
      where: { shiftId: req.params.id, status: 'APPROVED' },
      select: { userId: true },
    });

    if (assignments.length > 0) {
      const title = before?.title ?? 'Dienst';
      const io = req.app.locals.io;
      await Promise.all(
        assignments.map(async (a) => {
          await createUserNotification({
            recipientId: a.userId,
            type: 'SHIFT_CANCELLED',
            senderId: req.user.id,
            message: `Dienst geannuleerd: "${title}".`,
            data: { shiftId: req.params.id, url: '/notificaties' },
          });
          io?.to(`user:${a.userId}`)?.emit('notification', { type: 'SHIFT_CANCELLED', shiftId: req.params.id, userId: a.userId });
        }),
      );
    }
  } catch {
    // best-effort
  }
  res.json({ ok: true });
}

export async function get(req: any, res: any) {
  const isAdmin = req.user?.role === 'ADMIN';
  const includeDeleted = String(req.query?.includeDeleted ?? '').toLowerCase();
  const withDeleted = includeDeleted === '1' || includeDeleted === 'true' || includeDeleted === 'yes';

  let shift = await Shifts.getShift(req.params.id, { includeDeleted: isAdmin && withDeleted });
  // Admin quality-of-life: allow opening archived shifts without needing a special query param.
  if (!shift && isAdmin) {
    shift = await Shifts.getShift(req.params.id, { includeDeleted: true });
  }
  if (!shift) throw new HttpError(404, 'Shift not found');

  // Client isolation: clients may only read their own shifts.
  if (req.user?.role === 'CLIENT') {
    if (!req.user.clientId || (shift as any).clientId !== req.user.clientId) {
      throw new HttpError(404, 'Shift not found');
    }
  }

  // Phase 7: role-based visibility for rates + extra costs
  const role = req.user?.role;
  const safe: any = { ...shift };

  // Treat legacy DRAFT as OPEN
  if (safe?.status === 'DRAFT') safe.status = 'OPEN';

  // Archived shifts: expose as DELETED in UI (admin/archief), while keeping isDeleted flag.
  if ((safe as any)?.isDeleted) (safe as any).status = 'DELETED';

  if (role === 'EMPLOYEE' || role === 'SUBCONTRACTOR') {
    delete safe.employerRateCents;
  }
  if (role === 'CLIENT') {
    delete safe.workerRateCents;
    // Clients may see employerRateCents + extraCosts for their own shifts.
  }

  res.json({ shift: safe });
}


// Pin/unpin a shift note. Allowed: ADMIN or CLIENT that owns the shift.
export async function pinNote(req: any, res: any) {
  const shiftId = String(req.params.id);
  const noteId = String(req.params.noteId);
  const { pinned } = pinNoteSchema.parse(req.body ?? {});

  const note = await prisma.shiftNote.findUnique({
    where: { id: noteId },
    include: { shift: { select: { id: true, clientId: true } } },
  });
  if (!note || note.shiftId !== shiftId) throw new HttpError(404, 'Note not found');

  if (req.user.role === 'ADMIN') {
    // ok
  } else if (req.user.role === 'CLIENT') {
    if (!req.user.clientId || note.shift.clientId !== req.user.clientId) throw new HttpError(404, 'Shift not found');
  } else {
    throw new HttpError(403, 'Forbidden');
  }

  const updated = await prisma.shiftNote.update({
    where: { id: noteId },
    data: { isPinned: pinned, pinnedAt: pinned ? new Date() : null },
    include: { author: { select: { id: true, fullName: true, email: true } } },
  });

  await logAudit(req.user.id, pinned ? 'NOTE_PIN' : 'NOTE_UNPIN', {
    shiftId,
    noteId,
  });

  // Realtime update (admin + opdrachtgever + assigned employees)
  const io = req.app.locals.io;
  await emitShiftEvent(io, shiftId, {
    type: pinned ? 'NOTE_PIN' : 'NOTE_UNPIN',
    noteId,
    pinned,
  });

  res.json({ note: updated });
}

export async function request(req: any, res: any) {
  requestSchema.parse(req.body);
  const assignment = await Shifts.requestOpenShift(req.params.id, req.user.id, req.user.role);

  // Notify admins that someone responded to an open shift
  const shift = await prisma.shift.findUnique({ where: { id: req.params.id }, select: { id: true, title: true, startAt: true, endAt: true } });
  const sender = await prisma.user.findUnique({
    where: { id: req.user.id },
    select: { id: true, fullName: true, email: true },
  });
  const shiftTitle = shift?.title ?? 'Open dienst';
  const senderLabel = sender?.fullName || sender?.email || 'Een medewerker';

  await createAdminNotification({
    type: 'OPEN_SHIFT_REQUEST',
    senderId: req.user.id,
    message: `${senderLabel} heeft gereageerd op open dienst "${shiftTitle}"`,
    data: { shiftId: req.params.id, shiftTitle, userId: req.user.id, assignmentStatus: assignment.status, startAt: shift?.startAt ? shift.startAt.toISOString() : null, endAt: shift?.endAt ? shift.endAt.toISOString() : null },
  });

  // Also store a confirmation notification for the requester (so employees see it too)
  await createUserNotification({
    recipientId: req.user.id,
    type: 'OPEN_SHIFT_REQUEST_SENT',
    senderId: req.user.id,
    message: `Je hebt gereageerd op open dienst "${shiftTitle}". Wacht op goedkeuring.`,
    data: { shiftId: req.params.id, assignmentStatus: assignment.status, startAt: shift?.startAt ? shift.startAt.toISOString() : null, endAt: shift?.endAt ? shift.endAt.toISOString() : null },
  });

  const io = req.app.locals.io;
  io?.to('admins').emit('notification', { type: 'OPEN_SHIFT_REQUEST', shiftId: req.params.id, userId: req.user.id });
  io?.to(`user:${req.user.id}`).emit('notification', { type: 'OPEN_SHIFT_REQUEST_SENT', shiftId: req.params.id, userId: req.user.id });

  res.status(201).json({ assignment });
}

// Admin can directly assign one or more employees to a shift (immediate APPROVED).
export async function assign(req: any, res: any) {
  if (req.user?.role !== 'ADMIN') throw new HttpError(403, 'Forbidden');
  const body = assignSchema.parse(req.body ?? {});
  const ids = (body.userIds && body.userIds.length > 0) ? body.userIds : (body.userId ? [body.userId] : []);
  if (ids.length === 0) throw new HttpError(400, 'Provide userId or userIds');

  // Approve selected employees.
  await Shifts.assignMultiple(req.params.id, ids);

  // Audit on the shift itself (so it appears in /shifts/:id/activity)
  await logAudit(req.user.id, 'SHIFT_ASSIGN', { shiftId: req.params.id, userIds: ids });

  await createAdminNotification({
    type: 'SHIFT_ASSIGNED',
    senderId: req.user.id,
    message: `Dienst is toegewezen aan ${ids.length} medewerker(s).`,
    data: { shiftId: req.params.id, userIds: ids },
  });

  // Notify employees
  try {
    const shift = await prisma.shift.findUnique({
      where: { id: req.params.id },
      select: { id: true, title: true, startAt: true, endAt: true },
    });
    const shiftTitle = shift?.title ?? 'Dienst';
    const io = req.app.locals.io;
    await Promise.all(
      ids.map(async (uid: string) => {
        await createUserNotification({
          recipientId: uid,
          type: 'SHIFT_ASSIGNED',
          senderId: req.user.id,
          message: `Je bent toegewezen aan "${shiftTitle}".`,
          data: {
            shiftId: req.params.id,
            startAt: shift?.startAt ? shift.startAt.toISOString() : null,
            endAt: shift?.endAt ? shift.endAt.toISOString() : null,
            url: `/diensten/${req.params.id}`,
          },
        });
        io?.to(`user:${uid}`)?.emit('notification', { type: 'SHIFT_ASSIGNED', shiftId: req.params.id, userId: uid });
      }),
    );
  } catch {
    // best-effort
  }

  res.json({ ok: true });
}

// Admin can unassign one or more employees from a shift.
export async function unassign(req: any, res: any) {
  if (req.user?.role !== 'ADMIN') throw new HttpError(403, 'Forbidden');
  const body = assignSchema.parse(req.body ?? {});
  const ids = (body.userIds && body.userIds.length > 0) ? body.userIds : (body.userId ? [body.userId] : []);
  if (ids.length === 0) throw new HttpError(400, 'Provide userId or userIds');

  await Shifts.unassignMultiple(req.params.id, ids);

  await logAudit(req.user.id, 'SHIFT_UNASSIGN', { shiftId: req.params.id, userIds: ids });

  await createAdminNotification({
    type: 'SHIFT_UPDATED',
    senderId: req.user.id,
    message: `Dienst ontkoppeld van ${ids.length} medewerker(s).`,
    data: { shiftId: req.params.id, userIds: ids },
  });

  const io = req.app.locals.io;
  for (const uid of ids) {
    try {
      await createUserNotification({
        recipientId: uid,
        type: 'SHIFT_UPDATED',
        senderId: req.user.id,
        message: `Je bent ontkoppeld van een dienst.`,
        data: { shiftId: req.params.id, url: `/diensten/${req.params.id}` },
      });
      io?.to(`user:${uid}`)?.emit('notification', { type: 'SHIFT_UPDATED', shiftId: req.params.id, userId: uid });
    } catch {
      // best-effort
    }
  }

  res.json({ ok: true });
}

export async function review(req: any, res: any) {
  if (req.user.role !== 'ADMIN') throw new HttpError(403, 'Forbidden');
  const { userId, approve } = reviewSchema.parse(req.body);
  const before = await prisma.shiftAssignment.findUnique({ where: { shiftId_userId: { shiftId: req.params.id, userId } } });
  const assignment = await Shifts.reviewRequest(req.params.id, userId, approve);

  await logAudit({
    actorId: req.user.id,
    action: approve ? 'OPEN_SHIFT_APPROVE' : 'OPEN_SHIFT_REJECT',
    entity: 'ShiftAssignment',
    entityId: assignment?.id ?? `${req.params.id}:${userId}`,
    before,
    after: assignment,
  });

  // Also log on the Shift entity for the admin activity feed
  await logAudit(req.user.id, approve ? 'OPEN_SHIFT_APPROVE' : 'OPEN_SHIFT_REJECT', {
    shiftId: req.params.id,
    userId,
    approved: approve,
  });

  // Notify the employee about the decision
  const shift = await prisma.shift.findUnique({ where: { id: req.params.id }, select: { id: true, title: true, startAt: true, endAt: true } });
  const shiftTitle = shift?.title ?? 'Open dienst';
  await createUserNotification({
    recipientId: userId,
    type: 'OPEN_SHIFT_REVIEW',
    senderId: req.user.id,
    message: approve
      ? `Je reactie op open dienst "${shiftTitle}" is goedgekeurd.`
      : `Je reactie op open dienst "${shiftTitle}" is afgewezen.`,
    data: {
      shiftId: req.params.id,
      approved: approve,
      startAt: shift?.startAt ? shift.startAt.toISOString() : null,
      endAt: shift?.endAt ? shift.endAt.toISOString() : null,
    },
  });

  const io = req.app.locals.io;
  io?.to(`user:${userId}`).emit('notification', { type: 'OPEN_SHIFT_REVIEW', shiftId: req.params.id, userId, approved: approve });

  res.json({ assignment });
}

export async function clockIn(req: any, res: any) {
  // Validate identifiers early to avoid accidental misuse and keep downstream
  // errors predictable.
  const shiftId = z.string().cuid().parse(req.params.id);
  const userId = z.string().cuid().parse(req.user?.id);
  const geo = clockSchema.parse(req.body);
  const entry = await Time.clockIn(shiftId, userId, geo);

  // Non-repudiation: record BOTH a shift-scoped audit entry (for the shift activity feed)
  // and a TimeEntry-scoped audit entry (for immutable timekeeping trails).
  await logAudit(userId, 'CLOCK_IN', { shiftId, timeEntryId: entry.id, userId, after: entry });
  await logAudit({ actorId: userId, action: 'CLOCK_IN', entity: 'TimeEntry', entityId: entry.id, before: null, after: entry });

  const io = req.app.locals.io;
  await emitShiftEvent(io, shiftId, { type: 'CLOCK_IN', userId, timeEntryId: entry.id });

  res.status(201).json({ timeEntry: entry });
}

export async function clockOut(req: any, res: any) {
  const shiftId = z.string().cuid().parse(req.params.id);
  const userId = z.string().cuid().parse(req.user?.id);
  const geo = clockSchema.parse(req.body);
  const { existing, updated } = await Time.clockOut(shiftId, userId, geo);

  await logAudit(userId, 'CLOCK_OUT', { shiftId, timeEntryId: updated.id, userId, after: updated });
  await logAudit({ actorId: userId, action: 'CLOCK_OUT', entity: 'TimeEntry', entityId: updated.id, before: existing, after: updated });
  const io = req.app.locals.io;
  await emitShiftEvent(io, shiftId, { type: 'CLOCK_OUT', userId, timeEntryId: updated.id, minutesWorked: updated.minutesWorked });

  res.json({ timeEntry: updated });
}

export async function adminCorrectTime(req: any, res: any) {
  if (req.user.role !== 'ADMIN') throw new HttpError(403, 'Forbidden');
  const body = z.object({
    clockInAt: z.string().datetime().optional(),
    clockOutAt: z.string().datetime().optional(),
    reason: z.string().min(3),
  }).parse(req.body);

  if (!body.clockInAt && !body.clockOutAt) {
    throw new HttpError(400, 'Provide clockInAt and/or clockOutAt', 'NO_CHANGES');
  }

  const { existing, updated } = await Time.adminCorrectTimeEntry(req.user.id, req.params.timeEntryId, {
    clockInAt: body.clockInAt ? new Date(body.clockInAt) : undefined,
    clockOutAt: body.clockOutAt ? new Date(body.clockOutAt) : undefined,
    reason: body.reason,
  });

  // Structured audit for the time entry + shift activity feed
  await logAudit({ actorId: req.user.id, action: 'TIMEENTRY_CORRECT', entity: 'TimeEntry', entityId: updated.id, before: existing, after: updated });
  await logAudit(req.user.id, 'TIMEENTRY_CORRECT', { shiftId: updated.shiftId, timeEntryId: updated.id, userId: updated.userId, after: updated, correctionReason: body.reason });

  res.json({ timeEntry: updated });
}

export async function adminClockIn(req: any, res: any) {
  if (req.user.role !== 'ADMIN') throw new HttpError(403, 'Forbidden');
  const body = z
    .object({
      userId: z.string().cuid(),
      reason: z.string().min(3),
      clockInAt: z.string().datetime().optional(),
    })
    .parse(req.body);

  const entry = await Time.adminClockIn(req.user.id, req.params.id, body.userId, {
    reason: body.reason,
    clockInAt: body.clockInAt ? new Date(body.clockInAt) : undefined,
  });

  await logAudit({ actorId: req.user.id, action: 'ADMIN_CLOCK_IN', entity: 'TimeEntry', entityId: entry.id, before: null, after: entry });
  await logAudit(req.user.id, 'ADMIN_CLOCK_IN', { shiftId: req.params.id, timeEntryId: entry.id, userId: body.userId, correctionReason: body.reason, after: entry });

  const io = req.app.locals.io;
  await emitShiftEvent(io, req.params.id, { type: 'ADMIN_CLOCK_IN', userId: body.userId, timeEntryId: entry.id });

  res.status(201).json({ timeEntry: entry });
}

export async function adminClockOut(req: any, res: any) {
  if (req.user.role !== 'ADMIN') throw new HttpError(403, 'Forbidden');
  const body = z
    .object({
      userId: z.string().cuid(),
      reason: z.string().min(3),
      clockOutAt: z.string().datetime().optional(),
    })
    .parse(req.body);

  const entry = await Time.adminClockOut(req.user.id, req.params.id, body.userId, {
    reason: body.reason,
    clockOutAt: body.clockOutAt ? new Date(body.clockOutAt) : undefined,
  });

  await logAudit({ actorId: req.user.id, action: 'ADMIN_CLOCK_OUT', entity: 'TimeEntry', entityId: entry.id, before: null, after: entry });
  await logAudit(req.user.id, 'ADMIN_CLOCK_OUT', { shiftId: req.params.id, timeEntryId: entry.id, userId: body.userId, correctionReason: body.reason, after: entry });

  const io = req.app.locals.io;
  await emitShiftEvent(io, req.params.id, { type: 'ADMIN_CLOCK_OUT', userId: body.userId, timeEntryId: entry.id });

  res.status(201).json({ timeEntry: entry });
}

export async function adminResetTime(req: any, res: any) {
  if (req.user.role !== 'ADMIN') throw new HttpError(403, 'Forbidden');

  const existing = await Time.adminResetTimeEntry(req.user.id, req.params.timeEntryId);

  await logAudit({
    actorId: req.user.id,
    action: 'TIMEENTRY_RESET',
    entity: 'TimeEntry',
    entityId: existing.id,
    before: existing,
    after: null,
  });

  // Shift activity feed
  await logAudit(req.user.id, 'TIMEENTRY_RESET', { shiftId: existing.shiftId, timeEntryId: existing.id, userId: existing.userId, before: existing, after: null });

  // Persist notifications
  const shift = await prisma.shift.findUnique({ where: { id: existing.shiftId }, select: { id: true, title: true, startAt: true, endAt: true } });
  const shiftTitle = shift?.title ?? 'Dienst';

  await createUserNotification({
    recipientId: existing.userId,
    type: 'TIMEENTRY_RESET_NOTICE',
    senderId: req.user.id,
    message: `Je tijdregistratie voor "${shiftTitle}" is gereset door een admin. Je kunt opnieuw inklokken.`,
    data: { shiftId: existing.shiftId, timeEntryId: existing.id, startAt: shift?.startAt ? shift.startAt.toISOString() : null, endAt: shift?.endAt ? shift.endAt.toISOString() : null },
  });

  await createAdminNotification({
    type: 'TIMEENTRY_RESET_NOTICE',
    senderId: req.user.id,
    message: `Tijdregistratie gereset voor "${shiftTitle}"`,
    data: { shiftId: existing.shiftId, userId: existing.userId, timeEntryId: existing.id },
  });

  const io = req.app.locals.io;
  io?.to('admins').emit('notification', { type: 'TIMEENTRY_RESET', shiftId: existing.shiftId, userId: existing.userId, timeEntryId: existing.id });
  io?.to(`user:${existing.userId}`).emit('notification', { type: 'TIMEENTRY_RESET', shiftId: existing.shiftId, userId: existing.userId, timeEntryId: existing.id });

  res.json({ ok: true });
}

export async function activity(req: any, res: any) {
  if (req.user.role !== 'ADMIN') throw new HttpError(403, 'Forbidden');
  const shiftId = String(req.params.id || '').trim();
  if (!shiftId) throw new HttpError(400, 'Missing shift id');

  const page = Math.max(1, Number(req.query?.page ?? 1));
  const pageSize = Math.max(1, Math.min(200, Number(req.query?.pageSize ?? 25)));
  const skip = (page - 1) * pageSize;

  // Ensure shift exists (avoid leaking whether an id is valid in a different tenant)
  const exists = await prisma.shift.findUnique({ where: { id: shiftId }, select: { id: true } });
  if (!exists) throw new HttpError(404, 'Shift not found');

  const where = { entity: 'Shift', entityId: shiftId } as const;
  const [logs, totalCount] = await prisma.$transaction([
    prisma.auditLog.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      skip,
      take: pageSize,
      include: { actor: { select: { id: true, fullName: true, email: true, role: true } } },
    }),
    prisma.auditLog.count({ where }),
  ]);

  res.json({ logs, totalCount, page, pageSize });
}
