import { prisma } from '../db/prisma.js';
import { HttpError } from '../utils/http.js';
import { z } from 'zod';
import { logAudit } from '../services/auditService.js';

const convertSchema = z.object({
  startAt: z.string().min(10),
  endAt: z.string().min(10),
  locationId: z.string().min(5),
  type: z.string().optional(),
  requiredPassColor: z.enum(['GRAY', 'DARK_BLUE', 'LIGHT_BLUE', 'ORANGE', 'GREEN', 'BLACK']).optional(),
  requiredWorkers: z.coerce.number().int().min(1).max(50).optional(),
});

export async function list(req: any, res: any) {
  const status = req.query.status ? String(req.query.status) : undefined;
  const where: any = {};
  if (status && ['OPEN','IN_PROGRESS','DONE'].includes(status)) {
    where.status = status;
  }

  const pageRaw = req.query?.page;
  const pageSizeRaw = req.query?.pageSize;
  const page = pageRaw ? Number(pageRaw) : undefined;
  const pageSize = pageSizeRaw ? Number(pageSizeRaw) : undefined;
  const wantsPaged = Number.isFinite(page as any) || Number.isFinite(pageSize as any);

  if (wantsPaged) {
    const pg = Number.isFinite(page as any) ? Math.max(1, (page as number)) : 1;
    const ps = Number.isFinite(pageSize as any) ? Math.min(100, Math.max(1, (pageSize as number))) : 25;

    const [totalCount, requests] = await prisma.$transaction([
      prisma.clientRequest.count({ where }),
      prisma.clientRequest.findMany({
        where,
        orderBy: [{ status: 'asc' }, { createdAt: 'desc' }],
        include: {
          client: { select: { id: true, name: true } },
          createdBy: { select: { id: true, fullName: true, email: true } },
          handledBy: { select: { id: true, fullName: true, email: true } },
        },
        skip: (pg - 1) * ps,
        take: ps,
      }),
    ]);
    return res.json({ requests, totalCount, page: pg, pageSize: ps });
  }

  const requests = await prisma.clientRequest.findMany({
    where,
    orderBy: [{ status: 'asc' }, { createdAt: 'desc' }],
    include: {
      client: { select: { id: true, name: true } },
      createdBy: { select: { id: true, fullName: true, email: true } },
      handledBy: { select: { id: true, fullName: true, email: true } },
    },
  });

  return res.json({ requests });
}

export async function updateStatus(req: any, res: any) {
  const id = String(req.params.id);
  const status = String(req.body?.status ?? '').trim();

  if (!['OPEN','IN_PROGRESS','DONE'].includes(status)) throw new HttpError(400, 'Invalid status');

  const existing = await prisma.clientRequest.findUnique({ where: { id } });
  if (!existing) throw new HttpError(404, 'Request not found');

  const data: any = { status };
  if (status === 'OPEN') {
    data.handledById = null;
    data.handledAt = null;
  } else {
    data.handledById = req.user.id;
    if (status === 'DONE') data.handledAt = new Date();
  }

  const updated = await prisma.clientRequest.update({
    where: { id },
    data,
    include: {
      client: { select: { id: true, name: true } },
      createdBy: { select: { id: true, fullName: true, email: true } },
      handledBy: { select: { id: true, fullName: true, email: true } },
    },
  });

  await logAudit({
    actorId: req.user.id,
    action: 'CLIENT_REQUEST_STATUS_UPDATE',
    entity: 'ClientRequest',
    entityId: id,
    before: existing,
    after: updated,
  });

  return res.json(updated);
}

// Convert a client request into a shift (admin workflow).
// This keeps manual input minimal: title/description/client are auto-filled from the request.
export async function convertToShift(req: any, res: any) {
  const id = String(req.params.id);
  const body = convertSchema.parse(req.body ?? {});

  const request = await prisma.clientRequest.findUnique({
    where: { id },
    include: { client: { select: { id: true, name: true } } },
  });
  if (!request) throw new HttpError(404, 'Request not found');

  const startAt = new Date(body.startAt);
  const endAt = new Date(body.endAt);
  if (Number.isNaN(startAt.getTime()) || Number.isNaN(endAt.getTime())) throw new HttpError(400, 'Invalid dates');
  if (endAt.getTime() <= startAt.getTime()) throw new HttpError(400, 'endAt must be after startAt');

  // Ensure location exists and is not deleted
  const loc = await prisma.location.findUnique({ where: { id: body.locationId }, select: { id: true, isDeleted: true } });
  if (!loc || loc.isDeleted) throw new HttpError(400, 'Invalid location');

  const shift = await prisma.shift.create({
    data: {
      title: request.subject ?? 'Verzoek',
      description: request.message ?? '',
      clientId: request.clientId,
      locationId: body.locationId,
      type: body.type ?? 'GENERAL',
      requiredPassColor: (body.requiredPassColor as any) ?? 'BLACK',
      requiredWorkers: body.requiredWorkers ?? 1,
      startAt,
      endAt,
      status: 'OPEN',
      createdById: req.user.id,
    },
  });

  await logAudit({
    actorId: req.user.id,
    action: 'CLIENT_REQUEST_CONVERT_TO_SHIFT',
    entity: 'ClientRequest',
    entityId: id,
    before: request,
    after: { ...request, convertedShiftId: shift.id },
  });

  // Mark request as handled.
  const afterReq = await prisma.clientRequest.update({
    where: { id },
    data: {
      status: 'DONE',
      handledById: req.user.id,
      handledAt: new Date(),
    },
  });

  await logAudit({
    actorId: req.user.id,
    action: 'CLIENT_REQUEST_STATUS_UPDATE',
    entity: 'ClientRequest',
    entityId: id,
    before: request,
    after: afterReq,
  });

  return res.status(201).json({ shift });
}

// Admin-only activity feed for a client request (AuditLog)
export async function activity(req: any, res: any) {
  const id = String(req.params.id || '').trim();
  if (!id) throw new HttpError(400, 'Missing id');

  const exists = await prisma.clientRequest.findUnique({ where: { id }, select: { id: true } });
  if (!exists) throw new HttpError(404, 'Request not found');

  const page = Math.max(1, Number(req.query?.page ?? 1));
  const pageSize = Math.max(1, Math.min(200, Number(req.query?.pageSize ?? 25)));
  const skip = (page - 1) * pageSize;

  const where = { entity: 'ClientRequest', entityId: id } as const;
  const [logs, totalCount] = await prisma.$transaction([
    prisma.auditLog.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      skip,
      take: pageSize,
      include: { actor: { select: { id: true, fullName: true, email: true, role: true } } },
    }),
    prisma.auditLog.count({ where }),
  ]);

  return res.json({ logs, totalCount, page, pageSize });
}
