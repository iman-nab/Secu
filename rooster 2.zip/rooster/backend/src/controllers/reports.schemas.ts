import { z } from 'zod';

export const reportSchema = z.object({
  start: z.string(),
  end: z.string(),
  userId: z.string().optional(),
  clientId: z.string().optional(),
  subcontractorId: z.string().optional(),
  page: z.coerce.number().int().min(1).optional(),
  pageSize: z.coerce.number().int().min(1).max(200).optional(),
  format: z.enum(['csv', 'xlsx', 'pdf']).optional(),
  mode: z.enum(['entries', 'summary', 'payroll']).optional(),
  rounding: z.enum(['none', '15']).optional(),
  includeRates: z
    .union([z.literal('1'), z.literal('0'), z.literal('true'), z.literal('false')])
    .optional(),
});
