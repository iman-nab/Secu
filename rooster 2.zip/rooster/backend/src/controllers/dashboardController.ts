import { HttpError } from '../utils/http.js';
import { prisma } from '../db/prisma.js';
import { z } from 'zod';
import { parseDateParam } from './shifts.helpers.js';
import * as Shifts from '../services/shiftsService.js';

export async function nextRequestedShift(req: any, res: any) {
  if (req.user?.role !== 'ADMIN') throw new HttpError(403, 'Forbidden');
  const data = await Shifts.getNextRequestedShift();
  res.setHeader('Cache-Control', 'no-store');
  res.json({ data });
}

// For employees: next upcoming shift they reacted to (REQUESTED or APPROVED).
// Priority: APPROVED first, otherwise REQUESTED.
export async function myNextReactedShift(req: any, res: any) {
  if (!req.user?.id) throw new HttpError(401, 'Unauthorized');
  const data = await Shifts.getMyNextReactedShift(req.user.id);
  res.setHeader('Cache-Control', 'no-store');
  res.json({ data });
}



const kpiRangeSchema = z.object({
  start: z.string().min(10),
  end: z.string().min(10),
});

export async function adminKpis(req: any, res: any) {
  if (req.user?.role !== 'ADMIN') throw new HttpError(403, 'Forbidden');
  const { start, end } = kpiRangeSchema.parse(req.query ?? {});
  const startAt = parseDateParam(start);
  const endAt = parseDateParam(end, { endOfDay: true });

  const entries = await prisma.timeEntry.findMany({
    where: {
      clockInAt: { gte: startAt, lte: endAt },
      clockOutAt: { not: null },
      shift: { isDeleted: false },
    },
    select: {
      minutesWorked: true,
      shift: { select: { id: true, employerRateCents: true, workerRateCents: true } },
      user: { select: { subcontractorId: true } },
    },
  });

  let totalMinutes = 0;
  let toInvoiceCents = 0;
  let toPaySubcontractorsCents = 0;

  for (const e of entries) {
    const mins = e.minutesWorked ?? 0;
    totalMinutes += mins;
    const empRate = e.shift?.employerRateCents ?? 0;
    const workerRate = e.shift?.workerRateCents ?? 0;

    // cents-per-hour * (minutes/60)
    toInvoiceCents += Math.round((empRate * mins) / 60);
    if (e.user?.subcontractorId) {
      toPaySubcontractorsCents += Math.round((workerRate * mins) / 60);
    }
  }

  // Extra costs: count once per shift in range (shift startAt within range)
  const costs = await prisma.shiftExtraCost.findMany({
    where: {
      shift: { startAt: { gte: startAt, lte: endAt }, isDeleted: false },
    },
    select: { amountCents: true },
  });
  const extraCostsCents = costs.reduce((sum, c) => sum + (c.amountCents ?? 0), 0);
  toInvoiceCents += extraCostsCents;

  res.setHeader('Cache-Control', 'no-store');
  res.json({
    kpis: {
      start,
      end,
      totalMinutes,
      totalHours: Math.round((totalMinutes / 60) * 100) / 100,
      toInvoiceCents,
      toPaySubcontractorsCents,
      extraCostsCents,
    },
  });
}

// More detailed KPI insights for admin dashboards (series + top lists)
export async function adminKpisSeries(req: any, res: any) {
  if (req.user?.role !== 'ADMIN') throw new HttpError(403, 'Forbidden');
  const { start, end } = kpiRangeSchema.parse(req.query ?? {});
  const startAt = parseDateParam(start);
  const endAt = parseDateParam(end, { endOfDay: true });

  const entries = await prisma.timeEntry.findMany({
    where: {
      clockInAt: { gte: startAt, lte: endAt },
      clockOutAt: { not: null },
      shift: { isDeleted: false },
    },
    select: {
      minutesWorked: true,
      clockInAt: true,
      shiftId: true,
      shift: {
        select: {
          employerRateCents: true,
          workerRateCents: true,
          location: { select: { id: true, name: true } },
        },
      },
      user: { select: { id: true, fullName: true, email: true, subcontractorId: true } },
    },
  });

  const startOfIsoWeek = (d: Date) => {
    const date = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
    const day = date.getUTCDay() || 7; // 1..7 (Mon..Sun)
    date.setUTCDate(date.getUTCDate() - day + 1);
    date.setUTCHours(0, 0, 0, 0);
    return date;
  };

  const weekKey = (d: Date) => startOfIsoWeek(d).toISOString().slice(0, 10);
  const seriesMap = new Map<string, any>();
  const locMap = new Map<string, { id: string; name: string; totalMinutes: number }>();
  const workerMap = new Map<string, { id: string; name: string; totalMinutes: number }>();

  for (const e of entries as any[]) {
    const mins = Number(e.minutesWorked ?? 0);
    const wk = weekKey(new Date(e.clockInAt));
    const item = seriesMap.get(wk) ?? { weekStart: wk, totalMinutes: 0, toInvoiceCents: 0, toPayCents: 0, uniqueShifts: new Set<string>() };
    item.totalMinutes += mins;
    item.toInvoiceCents += Math.round((Number(e.shift?.employerRateCents ?? 0) * mins) / 60);
    // Pay is relevant for subcontractor users (same as adminKpis logic)
    if (e.user?.subcontractorId) {
      item.toPayCents += Math.round((Number(e.shift?.workerRateCents ?? 0) * mins) / 60);
    }
    if (e.shiftId) item.uniqueShifts.add(String(e.shiftId));
    seriesMap.set(wk, item);

    const loc = e.shift?.location;
    if (loc?.id) {
      const cur = locMap.get(loc.id) ?? { id: loc.id, name: loc.name, totalMinutes: 0 };
      cur.totalMinutes += mins;
      locMap.set(loc.id, cur);
    }

    const u = e.user;
    if (u?.id) {
      const label = u.fullName || u.email;
      const cur = workerMap.get(u.id) ?? { id: u.id, name: label, totalMinutes: 0 };
      cur.totalMinutes += mins;
      workerMap.set(u.id, cur);
    }
  }

  const series = Array.from(seriesMap.values())
    .map((s: any) => ({
      weekStart: s.weekStart,
      totalMinutes: s.totalMinutes,
      totalHours: Math.round((s.totalMinutes / 60) * 100) / 100,
      toInvoiceCents: s.toInvoiceCents,
      toPayCents: s.toPayCents,
      shiftCount: (s.uniqueShifts as Set<string>).size,
    }))
    .sort((a: any, b: any) => String(a.weekStart).localeCompare(String(b.weekStart)));

  const topLocations = Array.from(locMap.values())
    .sort((a, b) => b.totalMinutes - a.totalMinutes)
    .slice(0, 8)
    .map((l) => ({ ...l, totalHours: Math.round((l.totalMinutes / 60) * 100) / 100 }));

  const topWorkers = Array.from(workerMap.values())
    .sort((a, b) => b.totalMinutes - a.totalMinutes)
    .slice(0, 8)
    .map((u) => ({ ...u, totalHours: Math.round((u.totalMinutes / 60) * 100) / 100 }));

  const [openShifts, assignedShifts, completedShifts] = await prisma.$transaction([
    prisma.shift.count({ where: { isDeleted: false, status: 'OPEN', startAt: { gte: startAt, lte: endAt } } }),
    prisma.shift.count({ where: { isDeleted: false, status: 'ASSIGNED', startAt: { gte: startAt, lte: endAt } } }),
    prisma.shift.count({ where: { isDeleted: false, status: 'COMPLETED', startAt: { gte: startAt, lte: endAt } } }),
  ]);

  res.setHeader('Cache-Control', 'no-store');
  res.json({
    range: { start, end },
    series,
    topLocations,
    topWorkers,
    shiftCounts: { open: openShifts, assigned: assignedShifts, completed: completedShifts },
  });
}
