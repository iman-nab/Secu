import { z } from 'zod';
import jwt from 'jsonwebtoken';
import { env } from '../config/env.js';
import * as Auth from '../services/authService.js';
import * as Invites from '../services/inviteService.js';
import { HttpError } from '../utils/http.js';
import { logAudit } from '../services/auditService.js';
import type { $Enums } from '@prisma/client';


const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6),
});

const createInviteSchema = z.object({
  email: z.string().email(),
  fullName: z.string().min(2),
  role: z.enum(['ADMIN','EMPLOYEE','CLIENT','SUBCONTRACTOR']),
  clientId: z.string().cuid().optional().nullable(),
  subcontractorId: z.string().cuid().optional().nullable(),
  expiresInHours: z.number().int().positive().max(240).optional(),
  passColor: z.enum(['GRAY','DARK_BLUE','LIGHT_BLUE','ORANGE','GREEN','BLACK']).optional().nullable(),
}).superRefine((val, ctx) => {
  if (val.role === 'EMPLOYEE' && !val.passColor) {
    ctx.addIssue({ code: z.ZodIssueCode.custom, path: ['passColor'], message: 'passColor is required for EMPLOYEE invites' });
  }
});

const signupSchema = z.object({
  token: z.string().min(10),
  password: z.string().min(12),
  phone: z.string().optional(),
  birthDate: z.string().optional(),
  passColor: z.enum(['GRAY','DARK_BLUE','LIGHT_BLUE','ORANGE','GREEN','BLACK']).optional(),
});

const twoFaSetupSchema = z.object({});

const twoFaEnableSchema = z.object({
  code: z.string().min(4),
});

const twoFaVerifySchema = z.object({
  tempToken: z.string().min(10),
  code: z.string().min(4),
});


const cookieBase = () => {
  const base: any = {
    httpOnly: true,
    sameSite: 'lax' as const,
    secure: env.NODE_ENV === 'production',
    path: '/',
  };

  // Only set cookie domain when it is actually provided.
  // An empty string would create an invalid "Domain=" attribute that Chrome rejects.
  if (env.COOKIE_DOMAIN && env.COOKIE_DOMAIN.trim()) {
    base.domain = env.COOKIE_DOMAIN.trim();
  }

  return base;
};

const setAuthCookies = (res: any, tokens: { access: string; refresh: string }) => {
  res.cookie('access_token', tokens.access, { ...cookieBase(), maxAge: env.ACCESS_TOKEN_TTL_MIN * 60_000 });
  res.cookie('refresh_token', tokens.refresh, { ...cookieBase(), maxAge: env.REFRESH_TOKEN_TTL_DAYS * 24 * 60 * 60_000 });
};

const clearAuthCookies = (res: any) => {
  res.clearCookie('access_token', { ...cookieBase() });
  res.clearCookie('refresh_token', { ...cookieBase() });
};

export async function postLogin(req: any, res: any) {
  const { email, password } = loginSchema.parse(req.body);
  const result = await Auth.login(email, password);
  if (result.twoFactorRequired) {
    res.json({ twoFactorRequired: true, tempToken: result.tempToken, user: result.user });
    return;
  }
  setAuthCookies(res, { access: result.access, refresh: result.refresh });
  res.json({ twoFactorRequired: false, user: result.user });
}

export async function post2faVerify(req: any, res: any) {
  const { tempToken, code } = twoFaVerifySchema.parse(req.body);
  const result = await Auth.verify2faLogin(tempToken, code);
  setAuthCookies(res, { access: result.access, refresh: result.refresh });
  await logAudit({ actorId: result.user.id, action: '2FA_LOGIN_VERIFIED', entity: 'User', entityId: result.user.id, before: null, after: { twoFactor: true } });
  res.json({ user: result.user });
}

export async function postRefresh(req: any, res: any) {
  const token = req.cookies?.refresh_token;
  if (!token) throw new HttpError(401, 'Missing refresh token');

  let payload: any;
  try {
    payload = jwt.verify(token, env.JWT_REFRESH_SECRET);
  } catch {
    throw new HttpError(401, 'Invalid refresh token');
  }

  const { access, refresh, user } = await Auth.refresh(payload.sub, token);
  setAuthCookies(res, { access, refresh });
  res.json({ user });
}

export async function postLogout(req: any, res: any) {
  if (req.user?.id) await Auth.logout(req.user.id);
  clearAuthCookies(res);
  res.json({ ok: true });
}

export async function getMe(req: any, res: any) {
  if (!req.user?.id) throw new HttpError(401, 'Not authenticated');
  const user = await Auth.me(req.user.id);
  res.json({ user });
}

// -------------------- Phase 1: new invite/signup flow --------------------

// Admin/Subcontractor: create invite
export async function postCreateInvite(req: any, res: any) {
  if (!req.user?.id) throw new HttpError(401, 'Not authenticated');
  const body = createInviteSchema.parse(req.body);
  const invite = await Invites.createInvite({ id: req.user.id, role: req.user.role as $Enums.Role }, {
    email: body.email,
    fullName: body.fullName,
    role: body.role as $Enums.Role,
    clientId: body.clientId ?? null,
    subcontractorId: body.subcontractorId ?? null,
    expiresInHours: body.expiresInHours,
  });
  res.status(201).json({ invite: { token: invite.token, expiresAt: invite.expiresAt, role: invite.role, email: invite.email, fullName: invite.fullName } });
}

// Public: validate invite token
export async function getInviteV2(req: any, res: any) {
  const token = String(req.params.token || '').trim();
  if (!token) throw new HttpError(400, 'Missing token');
  const invite = await Invites.getInvitePublic(token);
  res.json({
    email: invite.email,
    fullName: invite.fullName,
    role: invite.role,
    passColor: (invite as any).passColor ?? null,
    expiresAt: invite.expiresAt,
  });
}

// Public: signup via invite
export async function postSignup(req: any, res: any) {
  const body = signupSchema.parse(req.body);
  const user = await Invites.consumeInviteAndCreateUser(body.token, {
    password: body.password,
    phone: body.phone ?? null,
    birthDate: body.birthDate ?? null,
    passColor: body.passColor ?? null,
  });
  res.json({ ok: true, user: { id: user.id, email: user.email, fullName: user.fullName, role: user.role } });
}

// -------------------- Phase 1: 2FA setup/enabled --------------------

export async function post2faSetup(req: any, res: any) {
  twoFaSetupSchema.parse(req.body ?? {});
  if (!req.user?.id) throw new HttpError(401, 'Not authenticated');
  const result = await Auth.twoFactorSetup(req.user.id);
  res.json(result);
}

export async function post2faEnable(req: any, res: any) {
  const { code } = twoFaEnableSchema.parse(req.body);
  if (!req.user?.id) throw new HttpError(401, 'Not authenticated');
  const result = await Auth.twoFactorEnable(req.user.id, code);
  setAuthCookies(res, { access: result.access, refresh: result.refresh });
  await logAudit({ actorId: req.user.id, action: '2FA_ENABLED', entity: 'User', entityId: req.user.id, before: null, after: { enabled: true } });
  res.json({ user: result.user });
}

export const authCookies = { setAuthCookies, clearAuthCookies };
