import type { $Enums } from '@prisma/client';


declare global {
  namespace Express {
    interface Request {
      user?: { id: string; role: $Enums.Role };
    }
  }
}
export {};
