import { Router } from 'express';
import { asyncHandler } from '../utils/http.js';
import { authLimiter, loginLimiter, verify2faLimiter } from '../middleware/rateLimit.js';
import { requireAuth, require2FA } from '../middleware/auth.js';
import * as Auth from '../controllers/authController.js';

export const authRoutes = Router();

authRoutes.post('/login', loginLimiter, asyncHandler(Auth.postLogin));
authRoutes.post('/refresh', authLimiter, asyncHandler(Auth.postRefresh));
// Allow logout even if access token is expired/missing; we still want to clear cookies.
authRoutes.post('/logout', asyncHandler(Auth.postLogout));
authRoutes.get('/me', requireAuth, asyncHandler(Auth.getMe));

// Phase 1: invite/signup flow
authRoutes.post('/invites', requireAuth, require2FA, asyncHandler(Auth.postCreateInvite));
authRoutes.get('/invites/:token', asyncHandler(Auth.getInviteV2));
authRoutes.post('/signup', authLimiter, asyncHandler(Auth.postSignup));

// Phase 1: 2FA
authRoutes.post('/2fa/setup', requireAuth, asyncHandler(Auth.post2faSetup));
authRoutes.post('/2fa/enable', requireAuth, asyncHandler(Auth.post2faEnable));
authRoutes.post('/2fa/verify', verify2faLimiter, asyncHandler(Auth.post2faVerify));

