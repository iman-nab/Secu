import { Router } from 'express';
import { asyncHandler } from '../utils/http.js';
import { requireAuth, requireRole, require2FA } from '../middleware/auth.js';
import * as Requests from '../controllers/requestsController.js';

export const requestsRoutes = Router();

requestsRoutes.use(requireAuth, require2FA, requireRole('ADMIN'));

requestsRoutes.get('/', asyncHandler(Requests.list));
requestsRoutes.patch('/:id', asyncHandler(Requests.updateStatus));
requestsRoutes.post('/:id/convert-to-shift', asyncHandler(Requests.convertToShift));
requestsRoutes.get('/:id/activity', asyncHandler(Requests.activity));
