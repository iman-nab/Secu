import { Router } from 'express';
import { asyncHandler } from '../utils/http.js';
import { requireAuth, require2FA, requireRole } from '../middleware/auth.js';
import * as Push from '../controllers/pushController.js';
import * as AdminPush from '../controllers/adminPushController.js';

export const pushRoutes = Router();

pushRoutes.get('/vapid-public-key', asyncHandler(Push.vapidPublicKey));

pushRoutes.use(requireAuth, require2FA);

pushRoutes.post('/subscribe', asyncHandler(Push.subscribe));
pushRoutes.post('/unsubscribe', asyncHandler(Push.unsubscribe));

// Phase 9: admin push composer + targeting
pushRoutes.post('/send', requireRole('ADMIN'), asyncHandler(AdminPush.send));
