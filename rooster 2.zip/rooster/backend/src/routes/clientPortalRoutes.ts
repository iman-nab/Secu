import { Router } from 'express';
import { asyncHandler } from '../utils/http.js';
import { requireAuth, requireRole, require2FA } from '../middleware/auth.js';
import * as ClientPortal from '../controllers/clientPortalController.js';

export const clientPortalRoutes = Router();

clientPortalRoutes.use(requireAuth, require2FA, requireRole('CLIENT'));

clientPortalRoutes.get('/me', asyncHandler(ClientPortal.me));
clientPortalRoutes.get('/shifts', asyncHandler(ClientPortal.listShifts));
clientPortalRoutes.get('/shifts/:id/notes', asyncHandler(ClientPortal.listShiftNotes));
clientPortalRoutes.post('/shifts/:id/notes', asyncHandler(ClientPortal.createShiftNote));
