import { Router } from 'express';
import { asyncHandler } from '../utils/http.js';
import { requireAuth, require2FA } from '../middleware/auth.js';
import * as Notifications from '../controllers/notificationsController.js';

export const notificationsRoutes = Router();
notificationsRoutes.use(requireAuth, require2FA);

notificationsRoutes.get('/', asyncHandler(Notifications.list));
notificationsRoutes.get('/unread-count', asyncHandler(Notifications.unreadCount));
notificationsRoutes.post('/:id/read', asyncHandler(Notifications.markRead));
notificationsRoutes.post('/read-all', asyncHandler(Notifications.markAllRead));

