import { Router } from 'express';
import { asyncHandler } from '../utils/http.js';
import { requireAuth, requireRole, require2FA } from '../middleware/auth.js';
import * as Client from '../controllers/clientController.js';

export const clientRoutes = Router();

clientRoutes.use(requireAuth, require2FA, requireRole('CLIENT'));

clientRoutes.get('/analytics/incidents', asyncHandler(Client.incidentsAnalytics));
clientRoutes.get('/requests', asyncHandler(Client.listRequests));
clientRoutes.post('/requests', asyncHandler(Client.createRequest));
