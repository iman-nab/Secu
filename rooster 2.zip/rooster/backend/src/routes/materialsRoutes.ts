import { Router } from 'express';
import * as Materials from '../controllers/materialsController.js';
import { requireAuth, require2FA } from '../middleware/auth.js';

export const materialsRoutes = Router();

// Assignments (static routes first, to avoid ':id' catch-all)
materialsRoutes.get('/assignments', requireAuth, require2FA, Materials.listAssignments);
materialsRoutes.get('/assignments/me', requireAuth, require2FA, Materials.listMyAssignments);
materialsRoutes.post('/assignments', requireAuth, require2FA, Materials.createAssignment);
materialsRoutes.post('/assignments/:id/return', requireAuth, require2FA, Materials.returnAssignment);
materialsRoutes.post('/assignments/:id/report', requireAuth, require2FA, Materials.reportIssue);

// History (admin)
materialsRoutes.get('/history', requireAuth, require2FA, Materials.listHistory);

// Catalog + inventory
materialsRoutes.get('/', requireAuth, require2FA, Materials.list);
materialsRoutes.post('/', requireAuth, require2FA, Materials.create);
materialsRoutes.patch('/:id', requireAuth, require2FA, Materials.update);
materialsRoutes.post('/:id/stock', requireAuth, require2FA, Materials.adjustStock);
materialsRoutes.delete('/:id', requireAuth, require2FA, Materials.remove);
