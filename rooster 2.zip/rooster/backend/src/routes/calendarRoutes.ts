import { Router } from 'express';
import { asyncHandler } from '../utils/http.js';
import { requireAuth, require2FA } from '../middleware/auth.js';
import * as Calendar from '../controllers/calendarController.js';

export const calendarRoutes = Router();

// Authenticated helper to copy your ICS feed link
calendarRoutes.get('/me', requireAuth, require2FA, asyncHandler(Calendar.myCalendarToken));

// Public ICS feed (secret-by-URL)
calendarRoutes.get('/:token.ics', asyncHandler(Calendar.calendarIcs));
