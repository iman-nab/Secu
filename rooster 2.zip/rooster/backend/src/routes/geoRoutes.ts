import { Router } from 'express';
import { geoSearch, geoReverse } from '../controllers/geoController.js';
import { requireAuth, require2FA } from '../middleware/auth.js';

export const geoRoutes = Router();

// Keep it behind auth so random internet traffic doesn't abuse your instance.
geoRoutes.get('/search', requireAuth, require2FA, geoSearch);

geoRoutes.get('/reverse', requireAuth, require2FA, geoReverse);
