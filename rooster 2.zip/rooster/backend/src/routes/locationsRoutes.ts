import { Router } from 'express';
import { asyncHandler } from '../utils/http.js';
import { requireAuth, requireRole, require2FA } from '../middleware/auth.js';
import * as Locations from '../controllers/locationsController.js';

export const locationsRoutes = Router();
locationsRoutes.use(requireAuth, require2FA, requireRole('ADMIN'));

locationsRoutes.get('/', asyncHandler(Locations.list));
locationsRoutes.post('/', asyncHandler(Locations.create));
locationsRoutes.patch('/:id', asyncHandler(Locations.update));
locationsRoutes.delete('/:id', asyncHandler(Locations.remove));
