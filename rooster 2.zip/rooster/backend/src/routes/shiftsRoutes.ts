import { Router } from 'express';
import { asyncHandler } from '../utils/http.js';
import { requireAuth, requireRole, require2FA } from '../middleware/auth.js';
import { clockLimiter, writeLimiter } from '../middleware/rateLimit.js';
import * as Shifts from '../controllers/shiftsController.js';
import * as ShiftReports from '../controllers/shiftReportsController.js';

export const shiftsRoutes = Router();

shiftsRoutes.use(requireAuth, require2FA);

shiftsRoutes.get('/', asyncHandler(Shifts.list));
// Lightweight calendar summary (reduced relations) for Agenda/Week views
shiftsRoutes.get('/calendar', asyncHandler(Shifts.calendarSummary));
shiftsRoutes.get('/open', asyncHandler(Shifts.openList));

shiftsRoutes.post('/', requireRole('ADMIN'), asyncHandler(Shifts.create));
shiftsRoutes.post('/bulk-week', requireRole('ADMIN'), asyncHandler(Shifts.bulkCreateWeek));
shiftsRoutes.post('/repeat-weekly', requireRole('ADMIN'), asyncHandler(Shifts.repeatWeekly));
shiftsRoutes.patch('/:id', requireRole('ADMIN'), asyncHandler(Shifts.update));
shiftsRoutes.delete('/:id', requireRole('ADMIN'), asyncHandler(Shifts.remove));

// Phase 7: rates + extra costs (admin only)
shiftsRoutes.patch('/:id/rates', requireRole('ADMIN'), asyncHandler(Shifts.updateRates));
shiftsRoutes.post('/:id/extra-costs', requireRole('ADMIN'), asyncHandler(Shifts.addExtraCost));
shiftsRoutes.patch('/:id/extra-costs/:costId', requireRole('ADMIN'), asyncHandler(Shifts.updateExtraCost));
shiftsRoutes.delete('/:id/extra-costs/:costId', requireRole('ADMIN'), asyncHandler(Shifts.deleteExtraCost));


// Admin-only activity feed (audit logs) for a shift
shiftsRoutes.get('/:id/activity', requireRole('ADMIN'), asyncHandler(Shifts.activity));
shiftsRoutes.get('/:id', asyncHandler(Shifts.get));

// Pin/unpin shift notes (ADMIN or owning CLIENT)
shiftsRoutes.patch('/:id/notes/:noteId/pin', asyncHandler(Shifts.pinNote));

shiftsRoutes.post('/:id/request', writeLimiter, asyncHandler(Shifts.request));
shiftsRoutes.post('/:id/assign', requireRole('ADMIN'), asyncHandler(Shifts.assign));
shiftsRoutes.post('/:id/unassign', requireRole('ADMIN'), asyncHandler(Shifts.unassign));

shiftsRoutes.post('/:id/review', writeLimiter, requireRole('ADMIN'), asyncHandler(Shifts.review));

shiftsRoutes.post('/:id/clock-in', clockLimiter, asyncHandler(Shifts.clockIn));
shiftsRoutes.post('/:id/clock-out', clockLimiter, asyncHandler(Shifts.clockOut));

// Admin remote clock-in (bypass geofence)
shiftsRoutes.post('/:id/admin-clock-in', requireRole('ADMIN'), asyncHandler(Shifts.adminClockIn));

// Admin remote clock-out (close active time entry)
shiftsRoutes.post('/:id/admin-clock-out', requireRole('ADMIN'), asyncHandler(Shifts.adminClockOut));

// admin corrections
shiftsRoutes.patch('/:id/time-entries/:timeEntryId', requireRole('ADMIN'), asyncHandler(Shifts.adminCorrectTime));
shiftsRoutes.delete('/:id/time-entries/:timeEntryId', requireRole('ADMIN'), asyncHandler(Shifts.adminResetTime));

// Phase 4: Day report (dagrapportage) + attachments + PDF export
shiftsRoutes.get('/:id/report', asyncHandler(ShiftReports.getReport));
shiftsRoutes.put('/:id/report', writeLimiter, asyncHandler(ShiftReports.upsertReport));
shiftsRoutes.post('/:id/report/attachments', writeLimiter, asyncHandler(ShiftReports.createAttachment));
shiftsRoutes.get('/:id/report/attachments/:attachmentId', asyncHandler(ShiftReports.downloadAttachment));
shiftsRoutes.delete('/:id/report/attachments/:attachmentId', writeLimiter, asyncHandler(ShiftReports.removeAttachment));
shiftsRoutes.get('/:id/report/pdf', asyncHandler(ShiftReports.exportPdf));
