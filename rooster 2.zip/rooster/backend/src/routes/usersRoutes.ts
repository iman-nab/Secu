import { Router } from 'express';
import { asyncHandler } from '../utils/http.js';
import { requireAuth, requireRole, require2FA } from '../middleware/auth.js';
import * as Users from '../controllers/usersController.js';

export const usersRoutes = Router();

usersRoutes.use(requireAuth, require2FA, requireRole('ADMIN'));

usersRoutes.get('/', asyncHandler(Users.list));
usersRoutes.post('/', asyncHandler(Users.create));
usersRoutes.get('/:id', asyncHandler(Users.get));
usersRoutes.patch('/:id', asyncHandler(Users.update));

// Admin: reset security for a user
usersRoutes.post('/:id/reset-2fa', asyncHandler(Users.reset2FA));
usersRoutes.post('/:id/reset-password', asyncHandler(Users.resetPassword));

// Reactivate a soft-deleted (inactive) account. Best-effort restores the original email when possible.
usersRoutes.post('/:id/reactivate', asyncHandler(Users.reactivate));

usersRoutes.delete('/:id', asyncHandler(Users.remove));
