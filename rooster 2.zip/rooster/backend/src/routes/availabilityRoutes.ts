import { Router } from 'express';
import { requireAuth, require2FA, requireRole } from '../middleware/auth.js';
import { createMe, createUser, deleteOne, listMe, listUser, updateOne } from '../controllers/availabilityController.js';

export const availabilityRoutes = Router();

availabilityRoutes.use(requireAuth, require2FA);

// Employee: manage own availability
availabilityRoutes.get('/me', listMe);
availabilityRoutes.post('/me', createMe);

// Admin/Subcontractor: view availability for a user (scope enforced in service)
availabilityRoutes.get('/user/:userId', listUser);

// Admin: create availability for a user
availabilityRoutes.post('/user/:userId', requireRole('ADMIN'), createUser);

availabilityRoutes.patch('/:id', updateOne);
availabilityRoutes.delete('/:id', deleteOne);
