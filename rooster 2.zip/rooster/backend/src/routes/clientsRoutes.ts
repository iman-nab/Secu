import { Router } from 'express';
import { asyncHandler } from '../utils/http.js';
import { requireAuth, require2FA } from '../middleware/auth.js';
import * as Clients from '../controllers/clientsController.js';

export const clientsRoutes = Router();
clientsRoutes.use(requireAuth, require2FA);

clientsRoutes.get('/', asyncHandler(Clients.list));
clientsRoutes.post('/', asyncHandler(Clients.create));
clientsRoutes.post('/onboard', asyncHandler(Clients.onboard));
clientsRoutes.post('/:id/regenerate-invite', asyncHandler(Clients.regenerateInvite));
clientsRoutes.post('/:id/create-portal-user', asyncHandler(Clients.createPortalUser));
clientsRoutes.patch('/:id', asyncHandler(Clients.update));
clientsRoutes.delete('/:id', asyncHandler(Clients.remove));
