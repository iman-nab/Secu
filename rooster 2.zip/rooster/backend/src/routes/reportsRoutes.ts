import { Router } from 'express';
import { asyncHandler } from '../utils/http.js';
import { requireAuth, require2FA } from '../middleware/auth.js';
import * as Reports from '../controllers/reportsController.js';

export const reportsRoutes = Router();
reportsRoutes.use(requireAuth, require2FA);

reportsRoutes.get('/hours', asyncHandler(Reports.hours));
reportsRoutes.get('/hours/export', asyncHandler(Reports.exportHours));
