import { Router } from 'express';
import { asyncHandler } from '../utils/http.js';
import { requireAuth, requireRole, require2FA } from '../middleware/auth.js';
import * as Dashboard from '../controllers/dashboardController.js';

export const dashboardRoutes = Router();
dashboardRoutes.use(requireAuth, require2FA);
dashboardRoutes.get('/next-requested', requireRole('ADMIN'), asyncHandler(Dashboard.nextRequestedShift));
// Phase 7: admin KPI dashboard
dashboardRoutes.get('/admin/kpis', requireRole('ADMIN'), asyncHandler(Dashboard.adminKpis));
dashboardRoutes.get('/admin/kpis/series', requireRole('ADMIN'), asyncHandler(Dashboard.adminKpisSeries));

// Employee quick view: next shift the user has reacted to (REQUESTED or APPROVED)
dashboardRoutes.get('/me/next-reacted', asyncHandler(Dashboard.myNextReactedShift));
