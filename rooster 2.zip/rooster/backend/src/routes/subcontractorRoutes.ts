import { Router } from 'express';
import { asyncHandler } from '../utils/http.js';
import { requireAuth, require2FA, requireRole } from '../middleware/auth.js';
import * as Sub from '../controllers/subcontractorController.js';

export const subcontractorRoutes = Router();

subcontractorRoutes.use(requireAuth, require2FA, requireRole('SUBCONTRACTOR'));

subcontractorRoutes.get('/me', asyncHandler(Sub.me));
subcontractorRoutes.get('/workers', asyncHandler(Sub.listWorkers));
subcontractorRoutes.patch('/workers/:id', asyncHandler(Sub.updateWorkerPassColor));
subcontractorRoutes.get('/shifts', asyncHandler(Sub.listShifts));
subcontractorRoutes.get('/reports', asyncHandler(Sub.listReports));
subcontractorRoutes.get('/hours', asyncHandler(Sub.hours));
subcontractorRoutes.post('/exports/weekly', asyncHandler(Sub.weeklyExportPdf));
