import dotenv from 'dotenv';
dotenv.config();

const required = (key: string): string => {
  const v = process.env[key];
  if (!v) throw new Error(`Missing env var: ${key}`);
  return v;
};

export const env = {
  NODE_ENV: process.env.NODE_ENV ?? 'development',
  APP_VERSION: process.env.APP_VERSION ?? '1.0.0',
  PORT: Number(process.env.PORT ?? 4000),
  DATABASE_URL: required('DATABASE_URL'),
  JWT_ACCESS_SECRET: required('JWT_ACCESS_SECRET'),
  JWT_REFRESH_SECRET: required('JWT_REFRESH_SECRET'),
  ACCESS_TOKEN_TTL_MIN: Number(process.env.ACCESS_TOKEN_TTL_MIN ?? 15),
  REFRESH_TOKEN_TTL_DAYS: Number(process.env.REFRESH_TOKEN_TTL_DAYS ?? 30),
  COOKIE_DOMAIN: process.env.COOKIE_DOMAIN ?? undefined,
  CORS_ORIGIN: required('CORS_ORIGIN'),
  GPS_ACCURACY_THRESHOLD_M: Number(process.env.GPS_ACCURACY_THRESHOLD_M ?? 50),
  CLOCK_IN_EARLY_MINUTES: Number(process.env.CLOCK_IN_EARLY_MINUTES ?? 15),
  CLOCK_IN_LATE_MINUTES: Number(process.env.CLOCK_IN_LATE_MINUTES ?? 60),
  // Reminder before shift end (used for clock-out reminders)
  CLOCK_OUT_REMINDER_MINUTES: Number(process.env.CLOCK_OUT_REMINDER_MINUTES ?? 15),

  // No-show alert: notify admins when an assigned employee has not clocked in after X minutes.
  NO_SHOW_GRACE_MINUTES: Number(process.env.NO_SHOW_GRACE_MINUTES ?? 15),

  // App URL (used for invite links in emails)
  APP_BASE_URL: process.env.APP_BASE_URL ?? '',

  // Mail mode:
  // - manual: never send email (admin copies invite link manually)
  // - smtp: send email via SMTP config below
  MAIL_MODE: (process.env.MAIL_MODE ?? 'manual') as 'manual' | 'smtp',

  // SMTP (optional) - if not set, the app will log invite links instead of emailing them
  SMTP_HOST: process.env.SMTP_HOST ?? '',
  SMTP_PORT: Number(process.env.SMTP_PORT ?? 587),
  SMTP_USER: process.env.SMTP_USER ?? '',
  SMTP_PASS: process.env.SMTP_PASS ?? '',
  SMTP_FROM: process.env.SMTP_FROM ?? 'no-reply@localhost',

  // Web Push (PWA push notifications)
  VAPID_SUBJECT: process.env.VAPID_SUBJECT ?? 'mailto:admin@example.com',
  VAPID_PUBLIC_KEY: process.env.VAPID_PUBLIC_KEY ?? '',
  VAPID_PRIVATE_KEY: process.env.VAPID_PRIVATE_KEY ?? '',
};
