import { shiftsOverlap } from '../utils/shift.js';
import { prisma } from '../db/prisma.js';
import { HttpError } from '../utils/http.js';
import { ShiftConflictError } from '../utils/domainErrors.js';
import type { Prisma, PrismaClient } from '@prisma/client';

type DbClient = Prisma.TransactionClient | PrismaClient;

async function assertNoAvailabilityOverlap(userId: string, startAt: Date, endAt: Date, db: DbClient = prisma) {
  const conflict = await db.userAvailability.findFirst({
    where: {
      userId,
      startAt: { lt: endAt },
      endAt: { gt: startAt },
    },
    orderBy: { startAt: 'asc' },
  });

  if (!conflict) return;

  throw new HttpError(
    409,
    'Niet beschikbaar in deze periode (beschikbaarheid overlapt)',
    'AVAILABILITY_OVERLAP',
    {
      availabilityId: conflict.id,
      availabilityType: conflict.type,
      availabilityStartAt: conflict.startAt,
      availabilityEndAt: conflict.endAt,
    },
  );
}

// Title uniqueness policy (product decision): avoid duplicates for the same location + same calendar day.
// This prevents confusion in planning lists and in duplication flows.
function dayBounds(d: Date) {
  const start = new Date(d);
  start.setHours(0, 0, 0, 0);
  const end = new Date(d);
  end.setHours(23, 59, 59, 999);
  return { start, end };
}

async function titleExistsOnDay(db: DbClient, args: { title: string; locationId: string; startAt: Date; excludeId?: string }) {
  const { start, end } = dayBounds(args.startAt);
  const found = await db.shift.findFirst({
    where: {
      isDeleted: false,
      locationId: args.locationId,
      title: args.title,
      startAt: { gte: start, lte: end },
      ...(args.excludeId ? { id: { not: args.excludeId } } : {}),
    },
    select: { id: true },
  });
  return !!found;
}

async function ensureUniqueTitleOrThrow(db: DbClient, args: { title: string; locationId: string; startAt: Date; excludeId?: string }) {
  const title = String(args.title ?? '').trim();
  if (!title) throw new HttpError(400, 'Title is required', 'TITLE_REQUIRED');
  const exists = await titleExistsOnDay(db, { ...args, title });
  if (exists) {
    throw new HttpError(409, 'Er bestaat al een dienst met dezelfde naam op deze dag (zelfde locatie).', 'SHIFT_TITLE_DUPLICATE');
  }
}

async function makeUniqueTitle(db: DbClient, args: { title: string; locationId: string; startAt: Date }) {
  const base = String(args.title ?? '').trim() || 'Dienst';
  if (!(await titleExistsOnDay(db, { ...args, title: base }))) return base;

  // Add a human-friendly suffix.
  for (let i = 2; i < 100; i++) {
    const candidate = `${base} (${i})`;
    if (!(await titleExistsOnDay(db, { ...args, title: candidate }))) return candidate;
  }
  // Fallback: append timestamp
  return `${base} (${args.startAt.toISOString().slice(11, 16)})`;
}

export async function listShiftsForAdmin(
  range?: { start: Date; end: Date },
  opts?: {
    includeDeleted?: boolean;
    clientId?: string;
    locationId?: string;
    type?: string;
    requiredPassColor?: string;
  },
) {
  const includeDeleted = Boolean(opts?.includeDeleted);
  return prisma.shift.findMany({
    where: {
      ...(includeDeleted ? {} : { isDeleted: false }),
      ...(range ? { startAt: { lt: range.end }, endAt: { gt: range.start } } : {}),
      ...(opts?.clientId ? { clientId: opts.clientId } : {}),
      ...(opts?.locationId ? { locationId: opts.locationId } : {}),
      ...(opts?.type ? { type: opts.type } : {}),
      ...(opts?.requiredPassColor ? { requiredPassColor: opts.requiredPassColor as any } : {}),
    },
    include: {
      location: true,
      client: true,
      extraCosts: { orderBy: { createdAt: 'asc' } },
      createdBy: { select: { id: true, fullName: true, email: true, role: true } },
      materials: { include: { material: true } },
      assignments: { include: { user: true, materials: { include: { material: true } } } },
    },
    orderBy: { startAt: 'asc' },
  });
}

// Calendar summary: keep the payload small to avoid heavy relations in week/month views.
export async function listShiftsCalendarSummaryForAdmin(
  range?: { start: Date; end: Date },
  opts?: {
    includeDeleted?: boolean;
    clientId?: string;
    locationId?: string;
    type?: string;
    requiredPassColor?: string;
    status?: string;
    assigneeId?: string;
    q?: string;
  },
) {
  const includeDeleted = Boolean(opts?.includeDeleted);
  const q = (opts?.q ?? '').trim();
  return prisma.shift.findMany({
    where: {
      ...(includeDeleted ? {} : { isDeleted: false }),
      ...(range ? { startAt: { lt: range.end }, endAt: { gt: range.start } } : {}),
      ...(opts?.clientId ? { clientId: opts.clientId } : {}),
      ...(opts?.locationId ? { locationId: opts.locationId } : {}),
      ...(opts?.type ? { type: opts.type } : {}),
      ...(opts?.requiredPassColor ? { requiredPassColor: opts.requiredPassColor as any } : {}),
      ...(opts?.status ? { status: opts.status as any } : {}),
      ...(opts?.assigneeId ? { assignments: { some: { userId: opts.assigneeId, status: 'APPROVED' } } } : {}),
      ...(q
        ? {
            OR: [
              { title: { contains: q, mode: 'insensitive' as any } },
              { location: { name: { contains: q, mode: 'insensitive' as any } } },
              { client: { name: { contains: q, mode: 'insensitive' as any } } },
              { id: { contains: q, mode: 'insensitive' as any } },
            ],
          }
        : {}),
    },
    select: {
      id: true,
      title: true,
      type: true,
      status: true,
      startAt: true,
      endAt: true,
      requiredWorkers: true,
      requiredPassColor: true,
      location: { select: { id: true, name: true } },
      client: { select: { id: true, name: true } },
      _count: { select: { assignments: true } },
    },
    orderBy: { startAt: 'asc' },
  });
}

export async function listShiftsCalendarSummaryForAdminPaged(
  range: { start: Date; end: Date } | undefined,
  opts: {
    includeDeleted?: boolean;
    clientId?: string;
    locationId?: string;
    type?: string;
    requiredPassColor?: string;
    status?: string;
    assigneeId?: string;
    q?: string;
    page: number;
    pageSize: number;
  },
) {
  const includeDeleted = Boolean(opts?.includeDeleted);
  const page = Math.max(1, opts.page || 1);
  const pageSize = Math.min(100, Math.max(1, opts.pageSize || 25));
  const q = (opts.q ?? '').trim();

  const where: any = {
    ...(includeDeleted ? {} : { isDeleted: false }),
    ...(range ? { startAt: { lt: range.end }, endAt: { gt: range.start } } : {}),
    ...(opts.clientId ? { clientId: opts.clientId } : {}),
    ...(opts.locationId ? { locationId: opts.locationId } : {}),
    ...(opts.type ? { type: opts.type } : {}),
    ...(opts.requiredPassColor ? { requiredPassColor: opts.requiredPassColor as any } : {}),
    ...(opts.status ? { status: opts.status as any } : {}),
    ...(opts.assigneeId ? { assignments: { some: { userId: opts.assigneeId, status: 'APPROVED' } } } : {}),
    ...(q
      ? {
          OR: [
            { title: { contains: q, mode: 'insensitive' as any } },
            { location: { name: { contains: q, mode: 'insensitive' as any } } },
            { client: { name: { contains: q, mode: 'insensitive' as any } } },
            { id: { contains: q, mode: 'insensitive' as any } },
          ],
        }
      : {}),
  };

  const [totalCount, items] = await prisma.$transaction([
    prisma.shift.count({ where }),
    prisma.shift.findMany({
      where,
      select: {
        id: true,
        title: true,
        type: true,
        status: true,
        startAt: true,
        endAt: true,
        requiredWorkers: true,
        requiredPassColor: true,
        location: { select: { id: true, name: true } },
        client: { select: { id: true, name: true } },
        _count: { select: { assignments: true } },
      },
      orderBy: { startAt: 'asc' },
      skip: (page - 1) * pageSize,
      take: pageSize,
    }),
  ]);

  return { items, totalCount };
}

export async function listShiftsCalendarSummaryForUser(
  userId: string,
  range?: { start: Date; end: Date },
) {
  return prisma.shift.findMany({
    where: {
      isDeleted: false,
      ...(range ? { startAt: { lt: range.end }, endAt: { gt: range.start } } : {}),
      assignments: { some: { userId, status: 'APPROVED' } },
    },
    select: {
      id: true,
      title: true,
      type: true,
      status: true,
      startAt: true,
      endAt: true,
      requiredWorkers: true,
      requiredPassColor: true,
      location: { select: { id: true, name: true } },
      client: { select: { id: true, name: true } },
      _count: { select: { assignments: true } },
    },
    orderBy: { startAt: 'asc' },
  });
}

export async function listShiftsForUser(userId: string, range?: { start: Date; end: Date }) {
  return prisma.shift.findMany({
    where: {
      isDeleted: false,
      ...(range ? { startAt: { lt: range.end }, endAt: { gt: range.start } } : {}),
      assignments: { some: { userId, status: 'APPROVED' } },
    },
    include: {
      location: true,
      client: true,
      createdBy: { select: { id: true, fullName: true, email: true, role: true } },
      // Extra costs should be visible to everyone who can see the shift.
      extraCosts: {
        orderBy: { createdAt: 'asc' },
        select: { id: true, description: true, amountCents: true, createdAt: true },
      },
      materials: { include: { material: true } },
      assignments: { include: { user: true, materials: { include: { material: true } } } },
    },
    orderBy: { startAt: 'asc' },
  });
}

export async function createShift(input: {
  title: string;
  description?: string;
  type?: string;
  requiredPassColor?: any;
  locationId: string;
  clientId?: string;
  requiredWorkers?: number;
  materials?: { materialId: string; quantity?: number }[];
  startAt: Date;
  endAt: Date;
  status: 'DRAFT' | 'OPEN' | 'ASSIGNED' | 'COMPLETED' | 'CANCELLED';
  // Title uniqueness: throw on duplicates for manual creation, but allow auto-suffix for duplication flows.
  titleUniqueness?: 'throw' | 'suffix';
  createdById: string;
}, db: DbClient = prisma) {
  // Support overnight shifts: if end <= start, move end to the next day.
  if (input.endAt <= input.startAt) {
    const nextEnd = new Date(input.endAt);
    nextEnd.setDate(nextEnd.getDate() + 1);
    input = { ...input, endAt: nextEnd };
  }
  const loc = await db.location.findUnique({ where: { id: input.locationId } });
  if (!loc || loc.isDeleted) throw new HttpError(400, 'Location not found');

  const { titleUniqueness, ...rest } = input as any;
  const titleMode = (titleUniqueness ?? 'throw') as 'throw' | 'suffix';
  const uniqueTitle =
    titleMode === 'suffix'
      ? await makeUniqueTitle(db, { title: rest.title, locationId: rest.locationId, startAt: rest.startAt })
      : (await ensureUniqueTitleOrThrow(db, { title: rest.title, locationId: rest.locationId, startAt: rest.startAt }), String(rest.title).trim());

  const materials = (input.materials || []).filter(Boolean);
  return db.shift.create({
    data: {
      ...rest,
      title: uniqueTitle,
      requiredWorkers: input.requiredWorkers ?? 1,
      materials: materials.length
        ? {
            create: materials.map((m) => ({ materialId: m.materialId, quantity: m.quantity ?? 1 })),
          }
        : undefined,
    },
  });
}

// Create a weekly repeating series for one shift template.
// For batches > 12 weeks we process in smaller transactions to avoid long locks.
export async function createWeeklyRepeatSeries(input: {
  title: string;
  description?: string;
  type?: string;
  requiredPassColor?: any;
  locationId: string;
  clientId?: string;
  requiredWorkers?: number;
  startAt: Date;
  endAt: Date;
  status?: 'DRAFT' | 'OPEN';
  repeatUntil: Date;
  intervalWeeks: number;
  assigneeIds?: string[];
  createdById: string;
}) {
  const intervalWeeks = Math.max(1, Math.min(12, Number(input.intervalWeeks || 1)));

  // Normalize overnight: if end <= start, move end to next day.
  let baseStart = new Date(input.startAt);
  let baseEnd = new Date(input.endAt);
  if (baseEnd.getTime() <= baseStart.getTime()) {
    baseEnd = new Date(baseEnd);
    baseEnd.setDate(baseEnd.getDate() + 1);
  }

  // Build occurrences (max 104 weeks).
  const maxWeeks = 104;
  const items: { startAt: Date; endAt: Date }[] = [];
  let curStart = new Date(baseStart);
  let curEnd = new Date(baseEnd);
  const until = new Date(input.repeatUntil);
  while (curStart.getTime() <= until.getTime() && items.length < maxWeeks) {
    items.push({ startAt: new Date(curStart), endAt: new Date(curEnd) });
    curStart.setDate(curStart.getDate() + intervalWeeks * 7);
    curEnd.setDate(curEnd.getDate() + intervalWeeks * 7);
  }

  const created: any[] = [];
  const allIds: string[] = [];
  const chunkSize = items.length > 12 ? 4 : items.length;

  try {
    for (let i = 0; i < items.length; i += chunkSize) {
      const chunk = items.slice(i, i + chunkSize);
      const chunkCreated = await prisma.$transaction(async (tx) => {
        const out: any[] = [];
        for (const occ of chunk) {
          const shift = await createShift(
            {
              title: input.title,
              description: input.description,
              type: input.type,
              requiredPassColor: input.requiredPassColor,
              locationId: input.locationId,
              clientId: input.clientId,
              requiredWorkers: input.requiredWorkers,
              startAt: occ.startAt,
              endAt: occ.endAt,
              status: ((input.status ?? 'OPEN') === 'DRAFT' ? 'OPEN' : (input.status ?? 'OPEN')) as any,
              createdById: input.createdById,
              titleUniqueness: 'suffix',
            },
            tx,
          );

          if (Array.isArray(input.assigneeIds) && input.assigneeIds.length > 0) {
            await assignMultiple(shift.id, input.assigneeIds, tx);
          }

          out.push(shift);
        }
        return out;
      });

      for (const s of chunkCreated) {
        created.push(s);
        allIds.push(s.id);
      }
    }
    return created;
  } catch (e) {
    if (allIds.length > 0) {
      try {
        await prisma.shift.deleteMany({ where: { id: { in: allIds } } });
      } catch {
        // ignore
      }
    }
    throw e;
  }
}

// Approve/assign multiple employees to a shift (used by admin create + weekplanner).
// This does NOT reject others; it simply creates APPROVED assignments and sets shift ASSIGNED.
export async function assignMultiple(shiftId: string, userIds: string[], db?: DbClient) {
  const uniq = Array.from(new Set((userIds || []).filter(Boolean)));
  if (uniq.length === 0) return;

  const shift = await prisma.shift.findUnique({ where: { id: shiftId } });
  if (!shift || shift.isDeleted) throw new HttpError(404, 'Shift not found');

  // Cancelled/completed shifts are read-only.
  if (shift.status === 'CANCELLED') {
    throw new HttpError(409, 'Kan geen personeel koppelen: dienst is geannuleerd.', 'SHIFT_LOCKED_CANCELLED');
  }
  if (shift.status === 'COMPLETED') {
    throw new HttpError(409, 'Kan geen personeel koppelen: dienst is afgerond (completed).', 'SHIFT_LOCKED_COMPLETED');
  }


  const runner = async (tx: DbClient) => {
    const shiftMaterials = await tx.shiftMaterial.findMany({ where: { shiftId } });

    for (const userId of uniq) {
      // Phase 8: do not allow assigning workers when they are marked unavailable
      await assertNoAvailabilityOverlap(userId, shift.startAt, shift.endAt, tx);

      // Business rule: prevent overlapping APPROVED shifts for this user
      const approved = await tx.shiftAssignment.findMany({
        where: { userId, status: 'APPROVED' },
        include: { shift: true },
      });
      for (const a of approved) {
        if (a.shiftId === shiftId) continue;
        if (shiftsOverlap(shift.startAt, shift.endAt, a.shift.startAt, a.shift.endAt)) {
          throw new ShiftConflictError({
            conflictShiftId: a.shiftId,
            conflictStartAt: a.shift.startAt,
            conflictEndAt: a.shift.endAt,
          });
        }
      }

      const assignment = await tx.shiftAssignment.upsert({
        where: { shiftId_userId: { shiftId, userId } },
        update: { status: 'APPROVED' },
        create: { shiftId, userId, status: 'APPROVED' },
      });

      // Copy planned materials to this worker (idempotent)
      for (const sm of shiftMaterials) {
        await tx.shiftAssignmentMaterial.upsert({
          where: { assignmentId_materialId: { assignmentId: assignment.id, materialId: sm.materialId } },
          update: { quantity: sm.quantity },
          create: { assignmentId: assignment.id, materialId: sm.materialId, quantity: sm.quantity },
        });
      }
    }

    // Keep status in sync with requiredWorkers.
    const approvedCount = await tx.shiftAssignment.count({ where: { shiftId, status: 'APPROVED' } });
    const required = Number(shift.requiredWorkers ?? 1);
    const nextStatus = approvedCount >= required ? 'ASSIGNED' : 'OPEN';
    await tx.shift.update({ where: { id: shiftId }, data: { status: nextStatus } });
  };

  if (db) {
    await runner(db);
    return;
  }

  await prisma.$transaction(async (tx) => {
    await runner(tx);
  });
}

// Remove assignments for one or more users from a shift (admin only).
// Keeps the shift status in sync with requiredWorkers.
export async function unassignMultiple(shiftId: string, userIds: string[], db?: DbClient) {
  const uniq = Array.from(new Set((userIds || []).filter(Boolean)));
  if (uniq.length === 0) return;

  const runner = async (tx: DbClient) => {
    const shiftMeta = await tx.shift.findUnique({ where: { id: shiftId }, select: { status: true, requiredWorkers: true, isDeleted: true } });
    if (!shiftMeta || shiftMeta.isDeleted) throw new HttpError(404, 'Shift not found');
    if (shiftMeta.status === 'COMPLETED') {
      throw new HttpError(409, 'Kan medewerkers niet ontkoppelen: dienst is afgerond (completed).', 'SHIFT_LOCKED_COMPLETED');
    }
    if (shiftMeta.status === 'CANCELLED') {
      throw new HttpError(409, 'Kan medewerkers niet ontkoppelen: dienst is geannuleerd.', 'SHIFT_LOCKED_CANCELLED');
    }

    // Delete assignment materials first (if not cascading)
    const assignments = await tx.shiftAssignment.findMany({
      where: { shiftId, userId: { in: uniq } },
      select: { id: true },
    });
    const assignmentIds = assignments.map((a) => a.id);
    if (assignmentIds.length) {
      await tx.shiftAssignmentMaterial.deleteMany({ where: { assignmentId: { in: assignmentIds } } });
    }
    await tx.shiftAssignment.deleteMany({ where: { shiftId, userId: { in: uniq } } });

    // Recompute status based on remaining APPROVED assignments
    const shift = shiftMeta;
    const approvedCount = await tx.shiftAssignment.count({ where: { shiftId, status: 'APPROVED' } });
    const req = shift?.requiredWorkers ?? 1;
    const nextStatus = approvedCount >= req ? 'ASSIGNED' : 'OPEN';
    await tx.shift.update({ where: { id: shiftId }, data: { status: nextStatus } });
  };

  if (db) {
    await runner(db);
    return;
  }

  await prisma.$transaction(async (tx) => {
    await runner(tx);
  });
}
export async function updateShift(id: string, input: any) {
  if (input.startAt && input.endAt && new Date(input.endAt) <= new Date(input.startAt)) {
    throw new HttpError(400, 'endAt must be after startAt');
  }

  // Cancelled shifts are read-only (except for status transitions).
  const existingForLock = await prisma.shift.findUnique({
    where: { id },
    select: { id: true, status: true, isDeleted: true, title: true, startAt: true, locationId: true },
  });
  if (!existingForLock || existingForLock.isDeleted) throw new HttpError(404, 'Shift not found');

  if (existingForLock.status === 'CANCELLED') {
    const keys = Object.keys(input ?? {}).filter((k) => input[k] !== undefined);
    const disallowed = keys.filter((k) => k !== 'status');
    if (disallowed.length) {
      throw new HttpError(
        409,
        'Dienst is geannuleerd en kan niet aangepast worden (read-only).',
        'SHIFT_LOCKED_CANCELLED',
        { disallowed },
      );
    }
  }

  // Enforce title uniqueness for the same location + day (prevents confusing duplicates).
  if (input.title || input.startAt || input.locationId) {
    const existing = existingForLock;
    const nextTitle = String(input.title ?? existing.title).trim();
    const nextStartAt = input.startAt ? new Date(input.startAt) : existing.startAt;
    const nextLocationId = input.locationId ?? existing.locationId;
    await ensureUniqueTitleOrThrow(prisma, { title: nextTitle, locationId: nextLocationId, startAt: nextStartAt, excludeId: id });
  }

  return prisma.shift.update({ where: { id }, data: input });
}

export async function deleteShift(id: string) {
  const existing = await prisma.shift.findUnique({ where: { id }, select: { id: true, isDeleted: true } });
  if (!existing) throw new HttpError(404, 'Shift not found');
  if (existing.isDeleted) {
    throw new HttpError(409, 'Shift is al verwijderd', 'SHIFT_ALREADY_ARCHIVED');
  }
  return prisma.shift.update({ where: { id }, data: { isDeleted: true, deletedAt: new Date(), status: 'CANCELLED' } });
}

export async function listOpenShifts(
  viewer: { id: string; role: string; passColor?: any | null },
  range?: { start: Date; end: Date },
  filters?: { type?: string; locationId?: string; occupancy?: 'free' | 'full' | 'all'; eligibility?: 'eligible' | 'ineligible' | 'all'; q?: string }
) {
  const viewerPassColor =
    viewer.passColor !== undefined
      ? viewer.passColor
      : (await prisma.user.findUnique({ where: { id: viewer.id }, select: { passColor: true } }))?.passColor ?? null;

  const where: any = {
    status: 'OPEN',
    isDeleted: false,
    ...(range ? { startAt: { lt: range.end }, endAt: { gt: range.start } } : {}),
    ...(filters?.type ? { type: filters.type } : {}),
    ...(filters?.locationId ? { locationId: filters.locationId } : {}),
    ...(filters?.q
      ? {
          OR: [
            { title: { contains: String(filters.q), mode: 'insensitive' as any } },
            { location: { name: { contains: String(filters.q), mode: 'insensitive' as any } } },
            { client: { name: { contains: String(filters.q), mode: 'insensitive' as any } } },
            { id: { contains: String(filters.q), mode: 'insensitive' as any } },
          ],
        }
      : {}),
  };

  const shifts = await prisma.shift.findMany({
    where,
    include: { location: true, client: true },
    orderBy: { startAt: 'asc' },
  });

  if (shifts.length === 0) return [];

  // Phase 8: prefetch availability for the viewer to mark open shifts as eligible/ineligible
  const availabilities = await prisma.userAvailability.findMany({
    where: {
      userId: viewer.id,
      ...(range ? { startAt: { lt: range.end }, endAt: { gt: range.start } } : {}),
    },
    orderBy: { startAt: 'asc' },
    select: { id: true, type: true, startAt: true, endAt: true },
  });

  const ids = shifts.map((s) => s.id);

  const approvedCounts = await prisma.shiftAssignment.groupBy({
    by: ['shiftId'],
    where: { shiftId: { in: ids }, status: 'APPROVED' },
    _count: { _all: true },
  });

  const approvedMap = new Map<string, number>();
  for (const r of approvedCounts) approvedMap.set(r.shiftId, r._count._all);

  const canApplyFor = (shift: any) => {
    const req = shift.requiredPassColor ?? 'BLACK';

    // Everyone can work BLACK shifts
    if (req === 'BLACK') return true;

    // Admins can respond to all open shifts, regardless of color
    if (viewer.role === 'ADMIN') return true;

    const u = viewerPassColor ?? null;

    // GRAY can work all shifts
    if (u === 'GRAY') return true;

    // LIGHT_BLUE can work LIGHT_BLUE and ORANGE
    if (u === 'LIGHT_BLUE') return req === 'LIGHT_BLUE' || req === 'ORANGE';

    // ORANGE can work ORANGE only
    if (u === 'ORANGE') return req === 'ORANGE';

    // DARK_BLUE can work DARK_BLUE only
    if (u === 'DARK_BLUE') return req === 'DARK_BLUE';

    // GREEN cannot respond to colored shifts (only BLACK, handled above)
    if (u === 'GREEN') return false;

    // Default fallback
    return u === req;
  };

  const hasAvailabilityConflict = (shift: any) => {
    // Admins are allowed to override availability.
    if (viewer.role === 'ADMIN') return false;
    return availabilities.some((a) => shiftsOverlap(shift.startAt, shift.endAt, a.startAt, a.endAt));
  };

  const enriched = shifts.map((s: any) => {
    const approved = approvedMap.get(s.id) ?? 0;
    const required = s.requiredWorkers ?? 1;
    const remaining = Math.max(0, required - approved);
    const filled = remaining === 0;
    const conflict = hasAvailabilityConflict(s);
    const eligible = canApplyFor(s) && !conflict;
    return {
      ...s,
      occupancy: { approved, required, remaining, filled },
      eligible,
      availabilityConflict: conflict ? true : false,
    };
  });

  const occ = filters?.occupancy ?? 'all';
  const elig = filters?.eligibility ?? 'all';

  return enriched.filter((s: any) => {
    if (occ === 'free' && s.occupancy.filled) return false;
    if (occ === 'full' && !s.occupancy.filled) return false;
    if (elig === 'eligible' && !s.eligible) return false;
    if (elig === 'ineligible' && s.eligible) return false;
    return true;
  });
}

export async function requestOpenShift(shiftId: string, userId: string, viewerRole?: string) {
  const shift = await prisma.shift.findUnique({ where: { id: shiftId } });
  if (!shift) throw new HttpError(404, 'Shift not found');
  if (shift.isDeleted) throw new HttpError(404, 'Shift not found');
  if (shift.status !== 'OPEN') throw new HttpError(400, 'Shift is not open for requests');

  // Admins may respond to any open shift, regardless of pass color.
  // They may also bypass availability overlap (admin is responsible for overrides).
  if (viewerRole === 'ADMIN') {
    return prisma.shiftAssignment.upsert({
      where: { shiftId_userId: { shiftId, userId } },
      update: { status: 'REQUESTED' },
      create: { shiftId, userId, status: 'REQUESTED' },
    });
  }

  // Phase 8: do not allow requesting open shifts if the user is marked unavailable
  await assertNoAvailabilityOverlap(userId, shift.startAt, shift.endAt);

  // Phase 2: Pass color rule engine (server-side enforced)
  const user = await prisma.user.findUnique({ where: { id: userId }, select: { passColor: true } });
  const required = (shift as any).requiredPassColor ?? 'BLACK';
  const userColor = user?.passColor ?? null;
  // Rule: GREEN users may only respond to BLACK open shifts
  if (userColor === 'GREEN' && required !== 'BLACK') {
    throw new HttpError(403, 'Groene kleurpas kan niet reageren op open diensten (behalve zwart)', 'PASSCOLOR_MISMATCH', {
      requiredPassColor: required,
      userPassColor: userColor,
    });
  }

  if (required !== 'BLACK') {
    if (userColor !== required) {
      throw new HttpError(403, 'Onjuiste kleurpas voor deze dienst', 'PASSCOLOR_MISMATCH', {
        requiredPassColor: required,
        userPassColor: userColor,
      });
    }
  }

  return prisma.shiftAssignment.upsert({
    where: { shiftId_userId: { shiftId, userId } },
    update: { status: 'REQUESTED' },
    create: { shiftId, userId, status: 'REQUESTED' },
  });
}

export async function reviewRequest(shiftId: string, userId: string, approve: boolean) {
  const shift = await prisma.shift.findUnique({ where: { id: shiftId } });
  if (!shift) throw new HttpError(404, 'Shift not found');
  if (shift.isDeleted) throw new HttpError(404, 'Shift not found');
  if (shift.status === 'CANCELLED') throw new HttpError(409, 'Dienst is geannuleerd', 'SHIFT_LOCKED_CANCELLED');
  if (shift.status === 'COMPLETED') throw new HttpError(409, 'Dienst is afgerond (completed)', 'SHIFT_LOCKED_COMPLETED');

  const assignment = await prisma.shiftAssignment.findUnique({
    where: { shiftId_userId: { shiftId, userId } },
  });
  if (!assignment) throw new HttpError(404, 'Request not found');

  // Idempotency: prevent approving/rejecting the same request multiple times
  if (assignment.status !== 'REQUESTED') {
    throw new HttpError(409, 'Request already reviewed', 'REQUEST_ALREADY_REVIEWED', {
      currentStatus: assignment.status,
    });
  }

  if (!approve) {
    return prisma.shiftAssignment.update({
      where: { shiftId_userId: { shiftId, userId } },
      data: { status: 'REJECTED' },
    });
  }

  // Phase 8: do not allow approving an assignment when the worker is marked unavailable
  await assertNoAvailabilityOverlap(userId, shift.startAt, shift.endAt);

  // Phase 8: do not approve if user is unavailable
  await assertNoAvailabilityOverlap(userId, shift.startAt, shift.endAt);

  // Business rule: no overlapping APPROVED shifts for this user
  const approved = await prisma.shiftAssignment.findMany({
    where: { userId, status: 'APPROVED', shift: { status: { in: ['ASSIGNED', 'OPEN', 'DRAFT', 'COMPLETED'] } } },
    include: { shift: true },
  });

  for (const a of approved) {
    if (a.shiftId === shiftId) continue;
    if (shiftsOverlap(shift.startAt, shift.endAt, a.shift.startAt, a.shift.endAt)) {
      throw new ShiftConflictError({
        conflictShiftId: a.shiftId,
        conflictStartAt: a.shift.startAt,
        conflictEndAt: a.shift.endAt,
      });
    }
  }

  // Approve request.
  // Multi-worker support: approve up to shift.requiredWorkers employees.
  // IMPORTANT: We lock the Shift row and run this transaction with SERIALIZABLE
  // isolation to prevent over-booking under concurrent approvals.
  return prisma.$transaction(async (tx) => {
    // Lock shift row (PostgreSQL) to serialize capacity checks.
    await tx.$executeRaw`SELECT 1 FROM "Shift" WHERE id = ${shiftId} FOR UPDATE`;

    // Re-check shift state inside the transaction (avoid TOCTOU).
    const shiftMeta = await tx.shift.findUnique({
      where: { id: shiftId },
      select: { status: true, requiredWorkers: true, isDeleted: true, startAt: true, endAt: true },
    });
    if (!shiftMeta || shiftMeta.isDeleted) throw new HttpError(404, 'Shift not found');
    if (shiftMeta.status === 'CANCELLED') throw new HttpError(409, 'Dienst is geannuleerd', 'SHIFT_LOCKED_CANCELLED');
    if (shiftMeta.status === 'COMPLETED') throw new HttpError(409, 'Dienst is afgerond (completed)', 'SHIFT_LOCKED_COMPLETED');

    const required = shiftMeta.requiredWorkers ?? 1;
    const alreadyApproved = await tx.shiftAssignment.count({ where: { shiftId, status: 'APPROVED' } });
    if (alreadyApproved >= required) {
      // Shift is already full.
      throw new HttpError(409, 'Shift is already filled', 'SHIFT_ALREADY_FILLED');
    }

    const approvedAssignment = await tx.shiftAssignment.update({
      where: { shiftId_userId: { shiftId, userId } },
      data: { status: 'APPROVED' },
    });

    // Copy planned materials to this worker (idempotent)
    const shiftMaterials = await tx.shiftMaterial.findMany({ where: { shiftId } });
    for (const sm of shiftMaterials) {
      await tx.shiftAssignmentMaterial.upsert({
        where: { assignmentId_materialId: { assignmentId: approvedAssignment.id, materialId: sm.materialId } },
        update: { quantity: sm.quantity },
        create: { assignmentId: approvedAssignment.id, materialId: sm.materialId, quantity: sm.quantity },
      });
    }

    const approvedCount = await tx.shiftAssignment.count({ where: { shiftId, status: 'APPROVED' } });

    if (approvedCount >= required) {
      // Shift is filled; mark as ASSIGNED and reject remaining pending requests.
      await tx.shift.update({ where: { id: shiftId }, data: { status: 'ASSIGNED' } });
      await tx.shiftAssignment.updateMany({
        where: { shiftId, status: 'REQUESTED' },
        data: { status: 'REJECTED' },
      });
    } else {
      // Still room: keep OPEN so more employees can request.
      await tx.shift.update({ where: { id: shiftId }, data: { status: 'OPEN' } });
    }

    return tx.shiftAssignment.findUnique({ where: { shiftId_userId: { shiftId, userId } } });
  }, { isolationLevel: 'Serializable' });
}


export async function assignUserToShift(shiftId: string, userId: string) {
  const shift = await prisma.shift.findUnique({ where: { id: shiftId } });
  if (!shift) throw new HttpError(404, 'Shift not found');
  if (shift.status === 'CANCELLED') throw new HttpError(409, 'Dienst is geannuleerd', 'SHIFT_LOCKED_CANCELLED');
  if (shift.status === 'COMPLETED') throw new HttpError(409, 'Dienst is afgerond (completed)', 'SHIFT_LOCKED_COMPLETED');

  // Phase 8: do not allow assigning a worker when they are marked unavailable
  await assertNoAvailabilityOverlap(userId, shift.startAt, shift.endAt);

  // overlap check
  const approved = await prisma.shiftAssignment.findMany({
    where: { userId, status: 'APPROVED' },
    include: { shift: true },
  });

  for (const a of approved) {
    if (a.shiftId === shiftId) continue;
    if (shiftsOverlap(shift.startAt, shift.endAt, a.shift.startAt, a.shift.endAt)) {
      throw new ShiftConflictError({
        conflictShiftId: a.shiftId,
        conflictStartAt: a.shift.startAt,
        conflictEndAt: a.shift.endAt,
      });
    }
  }

  return prisma.$transaction(async (tx) => {
    // Lock shift row to serialize capacity checks.
    await tx.$executeRaw`SELECT 1 FROM "Shift" WHERE id = ${shiftId} FOR UPDATE`;

    const shiftMeta = await tx.shift.findUnique({
      where: { id: shiftId },
      select: { status: true, requiredWorkers: true, isDeleted: true },
    });
    if (!shiftMeta || shiftMeta.isDeleted) throw new HttpError(404, 'Shift not found');
    if (shiftMeta.status === 'CANCELLED') throw new HttpError(409, 'Dienst is geannuleerd', 'SHIFT_LOCKED_CANCELLED');
    if (shiftMeta.status === 'COMPLETED') throw new HttpError(409, 'Dienst is afgerond (completed)', 'SHIFT_LOCKED_COMPLETED');

    const required = shiftMeta.requiredWorkers ?? 1;
    const alreadyApproved = await tx.shiftAssignment.count({ where: { shiftId, status: 'APPROVED' } });
    if (alreadyApproved >= required) throw new HttpError(409, 'Shift is already filled', 'SHIFT_ALREADY_FILLED');

    await tx.shiftAssignment.upsert({
      where: { shiftId_userId: { shiftId, userId } },
      update: { status: 'APPROVED' },
      create: { shiftId, userId, status: 'APPROVED' },
    });

    const approvedCount = await tx.shiftAssignment.count({ where: { shiftId, status: 'APPROVED' } });
    if (approvedCount >= required) {
      await tx.shift.update({ where: { id: shiftId }, data: { status: 'ASSIGNED' } });
      await tx.shiftAssignment.updateMany({ where: { shiftId, status: 'REQUESTED' }, data: { status: 'REJECTED' } });
    } else {
      await tx.shift.update({ where: { id: shiftId }, data: { status: 'OPEN' } });
    }

    return tx.shiftAssignment.findUnique({ where: { shiftId_userId: { shiftId, userId } } });
  }, { isolationLevel: 'Serializable' });
}

export async function getShift(id: string, opts?: { includeDeleted?: boolean }) {
  const includeDeleted = Boolean(opts?.includeDeleted);

  // NOTE: findUnique only supports unique fields. We use findFirst so we can
  // safely filter on isDeleted without relying on a compound unique index.
  return prisma.shift.findFirst({
    where: {
      id,
      ...(includeDeleted ? {} : { isDeleted: false }),
    },
    include: {
      location: true,
      client: true,
      materials: { include: { material: true } },
      assignments: { include: { user: true, materials: { include: { material: true } } } },
      timeEntries: { include: { user: true } },
      extraCosts: {
        orderBy: { createdAt: 'asc' },
        include: { createdBy: { select: { id: true, fullName: true, email: true } } },
      },
      notes: {
        orderBy: [{ isPinned: 'desc' }, { pinnedAt: 'desc' }, { createdAt: 'desc' }],
        include: { author: { select: { id: true, fullName: true, email: true } } },
      },
    },
  });
}


export async function getNextRequestedShift() {
  const now = new Date();
  const shift = await prisma.shift.findFirst({
    where: {
      isDeleted: false,
      status: 'OPEN',
      startAt: { gte: now },
      assignments: { some: { status: 'REQUESTED' } },
    },
    include: {
      location: true,
      assignments: {
        where: { status: 'REQUESTED' },
        include: { user: true },
        orderBy: { createdAt: 'asc' },
      },
    },
    orderBy: { startAt: 'asc' },
  });

  if (!shift) return null;

  return {
    shift: {
      id: shift.id,
      title: shift.title,
      startAt: shift.startAt.toISOString(),
      endAt: shift.endAt.toISOString(),
      locationName: shift.location.name,
    },
    requestCount: shift.assignments.length,
    firstRequester: shift.assignments[0]
      ? { id: shift.assignments[0].user.id, fullName: shift.assignments[0].user.fullName, email: shift.assignments[0].user.email }
      : null,
  };
}

// Next shift a user has reacted to (either REQUESTED or APPROVED).
// Priority: return the earliest APPROVED shift; if none, return the earliest REQUESTED shift.
export async function getMyNextReactedShift(userId: string) {
  const now = new Date();

  const findOne = async (status: 'APPROVED' | 'REQUESTED') => {
    const a = await prisma.shiftAssignment.findFirst({
      where: {
        userId,
        status,
        shift: {
          isDeleted: false,
          startAt: { gte: now },
          status: { in: ['OPEN', 'ASSIGNED'] },
        },
      },
      include: { shift: { include: { location: true } } },
      orderBy: { shift: { startAt: 'asc' } },
    });
    if (!a) return null;
    return {
      status: a.status,
      userId: a.userId,
      shift: {
        id: a.shift.id,
        title: a.shift.title,
        startAt: a.shift.startAt.toISOString(),
        endAt: a.shift.endAt.toISOString(),
        locationName: a.shift.location?.name ?? null,
      },
    };
  };

  return (await findOne('APPROVED')) ?? (await findOne('REQUESTED'));
}
