import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { prisma } from '../db/prisma.js';
import { env } from '../config/env.js';
import { HttpError } from '../utils/http.js';
import { AuthLockoutError } from '../utils/domainErrors.js';
import { buildOtpAuthUrl, generateTotpSecret, verifyTotp } from '../utils/totp.js';
import type { $Enums, User } from '@prisma/client';


const MAX_FAILED_LOGIN = 5;
const LOCKOUT_MINUTES = 15;
const TEMP_2FA_TTL_MIN = 5;

const signAccess = (user: { id: string; role: $Enums.Role; tfa: boolean }) =>
  jwt.sign({ sub: user.id, role: user.role, tfa: user.tfa }, env.JWT_ACCESS_SECRET, {
    expiresIn: `${env.ACCESS_TOKEN_TTL_MIN}m`,
  });

const signRefresh = (user: { id: string; role: $Enums.Role; tfa: boolean }) =>
  jwt.sign({ sub: user.id, role: user.role, tfa: user.tfa }, env.JWT_REFRESH_SECRET, {
    expiresIn: `${env.REFRESH_TOKEN_TTL_DAYS}d`,
  });

const sign2faTemp = (user: { id: string; role: $Enums.Role }) =>
  jwt.sign({ sub: user.id, role: user.role, purpose: '2fa_login' }, env.JWT_ACCESS_SECRET, {
    expiresIn: `${TEMP_2FA_TTL_MIN}m`,
  });

const hashToken = async (token: string) => bcrypt.hash(token, 10);
const verifyTokenHash = async (token: string, hash: string) => bcrypt.compare(token, hash);

async function issueTokens(user: User, tfa: boolean) {
  const access = signAccess({ id: user.id, role: user.role, tfa });
  const refresh = signRefresh({ id: user.id, role: user.role, tfa });
  await prisma.user.update({ where: { id: user.id }, data: { refreshTokenHash: await hashToken(refresh) } });
  return { access, refresh };
}

export async function login(emailRaw: string, password: string) {
  const email = emailRaw.toLowerCase().trim();
  const user = await prisma.user.findUnique({ where: { email } });
  if (!user || !user.isActive || user.status !== 'ACTIVE') throw new HttpError(401, 'Invalid credentials', 'INVALID_CREDENTIALS');

  if (user.lockoutUntil && user.lockoutUntil.getTime() > Date.now()) {
    const retryAfterSeconds = Math.max(1, Math.round((user.lockoutUntil.getTime() - Date.now()) / 1000));
    throw new AuthLockoutError(user.lockoutUntil.toISOString(), retryAfterSeconds);
  }

  const ok = await bcrypt.compare(password, user.passwordHash);
  if (!ok) {
    const nextCount = (user.failedLoginCount ?? 0) + 1;
    const lockoutUntil = nextCount >= MAX_FAILED_LOGIN ? new Date(Date.now() + LOCKOUT_MINUTES * 60_000) : null;
    await prisma.user.update({
      where: { id: user.id },
      data: {
        failedLoginCount: nextCount,
        lockoutUntil,
      },
    });
    throw new HttpError(401, 'Invalid credentials', 'INVALID_CREDENTIALS');
  }

  // reset counters
  await prisma.user.update({ where: { id: user.id }, data: { failedLoginCount: 0, lockoutUntil: null } });

  // If user already has 2FA enabled, require code verification before issuing cookies.
  if (user.twoFactorEnabled) {
    const tempToken = sign2faTemp({ id: user.id, role: user.role });
    return { twoFactorRequired: true as const, tempToken, user: safeUser(user) };
  }

  const { access, refresh } = await issueTokens(user, false);
  return { twoFactorRequired: false as const, user: safeUser(user), access, refresh };
}

export async function verify2faLogin(tempToken: string, code: string) {
  let payload: any;
  try {
    payload = jwt.verify(tempToken, env.JWT_ACCESS_SECRET);
  } catch {
    throw new HttpError(401, 'Invalid or expired 2FA token', 'INVALID_2FA_TOKEN');
  }
  if (payload?.purpose !== '2fa_login' || !payload?.sub) {
    throw new HttpError(401, 'Invalid 2FA token', 'INVALID_2FA_TOKEN');
  }

  const user = await prisma.user.findUnique({ where: { id: payload.sub } });
  if (!user || !user.isActive || user.status !== 'ACTIVE') throw new HttpError(401, 'Invalid credentials', 'INVALID_CREDENTIALS');
  if (!user.twoFactorEnabled || !user.twoFactorSecret) {
    throw new HttpError(400, '2FA is not enabled for this account', 'TWOFA_NOT_ENABLED');
  }

  // Allow a slightly larger window for clock drift on phones.
  const ok = verifyTotp(user.twoFactorSecret, code, { window: 2 });
  if (!ok) throw new HttpError(401, 'Invalid 2FA code', 'INVALID_2FA_CODE');

  const { access, refresh } = await issueTokens(user, true);
  return { user: safeUser(user), access, refresh };
}

export async function refresh(userId: string, refreshToken: string) {
  const user = await prisma.user.findUnique({ where: { id: userId } });
  if (!user || !user.refreshTokenHash) throw new HttpError(401, 'Invalid refresh token');

  const match = await verifyTokenHash(refreshToken, user.refreshTokenHash);
  if (!match) throw new HttpError(401, 'Invalid refresh token');

  // Preserve whether the session had passed 2FA.
  // If the user has 2FA enabled, refresh tokens are only issued after a successful 2FA verify.
  const tfa = !!(jwt.decode(refreshToken) as any)?.tfa;

  const access = signAccess({ id: user.id, role: user.role, tfa });
  const newRefresh = signRefresh({ id: user.id, role: user.role, tfa });

  await prisma.user.update({
    where: { id: user.id },
    data: { refreshTokenHash: await hashToken(newRefresh) },
  });

  return { access, refresh: newRefresh, user: safeUser(user) };
}

export async function logout(userId: string) {
  await prisma.user.update({ where: { id: userId }, data: { refreshTokenHash: null } });
}

export async function me(userId: string) {
  const user = await prisma.user.findUnique({ where: { id: userId } });
  if (!user) throw new HttpError(401, 'Not authenticated');
  return safeUser(user);
}

export async function twoFactorSetup(userId: string) {
  const user = await prisma.user.findUnique({ where: { id: userId } });
  if (!user) throw new HttpError(404, 'User not found');
  if (!user.isActive || user.status !== 'ACTIVE') throw new HttpError(403, 'Forbidden');

  if (user.twoFactorEnabled) {
    throw new HttpError(400, '2FA already enabled', 'TWOFA_ALREADY_ENABLED');
  }

  // IMPORTANT:
  // React StrictMode (dev) can call effects twice, which would otherwise generate
  // a new secret and invalidate a QR code the user may have already scanned.
  // Make setup idempotent: if a temp secret already exists, reuse it.
  const issuer = 'Rooster';
  const secret = user.twoFactorTempSecret || generateTotpSecret();
  const otpauthUrl = buildOtpAuthUrl({ issuer, accountName: user.email, secret });

  if (!user.twoFactorTempSecret) {
    await prisma.user.update({ where: { id: user.id }, data: { twoFactorTempSecret: secret } });
  }

  return { secret, otpauthUrl };
}

export async function twoFactorEnable(userId: string, code: string) {
  const user = await prisma.user.findUnique({ where: { id: userId } });
  if (!user) throw new HttpError(404, 'User not found');
  if (!user.isActive || user.status !== 'ACTIVE') throw new HttpError(403, 'Forbidden');

  if (user.twoFactorEnabled) {
    throw new HttpError(400, '2FA already enabled', 'TWOFA_ALREADY_ENABLED');
  }

  if (!user.twoFactorTempSecret) {
    throw new HttpError(400, '2FA setup not started', 'TWOFA_SETUP_REQUIRED');
  }

  // Allow a slightly larger window for clock drift on phones.
  const ok = verifyTotp(user.twoFactorTempSecret, code, { window: 2 });
  if (!ok) throw new HttpError(401, 'Invalid 2FA code', 'INVALID_2FA_CODE');

  const updated = await prisma.user.update({
    where: { id: user.id },
    data: {
      twoFactorEnabled: true,
      twoFactorSecret: user.twoFactorTempSecret,
      twoFactorTempSecret: null,
      twoFactorEnabledAt: new Date(),
    },
  });

  const { access, refresh } = await issueTokens(updated, true);
  return { user: safeUser(updated), access, refresh };
}

export async function registerAdminIfEmpty() {
  const count = await prisma.user.count();
  if (count > 0) return;

  const password = process.env.SEED_ADMIN_PASSWORD ?? 'Admin123!ChangeMe';
  const admin = await prisma.user.create({
    data: {
      email: 'admin@example.com',
      fullName: 'Admin',
      role: 'ADMIN',
      passwordHash: await bcrypt.hash(password, 12),
      isActive: true,
      status: 'ACTIVE',
    },
  });

  // eslint-disable-next-line no-console
  console.log(`Seeded admin: ${admin.email} password=${password}`);
}

function safeUser(user: User) {
  return {
    id: user.id,
    email: user.email,
    fullName: user.fullName,
    role: user.role,
    clientId: (user as any).clientId ?? null,
    subcontractorId: (user as any).subcontractorId ?? null,
    isActive: user.isActive,
    twoFactorEnabled: (user as any).twoFactorEnabled ?? false,
    createdAt: user.createdAt,
  };
}
