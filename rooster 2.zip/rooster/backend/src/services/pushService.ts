import webpush from 'web-push';
import { prisma } from '../db/prisma.js';
import { env } from '../config/env.js';

// If env keys are not set, we generate ephemeral keys for dev.
let vapidPublicKey = env.VAPID_PUBLIC_KEY;
let vapidPrivateKey = env.VAPID_PRIVATE_KEY;

if (!vapidPublicKey || !vapidPrivateKey) {
  const generated = webpush.generateVAPIDKeys();
  vapidPublicKey = generated.publicKey;
  vapidPrivateKey = generated.privateKey;
  // eslint-disable-next-line no-console
  console.log('[push] Generated ephemeral VAPID keys (set VAPID_PUBLIC_KEY/VAPID_PRIVATE_KEY in production)');
}

webpush.setVapidDetails(env.VAPID_SUBJECT, vapidPublicKey, vapidPrivateKey);

export function getVapidPublicKey() {
  return vapidPublicKey;
}

export async function upsertSubscription(input: {
  userId: string;
  endpoint: string;
  p256dh: string;
  auth: string;
  userAgent?: string;
}) {
  return prisma.pushSubscription.upsert({
    where: { endpoint: input.endpoint },
    update: { userId: input.userId, p256dh: input.p256dh, auth: input.auth, userAgent: input.userAgent },
    create: { userId: input.userId, endpoint: input.endpoint, p256dh: input.p256dh, auth: input.auth, userAgent: input.userAgent },
  });
}

export async function deleteSubscription(userId: string, endpoint: string) {
  return prisma.pushSubscription.deleteMany({ where: { userId, endpoint } });
}

export async function sendPushToUser(userId: string, payload: any) {
  const subs = await prisma.pushSubscription.findMany({ where: { userId } });
  if (subs.length === 0) return;

  const body = JSON.stringify(payload);

  await Promise.all(
    subs.map(async (s: any) => {
      try {
        await webpush.sendNotification(
          {
            endpoint: s.endpoint,
            keys: { p256dh: s.p256dh, auth: s.auth },
          } as any,
          body,
        );
      } catch (e: any) {
        // If subscription is gone/invalid, remove it.
        const status = e?.statusCode || e?.status;
        if (status === 404 || status === 410) {
          await prisma.pushSubscription.deleteMany({ where: { endpoint: s.endpoint } });
        }
      }
    }),
  );
}
