import { prisma } from '../db/prisma.js';

/**
 * Audit logging is **best-effort**.
 * The codebase historically called logAudit like:
 *   logAudit(actorId, action, meta)
 * while the Prisma model requires: actorId, action, entity, entityId.
 *
 * To avoid crashing business endpoints when audit data is incomplete,
 * this helper supports the legacy signature and silently skips on invalid input.
 */

type LegacyMeta = Record<string, any> | undefined;

type FullAudit = {
  actorId: string;
  action: string;
  entity: string;
  entityId: string;
  before?: any;
  after?: any;
};

function inferEntity(meta: LegacyMeta): { entity: string; entityId: string } | null {
  if (!meta) return null;
  if (typeof meta.clientId === 'string' && meta.clientId) return { entity: 'Client', entityId: meta.clientId };
  if (typeof meta.shiftId === 'string' && meta.shiftId) return { entity: 'Shift', entityId: meta.shiftId };
  if (typeof meta.userId === 'string' && meta.userId) return { entity: 'User', entityId: meta.userId };
  if (typeof meta.entityId === 'string' && meta.entityId && typeof meta.entity === 'string' && meta.entity) {
    return { entity: meta.entity, entityId: meta.entityId };
  }
  return null;
}

/**
 * logAudit supports BOTH calling styles:
 *  1) Legacy: logAudit(actorId, action, meta)
 *  2) Full:   logAudit({ actorId, action, entity, entityId, before, after })
 */
export async function logAudit(
  actorIdOrAudit: string | FullAudit,
  actionMaybe?: string,
  metaMaybe?: LegacyMeta,
) {
  try {
    // Full-object signature
    if (typeof actorIdOrAudit === 'object' && actorIdOrAudit) {
      const a = actorIdOrAudit;
      if (!a.actorId || !a.action || !a.entity || !a.entityId) return null;
      return await prisma.auditLog.create({
        data: {
          actorId: a.actorId,
          action: a.action,
          entity: a.entity,
          entityId: a.entityId,
          before: a.before ?? undefined,
          after: a.after ?? undefined,
        },
      });
    }

    // Legacy signature
    const actorId = actorIdOrAudit;
    const action = actionMaybe;
    const meta = metaMaybe;
    if (!actorId || !action) return null;
    const inferred = inferEntity(meta);
    if (!inferred) return null;

    return await prisma.auditLog.create({
      data: {
        actorId,
        action,
        entity: inferred.entity,
        entityId: inferred.entityId,
        before: meta?.before ?? undefined,
        after: meta?.after ?? (meta ? meta : undefined),
      },
    });
  } catch {
    // Best-effort: never break the request because audit logging failed.
    return null;
  }
}
