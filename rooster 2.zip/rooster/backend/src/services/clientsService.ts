import { prisma } from '../db/prisma.js';
import { HttpError } from '../utils/http.js';

export async function listClients(opts?: { includeDeleted?: boolean }) {
  const includeDeleted = Boolean(opts?.includeDeleted);
  return prisma.client.findMany({
    where: includeDeleted ? {} : { isDeleted: false },
    orderBy: { name: 'asc' },
    include: {
      users: {
        // Include inactive portal users as well so the admin UI can show
        // whether a opdrachtgever has an inactive/disabled portal account.
        where: { role: 'CLIENT' },
        orderBy: { createdAt: 'desc' },
        select: { id: true, email: true, fullName: true, status: true, isActive: true },
      },
    },
  });
}

export async function listClientsPaged(input: {
  includeDeleted?: boolean;
  page: number;
  pageSize: number;
  q?: string;
}) {
  const includeDeleted = Boolean(input.includeDeleted);
  const page = Math.max(1, Math.floor(Number(input.page || 1)));
  const pageSize = Math.max(1, Math.min(200, Math.floor(Number(input.pageSize || 25))));
  const skip = (page - 1) * pageSize;
  const q = String(input.q ?? '').trim();

  const where: any = includeDeleted ? {} : { isDeleted: false };
  if (q) {
    where.OR = [
      { name: { contains: q, mode: 'insensitive' } },
      { contactEmail: { contains: q, mode: 'insensitive' } },
      { contactName: { contains: q, mode: 'insensitive' } },
    ];
  }

  const [totalCount, items] = await prisma.$transaction([
    prisma.client.count({ where }),
    prisma.client.findMany({
      where,
      orderBy: { name: 'asc' },
      skip,
      take: pageSize,
      include: {
        users: {
          where: { role: 'CLIENT' },
          orderBy: { createdAt: 'desc' },
          select: { id: true, email: true, fullName: true, status: true, isActive: true },
        },
      },
    }),
  ]);

  return { items, totalCount };
}

export async function createClient(input: { name: string; contactName?: string; contactEmail?: string }) {
  return prisma.client.create({ data: input });
}

export async function updateClient(id: string, input: { name?: string; contactName?: string; contactEmail?: string }) {
  return prisma.client.update({ where: { id }, data: input });
}

export async function softDeleteClient(id: string) {
  const existing = await prisma.client.findUnique({ where: { id }, select: { id: true, isDeleted: true } });
  if (!existing) throw new HttpError(404, 'Opdrachtgever not found');
  if (existing.isDeleted) {
    throw new HttpError(409, 'Opdrachtgever is al verwijderd', 'CLIENT_ALREADY_ARCHIVED');
  }
  return prisma.client.update({ where: { id }, data: { isDeleted: true, deletedAt: new Date() } });
}
