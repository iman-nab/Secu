import { prisma } from '../db/prisma.js';
import { HttpError } from '../utils/http.js';

type ListOpts = { startAt?: Date; endAt?: Date };

function assertRange(startAt: Date, endAt: Date) {
  if (!(startAt instanceof Date) || isNaN(startAt.getTime())) {
    throw new HttpError(400, 'Invalid startAt', 'VALIDATION_ERROR');
  }
  if (!(endAt instanceof Date) || isNaN(endAt.getTime())) {
    throw new HttpError(400, 'Invalid endAt', 'VALIDATION_ERROR');
  }
  if (endAt <= startAt) {
    throw new HttpError(400, 'endAt must be after startAt', 'VALIDATION_ERROR');
  }
}

async function findOverlap(userId: string, startAt: Date, endAt: Date, excludeId?: string) {
  return prisma.userAvailability.findFirst({
    where: {
      userId,
      ...(excludeId ? { id: { not: excludeId } } : {}),
      startAt: { lt: endAt },
      endAt: { gt: startAt },
    },
    orderBy: { startAt: 'asc' },
  });
}

export async function listMyAvailability(userId: string, opts?: ListOpts) {
  const { startAt, endAt } = opts ?? {};
  return prisma.userAvailability.findMany({
    where: {
      userId,
      ...(startAt || endAt
        ? {
            AND: [
              ...(startAt ? [{ endAt: { gt: startAt } }] : []),
              ...(endAt ? [{ startAt: { lt: endAt } }] : []),
            ],
          }
        : {}),
    },
    orderBy: { startAt: 'asc' },
  });
}

export async function listAvailabilityForUser(actor: { id: string; role: string }, userId: string, opts?: ListOpts) {
  // Admin: can view all
  if (actor.role === 'ADMIN') return listMyAvailability(userId, opts);

  // Subcontractor: can view own workers only
  if (actor.role === 'SUBCONTRACTOR') {
    const u = await prisma.user.findUnique({ where: { id: userId }, select: { subcontractorId: true } });
    if (!u || u.subcontractorId !== actor.id) throw new HttpError(403, 'Forbidden');
    return listMyAvailability(userId, opts);
  }

  // Employee: can view self only
  if (actor.id !== userId) throw new HttpError(403, 'Forbidden');
  return listMyAvailability(userId, opts);
}

export async function createMyAvailability(userId: string, data: { type: any; startAt: Date; endAt: Date; note?: string }) {
  assertRange(data.startAt, data.endAt);

  const overlap = await findOverlap(userId, data.startAt, data.endAt);
  if (overlap) {
    throw new HttpError(409, 'Beschikbaarheid overlapt met een bestaande periode', 'AVAILABILITY_OVERLAP', {
      conflictId: overlap.id,
      conflictType: overlap.type,
      conflictStartAt: overlap.startAt,
      conflictEndAt: overlap.endAt,
    });
  }

  return prisma.userAvailability.create({
    data: {
      userId,
      type: data.type,
      startAt: data.startAt,
      endAt: data.endAt,
      note: data.note,
    },
  });
}

export async function updateAvailability(actor: { id: string; role: string }, id: string, data: { type?: any; startAt?: Date; endAt?: Date; note?: string }) {
  const existing = await prisma.userAvailability.findUnique({ where: { id } });
  if (!existing) throw new HttpError(404, 'Not found');

  if (actor.role !== 'ADMIN' && existing.userId !== actor.id) throw new HttpError(403, 'Forbidden');

  const startAt = data.startAt ?? existing.startAt;
  const endAt = data.endAt ?? existing.endAt;
  assertRange(startAt, endAt);

  const overlap = await findOverlap(existing.userId, startAt, endAt, id);
  if (overlap) {
    throw new HttpError(409, 'Beschikbaarheid overlapt met een bestaande periode', 'AVAILABILITY_OVERLAP', {
      conflictId: overlap.id,
      conflictType: overlap.type,
      conflictStartAt: overlap.startAt,
      conflictEndAt: overlap.endAt,
    });
  }

  return prisma.userAvailability.update({
    where: { id },
    data: {
      ...(data.type ? { type: data.type } : {}),
      ...(data.note !== undefined ? { note: data.note } : {}),
      ...(data.startAt ? { startAt: data.startAt } : {}),
      ...(data.endAt ? { endAt: data.endAt } : {}),
    },
  });
}

export async function deleteAvailability(actor: { id: string; role: string }, id: string) {
  const existing = await prisma.userAvailability.findUnique({ where: { id } });
  if (!existing) throw new HttpError(404, 'Not found');
  if (actor.role !== 'ADMIN' && existing.userId !== actor.id) throw new HttpError(403, 'Forbidden');

  return prisma.userAvailability.delete({ where: { id } });
}
