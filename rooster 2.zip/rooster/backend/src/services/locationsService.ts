import { prisma } from '../db/prisma.js';
import { HttpError } from '../utils/http.js';

export async function listLocations() {
  return prisma.location.findMany({ where: { isDeleted: false }, orderBy: { createdAt: 'desc' } });
}

export async function createLocation(input: {
  name: string;
  address: string;
  latitude: number;
  longitude: number;
  radiusM: number;
}) {
  return prisma.location.create({ data: input });
}

export async function updateLocation(id: string, input: Partial<{
  name: string;
  address: string;
  latitude: number;
  longitude: number;
  radiusM: number;
}>) {
  return prisma.location.update({ where: { id }, data: input });
}

export async function deleteLocation(id: string) {
  // Allow deleting a location if it's only referenced by historical shifts
  // (COMPLETED/CANCELLED). If there are still active/plannable shifts, block.
  const activeShiftCount = await prisma.shift.count({
    where: {
      locationId: id,
      isDeleted: false,
      status: { in: ['OPEN', 'ASSIGNED', 'DRAFT'] as any },
    },
  });
  if (activeShiftCount > 0) {
    throw new HttpError(
      409,
      `Locatie is gekoppeld aan ${activeShiftCount} dienst(en) en kan niet verwijderd worden.`,
      'LOCATION_IN_USE',
      { activeShiftCount },
    );
  }

  return prisma.location.update({
    where: { id },
    data: { isDeleted: true, deletedAt: new Date() },
  });
}
