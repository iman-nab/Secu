import bcrypt from 'bcryptjs';
import { prisma } from '../db/prisma.js';
import { HttpError } from '../utils/http.js';
import type { $Enums } from '@prisma/client';


export async function listUsers() {
  const users = await prisma.user.findMany({
    orderBy: { createdAt: 'desc' },
    select: {
      id: true,
      email: true,
      fullName: true,
      role: true,
      clientId: true,
      subcontractorId: true,
      isActive: true,
      status: true,
      passColor: true,
      twoFactorEnabled: true,
      createdAt: true,
    },
  });

  const ids = users.map((u) => u.id);
  if (ids.length === 0) return users as any;

  // Latest time entry per user (used for "laatst gewerkte dienst")
  const latest = await prisma.timeEntry.findMany({
    where: { userId: { in: ids } },
    orderBy: { clockInAt: 'desc' },
    distinct: ['userId'],
    include: { shift: { include: { location: true } } },
  });

  const map = new Map(
    latest.map((e) => [
      e.userId,
      {
        timeEntryId: e.id,
        shiftId: e.shiftId,
        shiftTitle: e.shift.title,
        startAt: e.shift.startAt.toISOString(),
        endAt: e.shift.endAt.toISOString(),
        locationName: e.shift.location?.name ?? null,
        clockInAt: e.clockInAt.toISOString(),
        clockOutAt: e.clockOutAt ? e.clockOutAt.toISOString() : null,
        minutesWorked: e.minutesWorked,
      },
    ]),
  );

  return users.map((u) => ({ ...u, lastWorked: map.get(u.id) ?? null })) as any;
}

export async function listUsersPaged(input: {
  page: number;
  pageSize: number;
  q?: string;
  role?: $Enums.Role;
  excludeRole?: $Enums.Role;
  roles?: $Enums.Role[];
  excludeRoles?: $Enums.Role[];
  includeLastWorked?: boolean;
}) {
  const page = Math.max(1, Math.floor(Number(input.page || 1)));
  const pageSize = Math.max(1, Math.min(200, Math.floor(Number(input.pageSize || 25))));
  const skip = (page - 1) * pageSize;
  const q = String(input.q ?? '').trim();
  const includeLastWorked = !!input.includeLastWorked;

  const where: any = {};
  if (input.roles && input.roles.length) where.role = { in: input.roles };
  else if (input.excludeRoles && input.excludeRoles.length) where.role = { notIn: input.excludeRoles };
  else if (input.role) where.role = input.role;
  else if (input.excludeRole) where.role = { not: input.excludeRole };
  if (q) {
    where.OR = [
      { email: { contains: q, mode: 'insensitive' } },
      { fullName: { contains: q, mode: 'insensitive' } },
    ];
  }

  const [totalCount, users] = await prisma.$transaction([
    prisma.user.count({ where }),
    prisma.user.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      skip,
      take: pageSize,
      select: {
        id: true,
        email: true,
        fullName: true,
        role: true,
        clientId: true,
        subcontractorId: true,
        isActive: true,
        status: true,
        passColor: true,
        twoFactorEnabled: true,
        createdAt: true,
      },
    }),
  ]);

  if (!includeLastWorked) {
    return { items: users as any[], totalCount };
  }

  const ids = users.map((u) => u.id);
  if (ids.length === 0) return { items: [] as any[], totalCount };

  const latest = await prisma.timeEntry.findMany({
    where: { userId: { in: ids } },
    orderBy: { clockInAt: 'desc' },
    distinct: ['userId'],
    include: { shift: { include: { location: true } } },
  });

  const map = new Map(
    latest.map((e) => [
      e.userId,
      {
        timeEntryId: e.id,
        shiftId: e.shiftId,
        shiftTitle: e.shift.title,
        startAt: e.shift.startAt.toISOString(),
        endAt: e.shift.endAt.toISOString(),
        locationName: e.shift.location?.name ?? null,
        clockInAt: e.clockInAt.toISOString(),
        clockOutAt: e.clockOutAt ? e.clockOutAt.toISOString() : null,
        minutesWorked: e.minutesWorked,
      },
    ]),
  );

  const items = users.map((u) => ({ ...u, lastWorked: map.get(u.id) ?? null })) as any[];
  return { items, totalCount };
}

export async function createUser(input: { email: string; fullName: string; role: $Enums.Role; password: string; clientId?: string }) {
  const exists = await prisma.user.findUnique({ where: { email: input.email } });
  if (exists) throw new HttpError(409, 'Email already exists');

  const user = await prisma.user.create({
    data: {
      email: input.email.toLowerCase(),
      fullName: input.fullName,
      role: input.role,
      clientId: input.clientId,
      passwordHash: await bcrypt.hash(input.password, 12),
      isActive: true,
    },
    select: { id: true, email: true, fullName: true, role: true, clientId: true, isActive: true, createdAt: true },
  });
  return user;
}


export async function updateUser(id: string, input: Partial<{ fullName: string; role: $Enums.Role; clientId: string | null; isActive: boolean; password: string; passColor: any | null }>) {
  const data: any = {};
  if (input.fullName !== undefined) data.fullName = input.fullName;
  if (input.role !== undefined) data.role = input.role;
  if (input.clientId !== undefined) data.clientId = input.clientId;
  if (input.passColor !== undefined) data.passColor = input.passColor;
  if (input.isActive !== undefined) {
    data.isActive = input.isActive;
    data.status = input.isActive ? 'ACTIVE' : 'INACTIVE';
  }
  if (input.password) data.passwordHash = await bcrypt.hash(input.password, 12);

  return prisma.user.update({
    where: { id },
    data,
    select: { id: true, email: true, fullName: true, role: true, clientId: true, isActive: true, createdAt: true },
  });
}

/**
 * Reactivate a previously deactivated account.
 *
 * Used primarily for opdrachtgever portal users: when an admin wants to re-enable
 * the existing portal account, we turn it active again and optionally update the
 * email/fullName to the desired values.
 */
export async function reactivateUser(
  id: string,
  input?: Partial<{ email: string; fullName: string }>
) {
  const u = await prisma.user.findUnique({ where: { id }, select: { id: true, email: true, isActive: true } });
  if (!u) throw new HttpError(404, 'User not found');

  // If already active, treat as a no-op to keep the endpoint safe to call.
  const nextEmail = (input?.email ?? u.email).toLowerCase();

  if (input?.email && nextEmail !== u.email.toLowerCase()) {
    const exists = await prisma.user.findUnique({ where: { email: nextEmail } });
    if (exists && exists.id !== id) throw new HttpError(409, 'Email already exists', 'EMAIL_EXISTS');
  }

  return prisma.user.update({
    where: { id },
    data: {
      isActive: true,
      status: 'ACTIVE',
      failedLoginCount: 0,
      lockoutUntil: null,
      email: nextEmail,
      ...(input?.fullName !== undefined ? { fullName: input.fullName } : {}),
    },
    select: { id: true, email: true, fullName: true, role: true, clientId: true, isActive: true, createdAt: true },
  });
}

export async function getUser(id: string) {
  return prisma.user.findUnique({
    where: { id },
    select: { id: true, email: true, fullName: true, role: true, clientId: true, isActive: true, createdAt: true },
  });
}


export async function deleteUser(id: string) {
  const u = await prisma.user.findUnique({ where: { id }, select: { id: true, email: true, isActive: true } });
  if (!u) throw new HttpError(404, 'User not found');

  // Soft-delete: deactivate and change email to keep uniqueness while preserving history.
  // Make this idempotent: once deactivated, further delete attempts return a 409.
  if (!u.isActive) {
    throw new HttpError(409, 'Gebruiker is al inactief', 'USER_ALREADY_DEACTIVATED');
  }

  const ts = Date.now();
  const alreadyTagged = u.email.includes('.deleted.');
  const newEmail = alreadyTagged ? u.email : `${u.email}.deleted.${ts}`;

  return prisma.user.update({
    where: { id },
    data: { isActive: false, status: 'DELETED', email: newEmail },
    select: { id: true, email: true, fullName: true, role: true, clientId: true, isActive: true, createdAt: true },
  });
}

// -------------------- Admin security resets --------------------

export async function reset2FA(id: string) {
  const u = await prisma.user.findUnique({ where: { id }, select: { id: true, isActive: true } });
  if (!u) throw new HttpError(404, 'User not found');

  return prisma.user.update({
    where: { id },
    data: {
      twoFactorEnabled: false,
      twoFactorSecret: null,
      twoFactorTempSecret: null,
      twoFactorEnabledAt: null,
      // Force re-auth by invalidating refresh token.
      refreshTokenHash: null,
    },
    select: { id: true, email: true, fullName: true, role: true, clientId: true, isActive: true, twoFactorEnabled: true, createdAt: true },
  });
}

function generateTempPassword(len = 14) {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%';
  let out = '';
  for (let i = 0; i < len; i++) {
    out += chars[Math.floor(Math.random() * chars.length)];
  }
  return out;
}

export async function resetPassword(id: string) {
  const u = await prisma.user.findUnique({ where: { id }, select: { id: true } });
  if (!u) throw new HttpError(404, 'User not found');

  const tempPassword = generateTempPassword(16);
  const passwordHash = await bcrypt.hash(tempPassword, 12);

  const user = await prisma.user.update({
    where: { id },
    data: {
      passwordHash,
      // Force re-auth by invalidating refresh token.
      refreshTokenHash: null,
      failedLoginCount: 0,
      lockoutUntil: null,
    },
    select: { id: true, email: true, fullName: true, role: true, clientId: true, isActive: true, createdAt: true },
  });

  return { user, tempPassword };
}
