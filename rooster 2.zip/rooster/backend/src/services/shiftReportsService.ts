import { prisma } from '../db/prisma.js';
import { HttpError } from '../utils/http.js';

export type ReportAccessMode = 'read' | 'write';

export const DEFAULT_INCIDENTS = [
  'Ongewenste persoon',
  'Agressie / conflict',
  'Alarmmelding',
  'Brand / rook',
  'Inbraak(poging)',
  'Medische situatie',
  'Schade / vandalisme',
  'Overig',
];

export async function getShiftForReportAccess(shiftId: string) {
  const shift = await prisma.shift.findUnique({
    where: { id: shiftId },
    select: {
      id: true,
      title: true,
      startAt: true,
      endAt: true,
      clientId: true,
      location: { select: { name: true } },
      assignments: {
        select: {
          userId: true,
          status: true,
          user: { select: { subcontractorId: true } },
        },
      },
      timeEntries: { select: { userId: true, user: { select: { subcontractorId: true } } } },
    },
  });
  if (!shift) throw new HttpError(404, 'Shift not found');
  return shift;
}

export async function assertCanAccessShiftReport(user: any, shiftId: string, mode: ReportAccessMode) {
  if (!user?.id) throw new HttpError(401, 'Not authenticated');
  const shift = await getShiftForReportAccess(shiftId);

  if (user.role === 'ADMIN') return shift;

  if (user.role === 'CLIENT') {
    const me = await prisma.user.findUnique({ where: { id: user.id }, select: { clientId: true } });
    if (!me?.clientId || me.clientId !== shift.clientId) throw new HttpError(403, 'Forbidden');
    if (mode === 'write') throw new HttpError(403, 'Forbidden');
    return shift;
  }

  if (user.role === 'SUBCONTRACTOR') {
    const hasOwnWorkers = shift.assignments.some((a) => a.user?.subcontractorId === user.id) ||
      shift.timeEntries.some((t) => t.user?.subcontractorId === user.id);
    if (!hasOwnWorkers) throw new HttpError(403, 'Forbidden');
    if (mode === 'write') throw new HttpError(403, 'Forbidden');
    return shift;
  }

  // EMPLOYEE
  const isInvolved = shift.assignments.some((a) => a.userId === user.id) || shift.timeEntries.some((t) => t.userId === user.id);
  if (!isInvolved) throw new HttpError(403, 'Forbidden');

  if (mode === 'write') {
    // Write access is restricted to workers who were actually approved for the shift
    // (or have an active timeEntry). A REQUESTED worker should never be able to
    // edit an official shift report.
    const allowed = shift.assignments.some((a) => a.userId === user.id && a.status === 'APPROVED')
      || shift.timeEntries.some((t) => t.userId === user.id);
    if (!allowed) throw new HttpError(403, 'Forbidden');
  }

  return shift;
}

export async function getShiftReportOrNull(shiftId: string) {
  return prisma.shiftReport.findUnique({
    where: { shiftId },
    include: {
      events: { orderBy: [{ kind: 'asc' }, { sortOrder: 'asc' }] },
      attachments: { select: { id: true, fileName: true, mimeType: true, sizeBytes: true, createdAt: true, uploadedById: true } },
    },
  });
}

export async function upsertShiftReport(shiftId: string, actorId: string, input: {
  locationText: string;
  summary?: string | null;
  incidents: { label: string; checked: boolean; notes?: string | null; timeText?: string | null }[];
  actions: { label: string; checked: boolean; notes?: string | null }[];
}) {
  const existing = await prisma.shiftReport.findUnique({ where: { shiftId } });

  const report = await prisma.$transaction(async (tx) => {
    const r = existing
      ? await tx.shiftReport.update({
          where: { shiftId },
          data: {
            locationText: input.locationText,
            summary: input.summary ?? null,
            updatedById: actorId,
          },
        })
      : await tx.shiftReport.create({
          data: {
            shiftId,
            locationText: input.locationText,
            summary: input.summary ?? null,
            createdById: actorId,
            updatedById: actorId,
          },
        });

    // Replace events wholesale for simplicity
    await tx.shiftReportEvent.deleteMany({ where: { reportId: r.id } });

    const eventsData = [
      ...input.incidents.map((it, idx) => ({
        reportId: r.id,
        kind: 'INCIDENT' as const,
        label: it.label,
        checked: Boolean(it.checked),
        notes: it.notes ?? null,
        timeText: (it as any).timeText ?? null,
        sortOrder: idx,
      })),
      ...input.actions.map((it, idx) => ({
        reportId: r.id,
        kind: 'ACTION' as const,
        label: it.label,
        checked: Boolean(it.checked),
        notes: it.notes ?? null,
        sortOrder: idx,
      })),
    ];

    if (eventsData.length) {
      await tx.shiftReportEvent.createMany({ data: eventsData });
    }

    return r;
  });

  return { report, created: !existing };
}

export async function ensureReportExists(shiftId: string, actorId: string, locationText: string) {
  const existing = await prisma.shiftReport.findUnique({ where: { shiftId } });
  if (existing) return existing;
  return prisma.shiftReport.create({
    data: {
      shiftId,
      locationText,
      createdById: actorId,
      updatedById: actorId,
    },
  });
}

export async function addAttachment(reportId: string, actorId: string, input: { fileName: string; mimeType: string; data: Buffer }) {
  return prisma.shiftReportAttachment.create({
    data: {
      reportId,
      uploadedById: actorId,
      fileName: input.fileName,
      mimeType: input.mimeType,
      sizeBytes: input.data.byteLength,
      // Prisma Bytes expects Uint8Array; Buffer is compatible at runtime but TS wants Uint8Array.
      data: new Uint8Array(input.data),
    },
    select: { id: true, fileName: true, mimeType: true, sizeBytes: true, createdAt: true, uploadedById: true },
  });
}

export async function getAttachmentWithData(attachmentId: string) {
  return prisma.shiftReportAttachment.findUnique({ where: { id: attachmentId } });
}

export async function deleteAttachment(attachmentId: string) {
  return prisma.shiftReportAttachment.delete({ where: { id: attachmentId }, select: { id: true, reportId: true, fileName: true } });
}
