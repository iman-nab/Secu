import nodemailer from 'nodemailer';
import { env } from '../config/env.js';

type SendInviteArgs = {
  to: string;
  inviteLink: string;
  clientName?: string;
  expiresAt?: Date | null;
};

function smtpConfigured() {
  return Boolean(env.SMTP_HOST && env.SMTP_USER && env.SMTP_PASS);
}

function getTransport() {
  return nodemailer.createTransport({
    host: env.SMTP_HOST,
    port: env.SMTP_PORT,
    secure: env.SMTP_PORT === 465,
    auth: {
      user: env.SMTP_USER,
      pass: env.SMTP_PASS,
    },
  });
}

type SendTextEmailArgs = {
  to: string;
  subject: string;
  text: string;
};

/**
 * Generic text email sender used for shift/in-app notifications.
 * - MAIL_MODE=manual -> never sends (logs)
 * - SMTP missing -> logs
 */
export async function sendTextEmail(args: SendTextEmailArgs) {
  if (env.MAIL_MODE === 'manual') {
    console.log(`[mail] MAIL_MODE=manual. Email to ${args.to}: ${args.subject}`);
    return { delivered: false, mode: 'manual' as const };
  }

  if (!smtpConfigured()) {
    console.log(`[mail] SMTP not configured. Email to ${args.to}: ${args.subject}`);
    return { delivered: false, mode: 'log' as const };
  }

  const transporter = getTransport();
  await transporter.sendMail({
    from: env.SMTP_FROM,
    to: args.to,
    subject: args.subject,
    text: args.text,
  });

  return { delivered: true, mode: 'smtp' as const };
}

export async function sendClientInviteEmail(args: SendInviteArgs) {
  // Manual mode: never send emails. We still log the invite link to help with testing.
  if (env.MAIL_MODE === 'manual') {
    console.log(`[mail] MAIL_MODE=manual. Invite for ${args.to}: ${args.inviteLink}`);
    return { delivered: false, mode: 'manual' as const };
  }

  const subject = `Activeer je opdrachtgever-portaal${args.clientName ? ` (${args.clientName})` : ''}`;
  const exp = args.expiresAt ? new Date(args.expiresAt).toLocaleString('nl-NL') : null;

  const text =
    `Hallo,\n\n` +
    `Je bent uitgenodigd om het opdrachtgever-portaal te activeren.\n` +
    `Open deze link om een wachtwoord te kiezen:\n\n` +
    `${args.inviteLink}\n\n` +
    (exp ? `Deze link is geldig tot: ${exp}\n\n` : '') +
    `Als je deze mail niet verwachtte, kun je hem negeren.\n`;

  // If SMTP is not configured, log the invite link so you still can move forward.
  if (!smtpConfigured()) {
    console.log(`[mail] SMTP not configured. Invite for ${args.to}: ${args.inviteLink}`);
    return { delivered: false, mode: 'log' as const };
  }

  const transporter = getTransport();
  await transporter.sendMail({
    from: env.SMTP_FROM,
    to: args.to,
    subject,
    text,
  });

  return { delivered: true, mode: 'smtp' as const };
}
