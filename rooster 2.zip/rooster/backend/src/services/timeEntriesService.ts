import { prisma } from '../db/prisma.js';
import { env } from '../config/env.js';
import { HttpError } from '../utils/http.js';
import { distanceMeters } from '../utils/geo.js';
import { minutesBetween } from '../utils/time.js';
import { createAdminNotification } from './notificationsService.js';
import { GeofenceError } from '../utils/domainErrors.js';

type GeoInput = {
  lat: number;
  lng: number;
  accuracyM: number;
  geoReason?: string | null;
  distanceM?: number;
  bypassGeofence?: boolean;
};

export async function clockIn(shiftId: string, userId: string, geo: GeoInput) {
  validateGeo(geo);

  const shift = await prisma.shift.findUnique({
    where: { id: shiftId },
    include: { location: true, assignments: true },
  });
  if (!shift) throw new HttpError(404, 'Shift not found');

  // Do not allow clock-in for archived or finished shifts.
  // This prevents incorrect hours on completed shifts.
  if ((shift as any).isDeleted) throw new HttpError(404, 'Shift not found');
  if (shift.status === 'COMPLETED') throw new HttpError(409, 'Shift is already completed', 'SHIFT_COMPLETED');
  if (shift.status === 'CANCELLED') throw new HttpError(409, 'Shift is cancelled', 'SHIFT_CANCELLED');

  // Must be assigned/approved
  const assigned = shift.assignments.some((a: any) => a.userId === userId && a.status === 'APPROVED');
  if (!assigned) throw new HttpError(403, 'Not assigned to this shift');

  // Must be within clock-in window
  validateTimeWindow(shift.startAt);

  // Geofence validation (soft-block supported via bypassGeofence)
  const distM = validateGeofence(shift.location, geo);

  // Business rule: one clock-in per shift per user (and only one active at a time)
  // Guard against race conditions by doing the check+insert in a SERIALIZABLE
  // transaction so concurrent clock-in requests cannot both succeed.
  const entry = await prisma.$transaction(
    async (tx) => {
      const anyEntry = await tx.timeEntry.findFirst({
        where: { shiftId, userId },
        orderBy: { clockInAt: 'desc' },
      });
      if (anyEntry?.clockOutAt) {
        throw new HttpError(409, 'Already clocked in for this shift (one time only)', 'TIMEENTRY_EXISTS');
      }

      const existing = await tx.timeEntry.findFirst({
        where: { shiftId, userId, clockOutAt: null },
      });
      if (existing) throw new HttpError(409, 'Already clocked in for this shift', 'TIMEENTRY_ACTIVE');

      return tx.timeEntry.create({
        data: {
          shiftId,
          userId,
          clockInAt: new Date(),
          clockInLat: geo.lat,
          clockInLng: geo.lng,
          clockInAccM: geo.accuracyM,
          clockInDistanceM: distM ?? null,
          clockInReason: geo.geoReason ?? null,
        } as any,
      });
    },
    { isolationLevel: 'Serializable' },
  );

  // Notify admins
  await createAdminNotification({
    type: 'CLOCK_IN',
    senderId: userId,
    message: `Employee clocked in for "${shift.title}"`,
    data: { shiftId, userId, timeEntryId: entry.id, distanceM: distM ?? null, geoReason: geo.geoReason ?? null },
  });

  return entry;
}

export async function clockOut(shiftId: string, userId: string, geo: GeoInput) {
  validateGeo(geo);

  const shift = await prisma.shift.findUnique({ where: { id: shiftId }, include: { location: true } });
  if (!shift) throw new HttpError(404, 'Shift not found');

  // Archived shifts should not be clocked.
  if ((shift as any).isDeleted) throw new HttpError(404, 'Shift not found');

  // Do not allow clock-out for cancelled/completed shifts.
  // If a shift is cancelled while someone is clocked in, an admin should resolve it via corrections.
  if (shift.status === 'COMPLETED') throw new HttpError(409, 'Shift is already completed', 'SHIFT_COMPLETED');
  if (shift.status === 'CANCELLED') throw new HttpError(409, 'Shift is cancelled', 'SHIFT_CANCELLED');

  // Find active entry
  const entry = await prisma.timeEntry.findFirst({ where: { shiftId, userId, clockOutAt: null } });
  if (!entry) throw new HttpError(404, 'No active clock-in found', 'TIMEENTRY_NOT_FOUND');

  // Geofence validation (also required for clock-out)
  const distM = validateGeofence(shift.location, geo);

  const now = new Date();
  const minutesWorked = minutesBetween(entry.clockInAt, now);

  const updated = await prisma.timeEntry.update({
    where: { id: entry.id },
    data: {
      clockOutAt: now,
      clockOutLat: geo.lat,
      clockOutLng: geo.lng,
      clockOutAccM: geo.accuracyM,
      clockOutDistanceM: distM ?? null,
      clockOutReason: geo.geoReason ?? null,
      minutesWorked,
    } as any,
  });

  await createAdminNotification({
    type: 'CLOCK_OUT',
    senderId: userId,
    message: `Employee clocked out for "${shift.title}" (${minutesWorked} min)`,
    data: { shiftId, userId, timeEntryId: updated.id, minutesWorked, distanceM: distM ?? null, geoReason: geo.geoReason ?? null },
  });

  // Business rule: mark the shift COMPLETED only when all approved assignees
  // have both clocked in AND clocked out.
  try {
    await maybeMarkShiftCompleted(shiftId);
  } catch {
    // best-effort; never block the user clock-out
  }

  return { existing: entry, updated };
}

async function maybeMarkShiftCompleted(shiftId: string) {
  const shift = await prisma.shift.findUnique({
    where: { id: shiftId },
    select: {
      id: true,
      status: true,
      isDeleted: true,
      assignments: { where: { status: 'APPROVED' }, select: { userId: true } },
    },
  });
  if (!shift || shift.isDeleted) return;
  if (shift.status === 'CANCELLED') return;
  if (shift.assignments.length === 0) return;

  const approvedUserIds = shift.assignments.map((a) => a.userId);

  // For each approved assignee, ensure there is a time entry with clockOutAt.
  const entries = await prisma.timeEntry.findMany({
    where: { shiftId, userId: { in: approvedUserIds } },
    orderBy: { clockInAt: 'desc' },
  });

  const latestByUser = new Map<string, { clockOutAt: Date | null }>();
  for (const e of entries) {
    if (!latestByUser.has(e.userId)) {
      latestByUser.set(e.userId, { clockOutAt: e.clockOutAt ?? null });
    }
  }

  const allDone = approvedUserIds.every((uid) => {
    const t = latestByUser.get(uid);
    return !!t && !!t.clockOutAt;
  });

  if (!allDone) return;

  if (shift.status !== 'COMPLETED') {
    await prisma.shift.update({ where: { id: shiftId }, data: { status: 'COMPLETED' } });
  }
}

export async function listMyTimeEntries(userId: string, range?: { start: Date; end: Date }) {
  return prisma.timeEntry.findMany({
    where: {
      userId,
      ...(range ? { clockInAt: { gte: range.start, lte: range.end } } : {}),
    },
    include: { shift: { include: { location: true } } },
    orderBy: { clockInAt: 'desc' },
  });
}

export async function listTimeEntriesAdmin(range?: { start: Date; end: Date; userId?: string }) {
  return prisma.timeEntry.findMany({
    where: {
      ...(range?.userId ? { userId: range.userId } : {}),
      ...(range ? { clockInAt: { gte: range.start, lte: range.end } } : {}),
    },
    include: { user: true, shift: { include: { location: true } } },
    orderBy: { clockInAt: 'desc' },
  });
}

export async function adminCorrectTimeEntry(
  actorId: string,
  id: string,
  input: { clockInAt?: Date; clockOutAt?: Date; reason: string },
) {
  const reason = String(input.reason ?? '').trim();
  if (reason.length < 3) throw new HttpError(400, 'Correction reason is required', 'REASON_REQUIRED');
  const existing = await prisma.timeEntry.findUnique({ where: { id } });
  if (!existing) throw new HttpError(404, 'Time entry not found');

  const updated = await prisma.timeEntry.update({
    where: { id },
    data: {
      clockInAt: input.clockInAt ?? existing.clockInAt,
      clockOutAt: input.clockOutAt ?? existing.clockOutAt,
      minutesWorked:
        input.clockOutAt && (input.clockInAt ?? existing.clockInAt)
          ? Math.max(0, Math.round((input.clockOutAt.getTime() - (input.clockInAt ?? existing.clockInAt).getTime()) / 60000))
          : existing.minutesWorked,
      adminOverride: true,
      correctedById: actorId,
      correctionReason: reason,
      correctedAt: new Date(),
    },
  });

  return { existing, updated };
}

export async function adminClockIn(actorId: string, shiftId: string, userId: string, input: { clockInAt?: Date; reason: string }) {
  const reason = String(input.reason ?? '').trim();
  if (reason.length < 3) throw new HttpError(400, 'Correction reason is required', 'REASON_REQUIRED');

  const shift = await prisma.shift.findUnique({
    where: { id: shiftId },
    include: { location: true, assignments: true },
  });
  if (!shift) throw new HttpError(404, 'Shift not found');
  if ((shift as any).isDeleted) throw new HttpError(404, 'Shift not found');
  if (shift.status === 'COMPLETED') throw new HttpError(409, 'Shift is already completed', 'SHIFT_COMPLETED');
  if (shift.status === 'CANCELLED') throw new HttpError(409, 'Shift is cancelled', 'SHIFT_CANCELLED');

  // Prefer: only clock-in employees that are approved/assigned
  const assigned = shift.assignments.some((a: any) => a.userId === userId && a.status === 'APPROVED');
  if (!assigned) throw new HttpError(400, 'User is not approved for this shift', 'NOT_ASSIGNED');

  // Prevent duplicate active clock-ins
  const existing = await prisma.timeEntry.findFirst({ where: { shiftId, userId, clockOutAt: null } });
  if (existing) throw new HttpError(409, 'Already clocked in for this shift', 'TIMEENTRY_ACTIVE');

  const now = new Date();
  const clockInAt = input.clockInAt ?? now;

  const entry = await prisma.timeEntry.create({
    data: {
      shiftId,
      userId,
      clockInAt,
      clockInLat: shift.location.latitude,
      clockInLng: shift.location.longitude,
      clockInAccM: 0,
      adminOverride: true,
      correctedById: actorId,
      correctionReason: reason,
      correctedAt: now,
    },
  });

  return entry;
}

export async function adminClockOut(
  actorId: string,
  shiftId: string,
  userId: string,
  input: { clockOutAt?: Date; reason: string },
) {
  const reason = String(input.reason ?? '').trim();
  if (reason.length < 3) throw new HttpError(400, 'Correction reason is required', 'REASON_REQUIRED');

  const shift = await prisma.shift.findUnique({
    where: { id: shiftId },
    include: { location: true, assignments: true },
  });
  if (!shift) throw new HttpError(404, 'Shift not found');
  if ((shift as any).isDeleted) throw new HttpError(404, 'Shift not found');
  if (shift.status === 'COMPLETED') throw new HttpError(409, 'Shift is already completed', 'SHIFT_COMPLETED');
  if (shift.status === 'CANCELLED') throw new HttpError(409, 'Shift is cancelled', 'SHIFT_CANCELLED');

  // Only allow for approved/assigned users (keeps data sane)
  const assigned = shift.assignments.some((a: any) => a.userId === userId && a.status === 'APPROVED');
  if (!assigned) throw new HttpError(400, 'User is not approved for this shift', 'NOT_ASSIGNED');

  // Find active entry
  const active = await prisma.timeEntry.findFirst({ where: { shiftId, userId, clockOutAt: null }, orderBy: { clockInAt: 'desc' } });
  if (!active) throw new HttpError(404, 'No active clock-in found', 'TIMEENTRY_NOT_FOUND');

  const now = new Date();
  const clockOutAt = input.clockOutAt ?? now;
  const minutesWorked = minutesBetween(active.clockInAt, clockOutAt);

  const updated = await prisma.timeEntry.update({
    where: { id: active.id },
    data: {
      clockOutAt,
      clockOutLat: shift.location.latitude,
      clockOutLng: shift.location.longitude,
      clockOutAccM: 0,
      minutesWorked,
      adminOverride: true,
      correctedById: actorId,
      correctionReason: reason,
      correctedAt: now,
    } as any,
  });

  // Best-effort completion update
  try {
    await maybeMarkShiftCompleted(shiftId);
  } catch {
    // ignore
  }

  return updated;
}

export async function adminResetTimeEntry(actorId: string, id: string) {
  const existing = await prisma.timeEntry.findUnique({
    where: { id },
    include: {
      user: { select: { id: true, fullName: true, email: true } },
      shift: { select: { id: true, title: true, startAt: true, endAt: true } },
    },
  });
  if (!existing) throw new HttpError(404, 'Time entry not found');

  await prisma.timeEntry.delete({ where: { id } });

  // Tell the user (helpful when an admin resets it so they can clock again)
  await prisma.notification.create({
    data: {
      recipientId: existing.userId,
      senderId: actorId,
      type: 'TIMEENTRY_RESET',
      message: `Je tijdregistratie voor "${existing.shift.title}" is gereset door een admin. Je kunt opnieuw inklokken.`,
      // IMPORTANT: Prisma Json cannot store Date objects. Use ISO strings.
      data: {
        shiftId: existing.shiftId,
        timeEntryId: existing.id,
        startAt: existing.shift.startAt.toISOString(),
        endAt: existing.shift.endAt.toISOString(),
      },
    },
  });

  return existing;
}

function validateGeo(geo: GeoInput) {
  if (!Number.isFinite(geo.lat) || !Number.isFinite(geo.lng) || !Number.isFinite(geo.accuracyM)) {
    throw new HttpError(400, 'Invalid geo payload');
  }
  if (geo.accuracyM > env.GPS_ACCURACY_THRESHOLD_M) {
    throw new HttpError(400, `GPS accuracy too low (>${env.GPS_ACCURACY_THRESHOLD_M}m)`, 'GPS_ACCURACY_LOW', {
      accuracyM: geo.accuracyM,
      thresholdM: env.GPS_ACCURACY_THRESHOLD_M,
    });
  }
}

function validateTimeWindow(shiftStartAt: Date) {
  const now = new Date();
  const early = new Date(shiftStartAt.getTime() - env.CLOCK_IN_EARLY_MINUTES * 60000);
  const late = new Date(shiftStartAt.getTime() + env.CLOCK_IN_LATE_MINUTES * 60000);
  if (now < early || now > late) {
    throw new HttpError(400, 'Clock-in not allowed outside time window', 'CLOCKIN_WINDOW', {
      now,
      allowedFrom: early,
      allowedUntil: late,
    });
  }
}

function validateGeofence(
  location: { latitude: number; longitude: number; radiusM: number },
  geo: GeoInput,
): number {
  const dist = distanceMeters(
    { lat: location.latitude, lng: location.longitude },
    { lat: geo.lat, lng: geo.lng },
  );
  const distM = Math.round(dist);
  if (dist > location.radiusM) {
    // Allow soft-block UX: the frontend can let the user proceed with a reason.
    if (geo.bypassGeofence) return distM;
    throw new GeofenceError(distM, location.radiusM);
  }
  return distM;
}
