import { prisma } from '../db/prisma.js';
import { sendPushToUser } from './pushService.js';
import { env } from '../config/env.js';
import { sendTextEmail } from './mailerService.js';

function serializeJsonSafe(value: any): any {
  if (value == null) return value;
  if (value instanceof Date) return value.toISOString();
  if (Array.isArray(value)) return value.map((v) => serializeJsonSafe(v));
  if (typeof value === 'object') {
    const out: any = {};
    for (const [k, v] of Object.entries(value)) {
      out[k] = serializeJsonSafe(v);
    }
    return out;
  }
  return value;
}

function appUrl(path: string) {
  const base = (env.APP_BASE_URL ?? '').replace(/\/$/, '');
  if (!base) return path;
  return path.startsWith('/') ? `${base}${path}` : `${base}/${path}`;
}

function buildEmailForNotification(args: { type: string; message: string; url?: string }) {
  const url = args.url ? appUrl(args.url) : null;

  // Keep this minimal; we can add templates later.
  const subject = `Rooster: ${args.type.replace(/_/g, ' ')}`;
  const text = `${args.message}\n${url ? `\nOpen in Rooster: ${url}\n` : ''}`;
  return { subject, text };
}

function shouldEmail(type: string, recipientRole: 'ADMIN' | 'EMPLOYEE') {
  // Minimum viable: employees get email for planning changes; admins only for no-show.
  if (recipientRole === 'ADMIN') return type === 'NO_SHOW';
  return ['SHIFT_ASSIGNED', 'SHIFT_UPDATED', 'SHIFT_CANCELLED'].includes(type);
}

export async function createAdminNotification(input: {
  type: string;
  message: string;
  data?: any;
  senderId?: string;
}) {
  const data = serializeJsonSafe(input.data);
  const admins = await prisma.user.findMany({ where: { role: 'ADMIN', isActive: true }, select: { id: true, email: true } });
  if (admins.length === 0) return [];

  const result = await prisma.notification.createMany({
    data: admins.map((a: { id: string }) => ({
      recipientId: a.id,
      senderId: input.senderId,
      type: input.type,
      message: input.message,
      data,
    })),
  });

  // Fire-and-forget push notifications
  await Promise.all(
    admins.map((a: { id: string }) =>
      sendPushToUser(a.id, {
        title: 'Rooster',
        body: input.message,
        type: input.type,
        data: { ...(data ?? {}), url: (data as any)?.url ?? '/notificaties' },
      }),
    ),
  );

  // Optional email (minimum viable)
  if (shouldEmail(input.type, 'ADMIN')) {
    const { subject, text } = buildEmailForNotification({
      type: input.type,
      message: input.message,
      url: (data as any)?.url ?? '/notificaties',
    });
    await Promise.all(
      admins
        .filter((a: any) => Boolean(a.email))
        .map((a: any) =>
          sendTextEmail({
            to: a.email,
            subject,
            text,
          }),
        ),
    );
  }

  return result;
}

export async function createUserNotification(input: {
  recipientId: string;
  type: string;
  message: string;
  data?: any;
  senderId?: string;
}) {
  const data = serializeJsonSafe(input.data);
  const created = await prisma.notification.create({
    data: {
      recipientId: input.recipientId,
      senderId: input.senderId,
      type: input.type,
      message: input.message,
      data,
    },
  });

  await sendPushToUser(input.recipientId, {
    title: 'Rooster',
    body: input.message,
    type: input.type,
    data: { ...(data ?? {}), url: (data as any)?.url ?? '/notificaties' },
  });

  // Subcontractor visibility: if this notification is for an employee under a subcontractor,
  // also notify the subcontractor account.
  try {
    const recipient = await prisma.user.findUnique({
      where: { id: input.recipientId },
      select: { id: true, fullName: true, email: true, role: true, subcontractorId: true },
    });
    const subId = recipient?.subcontractorId;
    if (subId && (recipient?.role === 'EMPLOYEE')) {
      const prefix = recipient?.fullName || recipient?.email || 'Werknemer';
      const msg = `Voor ${prefix}: ${input.message}`;
      const subData = serializeJsonSafe({ ...(data ?? {}), employeeId: recipient.id, employeeName: recipient.fullName ?? null });
      await prisma.notification.create({
        data: {
          recipientId: subId,
          senderId: input.senderId,
          type: input.type,
          message: msg,
          data: subData,
        },
      });
      await sendPushToUser(subId, {
        title: 'Rooster',
        body: msg,
        type: input.type,
        data: { ...(subData ?? {}), url: (subData as any)?.url ?? '/notificaties' },
      });
    }
  } catch {
    // best-effort
  }

  // Optional email (minimum viable)
  try {
    const user = await prisma.user.findUnique({ where: { id: input.recipientId }, select: { email: true, role: true } });
    const role = (user?.role ?? 'EMPLOYEE') as 'ADMIN' | 'EMPLOYEE';
    if (user?.email && shouldEmail(input.type, role)) {
      const { subject, text } = buildEmailForNotification({
        type: input.type,
        message: input.message,
        url: (data as any)?.url ?? '/notificaties',
      });
      await sendTextEmail({ to: user.email, subject, text });
    }
  } catch {
    // Best-effort: never block the API on email issues.
  }

  return created;
}

export async function listNotifications(
  recipientId: string,
  opts?: { page?: number; pageSize?: number; tab?: 'all' | 'action' },
) {
  const page = Math.max(1, Number(opts?.page ?? 1));
  const pageSize = Math.max(1, Math.min(200, Number(opts?.pageSize ?? 25)));
  const skip = (page - 1) * pageSize;

  const tab = opts?.tab ?? 'all';
  const where: any = {
    recipientId,
    ...(tab === 'action'
      ? {
          type: 'OPEN_SHIFT_REQUEST',
          readAt: null,
        }
      : {}),
  };

  const [items, totalCount] = await prisma.$transaction([
    prisma.notification.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      skip,
      take: pageSize,
      include: {
        sender: {
          select: {
            id: true,
            fullName: true,
            email: true,
            role: true,
          },
        },
      },
    }),
    prisma.notification.count({ where }),
  ]);

  return { items, totalCount, page, pageSize };
}

export async function markRead(recipientId: string, id: string) {
  return prisma.notification.updateMany({
    where: { id, recipientId },
    data: { readAt: new Date() },
  });
}


export async function markAllRead(recipientId: string) {
  return prisma.notification.updateMany({
    where: { recipientId, readAt: null },
    data: { readAt: new Date() },
  });
}

export async function countUnread(recipientId: string) {
  return prisma.notification.count({ where: { recipientId, readAt: null } });
}
