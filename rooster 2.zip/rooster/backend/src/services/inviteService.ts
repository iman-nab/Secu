import crypto from 'crypto';
import bcrypt from 'bcryptjs';
import { prisma } from '../db/prisma.js';
import { HttpError } from '../utils/http.js';
import { assertPasswordPolicy } from '../utils/passwordPolicy.js';
import { logAudit } from './auditService.js';
import type { $Enums } from '@prisma/client';


const DEFAULT_EXPIRES_HOURS = 72;

function generateToken() {
  return crypto.randomBytes(24).toString('base64url');
}

export async function createInvite(actor: { id: string; role: $Enums.Role }, input: {
  email: string;
  fullName: string;
  role: $Enums.Role;
  clientId?: string | null;
  subcontractorId?: string | null;
  expiresInHours?: number;
}) {
  const email = input.email.toLowerCase().trim();
  const fullName = input.fullName.trim();

  if (actor.role === 'SUBCONTRACTOR') {
    if (input.role !== 'EMPLOYEE') {
      throw new HttpError(403, 'Forbidden', 'FORBIDDEN');
    }
  } else if (actor.role !== 'ADMIN') {
    throw new HttpError(403, 'Forbidden', 'FORBIDDEN');
  }

  if (input.role === 'CLIENT' && !input.clientId) {
    throw new HttpError(400, 'clientId is required when role is CLIENT', 'CLIENT_ID_REQUIRED');
  }

  const subcontractorId = actor.role === 'SUBCONTRACTOR'
    ? actor.id
    : (input.subcontractorId ?? null);

  // Allow invites for existing users as well (admin-driven password reset / re-activation),
  // but only when the invite scope matches the existing account.
  const existing = await prisma.user.findUnique({
    where: { email },
    select: { id: true, role: true, clientId: true, subcontractorId: true },
  });

  // NOTE: passColor is a User property; some Prisma schemas don't include it on Invite.
  // We therefore do not persist passColor on invites.

  if (existing) {
    if (existing.role !== input.role) {
      throw new HttpError(409, 'Email already exists for a different role', 'ROLE_MISMATCH');
    }
    if (input.role === 'CLIENT' && existing.clientId !== input.clientId) {
      throw new HttpError(409, 'Client mismatch for existing account', 'CLIENT_MISMATCH');
    }
    if (input.role === 'EMPLOYEE' && subcontractorId && existing.subcontractorId && existing.subcontractorId !== subcontractorId) {
      throw new HttpError(409, 'Subcontractor mismatch for existing account', 'SUBCONTRACTOR_MISMATCH');
    }
  }

  const token = generateToken();
  const expiresIn = input.expiresInHours ?? DEFAULT_EXPIRES_HOURS;
  const expiresAt = new Date(Date.now() + expiresIn * 60 * 60 * 1000);

  const invite = await prisma.invite.create({
    data: {
      token,
      email,
      fullName,
      role: input.role,
      clientId: input.clientId ?? null,
      subcontractorId,
      createdById: actor.id,
      expiresAt,
    },
  });

  await logAudit({
    actorId: actor.id,
    action: 'INVITE_CREATED',
    entity: 'Invite',
    entityId: invite.id,
    before: null,
    after: { id: invite.id, token: invite.token, role: invite.role, email: invite.email, expiresAt: invite.expiresAt, subcontractorId: invite.subcontractorId, clientId: invite.clientId },
  });

  return invite;
}

export async function getInvitePublic(token: string) {
  const invite = await prisma.invite.findUnique({
    where: { token },
    select: { token: true, email: true, fullName: true, role: true, expiresAt: true, usedAt: true },
  });
  if (!invite) throw new HttpError(404, 'Invite not found', 'INVITE_NOT_FOUND');
  if (invite.usedAt) throw new HttpError(410, 'Invite already used', 'INVITE_USED');
  if (invite.expiresAt.getTime() < Date.now()) throw new HttpError(410, 'Invite expired', 'INVITE_EXPIRED');
  return invite;
}

export async function consumeInviteAndCreateUser(token: string, input: {
  password: string;
  phone?: string | null;
  birthDate?: string | null;
  passColor?: $Enums.PassColor | null;
}) {
  const invite = await prisma.invite.findUnique({ where: { token } });
  if (!invite) throw new HttpError(404, 'Invite not found', 'INVITE_NOT_FOUND');
  if (invite.usedAt) throw new HttpError(410, 'Invite already used', 'INVITE_USED');
  if (invite.expiresAt.getTime() < Date.now()) throw new HttpError(410, 'Invite expired', 'INVITE_EXPIRED');

  assertPasswordPolicy(input.password);

  const birthDate = input.birthDate ? new Date(input.birthDate) : null;

  const existing = await prisma.user.findUnique({ where: { email: invite.email }, select: { id: true, passColor: true } });

  // passColor is required for employees when the account doesn't already have it.
  if (invite.role === 'EMPLOYEE' && !existing?.passColor && !input.passColor) {
    throw new HttpError(400, 'passColor is required when role is EMPLOYEE', 'PASSCOLOR_REQUIRED');
  }

  const desiredPassColor = (invite.role === 'EMPLOYEE'
    ? (input.passColor ?? existing?.passColor ?? null)
    : (input.passColor ?? null)) as $Enums.PassColor | null;

  const user = existing
    ? await prisma.user.update({
        where: { id: existing.id },
        data: {
          fullName: invite.fullName,
          role: invite.role,
          clientId: invite.role === 'CLIENT' ? invite.clientId : null,
          subcontractorId: invite.role === 'EMPLOYEE' ? invite.subcontractorId : null,
          passColor: desiredPassColor,
          ...(input.phone !== undefined ? { phone: input.phone ?? null } : {}),
          ...(input.birthDate !== undefined ? { birthDate } : {}),
          status: 'ACTIVE',
          isActive: true,
          failedLoginCount: 0,
          lockoutUntil: null,
          refreshTokenHash: null,
          passwordHash: await bcrypt.hash(input.password, 12),
        },
      })
    : await prisma.user.create({
        data: {
          email: invite.email,
          fullName: invite.fullName,
          role: invite.role,
          clientId: invite.role === 'CLIENT' ? invite.clientId : null,
          subcontractorId: invite.role === 'EMPLOYEE' ? invite.subcontractorId : null,
          passColor: desiredPassColor,
          phone: input.phone ?? null,
          birthDate,
          status: 'ACTIVE',
          isActive: true,
          passwordHash: await bcrypt.hash(input.password, 12),
        },
      });

  await prisma.invite.update({
    where: { id: invite.id },
    data: { usedAt: new Date(), usedById: user.id },
  });

  await logAudit({
    actorId: user.id,
    action: 'INVITE_USED',
    entity: 'Invite',
    entityId: invite.id,
    before: null,
    after: { id: invite.id, token: invite.token, usedById: user.id },
  });

  return user;
}
