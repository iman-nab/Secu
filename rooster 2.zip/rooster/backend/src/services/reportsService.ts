import ExcelJS from 'exceljs';
import { prisma } from '../db/prisma.js';

export async function hoursReport(
  input: {
    start: Date;
    end: Date;
    userId?: string;
    clientId?: string;
    subcontractorId?: string;
    rounding?: 'none' | '15';
    page?: number;
    pageSize?: number;
  },
  opts?: { includeRates?: boolean },
) {
  // Include entries that *overlap* the requested period (not only those that
  // started within it). This fixes cases where someone clocked in before the
  // start-date but clocked out (or is still active) inside the period.
  const where: any = {
    ...(input.userId ? { userId: input.userId } : {}),
    clockInAt: { lte: input.end },
    OR: [{ clockOutAt: { gte: input.start } }, { clockOutAt: null }],
    ...(input.clientId ? { shift: { clientId: input.clientId } } : {}),
    ...(input.subcontractorId
      ? {
          user: {
            OR: [{ subcontractorId: input.subcontractorId }, { id: input.subcontractorId }],
          },
        }
      : {}),
  };

  const wantsPaging = Number.isFinite(input.page as any) || Number.isFinite(input.pageSize as any);
  const page = Math.max(1, Number(input.page || 1));
  const pageSize = Math.max(1, Math.min(200, Number(input.pageSize || 25)));
  const skip = (page - 1) * pageSize;

  const [entries, totalCount] = await prisma.$transaction([
    prisma.timeEntry.findMany({
      where,
      include: { user: true, shift: { include: { location: true, client: true } } },
      orderBy: { clockInAt: 'asc' },
      ...(wantsPaging ? { skip, take: pageSize } : {}),
    }),
    prisma.timeEntry.count({ where }),
  ]);

  // Shift-level extra costs: map shiftId -> total extra costs (cents)
  const shiftIdsThisPage = Array.from(new Set((entries as any[]).map((e) => e.shiftId).filter(Boolean)));
  const extraByShiftId = new Map<string, number>();
  if (shiftIdsThisPage.length > 0) {
    const grouped = await prisma.shiftExtraCost.groupBy({
      by: ['shiftId'],
      where: { shiftId: { in: shiftIdsThisPage } },
      _sum: { amountCents: true },
    });
    for (const g of grouped as any[]) {
      extraByShiftId.set(String(g.shiftId), Number(g._sum?.amountCents ?? 0));
    }
  }

  const clamp = (d: Date, min: Date, max: Date) => new Date(Math.min(max.getTime(), Math.max(min.getTime(), d.getTime())));
  const minutesBetween = (a: Date, b: Date) => Math.max(0, Math.round((b.getTime() - a.getTime()) / 60000));
  const now = new Date();

  const rounding: 'none' | '15' = (input.rounding === '15') ? '15' : 'none';
  const roundMins = (m: number) => (rounding === '15' ? Math.round(m / 15) * 15 : m);

  const includeRates = !!opts?.includeRates;

  const rows = entries.map((e: any) => {
    // Compute worked minutes even when `minutesWorked` is not (yet) stored.
    // Also clamp the duration to the requested report window.
    const rawEnd = e.clockOutAt ?? now;
    const effectiveStart = clamp(e.clockInAt, input.start, input.end);
    const effectiveEnd = clamp(rawEnd, input.start, input.end);
    const computedMinutesWorked = minutesBetween(effectiveStart, effectiveEnd);

    const baseRow: any = {
    timeEntryId: e.id,
    userId: e.userId,
    userName: e.user.fullName,
    userEmail: e.user.email,
    shiftId: e.shiftId,
    shiftTitle: e.shift.title,
    locationName: e.shift.location.name,
    clientId: e.shift.clientId ?? '',
    clientName: e.shift.client?.name ?? '',
    startAt: e.shift.startAt.toISOString(),
    endAt: e.shift.endAt.toISOString(),
    clockInAt: e.clockInAt.toISOString(),
    clockOutAt: e.clockOutAt ? e.clockOutAt.toISOString() : '',
    // Prefer stored minutes if available, otherwise use computed.
    // (For active entries, stored is usually null.)
    minutesWorked: (e.clockOutAt && e.minutesWorked > 0) ? e.minutesWorked : computedMinutesWorked,
    // Helpful for debugging / exports.
    minutesWorkedComputed: computedMinutesWorked,
    // Shift-level (not per worker) extra costs; shown in hours overview.
    shiftExtraCostsCents: extraByShiftId.get(String(e.shiftId)) ?? 0,
    };

    if (!includeRates) return baseRow;

    // Amounts should follow the chosen rounding mode so KPI + table stay consistent.
    const minutes = roundMins(Number(baseRow.minutesWorked || 0));
    const workerRateCents = Number(e.shift?.workerRateCents ?? 0);
    const employerRateCents = Number(e.shift?.employerRateCents ?? 0);

    // cents-per-hour * (minutes/60)
    const workerAmountCents = Math.round((workerRateCents * minutes) / 60);
    const employerAmountCents = Math.round((employerRateCents * minutes) / 60);

    return {
      ...baseRow,
      workerRateCents,
      employerRateCents,
      workerAmountCents,
      employerAmountCents,
    };
  });

  // KPI totals across ALL filtered entries (not just the current page).
  // These are used by the Hours page to show reliable totals even with pagination.
  const computeTotals = (list: any[]) => {
    let totalMinutesRaw = 0;
    let totalMinutesRounded = 0;
    let totalWorkerAmountCents = 0;
    let totalEmployerAmountCents = 0;

    for (const e of list) {
      const rawEnd = e.clockOutAt ?? now;
      const effectiveStart = clamp(e.clockInAt, input.start, input.end);
      const effectiveEnd = clamp(rawEnd, input.start, input.end);
      const computedMinutesWorked = minutesBetween(effectiveStart, effectiveEnd);
      const minsRaw = (e.clockOutAt && e.minutesWorked > 0) ? e.minutesWorked : computedMinutesWorked;
      const minsRounded = roundMins(Number(minsRaw || 0));

      totalMinutesRaw += Number(minsRaw || 0);
      totalMinutesRounded += minsRounded;

      const workerRateCents = Number(e.shift?.workerRateCents ?? 0);
      const employerRateCents = Number(e.shift?.employerRateCents ?? 0);
      totalWorkerAmountCents += Math.round((workerRateCents * minsRounded) / 60);
      totalEmployerAmountCents += Math.round((employerRateCents * minsRounded) / 60);
    }

    const avgWorkerRateCents = totalMinutesRounded > 0 ? Math.round((totalWorkerAmountCents * 60) / totalMinutesRounded) : null;
    const avgEmployerRateCents = totalMinutesRounded > 0 ? Math.round((totalEmployerAmountCents * 60) / totalMinutesRounded) : null;

    return {
      totalMinutesRaw,
      totalMinutesRounded,
      totalHoursRounded: Math.round((totalMinutesRounded / 60) * 100) / 100,
      totalWorkerAmountCents,
      totalEmployerAmountCents,
      avgWorkerRateCents,
      avgEmployerRateCents,
    };
  };

  let totals = computeTotals(entries);
  if (wantsPaging && totalCount > rows.length) {
    // Use a lighter query for totals.
    const all = await prisma.timeEntry.findMany({
      where,
      select: {
        clockInAt: true,
        clockOutAt: true,
        minutesWorked: true,
        shift: { select: { workerRateCents: true, employerRateCents: true } },
      },
      orderBy: { clockInAt: 'asc' },
    });
    totals = computeTotals(all);
  }

  // Total extra costs across the filtered dataset (unique per shift, to avoid double counting).
  // We base this on the distinct set of shiftIds present in the filtered time entries.
  let totalExtraCostsCents = 0;
  try {
    const distinctShiftIds = await prisma.timeEntry.findMany({
      where,
      select: { shiftId: true },
      distinct: ['shiftId'],
    });
    const allShiftIds = distinctShiftIds.map((r: any) => r.shiftId).filter(Boolean);
    if (allShiftIds.length > 0) {
      const groupedAll = await prisma.shiftExtraCost.groupBy({
        by: ['shiftId'],
        where: { shiftId: { in: allShiftIds } },
        _sum: { amountCents: true },
      });
      totalExtraCostsCents = (groupedAll as any[]).reduce((acc, g) => acc + Number(g._sum?.amountCents ?? 0), 0);
    }
  } catch {
    // Best-effort; do not break the report if distinct/groupBy is not supported.
    totalExtraCostsCents = 0;
  }

  return {
    rows,
    // Backwards compatible: keep raw minutes in totalMinutes.
    totalMinutes: totals.totalMinutesRaw,
    totalExtraCostsCents,
    totalMinutesRounded: totals.totalMinutesRounded,
    kpis: {
      rounding,
      totalMinutes: totals.totalMinutesRaw,
      totalMinutesRounded: totals.totalMinutesRounded,
      totalHoursRounded: totals.totalHoursRounded,
      totalWorkerAmountCents: totals.totalWorkerAmountCents,
      totalEmployerAmountCents: totals.totalEmployerAmountCents,
      avgWorkerRateCents: totals.avgWorkerRateCents,
      avgEmployerRateCents: totals.avgEmployerRateCents,
    },
    ...(wantsPaging ? { totalCount, page, pageSize } : {}),
  };
}

type RoundingMode = 'none' | '15';

function roundMinutes(m: number, mode: RoundingMode) {
  if (mode === '15') return Math.round(m / 15) * 15;
  return m;
}

function minutesToHoursDecimal(m: number) {
  return Math.round((m / 60) * 100) / 100;
}

function byKey<T extends Record<string, any>>(rows: T[], key: (r: T) => string) {
  const map = new Map<string, T[]>();
  for (const r of rows) {
    const k = key(r);
    const list = map.get(k) ?? [];
    list.push(r);
    map.set(k, list);
  }
  return map;
}

export function toCsv(rows: Record<string, any>[], opts?: { delimiter?: ',' | ';'; includeBom?: boolean }) {
  const delimiter = opts?.delimiter ?? ',';
  const includeBom = opts?.includeBom ?? false;
  if (rows.length === 0) return (includeBom ? '\ufeff' : '') + 'No data\n';
  const headers = Object.keys(rows[0]);
  const escape = (v: any) => {
    const s = String(v ?? '');
    // Quote when delimiter, quotes or newlines are present.
    const re = delimiter === ';' ? /[";\n]/ : /[",\n]/;
    if (re.test(s)) return `"${s.replaceAll('"', '""')}"`;
    return s;
  };
  const body = [
    headers.join(delimiter),
    ...rows.map((r) => headers.map((h) => escape(r[h])).join(delimiter)),
  ].join('\n') + '\n';
  return (includeBom ? '\ufeff' : '') + body;
}

export function toPayrollCsv(rows: Record<string, any>[], opts?: { rounding?: RoundingMode }) {
  const rounding = opts?.rounding ?? 'none';
  const users = byKey(rows, (r) => r.userId);
  const out = [] as any[];

  // If the report rows include money fields, aggregate them too.
  const hasWorkerAmount = rows.some((r: any) => r.workerAmountCents != null);
  const hasEmployerAmount = rows.some((r: any) => r.employerAmountCents != null);
  const eur = (cents: number) => (Number(cents || 0) / 100).toLocaleString('nl-NL', { style: 'currency', currency: 'EUR' });
  for (const [, list] of users) {
    const first = list[0];
    const totalMin = list.reduce((acc: number, r: any) => acc + roundMinutes(Number(r.minutesWorked || 0), rounding), 0);

    const totalWorkerAmountCents = hasWorkerAmount
      ? list.reduce((acc: number, r: any) => acc + Number(r.workerAmountCents || 0), 0)
      : null;
    const totalEmployerAmountCents = hasEmployerAmount
      ? list.reduce((acc: number, r: any) => acc + Number(r.employerAmountCents || 0), 0)
      : null;
    out.push({
      userId: first.userId,
      fullName: first.userName,
      email: first.userEmail,
      totalMinutes: totalMin,
      totalHours: minutesToHoursDecimal(totalMin),
      ...(hasWorkerAmount ? { totalWorkerAmountCents, totalWorkerAmountEur: eur(Number(totalWorkerAmountCents || 0)) } : {}),
      ...(hasEmployerAmount ? { totalEmployerAmountCents, totalEmployerAmountEur: eur(Number(totalEmployerAmountCents || 0)) } : {}),
      rounding,
    });
  }
  out.sort((a, b) => String(a.fullName).localeCompare(String(b.fullName)));
  // NL Excel import is far less painful with ; + UTF-8 BOM.
  return toCsv(out, { delimiter: ';', includeBom: true });
}

export function toSummaryCsv(rows: Record<string, any>[], opts?: { rounding?: RoundingMode }) {
  // Summary CSV = per user totals (same as payroll but without hours decimal rounding label)
  return toPayrollCsv(rows, opts);
}

function addTableSheet(workbook: ExcelJS.Workbook, name: string, rows: Record<string, any>[]) {
  const sheet = workbook.addWorksheet(name);
  if (rows.length === 0) {
    sheet.addRow(['No data']);
    return;
  }
  const headers = Object.keys(rows[0]);
  sheet.addRow(headers);
  for (const r of rows) sheet.addRow(headers.map((h) => r[h]));
  sheet.getRow(1).font = { bold: true };
  sheet.columns.forEach((c) => (c.width = Math.max(14, Math.min(32, (c.header ? String(c.header).length : 14) + 6))));
}

export async function toXlsxBuffer(
  rows: Record<string, any>[],
  opts?: { mode?: 'entries' | 'summary' | 'payroll'; rounding?: RoundingMode },
) {
  const mode = opts?.mode ?? 'entries';
  const rounding = opts?.rounding ?? 'none';

  const workbook = new ExcelJS.Workbook();
  workbook.creator = 'Rooster App';
  workbook.created = new Date();

  // Keep row shape intact (strict TS sometimes narrows spread objects too aggressively here)
  const withRounded = rows.map((r: any) => ({
    ...r,
    minutesWorkedRounded: roundMinutes(Number(r.minutesWorked || 0), rounding),
    hoursWorkedRounded: minutesToHoursDecimal(roundMinutes(Number(r.minutesWorked || 0), rounding)),
  })) as any[];

  if (mode === 'entries') {
    addTableSheet(workbook, 'Entries', withRounded);
    return workbook.xlsx.writeBuffer();
  }

  // Payroll = per user totals (rounded)
  if (mode === 'payroll') {
    const payrollRows = (() => {
      const users = byKey(withRounded, (r) => r.userId);
      const out: any[] = [];

      const hasWorkerAmount = withRounded.some((r: any) => r.workerAmountCents != null);
      const hasEmployerAmount = withRounded.some((r: any) => r.employerAmountCents != null);
      const eur = (cents: number) => (Number(cents || 0) / 100).toLocaleString('nl-NL', { style: 'currency', currency: 'EUR' });
      for (const [, list] of users) {
        const first = list[0];
        const totalMin = list.reduce((acc, r) => acc + Number(r.minutesWorkedRounded || 0), 0);
        const totalWorkerAmountCents = hasWorkerAmount
          ? list.reduce((acc: number, r: any) => acc + Number(r.workerAmountCents || 0), 0)
          : null;
        const totalEmployerAmountCents = hasEmployerAmount
          ? list.reduce((acc: number, r: any) => acc + Number(r.employerAmountCents || 0), 0)
          : null;
        out.push({
          userId: first.userId,
          fullName: first.userName,
          email: first.userEmail,
          totalMinutes: totalMin,
          totalHours: minutesToHoursDecimal(totalMin),
          ...(hasWorkerAmount ? { totalWorkerAmountCents, totalWorkerAmountEur: eur(Number(totalWorkerAmountCents || 0)) } : {}),
          ...(hasEmployerAmount ? { totalEmployerAmountCents, totalEmployerAmountEur: eur(Number(totalEmployerAmountCents || 0)) } : {}),
        });
      }
      out.sort((a, b) => String(a.fullName).localeCompare(String(b.fullName)));
      return out;
    })();

    addTableSheet(workbook, 'Payroll', payrollRows);
    return workbook.xlsx.writeBuffer();
  }

  // Summary = multiple useful sheets
  addTableSheet(workbook, 'Entries', withRounded);

  const byUser = (() => {
    const users = byKey(withRounded, (r) => r.userId);
    const out: any[] = [];
    for (const [, list] of users) {
      const first = list[0];
      const totalMin = list.reduce((acc, r) => acc + Number(r.minutesWorkedRounded || 0), 0);
      out.push({
        userId: first.userId,
        fullName: first.userName,
        email: first.userEmail,
        shifts: list.length,
        totalMinutes: totalMin,
        totalHours: minutesToHoursDecimal(totalMin),
      });
    }
    out.sort((a, b) => String(a.fullName).localeCompare(String(b.fullName)));
    return out;
  })();

  const byLocation = (() => {
    const locs = byKey(withRounded, (r) => r.locationName || '—');
    const out: any[] = [];
    for (const [loc, list] of locs) {
      const totalMin = list.reduce((acc, r) => acc + Number(r.minutesWorkedRounded || 0), 0);
      out.push({ locationName: loc, shifts: list.length, totalMinutes: totalMin, totalHours: minutesToHoursDecimal(totalMin) });
    }
    out.sort((a, b) => String(a.locationName).localeCompare(String(b.locationName)));
    return out;
  })();

  const byDay = (() => {
    const dayKey = (r: any) => String(r.clockInAt).slice(0, 10);
    const days = byKey(withRounded, dayKey);
    const out: any[] = [];
    for (const [day, list] of days) {
      const totalMin = list.reduce((acc, r) => acc + Number(r.minutesWorkedRounded || 0), 0);
      out.push({ day, shifts: list.length, totalMinutes: totalMin, totalHours: minutesToHoursDecimal(totalMin) });
    }
    out.sort((a, b) => String(a.day).localeCompare(String(b.day)));
    return out;
  })();

  addTableSheet(workbook, 'By User', byUser);
  addTableSheet(workbook, 'By Location', byLocation);
  addTableSheet(workbook, 'By Day', byDay);

  return workbook.xlsx.writeBuffer();
}
