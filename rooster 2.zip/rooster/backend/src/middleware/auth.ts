import jwt from 'jsonwebtoken';
import { env } from '../config/env.js';
import { HttpError } from '../utils/http.js';
import { prisma } from '../db/prisma.js';
import type { $Enums } from '@prisma/client';


type JwtPayload = { sub: string; role: $Enums.Role; tfa?: boolean; purpose?: string };

export async function requireAuth(req: any, _res: any, next: any) {
  const token = req.cookies?.access_token;
  if (!token) return next(new HttpError(401, 'Not authenticated'));

  try {
    const payload = jwt.verify(token, env.JWT_ACCESS_SECRET) as JwtPayload;

    // Ensure account is still active.
    const u = await prisma.user.findUnique({
      where: { id: payload.sub },
      select: {
        id: true,
        isActive: true,
        status: true,
        clientId: true,
        subcontractorId: true,
        twoFactorEnabled: true,
      },
    });
    if (!u || !u.isActive || u.status !== 'ACTIVE') {
      return next(new HttpError(401, 'Not authenticated'));
    }

    req.user = {
      id: payload.sub,
      role: payload.role,
      tfa: !!payload.tfa,
      twoFactorEnabled: !!u.twoFactorEnabled,
      clientId: u.clientId,
      subcontractorId: u.subcontractorId,
    };
    return next();
  } catch {
    next(new HttpError(401, 'Invalid or expired token'));
  }
}

export function require2FA(req: any, _res: any, next: any) {
  if (!req.user) return next(new HttpError(401, 'Not authenticated'));
  // Enforce both the token claim AND current DB state.
  // This makes admin "reset 2FA" take effect immediately even if a user still has a valid access token.
  if (!req.user.tfa || !req.user.twoFactorEnabled) {
    return next(new HttpError(428, '2FA setup required', 'TWOFA_SETUP_REQUIRED'));
  }
  next();
}

export function requireRole(...roles: $Enums.Role[]) {
  return (req: any, _res: any, next: any) => {
    if (!req.user) return next(new HttpError(401, 'Not authenticated'));
    if (!roles.includes(req.user.role)) return next(new HttpError(403, 'Forbidden'));
    next();
  };
}
