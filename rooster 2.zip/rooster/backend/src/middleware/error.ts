import { HttpError } from '../utils/http.js';
import { env } from '../config/env.js';
import { ZodError } from 'zod';

function formatZod(err: ZodError) {
  const details = (err.issues ?? []).map((i) => ({
    path: Array.isArray(i.path) ? i.path.join('.') : String(i.path ?? ''),
    message: i.message,
    code: (i as any).code,
  }));

  // Friendly default message; show a more specific one for common fields.
  const emailIssue = (err.issues ?? []).find(
    (i) => (i.path?.[0] === 'email') && (((i as any).validation === 'email') || ((i as any).code === 'invalid_string')),
  );

  const message = emailIssue
    ? 'Voer een geldig e-mailadres in (bijv. naam@bedrijf.nl).'
    : 'Ongeldige invoer. Controleer de velden en probeer opnieuw.';

  return { message, details };
}

export function errorHandler(err: any, _req: any, res: any, _next: any) {
  const isZod = err instanceof ZodError || err?.name === 'ZodError';
  const status = err instanceof HttpError ? err.status : isZod ? 400 : 500;

  const zod = isZod ? formatZod(err as ZodError) : null;
  const payload = {
    success: false,
    error: {
      message: err instanceof HttpError ? err.message : zod ? zod.message : 'Internal server error',
      code: err instanceof HttpError ? err.code : zod ? 'VALIDATION_ERROR' : undefined,
      details: err instanceof HttpError ? err.details : zod ? zod.details : undefined,
    },
    meta: {
      timestamp: new Date().toISOString(),
      version: env.APP_VERSION,
    },
  };

  if (status >= 500) {
    // eslint-disable-next-line no-console
    console.error(err);
  }
  res.status(status).json(payload);
}
