import express from 'express';
import http from 'http';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import cookieParser from 'cookie-parser';
import { Server as SocketIOServer } from 'socket.io';
import jwt from 'jsonwebtoken';
import { env } from './config/env.js';
import { prisma } from './db/prisma.js';

import { authRoutes } from './routes/authRoutes.js';
import { usersRoutes } from './routes/usersRoutes.js';
import { locationsRoutes } from './routes/locationsRoutes.js';
import { clientsRoutes } from './routes/clientsRoutes.js';
import { materialsRoutes } from './routes/materialsRoutes.js';
import { shiftsRoutes } from './routes/shiftsRoutes.js';
import { reportsRoutes } from './routes/reportsRoutes.js';
import { notificationsRoutes } from './routes/notificationsRoutes.js';
import { geoRoutes } from './routes/geoRoutes.js';
import { pushRoutes } from './routes/pushRoutes.js';
import { dashboardRoutes } from './routes/dashboardRoutes.js';
import { clientPortalRoutes } from './routes/clientPortalRoutes.js';
import { subcontractorRoutes } from './routes/subcontractorRoutes.js';
import { availabilityRoutes } from './routes/availabilityRoutes.js';
import { calendarRoutes } from './routes/calendarRoutes.js';
import { clientRoutes } from './routes/clientRoutes.js';
import { requestsRoutes } from './routes/requestsRoutes.js';

import { errorHandler } from './middleware/error.js';
import { startClockOutReminderScheduler } from './jobs/clockOutReminderJob.js';
import { startNoShowScheduler } from './jobs/noShowJob.js';

type SocketUserContext = {
  id: string;
  role: string;
  tfa: boolean;
  clientId?: string | null;
};

function parseCookies(cookieHeader: string): Record<string, string> {
  const out: Record<string, string> = {};
  if (!cookieHeader) return out;

  for (const part of cookieHeader.split(';')) {
    const trimmed = part.trim();
    if (!trimmed) continue;
    const idx = trimmed.indexOf('=');
    if (idx === -1) continue;
    const k = trimmed.slice(0, idx).trim();
    const v = trimmed.slice(idx + 1).trim();
    if (!k) continue;
    out[k] = decodeURIComponent(v);
  }
  return out;
}

const app = express();

// Behind reverse proxies (Render/Fly/Nginx), req.ip needs trust proxy enabled
app.set('trust proxy', 1);

// Security headers (incl. CSP). Note: CSP mainly affects browser-rendered documents.
// Our API is JSON-first, but this protects any future HTML endpoints and adds defense-in-depth.
app.use(
  helmet({
    contentSecurityPolicy: {
      useDefaults: true,
      directives: {
        // Defaults are good; we only widen where the frontend may need it.
        // Leaflet / OSM tiles and other external images should be allowed.
        'img-src': ["'self'", 'data:', 'https:'],
        // Allow API calls + websocket/push (same-origin + https). Adjust if you host API separately.
        'connect-src': ["'self'", 'https:', 'wss:'],
        // Tailwind injects styles via CSS files; we keep inline allowed for small inline styles.
        'style-src': ["'self'", "'unsafe-inline'", 'https:'],
        // No external scripts by default.
        'script-src': ["'self'"],
        // Allow fonts (Inter) if served locally; keep https for safety.
        'font-src': ["'self'", 'data:', 'https:'],
      },
    },
  }),
);
app.use(morgan('dev'));
app.use(express.json({ limit: '20mb' }));
app.use(cookieParser());

// API response envelope (backwards compatible):
// - For successful (2xx) JSON responses that are not already enveloped,
//   wrap them as { success: true, data, meta }.
app.use((req, res, next) => {
  const oldJson = res.json.bind(res);
  (res as any).json = (body: any) => {
    const is2xx = res.statusCode >= 200 && res.statusCode < 300;
    const isObject = body && typeof body === 'object' && !Array.isArray(body);
    const alreadyEnveloped = isObject && typeof (body as any).success === 'boolean' && 'meta' in (body as any);

    if (is2xx && isObject && !alreadyEnveloped) {
      return oldJson({
        success: true,
        data: body,
        meta: {
          timestamp: new Date().toISOString(),
          version: env.APP_VERSION,
          path: req.path,
        },
      });
    }
    return oldJson(body);
  };
  next();
});

app.use(
  cors({
    origin: env.CORS_ORIGIN.split(',').map((s) => s.trim()),
    credentials: true,
  }),
);

app.get('/health', (_req, res) => res.json({ ok: true }));

// Routes
app.use('/auth', authRoutes);
app.use('/users', usersRoutes);
app.use('/locations', locationsRoutes);
app.use('/clients', clientsRoutes);
app.use('/materials', materialsRoutes);
app.use('/shifts', shiftsRoutes);
app.use('/reports', reportsRoutes);
app.use('/notifications', notificationsRoutes);
app.use('/geo', geoRoutes);
app.use('/push', pushRoutes);
app.use('/dashboard', dashboardRoutes);

// Standardize client endpoints under /client
app.use('/client', clientPortalRoutes);
app.use('/client', clientRoutes);

// Backwards compatibility (deprecated): older clients used /client-portal
app.use('/client-portal', clientPortalRoutes);

// Admin inbox for client requests
app.use('/requests', requestsRoutes);

app.use('/subcontractor', subcontractorRoutes);
app.use('/availability', availabilityRoutes);
app.use('/calendar', calendarRoutes);

app.use(errorHandler);

const server = http.createServer(app);

const io = new SocketIOServer(server, {
  cors: {
    origin: env.CORS_ORIGIN.split(',').map((s) => s.trim()),
    credentials: true,
  },
});

app.locals.io = io;

/**
 * Socket auth:
 * - We still require a valid access_token cookie.
 * - We do NOT hard-block connections without 2FA, to avoid "loading forever" during 2FA setup.
 * - Instead we tag socket.user.tfa=false and only join limited rooms.
 * - Sensitive rooms (admins/client rooms) require tfa=true.
 */
io.use((socket, next) => {
  try {
    const cookieHeader = socket.request.headers.cookie ?? '';
    const cookies = parseCookies(cookieHeader);

    const token = cookies['access_token'];
    if (!token) return next(new Error('unauthorized'));

    const payload = jwt.verify(token, env.JWT_ACCESS_SECRET) as any;

    const ctx: SocketUserContext = {
      id: payload.sub,
      role: payload.role,
      tfa: !!payload?.tfa,
    };

    // Attach early; we will enrich below
    (socket as any).user = ctx;

    prisma.user
      .findUnique({
        where: { id: payload.sub },
        select: { clientId: true, isActive: true, status: true },
      })
      .then((u) => {
        if (!u?.isActive || u?.status !== 'ACTIVE') {
          return next(new Error('unauthorized'));
        }
        if (u?.clientId) {
          (socket as any).user.clientId = u.clientId;
        }
        return next();
      })
      .catch(() => next(new Error('unauthorized')));
  } catch {
    next(new Error('unauthorized'));
  }
});

io.on('connection', (socket) => {
  const user = (socket as any).user as SocketUserContext | undefined;
  if (!user?.id) {
    socket.disconnect(true);
    return;
  }

  // Always join personal room (safe)
  socket.join(`user:${user.id}`);

  // Only join privileged rooms once 2FA is enabled in the access token
  if (user.tfa) {
    if (user.role === 'ADMIN') socket.join('admins');
    if (user.clientId) socket.join(`client:${user.clientId}`);
  }

  socket.on('disconnect', () => {});
});

const main = async () => {
  await prisma.$queryRaw`SELECT 1`;

  const stopClockOutReminder = startClockOutReminderScheduler();
  const stopNoShow = startNoShowScheduler();
  process.once('SIGINT', () => stopClockOutReminder());
  process.once('SIGTERM', () => stopClockOutReminder());
  process.once('SIGINT', () => stopNoShow());
  process.once('SIGTERM', () => stopNoShow());

  server.listen(env.PORT, () => {
    // eslint-disable-next-line no-console
    console.log(`API listening on :${env.PORT}`);
  });
};

main().catch((e) => {
  // eslint-disable-next-line no-console
  console.error(e);
  process.exit(1);
});
