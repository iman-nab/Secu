import { env } from '../config/env.js';
import { prisma } from '../db/prisma.js';
import { createUserNotification } from '../services/notificationsService.js';

const DEFAULT_INTERVAL_MS = 60_000;

function formatTimeNL(d: Date) {
  // Force Amsterdam time for consistent UX regardless of server/container timezone.
  return new Intl.DateTimeFormat('nl-NL', {
    timeZone: 'Europe/Amsterdam',
    hour: '2-digit',
    minute: '2-digit',
  }).format(d);
}

async function runClockOutReminderTick(now: Date) {
  const minutes = Number.isFinite(env.CLOCK_OUT_REMINDER_MINUTES) && env.CLOCK_OUT_REMINDER_MINUTES > 0
    ? env.CLOCK_OUT_REMINDER_MINUTES
    : 15;
  const windowEnd = new Date(now.getTime() + minutes * 60_000);

  const entries = await prisma.timeEntry.findMany({
    where: {
      clockOutAt: null,
      clockOutReminderSentAt: null,
      user: { isActive: true, role: 'EMPLOYEE' },
      shift: {
        isDeleted: false,
        endAt: { gt: now, lte: windowEnd },
      },
    },
    include: {
      user: { select: { id: true, fullName: true } },
      shift: { select: { id: true, title: true, endAt: true } },
    },
  });

  if (entries.length === 0) return;

  await Promise.all(
    entries.map(async (e: any) => {
      try {
        const endTime = formatTimeNL(e.shift.endAt);
        const msg = `Je dienst "${e.shift.title}" eindigt om ${endTime}. Vergeet niet uit te klokken.`;

        await createUserNotification({
          recipientId: e.userId,
          type: 'CLOCK_OUT_REMINDER',
          message: msg,
          data: { shiftId: e.shiftId, timeEntryId: e.id },
        });

        await prisma.timeEntry.update({
          where: { id: e.id },
          data: { clockOutReminderSentAt: now },
        });
      } catch {
        // Best-effort: do not crash the scheduler on a single failing record.
      }
    }),
  );
}

export function startClockOutReminderScheduler() {
  let stopped = false;

  const tick = async () => {
    if (stopped) return;
    try {
      await runClockOutReminderTick(new Date());
    } catch {
      // swallow; this is best-effort in dev/prod
    }
  };

  // Run once shortly after boot, then every minute.
  void tick();
  const timer = setInterval(() => void tick(), DEFAULT_INTERVAL_MS);

  return () => {
    stopped = true;
    clearInterval(timer);
  };
}
