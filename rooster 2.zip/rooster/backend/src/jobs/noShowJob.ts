import { env } from '../config/env.js';
import { prisma } from '../db/prisma.js';
import { createAdminNotification } from '../services/notificationsService.js';

const DEFAULT_INTERVAL_MS = 60_000;

function minutesAgo(now: Date, minutes: number) {
  return new Date(now.getTime() - minutes * 60_000);
}

async function runNoShowTick(now: Date) {
  const grace = Number.isFinite(env.NO_SHOW_GRACE_MINUTES) && env.NO_SHOW_GRACE_MINUTES > 0 ? env.NO_SHOW_GRACE_MINUTES : 15;

  // Only check shifts that crossed the grace threshold in the last 2 minutes
  const windowEnd = minutesAgo(now, grace);
  const windowStart = minutesAgo(now, grace + 2);

  const shifts = await prisma.shift.findMany({
    where: {
      isDeleted: false,
      startAt: { gt: windowStart, lte: windowEnd },
    },
    select: {
      id: true,
      title: true,
      startAt: true,
      assignments: { where: { status: 'APPROVED' }, select: { userId: true, user: { select: { fullName: true, email: true } } } },
    },
  });

  if (shifts.length === 0) return;

  await Promise.all(
    shifts.map(async (s: any) => {
      await Promise.all(
        (s.assignments ?? []).map(async (a: any) => {
          // If the employee has already clocked in, it's not a no-show.
          const hasEntry = await prisma.timeEntry.findFirst({
            where: { shiftId: s.id, userId: a.userId },
            select: { id: true },
          });
          if (hasEntry) return;

          // Deduplicate: do not send the same NO_SHOW twice.
          const existing = await prisma.notification.findFirst({
            where: {
              type: 'NO_SHOW',
              data: { equals: { shiftId: s.id, userId: a.userId } },
            },
            select: { id: true },
          });
          if (existing) return;

          const who = a.user?.fullName || a.user?.email || 'Een medewerker';
          const msg = `No-show: ${who} heeft nog niet ingecheckt voor "${s.title}".`;
          await createAdminNotification({
            type: 'NO_SHOW',
            message: msg,
            data: { shiftId: s.id, userId: a.userId, url: `/diensten/${s.id}` },
          });
        }),
      );
    }),
  );
}

export function startNoShowScheduler() {
  let stopped = false;

  const tick = async () => {
    if (stopped) return;
    try {
      await runNoShowTick(new Date());
    } catch {
      // best-effort
    }
  };

  void tick();
  const timer = setInterval(() => void tick(), DEFAULT_INTERVAL_MS);

  return () => {
    stopped = true;
    clearInterval(timer);
  };
}
