import { prisma } from '../src/db/prisma.js';
import bcrypt from 'bcryptjs';
import type { $Enums } from '@prisma/client';

/**
 * Deterministic dev seed.
 * - Admin: admin@example.com / Admin123!ChangeMe
 * - Employee: employee@example.com / Employee123!ChangeMe
 *
 * Override via env:
 *  - SEED_ADMIN_EMAIL, SEED_ADMIN_PASSWORD
 *  - SEED_EMPLOYEE_EMAIL, SEED_EMPLOYEE_PASSWORD
 */
async function main() {
  const adminEmail = process.env.SEED_ADMIN_EMAIL ?? 'admin@example.com';
  const adminPassword = process.env.SEED_ADMIN_PASSWORD ?? 'Admin123!ChangeMe';
  const employeeEmail = process.env.SEED_EMPLOYEE_EMAIL ?? 'employee@example.com';
  const employeePassword = process.env.SEED_EMPLOYEE_PASSWORD ?? 'Employee123!ChangeMe';

  // --- Cleanup previous seed data (idempotent) ---
  // We tag seed entities by email prefix / name prefix.
  const seedEmailPrefix = 'seed-';
  const seedNamePrefix = 'Seed ';

  // Delete in dependency order
  await prisma.notification.deleteMany({ where: { recipient: { email: { startsWith: seedEmailPrefix } } } });
  await prisma.auditLog.deleteMany({ where: { actor: { email: { startsWith: seedEmailPrefix } } } });
  await prisma.timeEntry.deleteMany({ where: { user: { email: { startsWith: seedEmailPrefix } } } });
  await prisma.shiftAssignment.deleteMany({ where: { user: { email: { startsWith: seedEmailPrefix } } } });
  await prisma.shiftNote.deleteMany({ where: { author: { email: { startsWith: seedEmailPrefix } } } });
  await prisma.shiftExtraCost.deleteMany({ where: { shift: { title: { startsWith: seedNamePrefix } } } });
  await prisma.shiftMaterial.deleteMany({ where: { shift: { title: { startsWith: seedNamePrefix } } } });
  await prisma.shiftReport.deleteMany({ where: { shift: { title: { startsWith: seedNamePrefix } } } });
  await prisma.shift.deleteMany({ where: { title: { startsWith: seedNamePrefix } } });
  await prisma.user.deleteMany({ where: { email: { startsWith: seedEmailPrefix } } });
  await prisma.client.deleteMany({ where: { name: { startsWith: seedNamePrefix } } });
  await prisma.location.deleteMany({ where: { name: { startsWith: seedNamePrefix } } });

  // --- Core deterministic accounts ---
  // Upsert admin
  await prisma.user.upsert({
    where: { email: adminEmail },
    update: {
      fullName: 'Admin',
      role: 'ADMIN',
      isActive: true,
      passwordHash: await bcrypt.hash(adminPassword, 12),
    },
    create: {
      email: adminEmail,
      fullName: 'Admin',
      role: 'ADMIN',
      isActive: true,
      passwordHash: await bcrypt.hash(adminPassword, 12),
    },
  });

  // Upsert demo employee
  await prisma.user.upsert({
    where: { email: employeeEmail },
    update: {
      fullName: 'Employee',
      role: 'EMPLOYEE',
      isActive: true,
      passwordHash: await bcrypt.hash(employeePassword, 12),
    },
    create: {
      email: employeeEmail,
      fullName: 'Employee',
      role: 'EMPLOYEE',
      isActive: true,
      passwordHash: await bcrypt.hash(employeePassword, 12),
    },
  });

  // --- Seed entities (clients, locations, users, shifts) ---
  const admin = await prisma.user.findUnique({ where: { email: adminEmail } });
  const employee = await prisma.user.findUnique({ where: { email: employeeEmail } });
  if (!admin || !employee) throw new Error('Seed base users missing');

  // Locations (NL)
  const locations = await prisma.$transaction([
    prisma.location.create({
      data: { name: `${seedNamePrefix}HQ Amsterdam`, address: 'Damrak 1, Amsterdam', latitude: 52.373, longitude: 4.894, radiusM: 120 },
    }),
    prisma.location.create({
      data: { name: `${seedNamePrefix}Magazijn Utrecht`, address: 'Stationsplein 1, Utrecht', latitude: 52.089, longitude: 5.11, radiusM: 150 },
    }),
    prisma.location.create({
      data: { name: `${seedNamePrefix}Rotterdam Dock`, address: 'Wilhelminakade 699, Rotterdam', latitude: 51.905, longitude: 4.486, radiusM: 180 },
    }),
    prisma.location.create({
      data: { name: `${seedNamePrefix}Den Haag Office`, address: 'Spui 70, Den Haag', latitude: 52.077, longitude: 4.313, radiusM: 120 },
    }),
    prisma.location.create({
      data: { name: `${seedNamePrefix}Eindhoven Hub`, address: 'Stationsplein 22, Eindhoven', latitude: 51.441, longitude: 5.478, radiusM: 200 },
    }),
  ]);

  // Clients
  const clients = await prisma.$transaction([
    prisma.client.create({ data: { name: `${seedNamePrefix}Voetbalclub Orion`, contactName: 'Orion Admin', contactEmail: 'seed-orion@example.com' } }),
    prisma.client.create({ data: { name: `${seedNamePrefix}Bouwbedrijf Atlas`, contactName: 'Atlas Planning', contactEmail: 'seed-atlas@example.com' } }),
    prisma.client.create({ data: { name: `${seedNamePrefix}EventCrew Nova`, contactName: 'Nova Ops', contactEmail: 'seed-nova@example.com' } }),
  ]);

  // Extra demo portal users for each client
  const clientPortalPassword = 'Client123!ChangeMe';
  for (const c of clients) {
    const email = `${seedEmailPrefix}client-${c.id.slice(-5)}@example.com`;
    await prisma.user.create({
      data: {
        email,
        fullName: `Klant ${c.name.replace(seedNamePrefix, '')}`,
        role: 'CLIENT',
        clientId: c.id,
        isActive: true,
        passwordHash: await bcrypt.hash(clientPortalPassword, 12),
      },
    });
  }

  // Employees with pass colors (covers all business rules)
  const employeePasswordCommon = 'Employee123!ChangeMe';
  const passColors: Array<$Enums.PassColor | null> = ['GRAY', 'LIGHT_BLUE', 'ORANGE', 'DARK_BLUE', 'GREEN', null, 'BLACK'];
  const seededEmployees = [] as Array<{ id: string; email: string; passColor: $Enums.PassColor | null }>;
  for (let i = 1; i <= 18; i++) {
    const passColor = passColors[i % passColors.length];
    const email = `${seedEmailPrefix}emp${String(i).padStart(2, '0')}@example.com`;
    const u = await prisma.user.create({
      data: {
        email,
        fullName: `Seed Employee ${String(i).padStart(2, '0')}`,
        role: 'EMPLOYEE',
        passColor: passColor ?? undefined,
        isActive: true,
        passwordHash: await bcrypt.hash(employeePasswordCommon, 12),
      },
      select: { id: true, email: true, passColor: true },
    });
    seededEmployees.push({ id: u.id, email: u.email, passColor: (u.passColor as any) ?? null });
  }

  // Helper for time
  const at = (base: Date, addDays: number, hour: number, minute = 0) => {
    const d = new Date(base);
    d.setDate(d.getDate() + addDays);
    d.setHours(hour, minute, 0, 0);
    return d;
  };

  // Shifts: past 14 days + next 21 days (varied statuses/colors)
  const now = new Date();
  const shiftDefs: Array<{ day: number; startH: number; endH: number; clientIdx: number; locIdx: number; status: $Enums.ShiftStatus; pass: $Enums.PassColor; reqWorkers: number; title: string }> = [];

  const colors: $Enums.PassColor[] = ['BLACK', 'ORANGE', 'LIGHT_BLUE', 'DARK_BLUE', 'GRAY'];
  for (let d = -14; d <= 21; d++) {
    // 2 shifts per day
    const c1 = colors[(d + 100) % colors.length];
    const c2 = colors[(d + 101) % colors.length];
    shiftDefs.push({
      day: d,
      startH: 8,
      endH: 16,
      clientIdx: Math.abs(d) % clients.length,
      locIdx: Math.abs(d) % locations.length,
      status: d < 0 ? 'COMPLETED' : d === 0 ? 'ASSIGNED' : 'OPEN',
      pass: c1,
      reqWorkers: 1 + ((Math.abs(d) % 3) as 0 | 1 | 2),
      title: `${seedNamePrefix}Dienst Ochtend ${d}`,
    });
    shiftDefs.push({
      day: d,
      startH: 16,
      endH: 22,
      clientIdx: (Math.abs(d) + 1) % clients.length,
      locIdx: (Math.abs(d) + 2) % locations.length,
      status: d < -3 ? 'COMPLETED' : d < 0 ? 'ASSIGNED' : d % 5 === 0 ? 'DRAFT' : 'OPEN',
      pass: c2,
      reqWorkers: 1,
      title: `${seedNamePrefix}Dienst Avond ${d}`,
    });
  }

  const createdShifts = [] as Array<{ id: string; status: $Enums.ShiftStatus; reqWorkers: number }>;
  for (const def of shiftDefs) {
    const startAt = at(now, def.day, def.startH);
    const endAt = at(now, def.day, def.endH);
    const shift = await prisma.shift.create({
      data: {
        title: def.title,
        description: `Seed shift (${def.pass})`,
        type: def.pass === 'BLACK' ? 'GENERAL' : 'COLORED',
        requiredPassColor: def.pass,
        requiredWorkers: def.reqWorkers,
        locationId: locations[def.locIdx].id,
        clientId: clients[def.clientIdx].id,
        startAt,
        endAt,
        status: def.status,
        createdById: admin.id,
      },
      select: { id: true, status: true, requiredWorkers: true },
    });
    createdShifts.push({ id: shift.id, status: shift.status as any, reqWorkers: shift.requiredWorkers });
  }

  // Materials (existing ones kept) + extra
  const materials = [
    { name: 'Sleutelset', description: 'Sleutels / toegang' },
    { name: 'iPad', description: 'Tablet voor registratie' },
    { name: 'Werkkleding', description: 'Uniform / kleding' },
    { name: 'Veiligheidshelm', description: 'PPE' },
    { name: 'Portofoon', description: 'Communicatie' },
  ];
  for (const m of materials) {
    await prisma.material.upsert({
      where: { name: m.name },
      update: { description: m.description, isDeleted: false, deletedAt: null },
      create: m,
    });
  }

  // Assignments + time entries (for ASSIGNED/COMPLETED)
  // We create approvals up to requiredWorkers and create time entries for completed shifts.
  const employeesPool = [employee, ...seededEmployees.map((e) => ({ id: e.id }))] as Array<{ id: string }>;
  let poolIdx = 0;
  for (const s of createdShifts) {
    if (s.status === 'OPEN' || s.status === 'DRAFT' || s.status === 'CANCELLED') continue;

    const approvals = Math.max(1, Math.min(s.reqWorkers, 3));
    const assignedUsers = [] as string[];
    for (let j = 0; j < approvals; j++) {
      const uid = employeesPool[poolIdx % employeesPool.length].id;
      poolIdx++;
      assignedUsers.push(uid);
      await prisma.shiftAssignment.create({
        data: {
          shiftId: s.id,
          userId: uid,
          status: 'APPROVED',
        },
      });
    }

    // If completed: create time entries for each assigned user.
    if (s.status === 'COMPLETED') {
      const shiftRow = await prisma.shift.findUnique({ where: { id: s.id }, select: { startAt: true, endAt: true } });
      if (!shiftRow) continue;
      for (const uid of assignedUsers) {
        const clockInAt = new Date(shiftRow.startAt.getTime() + 5 * 60 * 1000);
        const clockOutAt = new Date(shiftRow.endAt.getTime() - 7 * 60 * 1000);
        await prisma.timeEntry.create({
          data: {
            shiftId: s.id,
            userId: uid,
            clockInAt,
            clockOutAt,
            minutesWorked: Math.max(0, Math.round((clockOutAt.getTime() - clockInAt.getTime()) / 60000)),
            clockInLat: locations[0].latitude,
            clockInLng: locations[0].longitude,
            clockInAccM: 12.5,
            clockOutLat: locations[0].latitude,
            clockOutLng: locations[0].longitude,
            clockOutAccM: 15.0,
          },
        });
      }
    }
  }

  // Seed a few notifications for seeded employees
  for (const e of seededEmployees.slice(0, 8)) {
    await prisma.notification.create({
      data: {
        recipientId: e.id,
        senderId: admin.id,
        type: 'INFO',
        message: 'Welkom! Dit is seed testdata. Je kunt hiermee de notificaties UI testen.',
        data: { kind: 'SEED' },
      },
    });
  }

  // eslint-disable-next-line no-console
  console.log(`\nSeeded credentials:`);
  // eslint-disable-next-line no-console
  console.log(`Admin    : ${adminEmail} / ${adminPassword}`);
  // eslint-disable-next-line no-console
  console.log(`Employee : ${employeeEmail} / ${employeePassword}`);
  console.log(`Seed employees: ${seedEmailPrefix}emp01@example.com .. ${seedEmailPrefix}emp18@example.com / ${employeePasswordCommon}`);
  console.log(`Seed client portal users: ${seedEmailPrefix}client-xxxxx@example.com / ${clientPortalPassword}`);
  console.log(`\nCreated:`);
  console.log(`- Locations: ${locations.length}`);
  console.log(`- Clients: ${clients.length}`);
  console.log(`- Shifts: ${createdShifts.length} (past 14d + next 21d)`);
  console.log(`- Notifications: 8`);
  console.log('');
}

main()
  .then(async () => {
    await prisma.$disconnect();
  })
  .catch(async (e) => {
    // eslint-disable-next-line no-console
    console.error(e);
    await prisma.$disconnect();
    process.exit(1);
  });

