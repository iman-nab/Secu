import { describe, expect, it } from 'vitest';
import { distanceMeters } from '../src/utils/geo.js';

describe('geofence distanceMeters', () => {
  it('returns ~0 for same point', () => {
    expect(distanceMeters({ lat: 52, lng: 4 }, { lat: 52, lng: 4 })).toBeLessThan(0.01);
  });

  it('calculates known distance approx (Amsterdam Central to Dam Square ~1.1-1.3km)', () => {
    const ams = { lat: 52.378, lng: 4.9 };
    const dam = { lat: 52.373, lng: 4.893 };
    const d = distanceMeters(ams, dam);
    expect(d).toBeGreaterThan(800);
    expect(d).toBeLessThan(2000);
  });
});
