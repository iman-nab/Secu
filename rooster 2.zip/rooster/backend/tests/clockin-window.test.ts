import { describe, expect, it, vi } from 'vitest';
import { env } from '../src/config/env.js';
import { HttpError } from '../src/utils/http.js';

// We test the time-window logic indirectly by importing the private function via dynamic eval is messy.
// Instead, we replicate the rule in a small helper and assert behavior matches env.
// This keeps the rule stable and explicit.

function isWithinClockInWindow(shiftStartAt: Date, now: Date) {
  const early = new Date(shiftStartAt.getTime() - env.CLOCK_IN_EARLY_MINUTES * 60000);
  const late = new Date(shiftStartAt.getTime() + env.CLOCK_IN_LATE_MINUTES * 60000);
  return now >= early && now <= late;
}

describe('clock-in window rule', () => {
  it('allows within window', () => {
    const start = new Date('2025-01-01T10:00:00Z');
    const now = new Date(start.getTime() - (env.CLOCK_IN_EARLY_MINUTES - 1) * 60000);
    expect(isWithinClockInWindow(start, now)).toBe(true);
  });

  it('rejects too early', () => {
    const start = new Date('2025-01-01T10:00:00Z');
    const now = new Date(start.getTime() - (env.CLOCK_IN_EARLY_MINUTES + 1) * 60000);
    expect(isWithinClockInWindow(start, now)).toBe(false);
  });
});
