import { describe, expect, it } from 'vitest';
import { shiftsOverlap } from '../src/utils/shift.js';

describe('shiftsOverlap', () => {
  it('detects overlap', () => {
    const a1 = new Date('2025-01-01T10:00:00Z');
    const a2 = new Date('2025-01-01T12:00:00Z');
    const b1 = new Date('2025-01-01T11:59:00Z');
    const b2 = new Date('2025-01-01T13:00:00Z');
    expect(shiftsOverlap(a1, a2, b1, b2)).toBe(true);
  });

  it('no overlap when touching end==start', () => {
    const a1 = new Date('2025-01-01T10:00:00Z');
    const a2 = new Date('2025-01-01T12:00:00Z');
    const b1 = new Date('2025-01-01T12:00:00Z');
    const b2 = new Date('2025-01-01T13:00:00Z');
    expect(shiftsOverlap(a1, a2, b1, b2)).toBe(false);
  });
});
