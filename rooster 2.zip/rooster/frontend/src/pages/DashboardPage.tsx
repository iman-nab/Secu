import { Link } from 'react-router-dom';
import { useMe } from '../hooks/useAuth';
import { useQuery } from '@tanstack/react-query';
import { listShifts } from '../api/shifts';
import { getMyNextReactedShift, getNextRequestedShift } from '../api/dashboard';
import { Button, Card } from '../components/ui';
import { usePushNotifications } from '../hooks/usePushNotifications';
import { useEffect, useState } from 'react';
import { useToast } from '../components/toast';

function formatDT(dt: string) {
  try {
    return new Date(dt).toLocaleString('nl-NL', { dateStyle: 'medium', timeStyle: 'short' });
  } catch {
    return dt;
  }
}

function startOfDayISO(d: Date) {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  const yyyy = x.getFullYear();
  const mm = String(x.getMonth() + 1).padStart(2, '0');
  const dd = String(x.getDate()).padStart(2, '0');
  return `${yyyy}-${mm}-${dd}`;
}

export default function DashboardPage() {
  const { data: me } = useMe();
  const push = usePushNotifications();
  const toast = useToast();
  const isSecure = typeof window !== 'undefined' ? window.isSecureContext : false;

  const [geoStatus, setGeoStatus] = useState<'unknown' | 'granted' | 'denied' | 'prompt'>('unknown');
  const [geoError, setGeoError] = useState<string | null>(null);

  const notifPermission = typeof Notification !== 'undefined' ? Notification.permission : 'default';

  // Permissions card: show only when needed, and allow dismissing for 30 days.
  const [permDismissUntil, setPermDismissUntil] = useState<number>(() => {
    try {
      const v = localStorage.getItem('rooster.permCardDismissedUntil');
      return v ? Number(v) : 0;
    } catch {
      return 0;
    }
  });

  const needsPermissions = notifPermission !== 'granted' || geoStatus !== 'granted';
  const isDismissed = permDismissUntil && Date.now() < permDismissUntil;
  const shouldShowPermissions = needsPermissions && !isDismissed;

  useEffect(() => {
    let cancelled = false;
    // Try to read permission state (not supported everywhere, so we fall back to unknown)
    (async () => {
      try {
        // @ts-ignore
        if (navigator.permissions?.query) {
          // @ts-ignore
          const p = await navigator.permissions.query({ name: 'geolocation' });
          if (!cancelled) setGeoStatus((p.state as any) ?? 'unknown');
          p.onchange = () => {
            if (!cancelled) setGeoStatus((p.state as any) ?? 'unknown');
          };
        } else {
          if (!cancelled) setGeoStatus('unknown');
        }
      } catch {
        if (!cancelled) setGeoStatus('unknown');
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const now = new Date();
  const start = new Date(now.getTime() - 2 * 24 * 3600 * 1000);
  const end = new Date(now.getTime() + 21 * 24 * 3600 * 1000);
  const startISO = startOfDayISO(start);
  const endISO = startOfDayISO(end);

  // Upcoming shifts in a window (fallback if user has no reacted shifts yet)
  const { data: shifts, isFetching: isFetchingShifts } = useQuery({
    queryKey: ['dashboard', 'shifts', startISO, endISO],
    queryFn: async () => (await listShifts({ start: startISO, end: endISO })).shifts as any[],
    enabled: !!me,
    staleTime: 10_000,
    refetchInterval: 60_000,
  });

  // Employee: next shift they reacted to (APPROVED first, otherwise REQUESTED)
  const { data: myNextReacted, isFetching: isFetchingMyNext } = useQuery({
    queryKey: ['dashboard', 'me', 'next-reacted'],
    queryFn: async () => (await getMyNextReactedShift()) as any,
    enabled: !!me && me.role !== 'ADMIN',
    staleTime: 5_000,
    refetchInterval: 30_000,
    refetchOnWindowFocus: true,
  });

  // Admin: next requested open shift (optional card)
  const { data: nextReqAdmin } = useQuery({
    queryKey: ['dashboard', 'admin', 'next-requested'],
    queryFn: async () => (await getNextRequestedShift()) as any,
    enabled: !!me && me.role === 'ADMIN',
    staleTime: 5_000,
    refetchInterval: 30_000,
  });

  const myNext = (myNextReacted && (myNextReacted as any).data) ? (myNextReacted as any).data : null;
  const all = Array.isArray(shifts) ? shifts : ((shifts as any)?.data ?? []);

  // "Volgende dienst" betekent: eerstvolgende dienst in de TOEKOMST.
  // Nooit terugvallen op een dienst in het verleden.
  const sortedAll = Array.isArray(all)
    ? [...all].sort((a: any, b: any) => +new Date(a.startAt) - +new Date(b.startAt))
    : [];
  const nextShift = sortedAll.find((s: any) => new Date(s.startAt).getTime() >= now.getTime()) ?? null;

  const adminNext = nextReqAdmin && (nextReqAdmin as any).data ? (nextReqAdmin as any).data : null;

  // No-show prevention: remind 10 minutes before shift start (toast + optional Notification)
  useEffect(() => {
    if (!me || me.role === 'ADMIN') return;
    const shift = myNext?.shift ?? nextShift;
    if (!shift?.startAt) return;
    const startMs = new Date(shift.startAt).getTime();
    if (!Number.isFinite(startMs)) return;
    const key = `rooster.reminder.10m.${shift.id}`;
    const tick = () => {
      const nowMs = Date.now();
      const diffMin = Math.round((startMs - nowMs) / 60000);
      if (diffMin <= 10 && diffMin >= 0) {
        if (!localStorage.getItem(key)) {
          localStorage.setItem(key, '1');
          toast.info(`Je dienst begint over ~${diffMin} min: ${shift.title}`);
          try {
            if (typeof Notification !== 'undefined' && Notification.permission === 'granted') {
              new Notification('Dienst reminder', { body: `Begint over ~${diffMin} min: ${shift.title}` });
            }
          } catch {
            // ignore
          }
        }
      }
    };
    tick();
    const t = setInterval(tick, 60_000);
    return () => clearInterval(t);
  }, [me, myNext?.shift?.id, myNext?.shift?.startAt, nextShift?.id, nextShift?.startAt]);

  return (
    <div className="space-y-4">
      {shouldShowPermissions && me && (
        <Card className="p-5">
          <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
            <div>
              <div className="text-xs uppercase tracking-wide text-gray-500">Toestemmingen</div>
              <div className="text-sm text-gray-700 mt-1">
                Voor notificaties en locatie (geofence) heeft je telefoon toestemming nodig.
                {!isSecure && (
                  <span className="block mt-1 text-amber-700">Let op: op mobiel werken notificaties/locatie alleen via HTTPS (of localhost).</span>
                )}
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Button
                variant="secondary"
                onClick={() => {
                  try {
                    const until = Date.now() + 30 * 24 * 60 * 60 * 1000;
                    localStorage.setItem('rooster.permCardDismissedUntil', String(until));
                    setPermDismissUntil(until);
                    toast.info('Toestemmingen kaart verborgen (30 dagen)');
                  } catch {
                    // ignore
                  }
                }}
              >
                Verberg 30 dagen
              </Button>
            </div>
          </div>

          <div className="mt-4 grid gap-3 md:grid-cols-2">
            <div className="rounded-xl border bg-white p-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="font-medium">Notificaties</div>
                  <div className="text-sm text-gray-600 mt-1">
                    Status: <span className="font-medium">{notifPermission === 'granted' ? 'Toegestaan' : notifPermission === 'denied' ? 'Geblokkeerd' : 'Nog niet gevraagd'}</span>
                  </div>
                  {push.supported ? (
                    <div className="text-sm text-gray-600 mt-1">
                      Push: <span className="font-medium">{push.enabled ? 'Aan' : 'Uit'}</span>
                    </div>
                  ) : (
                    <div className="text-sm text-gray-600 mt-1">Push wordt niet ondersteund in deze browser.</div>
                  )}
                </div>

                <div className="flex flex-col gap-2">
                  {push.supported && !push.enabled ? (
                    <Button disabled={push.busy} onClick={push.enable}>
                      Inschakelen
                    </Button>
                  ) : push.supported && push.enabled ? (
                    <Button variant="secondary" disabled={push.busy} onClick={push.disable}>
                      Uitschakelen
                    </Button>
                  ) : null}
                  <Button variant="secondary" asChild>
                    <Link to="/notificaties">Open inbox</Link>
                  </Button>
                </div>
              </div>
              {push.error && <div className="mt-2 text-sm text-red-700">{push.error}</div>}
            </div>

            <div className="rounded-xl border bg-white p-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="font-medium">Locatie</div>
                  <div className="text-sm text-gray-600 mt-1">
                    Status: <span className="font-medium">{geoStatus === 'granted' ? 'Toegestaan' : geoStatus === 'denied' ? 'Geblokkeerd' : geoStatus === 'prompt' ? 'Nog niet gevraagd' : 'Onbekend'}</span>
                  </div>
                  <div className="text-sm text-gray-600 mt-1">
                    Nodig om automatisch te checken of je binnen de locatie-geofence bent.
                  </div>
                </div>

                <div className="flex flex-col gap-2">
                  <Button
                    onClick={async () => {
                      setGeoError(null);
                      if (!isSecure) {
                        setGeoError('Locatie werkt alleen via HTTPS (of localhost). Open de app via https://.');
                        return;
                      }
                      if (!navigator.geolocation) {
                        setGeoError('Geolocatie wordt niet ondersteund.');
                        return;
                      }
                      navigator.geolocation.getCurrentPosition(
                        () => setGeoStatus('granted'),
                        (err) => {
                          setGeoStatus(err.code === 1 ? 'denied' : 'unknown');
                          setGeoError(err.message || 'Locatie toestemming geweigerd.');
                        },
                        { enableHighAccuracy: true, timeout: 10_000 },
                      );
                    }}
                  >
                    Toestaan
                  </Button>
                  <Button variant="secondary" asChild>
                    <Link to="/admin">Locaties beheren</Link>
                  </Button>
                </div>
              </div>
              {geoError && <div className="mt-2 text-sm text-red-700">{geoError}</div>}
            </div>
          </div>
        </Card>
      )}

      {me?.role !== 'ADMIN' && (
        <Card className="p-5">
          <div className="flex items-start justify-between gap-3">
            <div>
              <div className="text-xs uppercase tracking-wide text-gray-500">Mijn volgende dienst</div>
              <div className="text-sm text-gray-600 mt-1">
                {me ? me.fullName ?? me.email : '—'}
              </div>

              {isFetchingMyNext || isFetchingShifts ? (
                <div className="mt-3 text-sm text-gray-500">Laden…</div>
              ) : myNext ? (
                <>
                  <div className="text-xl font-semibold mt-2">{myNext.shift.title}</div>
                  <div className="text-sm text-gray-700 mt-1">
                    {formatDT(myNext.shift.startAt)} – {formatDT(myNext.shift.endAt)} • {myNext.shift.locationName ?? '—'}
                  </div>
                  <div className="mt-2 text-sm">
                    Status:{' '}
                    <span className={myNext.status === 'APPROVED' ? 'font-semibold text-green-700' : 'font-semibold text-amber-700'}>
                      {myNext.status === 'APPROVED' ? 'Goedgekeurd' : 'In afwachting'}
                    </span>
                  </div>
                  <div className="mt-4 flex gap-2 flex-wrap">
                    <Button asChild>
                      <Link to={`/diensten/${myNext.shift.id}`}>Open dienst</Link>
                    </Button>
                    {myNext.shift?.location?.latitude && myNext.shift?.location?.longitude ? (
                      <Button
                        variant="secondary"
                        onClick={() => {
                          const lat = Number(myNext.shift.location.latitude);
                          const lng = Number(myNext.shift.location.longitude);
                          const label = encodeURIComponent(myNext.shift.location?.name || myNext.shift.title || 'Locatie');
                          window.open(`https://www.google.com/maps/search/?api=1&query=${lat},${lng}&query_place_id=${label}`, '_blank');
                        }}
                      >
                        Route
                      </Button>
                    ) : null}
                    <Button variant="secondary" asChild>
                      <Link to="/uren">Uren</Link>
                    </Button>
                  </div>
                </>
              ) : nextShift ? (
                <>
                  <div className="text-xl font-semibold mt-2">{nextShift.title}</div>
                  <div className="text-sm text-gray-700 mt-1">
                    {formatDT(nextShift.startAt)} – {formatDT(nextShift.endAt)} • {nextShift.location?.name ?? '—'}
                  </div>
                  <div className="mt-2 text-sm text-gray-600">
                    Tip: reageer op open diensten om hier direct je bevestigde dienst te zien.
                  </div>
                  <div className="mt-4 flex gap-2 flex-wrap">
                    <Button asChild>
                      <Link to={`/diensten/${nextShift.id}`}>Open dienst</Link>
                    </Button>
                    {nextShift?.location?.latitude && nextShift?.location?.longitude ? (
                      <Button
                        variant="secondary"
                        onClick={() => {
                          const lat = Number(nextShift.location.latitude);
                          const lng = Number(nextShift.location.longitude);
                          const label = encodeURIComponent(nextShift.location?.name || nextShift.title || 'Locatie');
                          window.open(`https://www.google.com/maps/search/?api=1&query=${lat},${lng}&query_place_id=${label}`, '_blank');
                        }}
                      >
                        Route
                      </Button>
                    ) : null}
                    <Button variant="secondary" asChild>
                      <Link to="/open-diensten">Open diensten</Link>
                    </Button>
                  </div>
                </>
              ) : (
                <div className="mt-3 text-sm text-gray-600">
                  Geen aankomende diensten gevonden.
                </div>
              )}
            </div>

            <div className="flex flex-col items-end gap-2">
              <Button variant="secondary" asChild>
                <Link to="/notificaties">Notificaties</Link>
              </Button>
            </div>
          </div>
        </Card>
      )}

      {me?.role === 'ADMIN' && (
        <Card className="p-5">
          <div className="flex items-start justify-between gap-3">
            <div>
              <div className="text-xs uppercase tracking-wide text-gray-500">Admin dashboard</div>
              <div className="text-sm text-gray-700 mt-1">Snelkoppelingen</div>
              <div className="mt-4 flex gap-2 flex-wrap">
                <Button asChild><Link to="/admin">Admin</Link></Button>
                <Button variant="secondary" asChild><Link to="/open-diensten">Open diensten</Link></Button>
                <Button variant="secondary" asChild><Link to="/uren">Uren</Link></Button>
                <Button variant="secondary" asChild><Link to="/notificaties">Notificaties</Link></Button>
              </div>
              {adminNext && (
                <div className="mt-5 text-sm">
                  <div className="font-semibold">Volgende open-dienst aanvraag</div>
                  <div className="text-gray-700 mt-1">
                    {adminNext.title} • {formatDT(adminNext.startAt)} – {formatDT(adminNext.endAt)}
                  </div>
                </div>
              )}
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}
