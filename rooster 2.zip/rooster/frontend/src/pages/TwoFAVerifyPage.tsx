import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQueryClient } from '@tanstack/react-query';
import { apiFetch } from '../api/apiClient';
import { Button, Card, ErrorBanner, Input, Label } from '../components/ui';

const STORAGE_KEY = 'tfa_temp_token';

export default function TwoFAVerifyPage() {
  const nav = useNavigate();
  const qc = useQueryClient();

  const [tempToken, setTempToken] = useState<string>('');
  const [code, setCode] = useState('');
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState<string | undefined>();

  useEffect(() => {
    const tok = sessionStorage.getItem(STORAGE_KEY) || '';
    if (!tok) {
      setErr('Geen 2FA sessie gevonden. Log opnieuw in.');
      return;
    }
    setTempToken(tok);
  }, []);

  async function verify() {
    setErr(undefined);
    if (!tempToken) {
      setErr('Geen 2FA sessie gevonden. Log opnieuw in.');
      return;
    }
    if (!code.trim()) {
      setErr('Vul de 6-cijferige code in.');
      return;
    }
    setSaving(true);
    try {
      await apiFetch<{ user: any }>('/auth/2fa/verify', {
        method: 'POST',
        body: JSON.stringify({ tempToken, code: code.trim() }),
      });
      sessionStorage.removeItem(STORAGE_KEY);
      await qc.invalidateQueries({ queryKey: ['me'] });
      nav('/dashboard', { replace: true });
    } catch (e: any) {
      setErr(e?.error || 'Code ongeldig. Probeer opnieuw.');
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="mx-auto flex min-h-screen max-w-6xl items-center justify-center px-4">
      <Card className="w-full max-w-md p-6 space-y-4">
        <div>
          <div className="text-xl font-semibold">2FA verificatie</div>
          <div className="text-sm text-gray-600">Vul de code uit je authenticator app in om verder te gaan.</div>
        </div>

        <ErrorBanner message={err} />

        <div className="space-y-1">
          <Label>Code</Label>
          <Input
            value={code}
            onChange={(e) => setCode(e.target.value)}
            placeholder="123456"
            inputMode="numeric"
            autoComplete="one-time-code"
          />
        </div>

        <Button onClick={verify} disabled={saving}>
          {saving ? 'Verifiëren…' : 'Verifiëren'}
        </Button>

        <Button
          variant="secondary"
          type="button"
          onClick={() => {
            sessionStorage.removeItem(STORAGE_KEY);
            nav('/login', { replace: true });
          }}
        >
          Terug naar login
        </Button>
      </Card>
    </div>
  );
}
