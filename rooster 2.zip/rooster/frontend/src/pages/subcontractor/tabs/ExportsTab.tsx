import { useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { Button, Card, ErrorBanner, Input, Label, SuccessBanner } from '../../../components/ui';
import { downloadWeeklyHoursPdf } from '../../../api/subcontractor';

function isoDate(d: Date) { return d.toISOString().slice(0, 10); }

export default function ExportsTab() {
  const [weekStart, setWeekStart] = useState(() => {
    const d = new Date();
    // set to Monday
    const day = (d.getDay() + 6) % 7;
    d.setDate(d.getDate() - day);
    return isoDate(d);
  });

  const [ok, setOk] = useState<string | undefined>();
  const [err, setErr] = useState<string | undefined>();

  const usedKey = `weeklyExportUsed:${weekStart}`;
  const alreadyUsed = (() => {
    try {
      return window.localStorage.getItem(usedKey) === '1';
    } catch {
      return false;
    }
  })();

  const m = useMutation({
    mutationFn: async () => {
      setOk(undefined);
      setErr(undefined);
      await downloadWeeklyHoursPdf({ weekStart });
    },
    onSuccess: () => {
      try {
        window.localStorage.setItem(usedKey, '1');
      } catch {
        // ignore
      }
      setOk('Export gestart (download).');
    },
    onError: (e: any) => setErr(e?.error ?? e?.message ?? 'Export mislukt'),
  });

  return (
    <div className="space-y-4">
      <Card className="p-4 space-y-3">
        <div className="font-medium text-gray-900">Weekly urenexport (PDF)</div>
        <div className="grid gap-3 md:grid-cols-2">
          <div>
            <Label>Week start (maandag)</Label>
            <Input type="date" value={weekStart} onChange={(e) => setWeekStart(e.target.value)} />
          </div>
        </div>
        <div className="flex gap-2">
          <Button onClick={() => m.mutate()} disabled={m.isPending || !weekStart || alreadyUsed}>
            Download PDF
          </Button>
          <Button variant="secondary" onClick={() => { setOk(undefined); setErr(undefined); }}>
            Reset
          </Button>
        </div>
        <div className="text-xs text-gray-500">
          Quota: 1x per week. Na 1 export wordt de knop gedeactiveerd. De backend handhaaft dit ook.
        </div>
      </Card>

      <ErrorBanner message={err} />
      <SuccessBanner message={ok} />
    </div>
  );
}
