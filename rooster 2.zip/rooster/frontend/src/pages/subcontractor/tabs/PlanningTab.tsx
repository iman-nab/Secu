import { useMemo, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Badge, Button, Card, ErrorBanner, Input, Label } from '../../../components/ui';
import { listSubcontractorShifts } from '../../../api/subcontractor';

function isoDate(d: Date) { return d.toISOString().slice(0, 10); }

export default function PlanningTab() {
  const [start, setStart] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() - 7);
    return isoDate(d);
  });
  const [end, setEnd] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 14);
    return isoDate(d);
  });

  const { data, error, isLoading, refetch } = useQuery({
    queryKey: ['subcontractor', 'shifts', start, end],
    queryFn: () => listSubcontractorShifts({ start, end }),
  });

  const shifts = (data?.shifts ?? []) as any[];
  const rows = useMemo(() => shifts.slice(0, 100), [shifts]);

  return (
    <div className="space-y-4">
      <Card className="p-4">
        <div className="flex flex-wrap items-end gap-3 justify-between">
          <div className="grid gap-3 md:grid-cols-2">
            <div>
              <Label>Start</Label>
              <Input type="date" value={start} onChange={(e) => setStart(e.target.value)} />
            </div>
            <div>
              <Label>Eind</Label>
              <Input type="date" value={end} onChange={(e) => setEnd(e.target.value)} />
            </div>
          </div>
          <Button variant="secondary" onClick={() => refetch()} disabled={isLoading}>
            Refresh
          </Button>
        </div>
      </Card>

      <ErrorBanner message={(error as any)?.error ?? (error as any)?.message} />

      <Card className="p-4">
        <div className="font-medium text-gray-900 mb-3">Planning ({shifts.length})</div>
        {isLoading ? (
          <div className="text-sm text-gray-600">Laden…</div>
        ) : rows.length === 0 ? (
          <div className="text-sm text-gray-600">Geen diensten in deze periode.</div>
        ) : (
          <div className="space-y-2">
            {rows.map((s) => (
              <div key={s.id} className="rounded-xl border border-gray-100 p-3 flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <div className="font-medium text-gray-900 truncate">{s.title ?? 'Dienst'}</div>
                  <div className="text-xs text-gray-600 truncate">{s.startAt ?? ''} → {s.endAt ?? ''}</div>
                </div>
                <div className="flex gap-2 flex-wrap justify-end">
                  {s.type ? <Badge>{s.type}</Badge> : null}
                  {typeof s.requiredWorkers === 'number' ? <Badge>{(s.assignments?.length ?? 0)}/{s.requiredWorkers}</Badge> : null}
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}
