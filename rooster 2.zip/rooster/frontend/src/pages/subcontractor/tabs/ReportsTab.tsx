import { useMemo, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Badge, Button, Card, ErrorBanner, Input, Label } from '../../../components/ui';
import { listSubcontractorReports } from '../../../api/subcontractor';

function isoDate(d: Date) { return d.toISOString().slice(0, 10); }

export default function ReportsTab() {
  const [start, setStart] = useState(() => {
    const d = new Date(); d.setDate(d.getDate() - 30); return isoDate(d);
  });
  const [end, setEnd] = useState(() => isoDate(new Date()));

  const { data, error, isLoading, refetch } = useQuery({
    queryKey: ['subcontractor', 'reports', start, end],
    queryFn: () => listSubcontractorReports({ start, end }),
  });

  const reports = (data?.reports ?? []) as any[];
  const top = useMemo(() => reports.slice(0, 100), [reports]);

  return (
    <div className="space-y-4">
      <Card className="p-4">
        <div className="flex flex-wrap items-end gap-3 justify-between">
          <div className="grid gap-3 md:grid-cols-2">
            <div>
              <Label>Start</Label>
              <Input type="date" value={start} onChange={(e) => setStart(e.target.value)} />
            </div>
            <div>
              <Label>Eind</Label>
              <Input type="date" value={end} onChange={(e) => setEnd(e.target.value)} />
            </div>
          </div>
          <Button variant="secondary" onClick={() => refetch()} disabled={isLoading}>
            Refresh
          </Button>
        </div>
      </Card>

      <ErrorBanner message={(error as any)?.error ?? (error as any)?.message} />

      <Card className="p-4">
        <div className="flex items-center justify-between">
          <div className="font-medium text-gray-900">Rapporten</div>
          <Badge>{reports.length}</Badge>
        </div>

        <div className="mt-3 space-y-2">
          {isLoading ? (
            <div className="text-sm text-gray-600">Laden…</div>
          ) : top.length === 0 ? (
            <div className="text-sm text-gray-600">Geen rapporten.</div>
          ) : (
            top.map((r) => (
              <div key={r.id} className="rounded-xl border border-gray-100 p-3">
                <div className="font-medium text-gray-900">{r.shift?.title ?? r.title ?? 'Dienst rapport'}</div>
                <div className="text-xs text-gray-600">
                  {r.createdAt ?? ''} {r.locationName ? `• ${r.locationName}` : ''}
                </div>
                {r.incidents?.length ? <div className="text-sm text-gray-700 mt-1">Incidents: {r.incidents.join(', ')}</div> : null}
              </div>
            ))
          )}
        </div>
      </Card>
    </div>
  );
}
