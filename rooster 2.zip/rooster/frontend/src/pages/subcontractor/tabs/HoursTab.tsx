import { useMemo, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Badge, Button, Card, ErrorBanner, Input, Label } from '../../../components/ui';
import { subcontractorHours } from '../../../api/subcontractor';

function isoDate(d: Date) { return d.toISOString().slice(0, 10); }

export default function HoursTab() {
  const [start, setStart] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() - 7);
    return isoDate(d);
  });
  const [end, setEnd] = useState(() => isoDate(new Date()));

  const { data, error, isLoading, refetch } = useQuery({
    queryKey: ['subcontractor', 'hours', start, end],
    queryFn: () => subcontractorHours({ start, end }),
  });

  const totalMinutes = data?.totalMinutes ?? 0;
  const rows = (data?.rows ?? []) as any[];
  const top = useMemo(() => rows.slice(0, 200), [rows]);

  return (
    <div className="space-y-4">
      <Card className="p-4">
        <div className="flex flex-wrap items-end gap-3 justify-between">
          <div className="grid gap-3 md:grid-cols-2">
            <div>
              <Label>Start</Label>
              <Input type="date" value={start} onChange={(e) => setStart(e.target.value)} />
            </div>
            <div>
              <Label>Eind</Label>
              <Input type="date" value={end} onChange={(e) => setEnd(e.target.value)} />
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Badge>Totaal: {(totalMinutes / 60).toFixed(2)}u</Badge>
            <Button variant="secondary" onClick={() => refetch()} disabled={isLoading}>
              Refresh
            </Button>
          </div>
        </div>
      </Card>

      <ErrorBanner message={(error as any)?.error ?? (error as any)?.message} />

      <Card className="p-4">
        {isLoading ? (
          <div className="text-sm text-gray-600">Laden…</div>
        ) : top.length === 0 ? (
          <div className="text-sm text-gray-600">Geen uren in deze periode.</div>
        ) : (
          <div className="space-y-2">
            {top.map((r) => (
              <div key={r.id ?? `${r.userId}-${r.shiftId}-${r.clockInAt}`} className="rounded-xl border border-gray-100 p-3">
                <div className="font-medium text-gray-900">
                  {r.user?.fullName ?? r.userName ?? r.userId}
                </div>
                <div className="text-xs text-gray-600">
                  {r.clockInAt ?? ''} → {r.clockOutAt ?? ''}
                </div>
                {typeof r.minutes === 'number' ? (
                  <div className="text-sm text-gray-700 mt-1">{(r.minutes / 60).toFixed(2)} uur</div>
                ) : null}
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}
