import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Badge, Button, Card, ErrorBanner } from '../../../components/ui';
import { listSubcontractorWorkers, updateSubcontractorWorkerPassColor } from '../../../api/subcontractor';

const PASS_COLORS = ['GRAY','DARK_BLUE','LIGHT_BLUE','ORANGE','GREEN','BLACK'] as const;

export default function WorkersTab() {
  const qc = useQueryClient();
  const { data, error, isLoading, refetch } = useQuery({
    queryKey: ['subcontractor', 'workers'],
    queryFn: () => listSubcontractorWorkers(),
  });

  const workers = (data?.workers ?? []) as any[];

  const mut = useMutation({
    mutationFn: async (args: { id: string; passColor: string }) => {
      return updateSubcontractorWorkerPassColor(args.id, args.passColor);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['subcontractor', 'workers'] });
    },
  });

  return (
    <div className="space-y-4">
      <Card className="p-4 flex items-center justify-between">
        <div className="font-medium text-gray-900">Mijn werknemers</div>
        <Button variant="secondary" onClick={() => refetch()} disabled={isLoading}>
          Refresh
        </Button>
      </Card>

      <ErrorBanner message={(error as any)?.error ?? (error as any)?.message} />

      <Card className="p-4">
        {isLoading ? (
          <div className="text-sm text-gray-600">Laden…</div>
        ) : workers.length === 0 ? (
          <div className="text-sm text-gray-600">Geen werknemers gevonden.</div>
        ) : (
          <div className="space-y-2">
            {workers.map((w) => (
              <div key={w.id} className="rounded-xl border border-gray-100 p-3 flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <div className="font-medium text-gray-900 truncate">{w.fullName ?? w.email}</div>
                  <div className="text-xs text-gray-600 truncate">{w.email}</div>
                </div>
                <div className="flex gap-2 flex-wrap justify-end items-center">
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-gray-600">Kleurpas</span>
                    <select
                      className="h-9 rounded-xl border border-gray-200 bg-white px-2 text-sm"
                      value={w.passColor ?? ""}
                      onChange={(e) => mut.mutate({ id: w.id, passColor: e.target.value })}
                      disabled={mut.isPending}
                    >
                      <option value="" disabled>
                        Kies…
                      </option>
                      {PASS_COLORS.map((c) => (
                        <option key={c} value={c}>
                          {c}
                        </option>
                      ))}
                    </select>
                  </div>
                  {w.status ? <Badge>{w.status}</Badge> : null}
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}
