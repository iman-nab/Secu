import { useState } from 'react';
import { Button, Card } from '../../components/ui';
import WorkersTab from './tabs/WorkersTab';
import PlanningTab from './tabs/PlanningTab';
import HoursTab from './tabs/HoursTab';
import ReportsTab from './tabs/ReportsTab';
import ExportsTab from './tabs/ExportsTab';

type Tab = 'workers' | 'planning' | 'hours' | 'reports' | 'exports';

export default function SubcontractorPage() {
  const [tab, setTab] = useState<Tab>('workers');

  return (
    <div className="space-y-4">
      <Card className="p-4">
        <div className="flex flex-wrap gap-2">
          {(
            [
              { key: 'workers', label: 'Werknemers' },
              { key: 'planning', label: 'Planning' },
              { key: 'hours', label: 'Uren' },
              { key: 'reports', label: 'Rapporten' },
              { key: 'exports', label: 'Exports' },
            ] as Array<{ key: Tab; label: string }>
          ).map((t) => (
            <Button
              key={t.key}
              variant={tab === t.key ? 'primary' : 'secondary'}
              onClick={() => setTab(t.key)}
            >
              {t.label}
            </Button>
          ))}
        </div>
      </Card>

      {tab === 'workers' && <WorkersTab />}
      {tab === 'planning' && <PlanningTab />}
      {tab === 'hours' && <HoursTab />}
      {tab === 'reports' && <ReportsTab />}
      {tab === 'exports' && <ExportsTab />}
    </div>
  );
}
