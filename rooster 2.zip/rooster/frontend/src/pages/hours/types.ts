export type Row = {
  timeEntryId: string;
  userId: string;
  userName: string;
  userEmail: string;
  shiftTitle: string;
  locationName: string;
  /** Optional extra details returned by the backend report (kept optional for backwards compatibility). */
  shiftId?: string;
  startAt?: string;
  endAt?: string;
  clockInAt: string;
  clockOutAt: string;
  minutesWorked: number;

  // Phase 11: optional rate fields (RBAC filtered server-side)
  workerRateCents?: number;
  employerRateCents?: number;
  workerAmountCents?: number;
  employerAmountCents?: number;

  // Shift-level (not per worker) extra costs
  shiftExtraCostsCents?: number;
};
