import { useEffect, useMemo, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { listUsers } from '../../api/users';
import { listClients } from '../../api/clients';
import { hoursReport, exportHoursUrl } from '../../api/reports';
import { useMe } from '../../hooks/useAuth';
import { Card, Input, Label, Button } from '../../components/ui';
import { PaginationControls } from '../../components/PaginationControls';
import { useIsMobile } from '../../hooks/useIsMobile';
import { fmtMinutes, isoDate, startOfWeek } from './utils';
import type { Row } from './types';

type ExportPreset = 'csv_entries' | 'xlsx_summary' | 'csv_payroll' | 'xlsx_payroll' | 'pdf_entries';

function clamp(n: number, min: number, max: number) {
  return Math.max(min, Math.min(max, n));
}

function SimpleBarChart({
  title,
  rows,
  valueLabel,
}: {
  title: string;
  rows: Array<{ label: string; value: number }>;
  valueLabel?: (v: number) => string;
}) {
  const max = rows.reduce((m, r) => Math.max(m, r.value), 0) || 1;
  return (
    <div className="rounded-xl border p-4">
      <div className="font-semibold">{title}</div>
      <div className="mt-3 space-y-2">
        {rows.map((r) => (
          <div key={r.label} className="flex items-center gap-3">
            <div className="w-28 shrink-0 truncate text-xs text-gray-700" title={r.label}>
              {r.label}
            </div>
            <div className="h-2 flex-1 rounded-full bg-gray-100">
              <div
                className="h-2 rounded-full bg-gray-800"
                style={{ width: `${clamp((r.value / max) * 100, 2, 100)}%` }}
              />
            </div>
            <div className="w-20 shrink-0 text-right text-xs font-semibold text-gray-800">
              {valueLabel ? valueLabel(r.value) : r.value}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function fmtPlannedRange(r: Pick<Row, 'startAt' | 'endAt'>) {
  if (!r.startAt || !r.endAt) return '';
  const start = new Date(r.startAt);
  const end = new Date(r.endAt);
  const startStr = start.toLocaleString();
  const endStr = end.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  return `${startStr} – ${endStr}`;
}

function fmtSignedMinutes(mins: number) {
  if (!Number.isFinite(mins)) return '—';
  const m = Math.round(mins);
  const sign = m > 0 ? '+' : '';
  return `${sign}${m}m`;
}

function deviationText(r: Row) {
  try {
    if (!r.startAt || !r.endAt || !r.clockInAt) return '';
    const plannedStart = new Date(r.startAt);
    const plannedEnd = new Date(r.endAt);
    const actualIn = new Date(r.clockInAt);
    const actualOut = r.clockOutAt ? new Date(r.clockOutAt) : null;
    if (Number.isNaN(plannedStart.getTime()) || Number.isNaN(plannedEnd.getTime()) || Number.isNaN(actualIn.getTime())) return '';

    const startDiff = (actualIn.getTime() - plannedStart.getTime()) / 60000;
    const plannedMinutes = (plannedEnd.getTime() - plannedStart.getTime()) / 60000;
    const workedMinutes = r.minutesWorked ?? 0;
    const workedDiff = workedMinutes - plannedMinutes;

    const parts: string[] = [];
    parts.push(`Start ${fmtSignedMinutes(startDiff)}`);
    if (actualOut && !Number.isNaN(actualOut.getTime())) {
      const endDiff = (actualOut.getTime() - plannedEnd.getTime()) / 60000;
      parts.push(`Einde ${fmtSignedMinutes(endDiff)}`);
    }
    if (Number.isFinite(plannedMinutes) && plannedMinutes > 0) {
      parts.push(`Verschil ${fmtSignedMinutes(workedDiff)}`);
    }

    return parts.join(' • ');
  } catch {
    return '';
  }
}

export default function HoursPage() {
  const { data: me } = useMe();
  const isMobile = useIsMobile();

  const [start, setStart] = useState(() => isoDate(startOfWeek(new Date())));
  const [end, setEnd] = useState(() => isoDate(new Date()));
  const [selectedUserId, setSelectedUserId] = useState('');
  const [selectedClientId, setSelectedClientId] = useState('');
  const [selectedSubcontractorId, setSelectedSubcontractorId] = useState('');
  const [rounding, setRounding] = useState<'none' | '15'>('none');
  const [exportPreset, setExportPreset] = useState<ExportPreset>('xlsx_summary');
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(50);

  const fmtCents = (c?: number) => {
    if (c === undefined || c === null || !Number.isFinite(Number(c))) return '—';
    const eur = Number(c) / 100;
    return eur.toLocaleString('nl-NL', { style: 'currency', currency: 'EUR' });
  };

  const fmtRateCents = (c?: number | null) => {
    if (c === undefined || c === null || !Number.isFinite(Number(c))) return '—';
    const eur = Number(c) / 100;
    // Currency + per-hour label
    return `${eur.toLocaleString('nl-NL', { style: 'currency', currency: 'EUR' })} /uur`;
  };

  const isAdmin = me?.role === 'ADMIN';

  const roundMinutes = (m: number) => {
    if (rounding === '15') {
      // Round to nearest 15 minutes (payroll-friendly)
      return Math.round(m / 15) * 15;
    }
    return m;
  };

  const params = useMemo(
    () => ({
      start,
      end,
      userId: isAdmin ? (selectedUserId || undefined) : undefined,
      clientId: isAdmin ? (selectedClientId || undefined) : undefined,
      subcontractorId: isAdmin ? (selectedSubcontractorId || undefined) : undefined,
      rounding,
      page,
      pageSize,
    }),
    [start, end, selectedUserId, selectedClientId, selectedSubcontractorId, rounding, page, pageSize, isAdmin],
  );

  // Reset pagination when filters change
  useEffect(() => {
    setPage(1);
  }, [start, end, selectedUserId, selectedClientId, selectedSubcontractorId, pageSize]);

  const { data, isLoading, isError, error, refetch, isFetching } = useQuery({
    queryKey: ['hours', params],
    queryFn: () => hoursReport(params),
    enabled: !!me,
    refetchInterval: 30000,
  });

  const { data: adminUsers } = useQuery({
    queryKey: ['users'],
    // For the medewerker-filter we only need workers; subcontractor accounts live in a separate filter.
    queryFn: () => listUsers({ page: 1, pageSize: 200, role: 'EMPLOYEE' as any }),
    enabled: isAdmin,
  });

  const { data: clientsRes } = useQuery({
    queryKey: ['clients', 'hours-filter'],
    queryFn: () => listClients({ includeDeleted: false, page: 1, pageSize: 200 }),
    enabled: isAdmin,
    staleTime: 60_000,
  });

  const { data: subcontractorsRes } = useQuery({
    queryKey: ['users', 'subcontractors', 'hours-filter'],
    queryFn: () => listUsers({ page: 1, pageSize: 200, role: 'SUBCONTRACTOR' as any }),
    enabled: isAdmin,
    staleTime: 60_000,
  });

  const rows: Row[] = (data?.rows ?? []) as any;
  const totalCount = (data as any)?.totalCount as number | undefined;
  const totalExtraCostsCents = (data as any)?.totalExtraCostsCents as number | undefined;
  const reportKpis = (data as any)?.kpis as any | undefined;

  const allowedRateViews = (data as any)?.allowedRateViews as { pay?: boolean; bill?: boolean } | undefined;
  const canSeePay = allowedRateViews?.pay ?? (me?.role !== 'CLIENT');
  const canSeeBill = allowedRateViews?.bill ?? isAdmin;

  // Minutes on THIS page (used for grouped sections / small charts)
  const totalMinutesPage = useMemo(
    () => rows.reduce((acc, r) => acc + roundMinutes(r.minutesWorked || 0), 0),
    [rows, rounding],
  );

  // Reliable totals across ALL filtered results (server-side), with rounding applied.
  const totalMinutesAll =
    typeof reportKpis?.totalMinutesRounded === 'number'
      ? reportKpis.totalMinutesRounded
      : typeof (data as any)?.totalMinutesRounded === 'number'
        ? (data as any).totalMinutesRounded
        : totalMinutesPage;

  const grouped = useMemo(() => {
    const m = new Map<string, { userId: string; userName: string; userEmail: string; rows: Row[]; total: number }>();
    for (const r of rows) {
      const key = r.userId;
      const cur = m.get(key) ?? { userId: r.userId, userName: r.userName, userEmail: r.userEmail, rows: [], total: 0 };
      cur.rows.push(r);
      cur.total += roundMinutes(r.minutesWorked || 0);
      m.set(key, cur);
    }
    return Array.from(m.values()).sort((a, b) => a.userName.localeCompare(b.userName));
  }, [rows, rounding]);

  const byLocation = useMemo(() => {
    const m = new Map<string, { locationName: string; total: number; shifts: number }>();
    for (const r of rows) {
      const key = r.locationName || '—';
      const cur = m.get(key) ?? { locationName: key, total: 0, shifts: 0 };
      cur.total += roundMinutes(r.minutesWorked || 0);
      cur.shifts += 1;
      m.set(key, cur);
    }
    return Array.from(m.values()).sort((a, b) => a.locationName.localeCompare(b.locationName));
  }, [rows, rounding]);

  const byDay = useMemo(() => {
    const m = new Map<string, { day: string; total: number; shifts: number }>();
    for (const r of rows) {
      const day = (r.clockInAt || '').slice(0, 10) || '—';
      const cur = m.get(day) ?? { day, total: 0, shifts: 0 };
      cur.total += roundMinutes(r.minutesWorked || 0);
      cur.shifts += 1;
      m.set(day, cur);
    }
    return Array.from(m.values()).sort((a, b) => a.day.localeCompare(b.day));
  }, [rows, rounding]);

  const kpis = useMemo(() => {
    const shiftCount = rows.length;
    const employees = new Set(rows.map((r) => r.userId)).size;
    const locations = new Set(rows.map((r) => r.locationName)).size;
    const avg = shiftCount > 0 ? Math.round(totalMinutesPage / shiftCount) : 0;
    return { shiftCount, employees, locations, avgMinutesPerShift: avg };
  }, [rows, totalMinutesPage]);

  const quickToday = () => {
    const d = new Date();
    setStart(isoDate(d));
    setEnd(isoDate(d));
  };
  const quickWeek = () => {
    const s = startOfWeek(new Date());
    setStart(isoDate(s));
    setEnd(isoDate(new Date()));
  };
  const quickMonth = () => {
    const d = new Date();
    d.setDate(1);
    setStart(isoDate(d));
    setEnd(isoDate(new Date()));
  };

  const exportHref = useMemo(() => {
    const base = {
      start,
      end,
      userId: isAdmin ? (selectedUserId || undefined) : undefined,
      clientId: isAdmin ? (selectedClientId || undefined) : undefined,
      subcontractorId: isAdmin ? (selectedSubcontractorId || undefined) : undefined,
      rounding,
    } as const;
    switch (exportPreset) {
      case 'csv_entries':
        return exportHoursUrl({ ...base, format: 'csv', mode: 'entries' });
      case 'pdf_entries':
        return exportHoursUrl({ ...base, format: 'pdf', mode: 'entries' });
      case 'xlsx_summary':
        return exportHoursUrl({ ...base, format: 'xlsx', mode: 'summary' });
      case 'csv_payroll':
        return exportHoursUrl({ ...base, format: 'csv', mode: 'payroll' });
      case 'xlsx_payroll':
        return exportHoursUrl({ ...base, format: 'xlsx', mode: 'payroll' });
      default:
        return exportHoursUrl({ ...base, format: 'xlsx', mode: 'summary' });
    }
  }, [start, end, selectedUserId, selectedClientId, selectedSubcontractorId, rounding, exportPreset, isAdmin]);

  const chartByDay = useMemo(() => {
    // Last 14 days, keep readable labels.
    return byDay
      .slice(-14)
      .map((d) => ({ label: d.day.slice(5), value: d.total }));
  }, [byDay]);

  const chartByLocation = useMemo(() => {
    return [...byLocation]
      .sort((a, b) => b.total - a.total)
      .slice(0, 8)
      .map((l) => ({ label: l.locationName, value: l.total }));
  }, [byLocation]);

  const Empty = () => (
    <div className="text-sm text-gray-600">
      <div className="font-medium text-gray-800">Geen uren gevonden in deze periode.</div>
      <div className="mt-1">
        Tips:
        <ul className="ml-5 list-disc">
          <li>Klok eerst <span className="font-medium">in</span> op een dienst en daarna <span className="font-medium">uit</span>.</li>
          <li>Kies “Vandaag” of “Deze week”.</li>
          {me?.role === 'ADMIN' && <li>Kies “Iedereen” of een specifieke medewerker.</li>}
        </ul>
      </div>
    </div>
  );

  return (
    <div className="space-y-4">
      <Card className="p-5">
        <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-lg font-semibold">Urenoverzicht</h1>
            <div className="mt-1 text-sm text-gray-600">
              Totaal:{' '}
              <span className="font-semibold text-gray-900">{fmtMinutes(totalMinutesAll)}</span>
              <span className="ml-2 text-xs text-gray-500">({(totalCount ?? rows.length)} regels)</span>
              {typeof totalExtraCostsCents === 'number' ? (
                <span className="ml-2 text-xs text-gray-500">
                  • Extra kosten (per dienst): <span className="font-semibold">{fmtCents(totalExtraCostsCents)}</span>
                </span>
              ) : null}
              {isFetching && <span className="ml-2 text-xs text-gray-500">• verversen…</span>}
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" onClick={quickToday}>Vandaag</Button>
            <Button variant="outline" onClick={quickWeek}>Deze week</Button>
            <Button variant="outline" onClick={quickMonth}>Deze maand</Button>
            <select
              className="rounded-xl border px-3 py-2 text-sm"
              value={rounding}
              onChange={(e) => setRounding(e.target.value as any)}
              title="Afronden (payroll)"
            >
              <option value="none">Geen afronding</option>
              <option value="15">Afronden op 15 min</option>
            </select>

            {/* Admin sees both pay + bill columns in the table; other roles only see what they're allowed to. */}
            <Button onClick={() => refetch()} disabled={isFetching}>Verversen</Button>
            <div className="flex items-center gap-2">
              <select
                className="rounded-xl border px-3 py-2 text-sm"
                value={exportPreset}
                onChange={(e) => setExportPreset(e.target.value as ExportPreset)}
                title="Export"
              >
                <option value="xlsx_summary">Export Excel (summary)</option>
                <option value="csv_entries">Export CSV (regels)</option>
                {me?.role === 'ADMIN' && <option value="pdf_entries">Export PDF (regels)</option>}
                {me?.role === 'ADMIN' && <option value="xlsx_payroll">Payroll Excel</option>}
                {me?.role === 'ADMIN' && <option value="csv_payroll">Payroll CSV</option>}
              </select>
              <a
                className="inline-flex items-center justify-center rounded-xl border px-3 py-2 text-sm"
                href={exportHref}
                target="_blank"
                rel="noreferrer"
              >
                Download
              </a>
            </div>
          </div>
        </div>

        {/* KPI summary (based on active filters) */}
        <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
          <div className="rounded-xl border bg-gray-50 p-3">
            <div className="text-xs text-gray-600">Totale uren</div>
            <div className="text-lg font-semibold">{fmtMinutes(totalMinutesAll)}</div>
          </div>

          {canSeePay ? (
            <div className="rounded-xl border bg-gray-50 p-3">
              <div className="text-xs text-gray-600">Gem. uitbetaling tarief</div>
              <div className="text-lg font-semibold">{fmtRateCents(reportKpis?.avgWorkerRateCents)}</div>
            </div>
          ) : null}

          {canSeePay ? (
            <div className="rounded-xl border bg-gray-50 p-3">
              <div className="text-xs text-gray-600">Uitbetaling bedrag</div>
              <div className="text-lg font-semibold">{fmtCents(reportKpis?.totalWorkerAmountCents)}</div>
            </div>
          ) : null}

          {canSeeBill ? (
            <div className="rounded-xl border bg-gray-50 p-3">
              <div className="text-xs text-gray-600">Gem. facturatie tarief</div>
              <div className="text-lg font-semibold">{fmtRateCents(reportKpis?.avgEmployerRateCents)}</div>
            </div>
          ) : null}

          {canSeeBill ? (
            <div className="rounded-xl border bg-gray-50 p-3">
              <div className="text-xs text-gray-600">Facturatie bedrag</div>
              <div className="text-lg font-semibold">{fmtCents(reportKpis?.totalEmployerAmountCents)}</div>
            </div>
          ) : null}
        </div>

        {isAdmin && canSeePay && canSeeBill && typeof reportKpis?.totalEmployerAmountCents === 'number' && typeof reportKpis?.totalWorkerAmountCents === 'number' ? (
          <div className="mt-3 text-xs text-gray-600">
            Geschatte marge (facturatie − uitbetaling):{' '}
            <span className="font-semibold text-gray-900">{fmtCents(reportKpis.totalEmployerAmountCents - reportKpis.totalWorkerAmountCents)}</span>
            {typeof totalExtraCostsCents === 'number' ? (
              <span className="ml-2 text-gray-500">(excl. extra kosten)</span>
            ) : null}
          </div>
        ) : null}

        {me?.role === 'ADMIN' && (
          <div className="mt-4 grid gap-3 md:grid-cols-4">
            <div className="rounded-xl border bg-gray-50 p-3">
              <div className="text-xs text-gray-600">Regels</div>
              <div className="text-lg font-semibold">{kpis.shiftCount}</div>
            </div>
            <div className="rounded-xl border bg-gray-50 p-3">
              <div className="text-xs text-gray-600">Medewerkers</div>
              <div className="text-lg font-semibold">{kpis.employees}</div>
            </div>
            <div className="rounded-xl border bg-gray-50 p-3">
              <div className="text-xs text-gray-600">Locaties</div>
              <div className="text-lg font-semibold">{kpis.locations}</div>
            </div>
            <div className="rounded-xl border bg-gray-50 p-3">
              <div className="text-xs text-gray-600">Gem. per dienst</div>
              <div className="text-lg font-semibold">{fmtMinutes(kpis.avgMinutesPerShift)}</div>
            </div>
          </div>
        )}

        <div className="mt-4 grid gap-3 md:grid-cols-3">
          <div className="md:col-span-2">
            <Label>Periode</Label>
            <div className="mt-1 grid gap-2 sm:grid-cols-2">
              <Input type="date" value={start} onChange={(e) => setStart(e.target.value)} />
              <Input type="date" value={end} onChange={(e) => setEnd(e.target.value)} />
            </div>
            <div className="mt-1 text-xs text-gray-500">Tip: gebruik “Deze week” of “Deze maand” voor snelle selecties.</div>
          </div>

          {isAdmin && (
            <div className="space-y-3">
              <div>
                <Label>Personeel</Label>
                <select
                  className="mt-1 w-full rounded-xl border px-3 py-2 text-sm"
                  value={selectedUserId}
                  onChange={(e) => setSelectedUserId(e.target.value)}
                >
                  <option value="">Iedereen</option>
                  {(adminUsers?.users ?? []).map((u: any) => (
                    <option key={u.id} value={u.id}>
                      {u.fullName} ({u.email})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <Label>Klant</Label>
                <select
                  className="mt-1 w-full rounded-xl border px-3 py-2 text-sm"
                  value={selectedClientId}
                  onChange={(e) => setSelectedClientId(e.target.value)}
                >
                  <option value="">Alle klanten</option>
                  {((clientsRes as any)?.clients ?? []).map((c: any) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <Label>Onderaannemer</Label>
                <select
                  className="mt-1 w-full rounded-xl border px-3 py-2 text-sm"
                  value={selectedSubcontractorId}
                  onChange={(e) => setSelectedSubcontractorId(e.target.value)}
                >
                  <option value="">Alle onderaannemers</option>
                  {((subcontractorsRes as any)?.users ?? []).map((u: any) => (
                    <option key={u.id} value={u.id}>
                      {u.fullName || u.email}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          )}
        </div>

        {isLoading && <div className="mt-4 text-sm text-gray-600">Laden…</div>}
        {isError && <div className="mt-4 text-sm text-red-600">{(error as any)?.error || 'Fout bij laden van uren.'}</div>}
      </Card>

      {/* Mobile: cards */}
      {isMobile && (
        <div className="space-y-3">
          {(rows ?? []).map((r) => {
            const dev = deviationText(r);
            const showPay = canSeePay && (r.workerRateCents !== undefined || r.workerAmountCents !== undefined);
            const showBill = canSeeBill && (r.employerRateCents !== undefined || r.employerAmountCents !== undefined);
            return (
            <Card key={r.timeEntryId} className="p-4">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  {me?.role === 'ADMIN' && (
                    <div className="text-sm font-semibold break-words">{r.userName}</div>
                  )}
                  <div className="font-medium break-words">{r.shiftTitle}</div>
                  {!!fmtPlannedRange(r) && (
                    <div className="mt-1 text-xs text-gray-500 break-words">
                      Gepland: {fmtPlannedRange(r)}
                    </div>
                  )}
                  {!!dev && (
                    <div className="mt-1 text-xs text-gray-500 break-words">Afwijking: {dev}</div>
                  )}
                  <div className="mt-1 text-sm text-gray-600 break-words">{r.locationName}</div>
                  <div className="mt-2 text-xs text-gray-600">
                    In: {new Date(r.clockInAt).toLocaleString()}
                    {r.clockOutAt ? ` • Uit: ${new Date(r.clockOutAt).toLocaleString()}` : ' • (Nog ingeklokt)'}
                  </div>

                  {showPay ? (
                    <div className="mt-2 text-xs text-gray-700">
                      Uitbetaling: {fmtCents(r.workerRateCents)} • Bedrag: {fmtCents(r.workerAmountCents)}
                    </div>
                  ) : null}
                  {showBill ? (
                    <div className="mt-1 text-xs text-gray-700">
                      Facturatie: {fmtCents(r.employerRateCents)} • Bedrag: {fmtCents(r.employerAmountCents)}
                    </div>
                  ) : null}

                  {Number(r.shiftExtraCostsCents || 0) > 0 ? (
                    <div className="mt-1 text-xs text-gray-700">
                      Extra kosten (dienst): {fmtCents(r.shiftExtraCostsCents)}
                    </div>
                  ) : null}
                </div>
                <div className="shrink-0 rounded-xl border bg-gray-50 px-3 py-2 text-sm font-semibold">
                  {fmtMinutes(roundMinutes(r.minutesWorked))}
                </div>
              </div>
            </Card>
            );
          })}

          {!isLoading && (rows?.length ?? 0) === 0 && (
            <Card className="p-4">
              <Empty />
            </Card>
          )}

          <PaginationControls
            page={page}
            pageSize={pageSize}
            totalCount={totalCount}
            onPageChange={(p) => setPage(Math.max(1, p))}
            onPageSizeChange={(ps) => {
              setPageSize(ps);
              setPage(1);
            }}
          />
        </div>
      )}

      {/* Desktop: grouped if admin + everyone, otherwise table */}
      {!isMobile && (
        <Card className="p-5">
          {me?.role === 'ADMIN' && rows.length > 0 && (
            <div className="mb-6 grid gap-4 md:grid-cols-2">
              <SimpleBarChart title="Uren per locatie (top 8)" rows={chartByLocation} valueLabel={(v) => fmtMinutes(v)} />
              <SimpleBarChart title="Uren per dag (laatste 14 dagen)" rows={chartByDay} valueLabel={(v) => fmtMinutes(v)} />
            </div>
          )}
          {me?.role === 'ADMIN' && !selectedUserId ? (
            <div className="space-y-6">
              {grouped.map((g) => (
                <div key={g.userId}>
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-semibold">{g.userName}</div>
                      <div className="text-sm text-gray-600">{g.userEmail}</div>
                    </div>
                    <div className="rounded-xl border bg-gray-50 px-3 py-2 text-sm font-semibold">
                      {fmtMinutes(g.total)}
                    </div>
                  </div>

                  <div className="mt-3 overflow-auto rounded-xl border">
                    <table className="min-w-full text-sm">
                      <thead className="text-left text-gray-600">
                        <tr>
                          <th className="py-2 px-3">In</th>
                          <th className="py-2 px-3">Uit</th>
                          <th className="py-2 px-3">Dienst</th>
                          <th className="py-2 px-3">Locatie</th>
                          <th className="py-2 px-3">Uitbetaling tarief</th>
                          <th className="py-2 px-3">Uitbetaling bedrag</th>
                          <th className="py-2 px-3">Facturatie tarief</th>
                          <th className="py-2 px-3">Facturatie bedrag</th>
                          <th className="py-2 px-3">Extra kosten (dienst)</th>
                          <th className="py-2 px-3">Uren</th>
                        </tr>
                      </thead>
                      <tbody>
                        {g.rows.map((r) => (
                          <tr key={r.timeEntryId} className="border-t">
                            <td className="py-2 px-3">{new Date(r.clockInAt).toLocaleString()}</td>
                            <td className="py-2 px-3">{r.clockOutAt ? new Date(r.clockOutAt).toLocaleString() : '—'}</td>
                          <td className="py-2 px-3">
                            <div className="font-medium">{r.shiftTitle}</div>
                            {!!fmtPlannedRange(r) && (
                              <div className="mt-1 text-xs text-gray-500">Gepland: {fmtPlannedRange(r)}</div>
                            )}
                            {(() => {
                              const dev = deviationText(r);
                              return dev ? <div className="mt-1 text-xs text-gray-500">Afwijking: {dev}</div> : null;
                            })()}
                          </td>
                            <td className="py-2 px-3">{r.locationName}</td>
                            <td className="py-2 px-3">{fmtCents(r.workerRateCents)}</td>
                            <td className="py-2 px-3 font-medium">{fmtCents(r.workerAmountCents)}</td>
                            <td className="py-2 px-3">{fmtCents(r.employerRateCents)}</td>
                            <td className="py-2 px-3 font-medium">{fmtCents(r.employerAmountCents)}</td>
                            <td className="py-2 px-3">{fmtCents(r.shiftExtraCostsCents)}</td>
                            <td className="py-2 px-3 font-semibold">{fmtMinutes(roundMinutes(r.minutesWorked))}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              ))}

              {!isLoading && grouped.length === 0 && <Empty />}
            </div>
          ) : (
            <div className="overflow-auto rounded-xl border">
              <table className="min-w-full text-sm">
                <thead className="text-left text-gray-600">
                  <tr>
                    {me?.role === 'ADMIN' && <th className="py-2 px-3">Persoon</th>}
                    <th className="py-2 px-3">In</th>
                    <th className="py-2 px-3">Uit</th>
                    <th className="py-2 px-3">Dienst</th>
                    <th className="py-2 px-3">Locatie</th>
                    {isAdmin ? (
                      <>
                        <th className="py-2 px-3">Uitbetaling tarief</th>
                        <th className="py-2 px-3">Uitbetaling bedrag</th>
                        <th className="py-2 px-3">Facturatie tarief</th>
                        <th className="py-2 px-3">Facturatie bedrag</th>
                      </>
                    ) : (
                      <>
                        <th className="py-2 px-3">{canSeePay ? 'Uitbetaling tarief' : 'Facturatie tarief'}</th>
                        <th className="py-2 px-3">{canSeePay ? 'Uitbetaling bedrag' : 'Facturatie bedrag'}</th>
                      </>
                    )}
                    <th className="py-2 px-3">Extra kosten (dienst)</th>
                    <th className="py-2 px-3">Uren</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((r) => (
                    <tr key={r.timeEntryId} className="border-t">
                      {me?.role === 'ADMIN' && <td className="py-2 px-3">{r.userName}</td>}
                      <td className="py-2 px-3">{new Date(r.clockInAt).toLocaleString()}</td>
                      <td className="py-2 px-3">{r.clockOutAt ? new Date(r.clockOutAt).toLocaleString() : '—'}</td>
                      <td className="py-2 px-3">
                        <div className="font-medium">{r.shiftTitle}</div>
                        {!!fmtPlannedRange(r) && (
                          <div className="mt-1 text-xs text-gray-500">Gepland: {fmtPlannedRange(r)}</div>
                        )}
                        {(() => {
                          const dev = deviationText(r);
                          return dev ? <div className="mt-1 text-xs text-gray-500">Afwijking: {dev}</div> : null;
                        })()}
                      </td>
                      <td className="py-2 px-3">{r.locationName}</td>
                      {isAdmin ? (
                        <>
                          <td className="py-2 px-3">{fmtCents(r.workerRateCents)}</td>
                          <td className="py-2 px-3 font-medium">{fmtCents(r.workerAmountCents)}</td>
                          <td className="py-2 px-3">{fmtCents(r.employerRateCents)}</td>
                          <td className="py-2 px-3 font-medium">{fmtCents(r.employerAmountCents)}</td>
                        </>
                      ) : (
                        <>
                          <td className="py-2 px-3">{fmtCents(canSeePay ? r.workerRateCents : r.employerRateCents)}</td>
                          <td className="py-2 px-3 font-medium">{fmtCents(canSeePay ? r.workerAmountCents : r.employerAmountCents)}</td>
                        </>
                      )}
                      <td className="py-2 px-3">{fmtCents(r.shiftExtraCostsCents)}</td>
                      <td className="py-2 px-3 font-semibold">{fmtMinutes(roundMinutes(r.minutesWorked))}</td>
                    </tr>
                  ))}
                </tbody>
              </table>

              {!isLoading && rows.length === 0 && (
                <div className="p-4">
                  <Empty />
                </div>
              )}
            </div>
          )}

          <div className="mt-4">
            <PaginationControls
              page={page}
              pageSize={pageSize}
              totalCount={totalCount}
              onPageChange={(p) => setPage(Math.max(1, p))}
              onPageSizeChange={(ps) => {
                setPageSize(ps);
                setPage(1);
              }}
            />
          </div>
        </Card>
      )}
    </div>
  );
}
