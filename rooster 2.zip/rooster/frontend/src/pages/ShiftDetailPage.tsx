export { default } from './shiftDetail/ShiftDetailPage';
