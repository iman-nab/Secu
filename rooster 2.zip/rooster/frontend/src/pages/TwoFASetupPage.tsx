import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQueryClient } from '@tanstack/react-query';
import QRCode from 'qrcode';
import { apiFetch } from '../api/apiClient';
import { Button, Card, ErrorBanner, Input, Label, SuccessBanner } from '../components/ui';

type SetupResponse = { secret: string; otpauthUrl: string };

export default function TwoFASetupPage() {
  const nav = useNavigate();
  const qc = useQueryClient();

  const [loading, setLoading] = useState(true);
  const [setup, setSetup] = useState<SetupResponse | null>(null);
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [err, setErr] = useState<string | undefined>();
  const [okMsg, setOkMsg] = useState<string | undefined>();

  const [code, setCode] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    // NOTE:
    // In React 18 StrictMode (dev), effects run twice: mount -> cleanup -> mount.
    // If we try to "guard" the second run with a ref and also mark the first run as
    // unmounted in cleanup, we can accidentally prevent state updates and get stuck on
    // "Laden…" forever.
    //
    // Our backend /auth/2fa/setup is idempotent (reuses twoFactorTempSecret), so it's safe
    // to let this run twice in dev.
    let cancelled = false;
    (async () => {
      setLoading(true);
      setErr(undefined);
      setOkMsg(undefined);
      try {
        const data = await apiFetch<SetupResponse>('/auth/2fa/setup', { method: 'POST', body: '{}' });
        if (cancelled) return;
        setSetup(data);
      } catch (e: any) {
        if (cancelled) return;
        setErr(e?.error || 'Kon 2FA setup niet starten.');
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  // Generate a QR code from the otpauth URL so users can scan it in an authenticator app.
  useEffect(() => {
    let cancelled = false;
    (async () => {
      if (!setup?.otpauthUrl) {
        setQrDataUrl('');
        return;
      }
      try {
        const url = await QRCode.toDataURL(setup.otpauthUrl, { margin: 1, scale: 6 });
        if (!cancelled) setQrDataUrl(url);
      } catch {
        if (!cancelled) setQrDataUrl('');
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [setup?.otpauthUrl]);

  async function copy(text: string) {
    try {
      await navigator.clipboard.writeText(text);
      setOkMsg('Gekopieerd naar clipboard.');
    } catch {
      setErr('Kon niet kopiëren. Kopieer handmatig.');
    }
  }

  async function enable() {
    setErr(undefined);
    setOkMsg(undefined);
    if (!code.trim()) {
      setErr('Vul de 6-cijferige code in uit je authenticator app.');
      return;
    }
    setSaving(true);
    try {
      await apiFetch<{ user: any }>('/auth/2fa/enable', {
        method: 'POST',
        body: JSON.stringify({ code: code.trim() }),
      });
      await qc.invalidateQueries({ queryKey: ['me'] });
      nav('/dashboard', { replace: true });
    } catch (e: any) {
      setErr(e?.error || 'Code ongeldig. Probeer opnieuw.');
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="mx-auto flex min-h-screen max-w-6xl items-center justify-center px-4">
      <Card className="w-full max-w-lg p-6 space-y-4">
        <div>
          <div className="text-xl font-semibold">2FA instellen</div>
          <div className="text-sm text-gray-600">
            2FA is verplicht. Scan de QR-code met je authenticator app (bijv. Google Authenticator / Microsoft Authenticator).
          </div>
        </div>

        <ErrorBanner message={err} />
        <SuccessBanner message={okMsg} />

        {loading ? (
          <div className="text-sm text-gray-600">Laden…</div>
        ) : !setup ? (
          <div className="text-sm text-gray-600">Geen setup data beschikbaar.</div>
        ) : (
          <div className="space-y-4">
            {qrDataUrl ? (
              <div className="flex items-center justify-center">
                <div className="rounded-2xl border bg-white p-4 shadow-sm">
                  <img
                    src={qrDataUrl}
                    alt="Scan deze QR-code met Google Authenticator / Microsoft Authenticator"
                    className="h-[220px] w-[220px]"
                  />
                </div>
              </div>
            ) : (
              <div className="text-sm text-gray-600">
                QR-code kon niet worden gegenereerd. Gebruik de secret of otpauth-url hieronder.
              </div>
            )}

            <div className="rounded-xl border bg-gray-50 p-4 text-sm space-y-2">
              <div>
                <div className="font-semibold">Secret</div>
                <div className="mt-1 font-mono break-all">{setup.secret}</div>
                <div className="mt-2 flex gap-2">
                  <Button variant="secondary" type="button" onClick={() => copy(setup.secret)}>
                    Kopieer secret
                  </Button>
                </div>
              </div>

              <div className="pt-2 border-t">
                <div className="font-semibold">OTPAuth URL</div>
                <div className="mt-1 font-mono break-all text-xs">{setup.otpauthUrl}</div>
                <div className="mt-2 flex gap-2">
                  <Button variant="secondary" type="button" onClick={() => copy(setup.otpauthUrl)}>
                    Kopieer otpauth-url
                  </Button>
                </div>
              </div>

              <div className="text-xs text-gray-600">
                Tip: veel apps ondersteunen "QR from URL". Anders kun je de secret handmatig invoeren.
              </div>
            </div>

            <div className="space-y-1">
              <Label>Code uit authenticator</Label>
              <Input
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="123456"
                inputMode="numeric"
                autoComplete="one-time-code"
              />
            </div>

            <Button onClick={enable} disabled={saving}>
              {saving ? 'Bevestigen…' : '2FA inschakelen'}
            </Button>

            <div className="text-xs text-gray-600">
              Na het inschakelen wordt je automatisch doorgestuurd.
            </div>
          </div>
        )}
      </Card>
    </div>
  );
}
