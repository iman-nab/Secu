import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useParams } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { clockIn, clockOut, createShift, getShift, getShiftActivity, pinShiftNote, updateShift } from '../../api/shifts';
import { getCurrentGeo } from '../../hooks/useGeo';
import { useMe } from '../../hooks/useAuth';
import { useIsMobile } from '../../hooks/useIsMobile';
import { ShiftHeaderCard } from './components/ShiftHeaderCard';
import { ClientNotesCard } from './components/ClientNotesCard';
import { EmployeeStatusCard } from './components/EmployeeStatusCard';
import { AdminAssignmentsCard } from './components/AdminAssignmentsCard';
import { AdminTimeEntriesCard } from './components/AdminTimeEntriesCard';
import { AdminActivityCard } from './components/AdminActivityCard';
import { ShiftReportCard } from './components/ShiftReportCard';
import { RatesAndCostsCard } from './components/RatesAndCostsCard';
import { useToast } from '../../components/toast';
import { formatApiError } from '../../api/errorMessages';
import { normalizeAction } from '../../utils/auditHumanize';

type TabKey = 'OVERVIEW' | 'REPORT' | 'ADMIN';

function TabButton(props: {
  active: boolean;
  children: any;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={props.onClick}
      className={
        'px-3 py-2 rounded-xl text-sm border transition ' +
        (props.active
          ? 'bg-gray-900 text-white border-gray-900'
          : 'bg-white text-gray-700 border-gray-200 hover:bg-gray-50')
      }
    >
      {props.children}
    </button>
  );
}

export default function ShiftDetailPage() {
  const { id } = useParams();
  const { data: me } = useMe();
  const isMobile = useIsMobile();
  const qc = useQueryClient();
  const toast = useToast();
  const [err, setErr] = useState<string | undefined>();
  const [busy, setBusy] = useState(false);
  const [nowTick, setNowTick] = useState(() => Date.now());
  const [geoWarn, setGeoWarn] = useState<null | { distM: number; radiusM: number; mode: 'in' | 'out' }>(null);
  const [geoReason, setGeoReason] = useState<string>('GPS afwijking');
  const [pendingGeo, setPendingGeo] = useState<null | { lat: number; lng: number; accuracyM: number; distM?: number }>(null);
  const geoProceedBtnRef = useRef<HTMLButtonElement | null>(null);

  const isAdmin = me?.role === 'ADMIN';

  const updateShiftM = useMutation({
    mutationFn: async (input: any) => updateShift(id!, input),
    onSuccess: async () => {
      await qc.invalidateQueries({ queryKey: ['shift', id] });
      await qc.invalidateQueries({ queryKey: ['shifts'] });
      toast.success('Dienst opgeslagen');
    },
    onError: (e: any) => toast.error(formatApiError(e) || 'Opslaan mislukt'),
  });

  const duplicateM = useMutation({
    mutationFn: async (payload: any) => createShift(payload),
    onSuccess: async () => {
      await qc.invalidateQueries({ queryKey: ['shifts'] });
      toast.success('Dienst gedupliceerd (volgende week)');
    },
    onError: (e: any) => toast.error(formatApiError(e) || 'Dupliceren mislukt'),
  });

  const availableTabs = useMemo<{ key: TabKey; label: string }[]>(() => {
    const base: { key: TabKey; label: string }[] = [
      { key: 'OVERVIEW', label: 'Overzicht' },
      { key: 'REPORT', label: 'Dagrapportage' },
    ];
    if (isAdmin) base.push({ key: 'ADMIN', label: 'Admin' });
    return base;
  }, [isAdmin]);

  const [tab, setTab] = useState<TabKey>(() => {
    try {
      const hash = (typeof window !== 'undefined' ? window.location.hash : '').replace('#', '').toUpperCase();
      const fromHash = (hash === 'ADMIN' || hash === 'REPORT' || hash === 'OVERVIEW') ? (hash as TabKey) : null;
      const fromSession = (typeof sessionStorage !== 'undefined' ? (sessionStorage.getItem('rooster.shiftDetailTab') as any) : null);
      const fromStorage = (fromSession === 'ADMIN' || fromSession === 'REPORT' || fromSession === 'OVERVIEW') ? (fromSession as TabKey) : null;
      return (fromHash ?? fromStorage ?? 'OVERVIEW') as TabKey;
    } catch {
      return 'OVERVIEW';
    }
  });

  useEffect(() => {
    // If user role changes (me loads), keep tab valid.
    if (!availableTabs.some((t) => t.key === tab)) setTab('OVERVIEW');
  }, [availableTabs, tab]);

  useEffect(() => {
    // Persist last-used tab for faster admin workflows.
    try {
      sessionStorage.setItem('rooster.shiftDetailTab', tab);
      if (typeof window !== 'undefined') {
        const desired = `#${tab.toLowerCase()}`;
        if (window.location.hash !== desired) {
          window.history.replaceState(window.history.state, '', `${window.location.pathname}${desired}`);
        }
      }
    } catch {
      // ignore
    }
  }, [tab]);

  // Accessibility: when the geofence modal opens, move focus to the primary action.
  useEffect(() => {
    if (!geoWarn) return;
    // microtask so the element exists
    queueMicrotask(() => geoProceedBtnRef.current?.focus());
  }, [geoWarn]);

  const [activityImportantOnly, setActivityImportantOnly] = useState(true);
  const [activityExpanded, setActivityExpanded] = useState<Record<string, boolean>>({});
  const [activityPage, setActivityPage] = useState(1);
  const [activityPageSize, setActivityPageSize] = useState(25);

  const pinNoteM = useMutation({
    mutationFn: async (input: { noteId: string; pinned: boolean }) =>
      pinShiftNote(id!, input.noteId, input.pinned),
    onSuccess: async () => {
      await qc.invalidateQueries({ queryKey: ['shift', id] });
      await qc.invalidateQueries({ queryKey: ['shift-activity', id] });
    },
  });

  const { data: shiftData } = useQuery({
    queryKey: ['shift', id],
    queryFn: () => getShift(id!),
    enabled: !!id,
  });

  const { data: activityData, isLoading: activityLoading } = useQuery({
    queryKey: ['shift-activity', id, activityPage, activityPageSize],
    queryFn: () => getShiftActivity(id!, { page: activityPage, pageSize: activityPageSize }),
    enabled: !!id && isAdmin && tab === 'ADMIN',
  });

  const shift = shiftData?.shift;
  const assignees = useMemo(() => shift?.assignments ?? [], [shift]);

  const myEntry = useMemo(() => {
    if (!me?.id) return undefined;
    const entries = (shiftData?.shift as any)?.timeEntries as any[] | undefined;
    if (!entries) return undefined;
    return entries.find((e) => e.userId === me.id) as any | undefined;
  }, [shiftData?.shift, me?.id]);

  const shiftStatus = String(shift?.status ?? '').toUpperCase();
  const isArchivedOrDone = shiftStatus === 'COMPLETED' || shiftStatus === 'CANCELLED' || shiftStatus === 'DELETED';
  const isLocked = shiftStatus === 'COMPLETED' || shiftStatus === 'CANCELLED' || shiftStatus === 'DELETED';
  const canClockIn = !myEntry && !isArchivedOrDone;
  const canClockOut = !!myEntry && !myEntry.clockOutAt && !isLocked;

  const activityItems = useMemo(() => {
    const logsRaw = (activityData?.logs ?? []) as any[];
    // Some audit payloads can contain BigInt (e.g. from Prisma), which breaks JSON.stringify.
    const safeStringify = (v: any) => {
      try {
        return JSON.stringify(v ?? null, (_k, val) => (typeof val === 'bigint' ? val.toString() : val));
      } catch {
        try {
          return String(v);
        } catch {
          return '[unserializable]';
        }
      }
    };
    // Dedupe: sometimes the backend can record two logs with identical payloads (or dev can fetch twice).
    // We keep only the first instance of each signature.
    const seen = new Set<string>();
    const logs = logsRaw.filter((l) => {
      // Dedupe on content (not on id): some actions can be logged twice with different ids.
      const sig = [l?.action, l?.actorId, l?.entityId, safeStringify(l?.after), safeStringify(l?.before)].join('|');
      if (seen.has(sig)) return false;
      seen.add(sig);
      return true;
    });
    if (!activityImportantOnly) return logs;
    const important = new Set([
      'SHIFT_CREATE',
      'SHIFT_UPDATE',
      'SHIFT_DELETE',
      'SHIFT_CREATE_BULK',
      'SHIFT_ASSIGN',
      'SHIFT_UNASSIGN',
      'OPEN_SHIFT_APPROVE',
      'OPEN_SHIFT_REJECT',
      'CLOCK_IN',
      'CLOCK_OUT',
      'TIMEENTRY_RESET',
      'TIMEENTRY_CORRECT',
      'ADMIN_CLOCK_IN',
      'ADMIN_CLOCK_OUT',
    ]);
    return logs.filter((l) => important.has(normalizeAction(l.action)));
  }, [activityData?.logs, activityImportantOnly]);

  useEffect(() => {
    // When switching to Admin tab, start at page 1.
    if (tab === 'ADMIN') setActivityPage(1);
  }, [tab]);

  useEffect(() => {
    if (!myEntry || myEntry.clockOutAt) return;
    const t = setInterval(() => setNowTick(Date.now()), 1000);
    return () => clearInterval(t);
  }, [myEntry?.id, myEntry?.clockOutAt]);

  const doClock = useCallback(
    async (mode: 'in' | 'out') => {
      if (!id) return;
      setErr(undefined);
      setBusy(true);
      try {
        const geo = await getCurrentGeo();

        // Geofence warning (do not hard-block, just warn)
        if (
          mode === 'in' &&
          shift?.location?.latitude &&
          shift?.location?.longitude &&
          shift?.location?.radiusM
        ) {
          const toRad = (v: number) => (v * Math.PI) / 180;
          const R = 6371000;
          const dLat = toRad(shift.location.latitude - geo.lat);
          const dLon = toRad(shift.location.longitude - geo.lng);
          const a =
            Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(toRad(geo.lat)) * Math.cos(toRad(shift.location.latitude)) *
              Math.sin(dLon / 2) * Math.sin(dLon / 2);
          const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
          const distM = Math.round(R * c);
          if (distM > shift.location.radiusM) {
            // Show a friendly modal with quick reasons (no hard block)
            setGeoWarn({ distM, radiusM: shift.location.radiusM, mode });
            setPendingGeo({ lat: geo.lat, lng: geo.lng, accuracyM: geo.accuracyM, distM });
            setBusy(false);
            return;
          }
        }

        if (mode === 'in') await clockIn(id, { ...geo, geoReason: null, bypassGeofence: false });
        else await clockOut(id, { ...geo, geoReason: null, bypassGeofence: false });

        await qc.invalidateQueries({ queryKey: ['shift', id] });
        await qc.invalidateQueries({ queryKey: ['hours'] });

        toast.success(mode === 'in' ? 'Ingeklokt' : 'Uitgeklokt');
      } catch (e: any) {
        toast.error(formatApiError(e));
      } finally {
        setBusy(false);
      }
    },
    [id, qc, shift],
  );

  // Contextual keyboard shortcuts on this page:
  // - I: Clock in (when possible)
  // - O: Clock out (when possible)
  // - Esc: close modals (geofence warning)
  useEffect(() => {
    const isTypingTarget = (el: EventTarget | null) => {
      const node = el as HTMLElement | null;
      if (!node) return false;
      const tag = (node.tagName || '').toLowerCase();
      if (tag === 'input' || tag === 'textarea' || tag === 'select') return true;
      if ((node as any).isContentEditable) return true;
      return false;
    };

    const onKeyDown = (e: KeyboardEvent) => {
      if (isTypingTarget(e.target)) return;

      // Close modals
      if (e.key === 'Escape' && geoWarn) {
        e.preventDefault();
        setGeoWarn(null);
        return;
      }

      // Avoid triggering while busy or modal open.
      if (busy || geoWarn) return;

      const k = e.key.toLowerCase();
      if (k === 'i' && canClockIn) {
        e.preventDefault();
        void doClock('in');
      }
      if (k === 'o' && canClockOut) {
        e.preventDefault();
        void doClock('out');
      }
    };

    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [busy, geoWarn, canClockIn, canClockOut, doClock]);


  if (!shift) return <div className="text-sm text-gray-600">Loading…</div>;

  return (
    <div className="space-y-4">
      <ShiftHeaderCard
        shift={shift}
        isAdmin={isAdmin}
        busy={busy}
        myEntry={myEntry}
        canClockIn={canClockIn}
        canClockOut={canClockOut}
        doClock={doClock}
        saving={updateShiftM.isPending}
        onQuickAction={async (action, input) => {
          if (action === 'copyLink') {
            await navigator.clipboard.writeText(window.location.href);
            toast.success('Link gekopieerd');
            return;
          }
          if (!isAdmin) return;

          if (action === 'cancel') {
            if (!window.confirm('Weet je zeker dat je deze dienst wilt annuleren?')) return;
            await updateShiftM.mutateAsync({ status: 'CANCELLED' });
            return;
          }
          if (action === 'setStatus') {
            const next = String((input as any)?.status ?? '').toUpperCase();
            if (!next) return;
            if (next === 'COMPLETED') {
              if (!window.confirm('Dienst handmatig op COMPLETED zetten? Dit blokkeert toewijzen/ontkoppelen en klok-acties.')) return;
            }
            if (next === 'OPEN') {
              if (!window.confirm('Dienst heropenen (status OPEN)?')) return;
            }
            await updateShiftM.mutateAsync({ status: next });
            return;
          }
          if (action === 'save') {
            await updateShiftM.mutateAsync(input);
            return;
          }
          if (action === 'duplicateNextWeek') {
            const start = new Date(shift.startAt);
            const end = new Date(shift.endAt);
            start.setDate(start.getDate() + 7);
            end.setDate(end.getDate() + 7);
            await duplicateM.mutateAsync({
              title: shift.title,
              description: shift.description ?? null,
              locationId: shift.locationId,
              clientId: shift.clientId ?? null,
              requiredWorkers: shift.requiredWorkers ?? 0,
              startAt: start.toISOString(),
              endAt: end.toISOString(),
              status: 'OPEN',
            });
            return;
          }
        }}
        err={err}
      />

      {shiftStatus === 'CANCELLED' ? (
        <div className="rounded-2xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900">
          <div className="font-semibold">Geannuleerd (read-only)</div>
          <div className="mt-1">Deze dienst is geannuleerd. Personeel koppelen/ontkoppelen, tarieven, extra kosten en klok-acties zijn geblokkeerd.</div>
        </div>
      ) : null}

      {/* Simple tab bar (reduces scrolling) */}
      <div className="sticky top-0 z-10 -mx-4 px-4 py-3 bg-white/90 backdrop-blur border-b">
        <div className="flex flex-wrap gap-2">
          {availableTabs.map((t) => (
            <TabButton key={t.key} active={tab === t.key} onClick={() => setTab(t.key)}>
              {t.label}
            </TabButton>
          ))}
        </div>
      </div>

      {tab === 'OVERVIEW' && (
        <div className="space-y-4">
          <EmployeeStatusCard me={me} myEntry={myEntry} nowTick={nowTick} />

          {isAdmin ? (
            <AdminAssignmentsCard assignees={assignees} shift={shift} qc={qc} id={id} setErr={setErr} locked={isLocked} />
          ) : null}

          <ClientNotesCard shift={shift} me={me} pinNoteM={pinNoteM} />

          <RatesAndCostsCard shift={shiftData?.shift} me={me} qc={qc} id={id!} setErr={setErr} locked={isLocked} />
        </div>
      )}

      {tab === 'REPORT' && (
        <div className="space-y-4">
          <ShiftReportCard shift={shiftData?.shift} me={me} />
        </div>
      )}

      {tab === 'ADMIN' && isAdmin && (
        <div className="space-y-4">
          <AdminAssignmentsCard assignees={assignees} shift={shift} qc={qc} id={id} setErr={setErr} locked={isLocked} />
          <AdminTimeEntriesCard shift={shift} qc={qc} id={id} setErr={setErr} locked={isLocked} />
          <AdminActivityCard
            activityLoading={activityLoading}
            activityItems={activityItems}
            activityImportantOnly={activityImportantOnly}
            setActivityImportantOnly={setActivityImportantOnly}
            activityExpanded={activityExpanded}
            setActivityExpanded={setActivityExpanded}
            page={activityPage}
            pageSize={activityPageSize}
            totalCount={(activityData as any)?.totalCount}
            setPage={setActivityPage}
            setPageSize={setActivityPageSize}
          />
        </div>
      )}

      {/* Geofence warning modal */}
      {geoWarn ? (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
          <div className="w-full max-w-lg rounded-2xl bg-white p-5 shadow-xl">
            <div className="text-lg font-semibold">Buiten locatie-radius</div>
            <div className="mt-1 text-sm text-gray-600">
              Je bent ongeveer <span className="font-semibold">{geoWarn.distM}m</span> van de locatie verwijderd (radius{' '}
              {geoWarn.radiusM}m).
            </div>

            <div className="mt-4">
              <div className="text-sm font-medium text-gray-800">Kies reden (optioneel)</div>
              <div className="mt-2 flex flex-wrap gap-2">
                {['GPS afwijking', 'Werk elders', 'Locatie klopt niet', 'Parkeren/ingang', 'Anders'].map((r) => (
                  <button
                    key={r}
                    type="button"
                    onClick={() => setGeoReason(r)}
                    className={
                      'rounded-full border px-3 py-1 text-sm ' +
                      (geoReason === r
                        ? 'border-gray-900 bg-gray-900 text-white'
                        : 'border-gray-200 bg-white text-gray-700 hover:bg-gray-50')
                    }
                  >
                    {r}
                  </button>
                ))}
              </div>
              <div className="mt-2 text-xs text-gray-500">
                Deze reden wordt opgeslagen bij je klokactie, zodat de planner kan zien waar geofence vaak afwijkt.
              </div>
            </div>

            <div className="mt-5 flex items-center justify-end gap-2">
              <button
                type="button"
                className="rounded-xl border border-gray-200 bg-white px-3 py-2 text-sm text-gray-700 hover:bg-gray-50"
                onClick={() => setGeoWarn(null)}
              >
                Annuleer
              </button>
              <button
                type="button"
                className="rounded-xl bg-gray-900 px-3 py-2 text-sm text-white hover:bg-black"
                ref={geoProceedBtnRef}
                onClick={async () => {
                  const mode = geoWarn.mode;
                  setGeoWarn(null);
                  setBusy(true);
                  try {
                    // Use the already captured geo from the first check, so the audit log matches what the user saw.
                    const geo = pendingGeo ?? (await getCurrentGeo());
                    const payload = {
                      lat: geo.lat,
                      lng: geo.lng,
                      accuracyM: geo.accuracyM,
                      geoReason,
                      bypassGeofence: true,
                      distanceM: geo.distM,
                    } as any;
                    if (mode === 'in') await clockIn(id!, payload);
                    else await clockOut(id!, payload);
                    await qc.invalidateQueries({ queryKey: ['shift', id] });
                    await qc.invalidateQueries({ queryKey: ['hours'] });
                    toast.success(mode === 'in' ? `Ingeklokt (${geoReason})` : 'Uitgeklokt');
                  } catch (e: any) {
                    toast.error(formatApiError(e));
                  } finally {
                    setBusy(false);
                    setPendingGeo(null);
                  }
                }}
              >
                Toch doorgaan
              </button>
            </div>
          </div>
        </div>
      ) : null}

      {/* Mobile: sticky bottom action bar for primary clock action */}
      {isMobile && (canClockIn || canClockOut) ? (
        <div className="fixed inset-x-0 bottom-0 z-40 border-t bg-white/95 backdrop-blur">
          <div className="mx-auto flex max-w-3xl items-center justify-between gap-3 px-4 py-3">
            <div className="min-w-0">
              <div className="text-xs uppercase tracking-wide text-gray-500">Actie</div>
              <div className="truncate text-sm text-gray-800">
                {canClockIn ? 'Klaar om in te klokken' : 'Klaar om uit te klokken'}
              </div>
            </div>
            <button
              type="button"
              disabled={busy}
              onClick={() => doClock(canClockIn ? 'in' : 'out')}
              className={
                'shrink-0 rounded-xl px-4 py-2 text-sm font-medium text-white ' +
                (busy ? 'bg-gray-400' : 'bg-gray-900 hover:bg-black')
              }
            >
              {canClockIn ? 'Inklokken' : 'Uitklokken'}
            </button>
          </div>
        </div>
      ) : null}

      {/* Spacer so content isn't hidden behind sticky bar */}
      {isMobile && (canClockIn || canClockOut) ? <div className="h-20" /> : null}
    </div>
  );
}
