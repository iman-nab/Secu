import { Button, Card, Badge, Input, Label } from '../../../components/ui';
import { nlFullDate, nlTime } from '../../../utils/datetime';
import { useEffect, useState } from 'react';

function fmt(dt: string) {
  return `${nlFullDate(dt)} ${nlTime(dt)}`;
}

export function ShiftHeaderCard(props: {
  shift: any;
  isAdmin?: boolean;
  busy: boolean;
  myEntry: any;
  canClockIn: boolean;
  canClockOut: boolean;
  doClock: (mode: 'in' | 'out') => void;
  saving?: boolean;
  onQuickAction?: (action: 'copyLink' | 'cancel' | 'duplicateNextWeek' | 'save' | 'setStatus', input?: any) => void | Promise<void>;
  err?: string;
}) {
  const { shift, busy, canClockIn, canClockOut, doClock, err, myEntry, isAdmin, onQuickAction, saving } = props;

  const [editOpen, setEditOpen] = useState(false);
  const st = String(shift?.status ?? '').toUpperCase();
  const isCancelled = st === 'CANCELLED';
  const isCompleted = st === 'COMPLETED';
  const [form, setForm] = useState({
    title: String(shift.title || ''),
    startAt: '',
    endAt: '',
  });
  const [fieldErr, setFieldErr] = useState<{ title?: string; startAt?: string; endAt?: string }>({});

  // Keep form in sync if user navigates between shifts
  useEffect(() => {
    setForm({
      title: String(shift.title || ''),
      startAt: shift.startAt ? toLocalInputValue(String(shift.startAt)) : '',
      endAt: shift.endAt ? toLocalInputValue(String(shift.endAt)) : '',
    });
    setEditOpen(false);
    setFieldErr({});
  }, [shift.id]);

  function toLocalInputValue(iso: string) {
    // datetime-local expects YYYY-MM-DDTHH:mm
    const d = new Date(iso);
    const pad = (n: number) => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
  }

  function fromLocalInputValue(v: string) {
    // Interpret as local time
    const d = new Date(v);
    return d.toISOString();
  }

  async function save() {
    if (isCancelled) return;
    setFieldErr({});
    const nextErr: any = {};
    if (!form.title.trim()) nextErr.title = 'Titel is verplicht';
    if (!form.startAt) nextErr.startAt = 'Start is verplicht';
    if (!form.endAt) nextErr.endAt = 'Eind is verplicht';
    if (form.startAt && form.endAt) {
      const a = new Date(form.startAt).getTime();
      const b = new Date(form.endAt).getTime();
      if (isFinite(a) && isFinite(b) && b <= a) nextErr.endAt = 'Eindtijd moet na starttijd liggen';
    }
    if (Object.keys(nextErr).length) {
      setFieldErr(nextErr);
      return;
    }
    await onQuickAction?.('save', {
      title: form.title.trim(),
      startAt: fromLocalInputValue(form.startAt),
      endAt: fromLocalInputValue(form.endAt),
    });
    setEditOpen(false);
  }

  return (
    <Card className="p-6 space-y-3">
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div>
          <div className="text-xl font-semibold">{shift.title}</div>
          <div className="text-sm text-gray-600">
            {shift.location?.name ? `${shift.location.name} • ` : ''}
            {fmt(shift.startAt)} – {fmt(shift.endAt)}
          </div>
          <div className="mt-2 flex flex-wrap gap-2">
            <Badge>Status: {shift.status}</Badge>
            {shift.requiredWorkers ? <Badge>Benodigd: {shift.requiredWorkers}</Badge> : null}
          </div>

          {/* Quick actions */}
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <Button
              variant="secondary"
              onClick={() => onQuickAction?.('copyLink')}
              title="Kopieer link"
            >
              Kopieer link
            </Button>
            {shift?.location?.latitude && shift?.location?.longitude ? (
              <Button
                variant="secondary"
                onClick={() => {
                  const lat = Number(shift.location.latitude);
                  const lng = Number(shift.location.longitude);
                  const label = encodeURIComponent(shift.location?.name || shift.title || 'Locatie');
                  // Universal maps link
                  const url = `https://www.google.com/maps/search/?api=1&query=${lat},${lng}&query_place_id=${label}`;
                  window.open(url, '_blank');
                }}
                title="Open route in Maps"
              >
                Route
              </Button>
            ) : null}
            {isAdmin ? (
              <>
                <Button
                  variant="secondary"
                  onClick={() => setEditOpen((v) => !v)}
                  title="Bewerk basisgegevens"
                  disabled={isCancelled}
                >
                  {editOpen ? 'Sluiten' : 'Bewerk'}
                </Button>
                {!isCompleted && !isCancelled ? (
                  <Button
                    variant="secondary"
                    onClick={() => onQuickAction?.('setStatus', { status: 'COMPLETED' })}
                    disabled={!!saving}
                    title="Zet deze dienst handmatig op completed"
                  >
                    Markeer completed
                  </Button>
                ) : (
                  <Button
                    variant="secondary"
                    onClick={() => onQuickAction?.('setStatus', { status: 'OPEN' })}
                    disabled={!!saving}
                    title="Heropen deze dienst"
                  >
                    Heropen
                  </Button>
                )}
                <Button
                  variant="secondary"
                  onClick={() => onQuickAction?.('duplicateNextWeek')}
                  disabled={!!saving || isCancelled}
                  title="Maak een kopie voor dezelfde tijd volgende week (als concept)"
                >
                  Dupliceer (volgende week)
                </Button>
                <Button
                  variant="danger"
                  onClick={() => onQuickAction?.('cancel')}
                  disabled={!!saving || isCancelled}
                  title="Annuleer deze dienst"
                >
                  Annuleer
                </Button>
              </>
            ) : null}
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          <Button onClick={() => doClock('in')} disabled={busy || !canClockIn}>
            Inklokken
          </Button>
          <Button variant="secondary" onClick={() => doClock('out')} disabled={busy || !canClockOut}>
            Uitklokken
          </Button>
        </div>
      </div>

      {isAdmin && editOpen ? (
        <div className="rounded-2xl border bg-gray-50 p-4">
          <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
            <div className="md:col-span-1">
              <Label>Titel</Label>
              <Input
                value={form.title}
                onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))}
                placeholder="Bijv. Avondshift"
              />
              {fieldErr.title ? <div className="mt-1 text-xs text-red-600">{fieldErr.title}</div> : null}
            </div>
            <div>
              <Label>Start</Label>
              <Input
                type="datetime-local"
                value={form.startAt}
                onChange={(e) => setForm((f) => ({ ...f, startAt: e.target.value }))}
              />
              {fieldErr.startAt ? <div className="mt-1 text-xs text-red-600">{fieldErr.startAt}</div> : null}
            </div>
            <div>
              <Label>Eind</Label>
              <Input
                type="datetime-local"
                value={form.endAt}
                onChange={(e) => setForm((f) => ({ ...f, endAt: e.target.value }))}
              />
              {fieldErr.endAt ? <div className="mt-1 text-xs text-red-600">{fieldErr.endAt}</div> : null}
            </div>
          </div>
          <div className="mt-3 flex items-center justify-end gap-2">
            <Button variant="secondary" onClick={() => setEditOpen(false)}>
              Annuleer
            </Button>
            <Button onClick={save} disabled={!!saving || isCancelled}>
              {saving ? 'Opslaan…' : 'Opslaan'}
            </Button>
          </div>
        </div>
      ) : null}

      {myEntry ? (
        <div className="text-sm text-gray-700">
          Jouw registratie: {fmt(myEntry.clockInAt)}
          {myEntry.clockOutAt ? ` → ${fmt(myEntry.clockOutAt)} (${myEntry.minutesWorked} min)` : ' (actief)'}
        </div>
      ) : (
        <div className="text-sm text-gray-600">Nog geen tijdregistratie voor jou op deze dienst.</div>
      )}

      {err ? <div className="text-sm text-gray-700">{err}</div> : null}
    </Card>
  );
}
