import { useMutation, useQuery } from '@tanstack/react-query';
import { useMemo, useState } from 'react';
import { Card, Badge, Button } from '../../../components/ui';
import { adminAssignShift, adminUnassignShift, listShifts, reviewShiftRequest } from '../../../api/shifts';
import { listUsers } from '../../../api/users';
import { useToast } from '../../../components/toast';
import { formatApiError } from '../../../api/errorMessages';

export function AdminAssignmentsCard(props: {
  assignees: any[];
  shift: any;
  qc: any;
  id: string | undefined;
  setErr: (s?: string) => void;
  locked?: boolean;
}) {
  const { assignees, qc, id, setErr, shift, locked } = props;
  const toast = useToast();
  const isCompleted = String(shift?.status ?? '') === 'COMPLETED';
  const isCancelled = String(shift?.status ?? '') === 'CANCELLED';
  const isLocked = Boolean(locked) || isCompleted || isCancelled;
  const requiredWorkers = Math.max(1, Number(shift?.requiredWorkers ?? 1));
  const approvedCount = (assignees ?? []).filter((a: any) => a.status === 'APPROVED').length;
  const overPlanned = approvedCount > requiredWorkers;
  const [conflictUserId, setConflictUserId] = useState<string | null>(null);
  const [assignUserId, setAssignUserId] = useState<string>('');
  const [userSearch, setUserSearch] = useState<string>('');

  const { data: usersRes } = useQuery({
    queryKey: ['users', 'assignable', userSearch],
    // Assignments are for workers only; subcontractor accounts should never show up here.
    queryFn: () => listUsers({ page: 1, pageSize: 200, q: userSearch.trim() || undefined, role: 'EMPLOYEE' as any }),
    staleTime: 60_000,
  });

  const workers = useMemo(() => {
    const all = (usersRes as any)?.users ?? [];
    return all
      .filter((u: any) => u.role === 'EMPLOYEE')
      .filter((u: any) => u.isActive !== false)
      .sort((a: any, b: any) => String(a.fullName || a.email).localeCompare(String(b.fullName || b.email), 'nl'));
  }, [usersRes]);

  const assignedUserIds = useMemo(() => new Set((assignees ?? []).map((a: any) => a.userId)), [assignees]);
  const availableWorkers = useMemo(() => workers.filter((u: any) => !assignedUserIds.has(u.id)), [workers, assignedUserIds]);

  const assignM = useMutation({
    mutationFn: async () => adminAssignShift(id!, { userId: assignUserId }),
    onMutate: async () => {
      if (!id || !assignUserId) return;
      await qc.cancelQueries({ queryKey: ['shift', id] });
      const prev = qc.getQueryData(['shift', id]);
      qc.setQueryData(['shift', id], (old: any) => {
        const s = old?.shift;
        if (!s) return old;
        const user = workers.find((u: any) => u.id === assignUserId);
        const next = {
          ...s,
          assignments: [
            ...(s.assignments ?? []),
            {
              id: `temp-${id}-${assignUserId}`,
              userId: assignUserId,
              status: 'APPROVED',
              user: user ? { id: user.id, fullName: user.fullName, email: user.email } : undefined,
            },
          ],
        };
        return { ...old, shift: next };
      });
      setAssignUserId('');
      return { prev } as any;
    },
    onError: (e: any, _v, ctx: any) => {
      if (ctx?.prev) qc.setQueryData(['shift', id], ctx.prev);
      let msg = formatApiError(e) || 'Toewijzen mislukt';
      if (e?.code === 'SHIFT_OVERLAP') {
        msg = 'Overlap: deze medewerker heeft al een andere (goedgekeurde) dienst die overlapt.';
      }
      if (e?.code === 'AVAILABILITY_OVERLAP') {
        msg = 'Niet beschikbaar: de beschikbaarheid van deze medewerker overlapt met dit tijdslot.';
      }
      setErr(msg);
      toast.error(msg);
    },
    onSuccess: async () => {
      toast.success('Toegewezen');
      await qc.invalidateQueries({ queryKey: ['shift', id] });
      await qc.invalidateQueries({ queryKey: ['shift-activity', id] });
      await qc.invalidateQueries({ queryKey: ['shiftsCalendar'] });
    },
  });

  const unassignM = useMutation({
    mutationFn: async (userId: string) => adminUnassignShift(id!, { userId }),
    onMutate: async (userId: string) => {
      if (!id) return;
      await qc.cancelQueries({ queryKey: ['shift', id] });
      const prev = qc.getQueryData(['shift', id]);
      qc.setQueryData(['shift', id], (old: any) => {
        const s = old?.shift;
        if (!s) return old;
        const next = { ...s, assignments: (s.assignments ?? []).filter((a: any) => a.userId !== userId) };
        return { ...old, shift: next };
      });
      return { prev } as any;
    },
    onError: (e: any, _v, ctx: any) => {
      if (ctx?.prev) qc.setQueryData(['shift', id], ctx.prev);
      const msg = formatApiError(e) || 'Ontkoppelen mislukt';
      setErr(msg);
      toast.error(msg);
    },
    onSuccess: async () => {
      toast.success('Ontkoppeld');
      await qc.invalidateQueries({ queryKey: ['shift', id] });
      await qc.invalidateQueries({ queryKey: ['shift-activity', id] });
      await qc.invalidateQueries({ queryKey: ['shiftsCalendar'] });
    },
  });

  const reviewM = useMutation({
    mutationFn: (input: { userId: string; approve: boolean }) => reviewShiftRequest(id!, input),
    onMutate: async (input) => {
      if (!id) return;
      await qc.cancelQueries({ queryKey: ['shift', id] });
      const prev = qc.getQueryData(['shift', id]);

      qc.setQueryData(['shift', id], (old: any) => {
        const s = old?.shift;
        if (!s) return old;

        const nextAssignments = (s.assignments ?? []).map((a: any) =>
          a.userId === input.userId ? { ...a, status: input.approve ? 'APPROVED' : 'REJECTED' } : a,
        );

        // Best-effort status recalculation. Server remains the source of truth.
        const approvedCount = nextAssignments.filter((a: any) => a.status === 'APPROVED').length;
        const required = Number(s.requiredWorkers ?? 1);
        const nextStatus = approvedCount >= required ? 'ASSIGNED' : 'OPEN';

        return { ...old, shift: { ...s, assignments: nextAssignments, status: nextStatus } };
      });

      return { prev } as any;
    },
    onError: (e: any, _v, ctx: any) => {
      if (ctx?.prev) qc.setQueryData(['shift', id], ctx.prev);
      const msg = formatApiError(e) || 'Actie mislukt';
      setErr(msg);
      toast.error(msg);
    },
    onSuccess: async (_res, input) => {
      toast.success(input.approve ? 'Goedgekeurd' : 'Afgewezen');
      await qc.invalidateQueries({ queryKey: ['shift', id] });
      await qc.invalidateQueries({ queryKey: ['shift-activity', id] });
      await qc.invalidateQueries({ queryKey: ['shiftsCalendar'] });
    },
  });

  async function confirmNoOverlap(userId: string) {
    try {
      const start = new Date(shift.startAt);
      const end = new Date(shift.endAt);
      // Search a bit wider around the shift
      const rangeStart = new Date(start);
      rangeStart.setHours(0, 0, 0, 0);
      const rangeEnd = new Date(end);
      rangeEnd.setHours(23, 59, 59, 999);
      const res: any = await listShifts({ start: rangeStart.toISOString(), end: rangeEnd.toISOString() });
      const all = (res?.shifts ?? []) as any[];
      const overlaps = all
        .filter((s) => s.id !== shift.id)
        .filter((s) => s.status !== 'CANCELLED')
        .filter((s) => (s.assignments ?? []).some((a: any) => a.userId === userId && a.status !== 'REJECTED'))
        .filter((s) => {
          const a1 = new Date(s.startAt).getTime();
          const b1 = new Date(s.endAt).getTime();
          const a2 = start.getTime();
          const b2 = end.getTime();
          return Math.max(a1, a2) < Math.min(b1, b2);
        });
      if (!overlaps.length) return true;

      const first = overlaps[0];
      const txt = `${first.title} (${new Date(first.startAt).toLocaleTimeString('nl-NL', { hour: '2-digit', minute: '2-digit' })}–${new Date(first.endAt).toLocaleTimeString('nl-NL', { hour: '2-digit', minute: '2-digit' })})`;
      return window.confirm(
        `⚠️ Overlap gedetecteerd. Deze medewerker heeft al een andere dienst die overlapt met dit tijdslot:\n\n${txt}\n\nWil je toch goedkeuren?`,
      );
    } catch {
      // If we can't check, don't block
      return true;
    }
  }

  const overlapRange = useMemo(() => {
    const start = new Date(shift.startAt);
    const end = new Date(shift.endAt);
    const rangeStart = new Date(start);
    rangeStart.setHours(0, 0, 0, 0);
    const rangeEnd = new Date(end);
    rangeEnd.setHours(23, 59, 59, 999);
    return { start: rangeStart.toISOString(), end: rangeEnd.toISOString() };
  }, [shift.startAt, shift.endAt]);

  // Preload overlaps so admins see warnings *before* clicking Approve.
  const { data: overlapRes } = useQuery({
    queryKey: ['shift-overlaps', shift.id, overlapRange.start, overlapRange.end],
    queryFn: () => listShifts(overlapRange as any),
    enabled: assignees.length > 0,
    staleTime: 15_000,
  });

  const overlapsByUserId = useMemo(() => {
    const start = new Date(shift.startAt).getTime();
    const end = new Date(shift.endAt).getTime();
    const all = ((overlapRes as any)?.shifts ?? []) as any[];
    const map = new Map<string, any[]>();
    for (const a of assignees) map.set(a.userId, []);
    for (const s of all) {
      if (!s || s.id === shift.id) continue;
      if (s.status === 'CANCELLED') continue;
      const a1 = new Date(s.startAt).getTime();
      const b1 = new Date(s.endAt).getTime();
      if (Math.max(a1, start) >= Math.min(b1, end)) continue;
      for (const asn of s.assignments ?? []) {
        if (!asn?.userId || asn.status === 'REJECTED') continue;
        if (!map.has(asn.userId)) continue;
        map.get(asn.userId)!.push(s);
      }
    }
    return map;
  }, [assignees, overlapRes, shift.id, shift.startAt, shift.endAt]);

  const conflictUser = conflictUserId ? assignees.find((a) => a.userId === conflictUserId) : null;
  const conflictList = conflictUserId ? overlapsByUserId.get(conflictUserId) ?? [] : [];

  return (
    <Card className="p-6 space-y-3">
      <div>
        <div className="text-lg font-semibold">Assignments</div>
        <div className="text-sm text-gray-600">Open dienst reacties / toewijzingen.</div>
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <Badge>
          Benodigd: {requiredWorkers}
        </Badge>
        <Badge className={overPlanned ? 'bg-amber-50 border-amber-200 text-amber-900' : ''}>
          Toegewezen: {approvedCount}
        </Badge>
        {overPlanned ? (
          <div className="text-sm text-amber-900">
            ⚠ Er zijn meer medewerkers ingepland dan nodig.
          </div>
        ) : null}
      </div>

      <div className="rounded-xl border bg-white p-3">
        <div className="text-sm font-medium">Direct toewijzen</div>
        <div className="mt-2 flex flex-col gap-2 sm:flex-row sm:items-end">
          <div className="flex-1">
            <div className="text-xs text-gray-600">Medewerker / onderaannemer</div>
            <input
              className="mt-1 w-full rounded border px-3 py-2 text-sm"
              value={userSearch}
              onChange={(e) => setUserSearch(e.target.value)}
              placeholder="Zoek op naam of e-mail…"
            />
            <select
              className="mt-1 w-full rounded border px-3 py-2 text-sm"
              value={assignUserId}
              onChange={(e) => setAssignUserId(e.target.value)}
            >
              <option value="">Kies medewerker…</option>
              {availableWorkers.map((u: any) => (
                <option key={u.id} value={u.id}>
                  {u.fullName || u.email}
                </option>
              ))}
            </select>
          </div>
          <Button
            onClick={async () => {
              if (!assignUserId) return;
              const ok = await confirmNoOverlap(assignUserId);
              if (!ok) return;
              assignM.mutate();
            }}
            disabled={!assignUserId || assignM.isPending || isLocked}
            title={isLocked ? 'Dienst is locked: toewijzen is geblokkeerd' : (!availableWorkers.length ? 'Geen beschikbare medewerkers' : '')}
          >
            Toewijzen
          </Button>
        </div>
      </div>

      {isLocked ? (
        <div className="rounded-xl border border-amber-200 bg-amber-50 p-3 text-sm text-amber-900">
          Deze dienst is <span className="font-semibold">{isCancelled ? 'CANCELLED' : 'COMPLETED'}</span>. Toewijzen/ontkoppelen van medewerkers is niet toegestaan.
        </div>
      ) : null}

      {assignees.length === 0 ? (
        <div className="text-sm text-gray-600">Geen assignments.</div>
      ) : (
        <div className="overflow-auto">
          <table className="min-w-full text-sm">
            <thead>
              <tr className="text-left text-gray-600">
                <th className="py-2 pr-4">Werknemer</th>
                <th className="py-2 pr-4">Status</th>
                <th className="py-2 pr-4">Acties</th>
              </tr>
            </thead>
            <tbody>
              {assignees.map((a: any) => (
                <tr key={a.id} className="border-t">
                  <td className="py-2 pr-4">
                    {a.user?.fullName || a.user?.email}
                  </td>
                  <td className="py-2 pr-4">
                    <div className="flex flex-wrap items-center gap-2">
                      <Badge>{a.status}</Badge>
                      {(overlapsByUserId.get(a.userId)?.length ?? 0) > 0 ? (
                        <button
                          type="button"
                          className="text-left"
                          onClick={() => setConflictUserId(a.userId)}
                          title="Deze medewerker heeft een overlappende dienst"
                        >
                          <Badge className="border-red-200 bg-red-50 text-red-800">Overlap</Badge>
                        </button>
                      ) : null}
                    </div>
                  </td>
                  <td className="py-2 pr-4">
                    {a.status === 'REQUESTED' ? (
                      <div className="flex gap-2">
                        <Button
                          onClick={async () => {
                            const ok = await confirmNoOverlap(a.userId);
                            if (ok) reviewM.mutate({ userId: a.userId, approve: true });
                          }}
                          disabled={reviewM.isPending || isLocked}
                        >
                          Approve
                        </Button>
                        <Button
                          variant="secondary"
                          onClick={() => reviewM.mutate({ userId: a.userId, approve: false })}
                          disabled={reviewM.isPending || isLocked}
                        >
                          Reject
                        </Button>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-gray-500">—</span>
                        {a.status === 'APPROVED' ? (
                          <Button
                            variant="secondary"
                            onClick={() => {
                              const ok = window.confirm('Medewerker ontkoppelen van deze dienst?');
                              if (ok) unassignM.mutate(a.userId);
                            }}
                            disabled={unassignM.isPending || isLocked}
                            title={isLocked ? 'Dienst is locked: ontkoppelen is geblokkeerd' : ''}
                          >
                            Ontkoppelen
                          </Button>
                        ) : null}
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {conflictUserId && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4"
          role="dialog"
          aria-modal="true"
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) setConflictUserId(null);
          }}
        >
          <Card className="w-full max-w-xl p-5">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <div className="text-lg font-semibold">Overlap gevonden</div>
                <div className="mt-1 text-sm text-gray-600">
                  {conflictUser?.user?.fullName || conflictUser?.user?.email}
                </div>
              </div>
              <Button variant="secondary" onClick={() => setConflictUserId(null)}>
                Sluit
              </Button>
            </div>

            <div className="mt-4 space-y-2">
              {conflictList.map((s: any) => (
                <div key={s.id} className="rounded-xl border bg-white p-3">
                  <div className="font-semibold truncate">{s.title}</div>
                  <div className="mt-1 text-sm text-gray-600">
                    {new Date(s.startAt).toLocaleString('nl-NL', { dateStyle: 'medium', timeStyle: 'short' })} –{' '}
                    {new Date(s.endAt).toLocaleString('nl-NL', { dateStyle: 'medium', timeStyle: 'short' })}
                  </div>
                  <div className="mt-2 flex items-center justify-end">
                    <Button onClick={() => (window.location.href = `/diensten/${s.id}`)}>Ga naar dienst</Button>
                  </div>
                </div>
              ))}
              {!conflictList.length && <div className="text-sm text-gray-600">Geen details beschikbaar.</div>}
            </div>
          </Card>
        </div>
      )}
    </Card>
  );
}
