import { Card, Badge, Button } from '../../../components/ui';
import { nlFullDate, nlTime } from '../../../utils/datetime';

function fmt(dt: string) {
  return `${nlFullDate(dt)} ${nlTime(dt)}`;
}

export function ClientNotesCard(props: {
  shift: any;
  me: any;
  pinNoteM: any;
}) {
  const { shift, me, pinNoteM } = props;
  const notes = (shift.notes ?? []) as any[];

  return (
    <Card className="p-6 space-y-3">
      <div>
        <div className="text-lg font-semibold">Notities</div>
        <div className="text-sm text-gray-600">Notities voor deze dienst.</div>
      </div>

      {notes.length === 0 ? (
        <div className="text-sm text-gray-600">Geen notities.</div>
      ) : (
        <div className="space-y-3">
          {notes.map((n) => (
            <div key={n.id} className="rounded-xl border border-gray-100 p-4">
              <div className="flex flex-wrap items-start justify-between gap-2">
                <div className="space-y-1">
                  <div className="flex flex-wrap gap-2">
                    {n.isPinned ? <Badge className="bg-yellow-50 border-yellow-200 text-yellow-900">Pinned</Badge> : null}
                    {n.visibleToEmployees ? <Badge>Visible to employees</Badge> : <Badge className="bg-gray-100">Admin/Client only</Badge>}
                  </div>
                  <div className="text-xs text-gray-500">
                    {n.author ? `${n.author.fullName} • ` : ''}{fmt(n.createdAt)}
                  </div>
                </div>

                {me?.role === 'ADMIN' && (
                  <Button
                    variant="secondary"
                    onClick={() => pinNoteM.mutate({ noteId: n.id, pinned: !n.isPinned })}
                    disabled={pinNoteM.isPending}
                  >
                    {n.isPinned ? 'Unpin' : 'Pin'}
                  </Button>
                )}
              </div>

              <div className="mt-2 text-sm whitespace-pre-wrap">{n.content}</div>
            </div>
          ))}
        </div>
      )}
    </Card>
  );
}
