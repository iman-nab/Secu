import { useMemo, useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { Button, Card, Input, Label, Badge } from '../../../components/ui';
import { addShiftExtraCost, deleteShiftExtraCost, updateShiftRates } from '../../../api/shifts';

function fmtEuro(cents: number) {
  const v = (cents ?? 0) / 100;
  return new Intl.NumberFormat('nl-NL', { style: 'currency', currency: 'EUR' }).format(v);
}

function parseEuroToCents(s: string) {
  const n = Number(String(s).replace(',', '.'));
  if (!Number.isFinite(n) || n < 0) return null;
  return Math.round(n * 100);
}

export function RatesAndCostsCard(props: {
  shift: any;
  me: any;
  qc: any;
  id: string;
  setErr: (s?: string) => void;
  locked?: boolean;
}) {
  const { shift, me, qc, id, setErr, locked } = props;

  const isAdmin = me?.role === 'ADMIN';
  const isLocked = Boolean(locked) || String(shift?.status ?? '') === 'CANCELLED' || String(shift?.status ?? '') === 'COMPLETED';
  const canSeeWorkerRate = me?.role === 'ADMIN' || me?.role === 'SUBCONTRACTOR' || me?.role === 'EMPLOYEE';
  const canSeeEmployerRate = me?.role === 'ADMIN' || me?.role === 'CLIENT';

  const [employerRate, setEmployerRate] = useState(() => String(((shift?.employerRateCents ?? 0) / 100).toFixed(2)));
  const [workerRate, setWorkerRate] = useState(() => String(((shift?.workerRateCents ?? 0) / 100).toFixed(2)));

  const costs = (shift?.extraCosts ?? []) as any[];
  const totalExtraCosts = useMemo(() => costs.reduce((sum, c) => sum + (c.amountCents ?? 0), 0), [costs]);

  const ratesM = useMutation({
    mutationFn: async () => {
      const emp = parseEuroToCents(employerRate);
      const worker = parseEuroToCents(workerRate);
      if (emp === null || worker === null) throw { error: 'Ongeldig tarief (gebruik bijv. 25.00)' };
      return updateShiftRates(id, { employerRateCents: emp, workerRateCents: worker });
    },
    onSuccess: async () => {
      await qc.invalidateQueries({ queryKey: ['shift', id] });
      setErr('Tarieven opgeslagen');
    },
    onError: (e: any) => setErr(e?.error ?? 'Opslaan mislukt'),
  });

  const addCostM = useMutation({
    mutationFn: async (input: { description: string; amountCents: number }) => addShiftExtraCost(id, input),
    onSuccess: async () => {
      await qc.invalidateQueries({ queryKey: ['shift', id] });
      setErr('Extra kosten toegevoegd');
    },
    onError: (e: any) => setErr(e?.error ?? 'Toevoegen mislukt'),
  });

  const delCostM = useMutation({
    mutationFn: async (costId: string) => deleteShiftExtraCost(id, costId),
    onSuccess: async () => {
      await qc.invalidateQueries({ queryKey: ['shift', id] });
      setErr('Extra kosten verwijderd');
    },
    onError: (e: any) => setErr(e?.error ?? 'Verwijderen mislukt'),
  });

  const [desc, setDesc] = useState('');
  const [amount, setAmount] = useState('');

  const add = () => {
    const cents = parseEuroToCents(amount);
    if (!desc.trim()) return setErr('Omschrijving is verplicht');
    if (cents === null) return setErr('Bedrag is ongeldig (gebruik bijv. 12.50)');
    addCostM.mutate({ description: desc.trim(), amountCents: cents });
    setDesc('');
    setAmount('');
  };

  // Show this card if any rate is visible OR there are extra costs.
  if (!isAdmin && !canSeeWorkerRate && !canSeeEmployerRate && costs.length === 0) return null;

  return (
    <Card className="p-6 space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="text-lg font-semibold">Tarieven & extra kosten</div>
        <div className="flex flex-wrap gap-2">
          {canSeeWorkerRate ? <Badge>Werknemer tarief: {fmtEuro(shift?.workerRateCents ?? 0)}/uur</Badge> : null}
          {canSeeEmployerRate ? <Badge>Werkgever tarief: {fmtEuro(shift?.employerRateCents ?? 0)}/uur</Badge> : null}
        </div>
      </div>

      {isAdmin ? (
        <div className="grid gap-3 md:grid-cols-3">
          <div>
            <Label>Werkgever tarief (€/uur)</Label>
            <Input value={employerRate} onChange={(e: any) => setEmployerRate(e.target.value)} disabled={isLocked} />
          </div>
          <div>
            <Label>Werknemer tarief (€/uur)</Label>
            <Input value={workerRate} onChange={(e: any) => setWorkerRate(e.target.value)} disabled={isLocked} />
          </div>
          <div className="flex items-end">
            <Button onClick={() => ratesM.mutate()} disabled={ratesM.isPending || isLocked}>
              Opslaan
            </Button>
          </div>
        </div>
      ) : null}

      {/* Extra costs: visible for everyone who can see the shift; only admin can add/remove */}
      <div className="space-y-2">
        <div className="text-sm font-medium">Extra kosten</div>

        {isAdmin ? (
          <div className="grid gap-2 md:grid-cols-3">
            <div>
              <Label>Omschrijving</Label>
              <Input value={desc} onChange={(e: any) => setDesc(e.target.value)} placeholder="Bijv. parkeerkosten" disabled={isLocked} />
            </div>
            <div>
              <Label>Bedrag (€)</Label>
              <Input value={amount} onChange={(e: any) => setAmount(e.target.value)} placeholder="Bijv. 12.50" disabled={isLocked} />
            </div>
            <div className="flex items-end">
              <Button onClick={add} disabled={addCostM.isPending || isLocked}>
                Toevoegen
              </Button>
            </div>
          </div>
        ) : null}

        {costs.length ? (
          <div className="mt-2 space-y-2">
            {costs.map((c) => (
              <div key={c.id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl border p-3">
                <div className="text-sm">
                  <div className="font-medium">{c.description}</div>
                  <div className="text-gray-600">{fmtEuro(c.amountCents)}</div>
                  {c.createdBy ? (
                    <div className="mt-1 text-xs text-gray-500">
                      Toegevoegd door: {c.createdBy.fullName || c.createdBy.email}
                    </div>
                  ) : null}
                </div>
                {isAdmin ? (
                  <Button variant="secondary" onClick={() => delCostM.mutate(c.id)} disabled={delCostM.isPending || isLocked}>
                    Verwijderen
                  </Button>
                ) : null}
              </div>
            ))}
            <div className="text-sm text-gray-700">
              Totaal extra kosten: <b>{fmtEuro(totalExtraCosts)}</b>
            </div>
          </div>
        ) : (
          <div className="text-sm text-gray-600">Nog geen extra kosten.</div>
        )}
      </div>

      {!isAdmin && canSeeWorkerRate ? (
        <div className="text-sm text-gray-700">
          Jouw tarief voor deze dienst: <b>{fmtEuro(shift?.workerRateCents ?? 0)}/uur</b>
        </div>
      ) : null}
      {!isAdmin && canSeeEmployerRate ? (
        <div className="text-sm text-gray-700">
          Tarief voor deze dienst: <b>{fmtEuro(shift?.employerRateCents ?? 0)}/uur</b>
        </div>
      ) : null}
    </Card>
  );
}
