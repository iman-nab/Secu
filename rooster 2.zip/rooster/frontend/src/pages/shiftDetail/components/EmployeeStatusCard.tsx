import { Card, Badge } from '../../../components/ui';
import { nlFullDate, nlTime } from '../../../utils/datetime';

function fmt(dt: string) {
  return `${nlFullDate(dt)} ${nlTime(dt)}`;
}

export function EmployeeStatusCard(props: { me: any; myEntry: any; nowTick: number }) {
  const { me, myEntry, nowTick } = props;

  if (!me) return null;

  const active = myEntry && !myEntry.clockOutAt;
  const now = new Date(nowTick);
  const mins = active ? Math.max(0, Math.round((now.getTime() - new Date(myEntry.clockInAt).getTime()) / 60000)) : null;

  return (
    <Card className="p-6 space-y-2">
      <div className="text-lg font-semibold">Status</div>
      {active ? (
        <>
          <Badge className="bg-green-50 border-green-200 text-green-800">Actief inge-klokt</Badge>
          <div className="text-sm text-gray-700">Sinds: {fmt(myEntry.clockInAt)}</div>
          <div className="text-sm text-gray-700">Tijd nu: {mins} min</div>
        </>
      ) : myEntry ? (
        <>
          <Badge>Afgerond</Badge>
          <div className="text-sm text-gray-700">
            {fmt(myEntry.clockInAt)} → {myEntry.clockOutAt ? fmt(myEntry.clockOutAt) : '—'} ({myEntry.minutesWorked} min)
          </div>
        </>
      ) : (
        <div className="text-sm text-gray-600">Geen actieve tijdregistratie.</div>
      )}
    </Card>
  );
}
