import { Card, Badge, Button } from '../../../components/ui';
import { nlFullDate, nlTime } from '../../../utils/datetime';
import { normalizeAction } from '../../../utils/auditHumanize';

// Some audit payloads can contain BigInt (e.g. from Prisma), which breaks JSON.stringify.
function safeStringify(v: any) {
  try {
    return JSON.stringify(v ?? null, (_k, val) => (typeof val === 'bigint' ? val.toString() : val), 2);
  } catch {
    try {
      return String(v);
    } catch {
      return '[unserializable]';
    }
  }
}

function fmt(dt: string) {
  return `${nlFullDate(dt)} ${nlTime(dt)}`;
}

function eur(cents: any) {
  const n = Number(cents ?? 0);
  if (!Number.isFinite(n)) return String(cents ?? '—');
  return (n / 100).toLocaleString('nl-NL', { style: 'currency', currency: 'EUR' });
}

function actionLabel(action: string) {
  const a = normalizeAction(action);
  const map: Record<string, string> = {
    SHIFT_CREATE: 'Dienst aangemaakt',
    SHIFT_UPDATE: 'Dienst aangepast',
    SHIFT_DELETE: 'Dienst verwijderd',
    SHIFT_CREATE_BULK: 'Bulk diensten aangemaakt',
    SHIFT_ASSIGN: 'Medewerker toegewezen',
    SHIFT_UNASSIGN: 'Medewerker ontkoppeld',
    OPEN_SHIFT_APPROVE: 'Open dienst goedgekeurd',
    OPEN_SHIFT_REJECT: 'Open dienst geweigerd',
    CLOCK_IN: 'Ingeklokt',
    CLOCK_OUT: 'Uitgeklokt',
    ADMIN_CLOCK_IN: 'Admin klokactie (in)',
    ADMIN_CLOCK_OUT: 'Admin klokactie (uit)',
    TIMEENTRY_RESET: 'Tijdregistratie gereset',
    TIMEENTRY_CORRECT: 'Tijdregistratie gecorrigeerd',
    NOTE_PIN: 'Notitie gepind',
    NOTE_UNPIN: 'Notitie ontpind',
    SHIFT_RATES_UPDATE: 'Tarieven aangepast',
    SHIFT_EXTRA_COST_ADD: 'Extra kosten toegevoegd',
    SHIFT_EXTRA_COST_UPDATE: 'Extra kosten aangepast',
    SHIFT_EXTRA_COST_DELETE: 'Extra kosten verwijderd',
  };
  if (map[a]) return map[a];
  return a
    .split('_')
    .filter(Boolean)
    .map((p) => p.charAt(0) + p.slice(1).toLowerCase())
    .join(' ');
}

function statusLabel(s: any) {
  const v = String(s ?? '').toUpperCase();
  const map: Record<string, string> = {
    OPEN: 'Open',
    ASSIGNED: 'Toegewezen',
    COMPLETED: 'Completed',
    CANCELLED: 'Geannuleerd',
    DRAFT: 'Open',
  };
  return map[v] ?? String(s ?? '—');
}

function fieldLabel(key: string) {
  const k = String(key);
  const map: Record<string, string> = {
    title: 'Naam',
    description: 'Omschrijving',
    startAt: 'Start',
    endAt: 'Einde',
    status: 'Status',
    locationId: 'Locatie',
    clientId: 'Klant',
    requiredWorkers: 'Benodigd personeel',
    requiredPassColor: 'Kleurpas',
    workerRateCents: 'Uitbetaling tarief',
    employerRateCents: 'Facturatie tarief',
    amountCents: 'Bedrag',
    descriptionText: 'Omschrijving',
    description_: 'Omschrijving',
  };
  if (map[k]) return map[k];
  // Nested keys, take the last segment.
  const last = k.split('.').slice(-1)[0];
  if (map[last]) return map[last];
  return last;
}

function formatValue(key: string, v: any) {
  const k = String(key);
  if (k.toLowerCase().includes('ratecents') || k.toLowerCase().endsWith('amountcents') || k.toLowerCase().endsWith('amountcents') || k.toLowerCase().endsWith('amountcents') || k.toLowerCase().endsWith('amountcents')) {
    return eur(v);
  }
  if (k.toLowerCase().endsWith('amountcents') || k.toLowerCase().endsWith('amountcents') || k.toLowerCase().endsWith('amountcents')) {
    return eur(v);
  }
  if (k.toLowerCase().endsWith('amountcents') || k.toLowerCase().endsWith('amountcents')) {
    return eur(v);
  }
  if (k.toLowerCase().includes('amountcents') || k.toLowerCase().includes('amount')) {
    if (String(k).toLowerCase().includes('cents')) return eur(v);
  }
  if (k.toLowerCase().includes('at') && typeof v === 'string' && v.includes('T')) {
    try {
      return fmt(v);
    } catch {
      return String(v ?? '—');
    }
  }
  if (k.endsWith('status')) return statusLabel(v);
  return String(v ?? '—');
}

function actorName(l: any) {
  // Some endpoints may not include the actor relation (or the user could be deleted).
  // Always show *something* so admins can identify who did what.
  return l?.actor?.fullName || l?.actor?.email || l?.actorId || 'Onbekend';
}

function summarizeLog(l: any, changes: Array<{ key: string; from: any; to: any }>) {
  const a = normalizeAction(l?.action);
  const who = actorName(l);

  if (a === 'SHIFT_RATES_UPDATE') {
    const worker = changes.find((c) => c.key.endsWith('workerRateCents'));
    const employer = changes.find((c) => c.key.endsWith('employerRateCents'));
    const parts: string[] = [];
    if (worker) parts.push(`${who} heeft het uitbetalingstarief aangepast van ${eur(worker.from)} naar ${eur(worker.to)}.`);
    if (employer) parts.push(`${who} heeft het facturatietarief aangepast van ${eur(employer.from)} naar ${eur(employer.to)}.`);
    return parts.length ? parts.join(' ') : `${who} heeft tarieven aangepast.`;
  }

  if (a === 'SHIFT_EXTRA_COST_ADD') {
    const desc = (l?.after?.description ?? l?.after?.descriptionText ?? l?.after?.name ?? '') as any;
    const amt = l?.after?.amountCents;
    if (desc || amt !== undefined) {
      return `${who} heeft extra kosten toegevoegd: ${String(desc || '—')} (${eur(amt)}).`;
    }
    return `${who} heeft extra kosten toegevoegd.`;
  }

  if (a === 'SHIFT_EXTRA_COST_UPDATE') {
    const amount = changes.find((c) => c.key.endsWith('amountCents'));
    const desc = changes.find((c) => c.key.endsWith('description'));
    const parts: string[] = [];
    if (desc) parts.push(`omschrijving van “${String(desc.from ?? '—')}” naar “${String(desc.to ?? '—')}”`);
    if (amount) parts.push(`bedrag van ${eur(amount.from)} naar ${eur(amount.to)}`);
    return parts.length ? `${who} heeft extra kosten aangepast (${parts.join(', ')}).` : `${who} heeft extra kosten aangepast.`;
  }

  if (a === 'SHIFT_EXTRA_COST_DELETE') {
    const desc = l?.before?.description ?? l?.before?.descriptionText ?? '';
    const amt = l?.before?.amountCents;
    if (desc || amt !== undefined) {
      return `${who} heeft extra kosten verwijderd: ${String(desc || '—')} (${eur(amt)}).`;
    }
    return `${who} heeft extra kosten verwijderd.`;
  }

  if (a === 'SHIFT_UPDATE') {
    const status = changes.find((c) => c.key.endsWith('status'));
    if (status) return `${who} heeft de status aangepast van ${statusLabel(status.from)} naar ${statusLabel(status.to)}.`;
    const title = changes.find((c) => c.key.endsWith('title'));
    if (title) return `${who} heeft de naam aangepast van “${String(title.from ?? '—')}” naar “${String(title.to ?? '—')}”.`;
    if (changes.length) return `${who} heeft dienstgegevens aangepast.`;
  }

  if (a === 'SHIFT_ASSIGN') {
    const count = Array.isArray(l?.after?.userIds) ? l.after.userIds.length : l?.after?.userId ? 1 : undefined;
    return `${who} heeft ${count ?? 'één of meer'} medewerker(s) toegewezen.`;
  }

  if (a === 'SHIFT_UNASSIGN') {
    const count = Array.isArray(l?.after?.userIds) ? l.after.userIds.length : l?.after?.userId ? 1 : undefined;
    return `${who} heeft ${count ?? 'één of meer'} medewerker(s) ontkoppeld.`;
  }

  if (a === 'CLOCK_IN') return `${who} heeft inge-klokt.`;
  if (a === 'CLOCK_OUT') return `${who} heeft uitge-klokt.`;
  if (a === 'ADMIN_CLOCK_IN') return `${who} heeft een admin clock-in gedaan.`;
  if (a === 'ADMIN_CLOCK_OUT') return `${who} heeft een admin clock-out gedaan.`;

  return `${who}: ${actionLabel(a)}`;
}

function isPlainObject(v: any) {
  return !!v && typeof v === 'object' && !Array.isArray(v);
}

function flatten(obj: any, prefix = '', out: Record<string, any> = {}) {
  if (!isPlainObject(obj)) return out;
  for (const [k, v] of Object.entries(obj)) {
    const key = prefix ? `${prefix}.${k}` : k;
    if (isPlainObject(v)) {
      flatten(v, key, out);
    } else if (Array.isArray(v)) {
      out[key] = `(${v.length} items)`;
    } else {
      out[key] = v;
    }
  }
  return out;
}

function diff(before: any, after: any) {
  const b = isPlainObject(before) ? flatten(before) : {};
  const a = isPlainObject(after) ? flatten(after) : {};
  const keys = Array.from(new Set([...Object.keys(b), ...Object.keys(a)])).sort();
  const changes: Array<{ key: string; from: any; to: any }> = [];
  for (const key of keys) {
    const from = b[key];
    const to = a[key];
    if (from === undefined && to === undefined) continue;
    if (safeStringify(from) === safeStringify(to)) continue;
    changes.push({ key, from, to });
  }
  return changes;
}

export function AdminActivityCard(props: {
  activityLoading: boolean;
  activityItems: any[];
  activityImportantOnly: boolean;
  setActivityImportantOnly: (v: boolean) => void;
  activityExpanded: Record<string, boolean>;
  setActivityExpanded: (v: any) => void;
  page: number;
  pageSize: number;
  totalCount?: number;
  setPage: (n: number) => void;
  setPageSize: (n: number) => void;
}) {
  const { activityLoading, activityItems, activityImportantOnly, setActivityImportantOnly, activityExpanded, setActivityExpanded, page, pageSize, totalCount, setPage, setPageSize } = props;

  const maxPage = totalCount ? Math.max(1, Math.ceil(totalCount / pageSize)) : undefined;
  const canPrev = page > 1;
  const canNext = maxPage ? page < maxPage : activityItems.length === pageSize;

  return (
    <Card className="p-6 space-y-3">
      <div className="flex items-start justify-between gap-2">
        <div>
          <div className="text-lg font-semibold">Activiteit</div>
          <div className="text-sm text-gray-600">Leesbare audit trail voor deze dienst.</div>
        </div>
        <div className="flex flex-wrap items-center justify-end gap-2">
          <select
            className="rounded-xl border px-3 py-2 text-sm"
            value={pageSize}
            onChange={(e) => {
              setPage(1);
              setPageSize(Number(e.target.value) || 25);
            }}
            title="Items per pagina"
          >
            <option value={10}>10</option>
            <option value={25}>25</option>
            <option value={50}>50</option>
            <option value={100}>100</option>
          </select>
          <Button variant="outline" onClick={() => setPage(Math.max(1, page - 1))} disabled={!canPrev}>
            Vorige
          </Button>
          <div className="text-sm text-gray-700">
            Pagina <span className="font-semibold">{page}</span>
            {maxPage ? <> / <span className="font-semibold">{maxPage}</span></> : null}
          </div>
          <Button variant="outline" onClick={() => setPage(page + 1)} disabled={!canNext}>
            Volgende
          </Button>
          <Button variant="secondary" onClick={() => setActivityImportantOnly(!activityImportantOnly)}>
            {activityImportantOnly ? 'Toon alles' : 'Alleen belangrijk'}
          </Button>
        </div>
      </div>

      {activityLoading ? (
        <div className="text-sm text-gray-600">Laden…</div>
      ) : activityItems.length === 0 ? (
        <div className="text-sm text-gray-600">Geen activiteit.</div>
      ) : (
        <div className="space-y-2">
          {activityItems.map((l: any) => {
            const expanded = !!activityExpanded[l.id];
            const changes = diff(l.before, l.after);
            const hasDetails = changes.length > 0 || l.before || l.after;

            const headline = summarizeLog(l, changes);
            return (
              <div key={l.id} className="rounded-xl border border-gray-100 p-3">
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <Badge>{actionLabel(l.action)}</Badge>
                      <div className="text-xs text-gray-500">{fmt(l.createdAt)}</div>
                      <div className="text-xs text-gray-700">Door: {actorName(l)}</div>
                    </div>
                    <div className="mt-2 text-sm text-gray-900 font-medium">{headline}</div>

                    {changes.length > 0 ? (
                      <div className="mt-2 text-xs text-gray-700">
                        {changes.slice(0, expanded ? 50 : 4).map((c) => (
                          <div key={c.key} className="break-words">
                            <span className="font-medium">{fieldLabel(c.key)}</span>: {formatValue(c.key, c.from)} → {formatValue(c.key, c.to)}
                          </div>
                        ))}
                        {!expanded && changes.length > 4 ? <div className="text-gray-500 mt-1">+{changes.length - 4} meer…</div> : null}
                      </div>
                    ) : null}
                  </div>

                  {hasDetails ? (
                    <div className="flex items-center gap-2">
                      <Button
                        variant="secondary"
                        onClick={() => setActivityExpanded({ ...activityExpanded, [l.id]: !expanded })}
                      >
                        {expanded ? 'Verberg' : 'Details'}
                      </Button>
                      <Button
                        variant="secondary"
                        onClick={async () => {
                          try {
                          const txt = safeStringify({ before: l.before, after: l.after });
                          await navigator.clipboard.writeText(txt);
                          } catch {
                            // ignore
                          }
                        }}
                        title="Kopieer raw JSON"
                      >
                        Copy JSON
                      </Button>
                    </div>
                  ) : null}
                </div>

                {expanded ? (
                  <pre className="mt-3 max-h-56 overflow-auto rounded-lg bg-gray-50 p-2 text-xs">
                    {safeStringify({ before: l.before, after: l.after })}
                  </pre>
                ) : null}
              </div>
            );
          })}
        </div>
      )}
    </Card>
  );
}
