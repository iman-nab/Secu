import { useEffect, useMemo, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Button, Card, ErrorBanner, Input, Label, SuccessBanner } from '../../../components/ui';
import {
  deleteShiftReportAttachment,
  downloadShiftReportAttachment,
  getShiftReport,
  upsertShiftReport,
  uploadShiftReportAttachment,
  type ShiftReport,
} from '../../../api/shifts';

function formatKB(bytes: number) {
  return `${Math.max(1, Math.round(bytes / 1024))} KB`;
}

async function fileToDataUrl(file: File): Promise<string> {
  return await new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('File read failed'));
    reader.onload = () => resolve(String(reader.result || ''));
    reader.readAsDataURL(file);
  });
}

// Client-side best-effort image compression (saves bandwidth/storage)
async function compressIfImage(file: File): Promise<File> {
  try {
    if (!file.type.startsWith('image/')) return file;
    // Skip small images
    if (file.size <= 600_000) return file;

    const img = document.createElement('img');
    const url = URL.createObjectURL(file);
    img.src = url;
    await new Promise<void>((resolve, reject) => {
      img.onload = () => resolve();
      img.onerror = () => reject(new Error('image load failed'));
    });

    const maxSide = 1600;
    const ratio = Math.min(1, maxSide / Math.max(img.width, img.height));
    const w = Math.round(img.width * ratio);
    const h = Math.round(img.height * ratio);

    const canvas = document.createElement('canvas');
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext('2d');
    if (!ctx) return file;
    ctx.drawImage(img, 0, 0, w, h);

    const blob: Blob | null = await new Promise((resolve) => canvas.toBlob(resolve, 'image/jpeg', 0.8));
    URL.revokeObjectURL(url);
    if (!blob) return file;
    if (blob.size >= file.size) return file;
    return new File([blob], file.name.replace(/\.(png|webp|heic|heif)$/i, '.jpg'), { type: 'image/jpeg' });
  } catch {
    return file;
  }
}

export function ShiftReportCard(props: { shift: any; me: any }) {
  const { shift, me } = props;
  const qc = useQueryClient();
  const [err, setErr] = useState<string | undefined>();
  const [ok, setOk] = useState<string | undefined>();

  const canEdit = useMemo(() => {
    if (!me?.role) return false;
    if (me.role === 'ADMIN') return true;
    if (me.role !== 'EMPLOYEE') return false;
    const isAssigned = (shift?.assignments ?? []).some((a: any) => a.userId === me.id);
    const hasEntry = (shift?.timeEntries ?? []).some((t: any) => t.userId === me.id);
    return isAssigned || hasEntry;
  }, [me?.role, me?.id, shift?.assignments, shift?.timeEntries]);

  const reportQ = useQuery({
    queryKey: ['shift-report', shift.id],
    queryFn: async () => (await getShiftReport(shift.id)).report,
    enabled: !!shift?.id,
  });

  const [draft, setDraft] = useState<ShiftReport | null>(null);

  useEffect(() => {
    if (reportQ.data) setDraft(reportQ.data);
  }, [reportQ.data]);

  const saveM = useMutation({
    mutationFn: async () => {
      if (!draft) throw new Error('Geen rapport');
      return upsertShiftReport(shift.id, {
        locationText: draft.locationText,
        summary: draft.summary,
        incidents: draft.incidents,
        actions: draft.actions,
      });
    },
    onSuccess: async () => {
      setOk('Opgeslagen');
      setErr(undefined);
      await qc.invalidateQueries({ queryKey: ['shift-report', shift.id] });
    },
    onError: (e: any) => setErr(e?.error ?? e?.message ?? 'Opslaan mislukt'),
  });

  const uploadM = useMutation({
    mutationFn: async (file: File) => {
      const dataUrl = await fileToDataUrl(file);
      return uploadShiftReportAttachment(shift.id, {
        fileName: file.name,
        mimeType: file.type || 'application/octet-stream',
        base64: dataUrl,
      });
    },
    onSuccess: async () => {
      setOk('Bijlage toegevoegd');
      setErr(undefined);
      await qc.invalidateQueries({ queryKey: ['shift-report', shift.id] });
    },
    onError: (e: any) => setErr(e?.error ?? e?.message ?? 'Upload mislukt'),
  });

  const delAttachM = useMutation({
    mutationFn: async (attachmentId: string) => deleteShiftReportAttachment(shift.id, attachmentId),
    onSuccess: async () => {
      await qc.invalidateQueries({ queryKey: ['shift-report', shift.id] });
    },
    onError: (e: any) => setErr(e?.error ?? e?.message ?? 'Verwijderen mislukt'),
  });

  const download = async (a: any) => {
    try {
      const { blob, fileName } = await downloadShiftReportAttachment(shift.id, a.id);
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = fileName || a.fileName || 'bijlage';
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(url);
    } catch (e: any) {
      setErr(e?.error ?? e?.message ?? 'Download mislukt');
    }
  };

  const addAction = () => {
    if (!draft) return;
    setDraft({ ...draft, actions: [...draft.actions, { label: 'Nieuwe actie', checked: false, notes: '' }] });
  };

  const addIncident = () => {
    if (!draft) return;
    setDraft({ ...draft, incidents: [...draft.incidents, { label: 'Nieuw incident', checked: false, notes: '', timeText: '' }] });
  };

  return (
    <Card className="p-6 space-y-4">
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div>
          <div className="text-lg font-semibold">Dagrapportage</div>
          <div className="text-sm text-gray-600">Incidenten, acties en bijlagen voor deze dienst.</div>
        </div>

        <div className="flex flex-wrap gap-2">
          <a href={`/shifts/${shift.id}/report/pdf`} target="_blank" rel="noreferrer">
            <Button variant="secondary">PDF export</Button>
          </a>
          {canEdit && (
            <Button onClick={() => saveM.mutate()} disabled={saveM.isPending || !draft}>
              {saveM.isPending ? 'Opslaan…' : 'Opslaan'}
            </Button>
          )}
        </div>
      </div>

      <ErrorBanner message={err || (reportQ.error as any)?.error} />
      <SuccessBanner message={ok} />

      {!draft ? (
        <div className="text-sm text-gray-600">Laden…</div>
      ) : (
        <div className="space-y-6">
          <div>
            <Label>Locatie</Label>
            <Input
              value={draft.locationText}
              disabled={!canEdit}
              onChange={(e) => setDraft({ ...draft, locationText: e.target.value })}
              placeholder="Locatie"
            />
          </div>

          <div>
            <div className="flex items-center justify-between gap-2">
              <div>
                <div className="text-sm font-semibold">Incident checklist</div>
                <div className="text-xs text-gray-500">Vink aan wat er is gebeurd en voeg evt. details toe.</div>
              </div>
              {canEdit && (
                <Button variant="secondary" onClick={addIncident}>
                  + Incident
                </Button>
              )}
            </div>

            <div className="mt-3 space-y-2">
              {draft.incidents.map((it, idx) => (
                <div key={`${it.label}-${idx}`} className="rounded-xl border border-gray-100 p-3">
                  <label className="flex items-start gap-3">
                    <input
                      type="checkbox"
                      className="mt-1"
                      checked={!!it.checked}
                      disabled={!canEdit}
                      onChange={(e) => {
                        const next = draft.incidents.slice();
                        next[idx] = { ...next[idx], checked: e.target.checked };
                        setDraft({ ...draft, incidents: next });
                      }}
                    />
                    <div className="flex-1 space-y-2">
                      <div className="grid gap-2 md:grid-cols-3">
                        <div className="md:col-span-2">
                          <Input
                            value={it.label}
                            disabled={!canEdit}
                            onChange={(e) => {
                              const next = draft.incidents.slice();
                              next[idx] = { ...next[idx], label: e.target.value };
                              setDraft({ ...draft, incidents: next });
                            }}
                          />
                        </div>

                        <div>
                          <div className="text-xs text-gray-500 mb-1">Tijdstip</div>
                          <input
                            type="time"
                            className="w-full rounded border px-3 py-2 text-sm outline-none focus:ring"
                            value={String((it as any).timeText ?? '')}
                            disabled={!canEdit}
                            onChange={(e) => {
                              const next = draft.incidents.slice();
                              next[idx] = { ...next[idx], timeText: e.target.value };
                              setDraft({ ...draft, incidents: next });
                            }}
                          />
                        </div>
                      </div>
                      <textarea
                        className="w-full rounded border px-3 py-2 text-sm outline-none focus:ring"
                        rows={2}
                        value={it.notes ?? ''}
                        disabled={!canEdit}
                        onChange={(e) => {
                          const next = draft.incidents.slice();
                          next[idx] = { ...next[idx], notes: e.target.value };
                          setDraft({ ...draft, incidents: next });
                        }}
                        placeholder="Details (optioneel)"
                      />
                    </div>
                  </label>
                </div>
              ))}
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between gap-2">
              <div>
                <div className="text-sm font-semibold">Actielijst</div>
                <div className="text-xs text-gray-500">Taken voor opvolging tijdens/na de dienst.</div>
              </div>
              {canEdit && (
                <Button variant="secondary" onClick={addAction}>
                  + Actie
                </Button>
              )}
            </div>

            <div className="mt-3 space-y-2">
              {draft.actions.length === 0 && <div className="text-sm text-gray-600">Geen acties.</div>}
              {draft.actions.map((it, idx) => (
                <div key={`${it.label}-${idx}`} className="rounded-xl border border-gray-100 p-3">
                  <label className="flex items-start gap-3">
                    <input
                      type="checkbox"
                      className="mt-1"
                      checked={!!it.checked}
                      disabled={!canEdit}
                      onChange={(e) => {
                        const next = draft.actions.slice();
                        next[idx] = { ...next[idx], checked: e.target.checked };
                        setDraft({ ...draft, actions: next });
                      }}
                    />
                    <div className="flex-1 space-y-2">
                      <Input
                        value={it.label}
                        disabled={!canEdit}
                        onChange={(e) => {
                          const next = draft.actions.slice();
                          next[idx] = { ...next[idx], label: e.target.value };
                          setDraft({ ...draft, actions: next });
                        }}
                      />
                      <textarea
                        className="w-full rounded border px-3 py-2 text-sm outline-none focus:ring"
                        rows={2}
                        value={it.notes ?? ''}
                        disabled={!canEdit}
                        onChange={(e) => {
                          const next = draft.actions.slice();
                          next[idx] = { ...next[idx], notes: e.target.value };
                          setDraft({ ...draft, actions: next });
                        }}
                        placeholder="Details (optioneel)"
                      />
                    </div>
                  </label>
                </div>
              ))}
            </div>
          </div>

          <div>
            <Label>Opmerkingen</Label>
            <textarea
              className="w-full rounded border px-3 py-2 text-sm outline-none focus:ring"
              rows={4}
              value={draft.summary ?? ''}
              disabled={!canEdit}
              onChange={(e) => setDraft({ ...draft, summary: e.target.value })}
              placeholder="Samenvatting / bijzonderheden…"
            />
          </div>

          <div>
            <div className="flex items-end justify-between gap-2">
              <div>
                <div className="text-sm font-semibold">Bijlagen</div>
                <div className="text-xs text-gray-500">Foto’s of documenten (max 8MB per bijlage).</div>
              </div>
              {canEdit && (
                <div>
                  <input
                    type="file"
                    onChange={(e) => {
                      const f = e.target.files?.[0];
                      if (!f) return;
                      (async () => {
                        const file = await compressIfImage(f);
                        uploadM.mutate(file);
                      })();
                      e.currentTarget.value = '';
                    }}
                  />
                </div>
              )}
            </div>

            <div className="mt-3 space-y-2">
              {draft.attachments.length === 0 ? (
                <div className="text-sm text-gray-600">Geen bijlagen.</div>
              ) : (
                draft.attachments.map((a) => (
                  <div key={a.id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-gray-100 p-3">
                    <div className="text-sm">
                      <div className="font-medium">{a.fileName}</div>
                      <div className="text-xs text-gray-500">{a.mimeType} · {formatKB(a.sizeBytes)}</div>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="secondary" onClick={() => download(a)}>Download</Button>
                      {canEdit && (me?.role === 'ADMIN' || a.uploadedById === me?.id) && (
                        <Button variant="danger" onClick={() => delAttachM.mutate(a.id)} disabled={delAttachM.isPending}>
                          Verwijder
                        </Button>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}
    </Card>
  );
}
