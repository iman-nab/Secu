import { useMemo, useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { Card, Badge, Button, ErrorBanner, Input, Label, SuccessBanner } from '../../../components/ui';
import { adminRemoteClockIn, adminRemoteClockOut, correctTimeEntry, resetTimeEntry } from '../../../api/shifts';
import { nlFullDate, nlTime, toLocalDateTimeInputValue } from '../../../utils/datetime';

function fmt(dt: string) {
  return `${nlFullDate(dt)} ${nlTime(dt)}`;
}

export function AdminTimeEntriesCard(props: {
  shift: any;
  qc: any;
  id: string | undefined;
  setErr: (s?: string) => void;
  locked?: boolean;
}) {
  const { shift, qc, id, setErr, locked } = props;
  const isLocked = Boolean(locked) || String(shift?.status ?? '') === 'CANCELLED' || String(shift?.status ?? '') === 'COMPLETED';
  const timeEntries = (shift.timeEntries ?? []) as any[];

  const approvedAssignees = useMemo(() => {
    const a = (shift.assignments ?? []) as any[];
    return a.filter((x) => x.status === 'APPROVED');
  }, [shift.assignments]);

  // Remote clock-in
  const [remoteUserId, setRemoteUserId] = useState('');
  const [remoteReason, setRemoteReason] = useState('');
  const [remoteClockInAt, setRemoteClockInAt] = useState('');

  // Remote clock-out
  const [remoteOutUserId, setRemoteOutUserId] = useState('');
  const [remoteOutReason, setRemoteOutReason] = useState('');
  const [remoteClockOutAt, setRemoteClockOutAt] = useState('');
  const [okMsg, setOkMsg] = useState<string | undefined>();
  const [localErr, setLocalErr] = useState<string | undefined>();

  const remoteM = useMutation({
    mutationFn: (input: { userId: string; reason: string; clockInAt?: string }) => adminRemoteClockIn(id!, input),
    onSuccess: async () => {
      setOkMsg('Remote clock-in uitgevoerd.');
      setLocalErr(undefined);
      setRemoteReason('');
      setRemoteClockInAt('');
      await qc.invalidateQueries({ queryKey: ['shift', id] });
      await qc.invalidateQueries({ queryKey: ['shift-activity', id] });
      await qc.invalidateQueries({ queryKey: ['hours'] });
    },
    onError: (e: any) => setLocalErr(e?.error || 'Remote clock-in mislukt'),
  });

  const remoteOutM = useMutation({
    mutationFn: (input: { userId: string; reason: string; clockOutAt?: string }) => adminRemoteClockOut(id!, input),
    onSuccess: async () => {
      setOkMsg('Remote clock-out uitgevoerd.');
      setLocalErr(undefined);
      setRemoteOutReason('');
      setRemoteClockOutAt('');
      await qc.invalidateQueries({ queryKey: ['shift', id] });
      await qc.invalidateQueries({ queryKey: ['shift-activity', id] });
      await qc.invalidateQueries({ queryKey: ['hours'] });
    },
    onError: (e: any) => setLocalErr(e?.error || 'Remote clock-out mislukt'),
  });

  const resetM = useMutation({
    mutationFn: (timeEntryId: string) => resetTimeEntry(id!, timeEntryId),
    onSuccess: async () => {
      setOkMsg('Time entry gereset.');
      setLocalErr(undefined);
      await qc.invalidateQueries({ queryKey: ['shift', id] });
      await qc.invalidateQueries({ queryKey: ['shift-activity', id] });
      await qc.invalidateQueries({ queryKey: ['hours'] });
    },
    onError: (e: any) => setLocalErr(e?.error || 'Reset mislukt'),
  });

  const correctM = useMutation({
    mutationFn: (input: { timeEntryId: string; clockInAt?: string; clockOutAt?: string; reason: string }) =>
      correctTimeEntry(id!, input.timeEntryId, { clockInAt: input.clockInAt, clockOutAt: input.clockOutAt, reason: input.reason }),
    onSuccess: async (_res, vars) => {
      setOkMsg('Correctie opgeslagen.');
      setLocalErr(undefined);
      // Close the inline editor for this entry (prevents "hanging" edit UI)
      if (vars?.timeEntryId) {
        setEdit((prev) => {
          const next = { ...prev };
          delete next[vars.timeEntryId];
          return next;
        });
      }
      await qc.invalidateQueries({ queryKey: ['shift', id] });
      await qc.invalidateQueries({ queryKey: ['shift-activity', id] });
      await qc.invalidateQueries({ queryKey: ['hours'] });
    },
    onError: (e: any) => setLocalErr(e?.error || 'Correctie mislukt'),
  });

  // Inline edit state per time entry
  const [edit, setEdit] = useState<Record<string, { clockInAt?: string; clockOutAt?: string; reason: string }>>({});

  const initEdit = (e: any) => {
    setEdit((prev) => {
      if (prev[e.id]) return prev;
      return {
        ...prev,
        [e.id]: {
          clockInAt: toLocalDateTimeInputValue(new Date(e.clockInAt)),
          clockOutAt: e.clockOutAt ? toLocalDateTimeInputValue(new Date(e.clockOutAt)) : '',
          reason: '',
        },
      };
    });
  };

  const submitCorrection = (timeEntryId: string) => {
    const st = edit[timeEntryId];
    if (!st) return;
    if (isLocked) {
      setLocalErr('Dienst is geannuleerd/afgerond: correcties zijn geblokkeerd.');
      return;
    }
    const reason = st.reason.trim();
    if (reason.length < 3) {
      setLocalErr('Reden is verplicht (min 3 tekens).');
      return;
    }
    const toISO = (v?: string) => (v ? new Date(v).toISOString() : undefined);
    correctM.mutate({
      timeEntryId,
      clockInAt: toISO(st.clockInAt),
      clockOutAt: toISO(st.clockOutAt),
      reason,
    });
  };

  const doRemote = () => {
    setOkMsg(undefined);
    setLocalErr(undefined);
    const userId = remoteUserId || approvedAssignees[0]?.userId;
    const reason = remoteReason.trim();
    if (!userId) {
      setLocalErr('Kies een werknemer.');
      return;
    }
    if (reason.length < 3) {
      setLocalErr('Reden is verplicht (min 3 tekens).');
      return;
    }
    const clockInAt = remoteClockInAt ? new Date(remoteClockInAt).toISOString() : undefined;
    remoteM.mutate({ userId, reason, clockInAt });
  };

  const activeEntries = useMemo(() => timeEntries.filter((e: any) => !e.clockOutAt), [timeEntries]);

  const doRemoteOut = () => {
    setOkMsg(undefined);
    setLocalErr(undefined);
    const userId = remoteOutUserId || activeEntries[0]?.userId;
    const reason = remoteOutReason.trim();
    if (!userId) {
      setLocalErr('Kies een werknemer met een actieve clock-in.');
      return;
    }
    if (reason.length < 3) {
      setLocalErr('Reden is verplicht (min 3 tekens).');
      return;
    }
    const clockOutAt = remoteClockOutAt ? new Date(remoteClockOutAt).toISOString() : undefined;
    remoteOutM.mutate({ userId, reason, clockOutAt });
  };

  return (
    <Card className="p-6 space-y-4">
      <div>
        <div className="text-lg font-semibold">Tijdregistratie (admin)</div>
        <div className="text-sm text-gray-600">Remote clock-in, correcties en resets. Correcties vereisen een reden.</div>
      </div>

      <ErrorBanner message={localErr} />
      <SuccessBanner message={okMsg} />

      <div className="rounded-2xl border border-gray-100 p-4 space-y-3">
        <div className="text-sm font-semibold">Remote clock-in</div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="space-y-1">
            <Label>Werknemer</Label>
            <select
              className="w-full rounded border px-3 py-2 text-sm outline-none focus:ring"
              value={remoteUserId}
              onChange={(e) => setRemoteUserId(e.target.value)}
              disabled={isLocked}
            >
              <option value="">— Kies —</option>
              {approvedAssignees.map((a: any) => (
                <option key={a.userId} value={a.userId}>
                  {a.user?.fullName || a.user?.email}
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-1">
            <Label>Clock-in tijd (optioneel)</Label>
            <Input type="datetime-local" value={remoteClockInAt} onChange={(e) => setRemoteClockInAt(e.target.value)} disabled={isLocked} />
          </div>

          <div className="space-y-1">
            <Label>Reden (verplicht)</Label>
            <Input value={remoteReason} onChange={(e) => setRemoteReason(e.target.value)} placeholder="Bijv. medewerker vergeten inklokken" disabled={isLocked} />
          </div>
        </div>
        <div>
          <Button onClick={doRemote} disabled={remoteM.isPending || isLocked}>Remote clock-in</Button>
        </div>
      </div>

      <div className="rounded-2xl border border-gray-100 p-4 space-y-3">
        <div className="text-sm font-semibold">Remote clock-out</div>
        <div className="text-xs text-gray-600">Sluit een actieve tijdregistratie af (admin override). Alleen beschikbaar als er een actieve clock-in bestaat.</div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="space-y-1">
            <Label>Werknemer</Label>
            <select
              className="w-full rounded border px-3 py-2 text-sm outline-none focus:ring"
              value={remoteOutUserId}
              onChange={(e) => setRemoteOutUserId(e.target.value)}
              disabled={activeEntries.length === 0 || isLocked}
            >
              <option value="">— Kies —</option>
              {activeEntries.map((e: any) => (
                <option key={e.userId} value={e.userId}>
                  {e.user?.fullName || e.user?.email}
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-1">
            <Label>Clock-out tijd (optioneel)</Label>
            <Input type="datetime-local" value={remoteClockOutAt} onChange={(e) => setRemoteClockOutAt(e.target.value)} disabled={activeEntries.length === 0 || isLocked} />
          </div>

          <div className="space-y-1">
            <Label>Reden (verplicht)</Label>
            <Input value={remoteOutReason} onChange={(e) => setRemoteOutReason(e.target.value)} placeholder="Bijv. medewerker vergeten uitklokken" disabled={activeEntries.length === 0 || isLocked} />
          </div>
        </div>
        <div>
          <Button onClick={doRemoteOut} disabled={remoteOutM.isPending || activeEntries.length === 0 || isLocked}>Remote clock-out</Button>
        </div>
      </div>

      {timeEntries.length === 0 ? (
        <div className="text-sm text-gray-600">Geen time entries.</div>
      ) : (
        <div className="overflow-auto">
          <table className="min-w-full text-sm">
            <thead>
              <tr className="text-left text-gray-600">
                <th className="py-2 pr-4">Werknemer</th>
                <th className="py-2 pr-4">In</th>
                <th className="py-2 pr-4">Uit</th>
                <th className="py-2 pr-4">Min</th>
                <th className="py-2 pr-4">Flags</th>
                <th className="py-2 pr-4">Acties</th>
              </tr>
            </thead>
            <tbody>
              {timeEntries.map((e: any) => {
                const st = edit[e.id];
                const isEditing = !!st;
                return (
                  <tr key={e.id} className="border-t align-top">
                    <td className="py-2 pr-4">{e.user?.fullName || e.user?.email}</td>
                    <td className="py-2 pr-4">{fmt(e.clockInAt)}</td>
                    <td className="py-2 pr-4">{e.clockOutAt ? fmt(e.clockOutAt) : '—'}</td>
                    <td className="py-2 pr-4">{e.minutesWorked}</td>
                    <td className="py-2 pr-4">
                      {e.adminOverride ? <Badge className="bg-orange-50 border-orange-200 text-orange-800">Admin override</Badge> : <Badge>Normal</Badge>}
                      {e.correctionReason ? (
                        <div className="mt-1 text-xs text-gray-600">Reden: {e.correctionReason}</div>
                      ) : null}
                    </td>
                    <td className="py-2 pr-4">
                      <div className="flex flex-wrap gap-2">
                        {!isEditing ? (
                          <Button variant="secondary" onClick={() => initEdit(e)} disabled={isLocked}>
                            Corrigeer
                          </Button>
                        ) : (
                          <>
                            <Button onClick={() => submitCorrection(e.id)} disabled={correctM.isPending || isLocked}>
                              Opslaan
                            </Button>
                            <Button
                              variant="secondary"
                              onClick={() => {
                                setLocalErr(undefined);
                                setOkMsg(undefined);
                                setEdit((prev) => {
                                  const next = { ...prev };
                                  delete next[e.id];
                                  return next;
                                });
                              }}
                            >
                              Annuleren
                            </Button>
                          </>
                        )}
                        <Button
                          variant="danger"
                          onClick={() => {
                            if (window.confirm('Time entry resetten?')) resetM.mutate(e.id);
                          }}
                          disabled={resetM.isPending || isLocked}
                        >
                          Reset
                        </Button>
                      </div>
                      {isEditing ? (
                        <div className="mt-2 grid grid-cols-1 md:grid-cols-3 gap-2">
                          <div className="space-y-1">
                            <Label>Clock-in</Label>
                            <Input
                              type="datetime-local"
                              value={st.clockInAt || ''}
                              onChange={(ev) => setEdit((p) => ({ ...p, [e.id]: { ...p[e.id], clockInAt: ev.target.value } }))}
                              disabled={isLocked}
                            />
                          </div>
                          <div className="space-y-1">
                            <Label>Clock-out</Label>
                            <Input
                              type="datetime-local"
                              value={st.clockOutAt || ''}
                              onChange={(ev) => setEdit((p) => ({ ...p, [e.id]: { ...p[e.id], clockOutAt: ev.target.value } }))}
                              disabled={isLocked}
                            />
                          </div>
                          <div className="space-y-1">
                            <Label>Reden</Label>
                            <Input
                              value={st.reason}
                              onChange={(ev) => setEdit((p) => ({ ...p, [e.id]: { ...p[e.id], reason: ev.target.value } }))}
                              disabled={isLocked}
                            />
                          </div>
                        </div>
                      ) : null}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </Card>
  );
}
