import { useMemo, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Badge, Button, Card, ErrorBanner, Input, Label } from '../../../components/ui';
import { getAdminKpis, getAdminKpisSeries } from '../../../api/dashboard';

function clamp(n: number, min: number, max: number) {
  return Math.max(min, Math.min(max, n));
}

function isoDate(d: Date) {
  return d.toISOString().slice(0, 10);
}

export default function KpisTab() {
  const [start, setStart] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() - 30);
    return isoDate(d);
  });
  const [end, setEnd] = useState(() => isoDate(new Date()));

  const { data, error, isLoading, refetch } = useQuery({
    queryKey: ['admin', 'kpis', start, end],
    queryFn: () => getAdminKpis({ start, end }),
  });

  const { data: seriesData, isLoading: seriesLoading } = useQuery({
    queryKey: ['admin', 'kpis-series', start, end],
    queryFn: () => getAdminKpisSeries({ start, end }),
  });

  const kpis = data?.kpis as any;
  const eur = (cents?: number) => {
    if (cents === undefined || cents === null || !Number.isFinite(Number(cents))) return '—';
    return (Number(cents) / 100).toLocaleString('nl-NL', { style: 'currency', currency: 'EUR' });
  };

  type Point = {
    label: string;
    hours: number;
    shifts: number;
    revenue: number; // EUR
    pay: number; // EUR
    margin: number; // EUR
  };

  const metric = {
    hours: { label: 'Uren', short: 'u', fmt: (v: number) => `${Math.round(v * 100) / 100}u` },
    shifts: { label: 'Diensten', short: 'x', fmt: (v: number) => `${Math.round(v)}x` },
    revenue: { label: 'Omzet (facturatie)', short: '€', fmt: (v: number) => `€${Math.round(v).toLocaleString('nl-NL')}` },
    pay: { label: 'Uitbetaling', short: '€', fmt: (v: number) => `€${Math.round(v).toLocaleString('nl-NL')}` },
    margin: { label: 'Marge', short: '€', fmt: (v: number) => `€${Math.round(v).toLocaleString('nl-NL')}` },
  } as const;

  const periodLabel = (p: 'week' | 'month' | 'quarter' | 'year') => {
    if (p === 'week') return 'week';
    if (p === 'month') return 'maand';
    if (p === 'quarter') return 'kwartaal';
    return 'jaar';
  };

  const MultiChart = ({
    title,
    subtitle,
    points,
    primary,
    secondary,
    primaryFmt,
    secondaryFmt,
    primaryLabel,
    secondaryLabel,
  }: {
    title: string;
    subtitle?: string;
    points: Point[];
    primary: keyof Point;
    secondary?: keyof Point;
    primaryFmt?: (v: number) => string;
    secondaryFmt?: (v: number) => string;
    primaryLabel?: string;
    secondaryLabel?: string;
  }) => {
    const [hover, setHover] = useState<number | null>(null);
    const w = 640;
    const h = 220;
    const padL = 44;
    const padR = secondary ? 44 : 18;
    const padT = 18;
    const padB = 30;

    const primVals = points.map((p) => Number(p[primary] ?? 0));
    const secVals = secondary ? points.map((p) => Number(p[secondary] ?? 0)) : [];

    const pMin = Math.min(0, ...primVals);
    const pMax = Math.max(1, ...primVals);
    const sMin = secondary ? Math.min(0, ...secVals) : 0;
    const sMax = secondary ? Math.max(1, ...secVals) : 1;

    const xAt = (i: number) => {
      if (points.length <= 1) return padL + (w - padL - padR) / 2;
      return padL + (i / (points.length - 1)) * (w - padL - padR);
    };
    const yP = (v: number) => {
      const range = pMax - pMin || 1;
      const t = (v - pMin) / range;
      return padT + (1 - t) * (h - padT - padB);
    };
    const yS = (v: number) => {
      const range = sMax - sMin || 1;
      const t = (v - sMin) / range;
      return padT + (1 - t) * (h - padT - padB);
    };

    const linePath = (getter: (p: Point) => number, yFn: (v: number) => number) =>
      points
        .map((p, i) => {
          const x = xAt(i);
          const y = yFn(getter(p));
          return `${i === 0 ? 'M' : 'L'} ${x.toFixed(2)} ${y.toFixed(2)}`;
        })
        .join(' ');

    const primaryPath = linePath((p) => Number(p[primary] ?? 0), yP);
    const secondaryPath = secondary ? linePath((p) => Number(p[secondary] ?? 0), yS) : '';
    const hoverPoint = hover != null ? points[hover] : null;

    const totalPrimary = primVals.reduce((a, b) => a + b, 0);
    const avgPrimary = points.length ? totalPrimary / points.length : 0;
    const peakPrimary = primVals.length ? Math.max(...primVals) : 0;

    const ticks = 4;
    const tickVals = Array.from({ length: ticks + 1 }, (_, i) => pMin + ((pMax - pMin) * i) / ticks);
    const tickValsS = secondary
      ? Array.from({ length: ticks + 1 }, (_, i) => sMin + ((sMax - sMin) * i) / ticks)
      : [];

    return (
      <div className="rounded-xl border p-4">
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="font-semibold">{title}</div>
            {subtitle ? <div className="text-xs text-gray-500 mt-0.5">{subtitle}</div> : null}
          </div>
          <div className="text-xs text-gray-600 text-right">
            {hoverPoint ? (
              <>
                <div className="font-medium">{hoverPoint.label}</div>
                <div className="mt-0.5">
                  <span className="inline-flex items-center gap-1">
                    <span className="inline-block w-2 h-2 rounded-sm bg-gray-900" />
                    {(primaryLabel ?? String(primary))}: {primaryFmt ? primaryFmt(Number(hoverPoint[primary] ?? 0)) : String(hoverPoint[primary])}
                  </span>
                </div>
                {secondary ? (
                  <div>
                    <span className="inline-flex items-center gap-1">
                      <span className="inline-block w-2 h-2 rounded-sm bg-gray-400" />
                      {(secondaryLabel ?? String(secondary))}: {secondaryFmt ? secondaryFmt(Number(hoverPoint[secondary] ?? 0)) : String(hoverPoint[secondary])}
                    </span>
                  </div>
                ) : null}
              </>
            ) : (
              <div className="text-gray-500">Hover voor details</div>
            )}
          </div>
        </div>

        {/* mini-cards */}
        <div className="mt-3 grid gap-2 sm:grid-cols-3">
          <div className="rounded-lg border bg-gray-50 p-2">
            <div className="text-[11px] text-gray-600">Totaal</div>
            <div className="text-sm font-semibold text-gray-900">{primaryFmt ? primaryFmt(totalPrimary) : Math.round(totalPrimary).toString()}</div>
          </div>
          <div className="rounded-lg border bg-gray-50 p-2">
            <div className="text-[11px] text-gray-600">Gemiddeld per {periodLabel(period)}</div>
            <div className="text-sm font-semibold text-gray-900">{primaryFmt ? primaryFmt(avgPrimary) : Math.round(avgPrimary).toString()}</div>
          </div>
          <div className="rounded-lg border bg-gray-50 p-2">
            <div className="text-[11px] text-gray-600">Piek (max)</div>
            <div className="text-sm font-semibold text-gray-900">{primaryFmt ? primaryFmt(peakPrimary) : Math.round(peakPrimary).toString()}</div>
          </div>
        </div>

        <div className="mt-3 overflow-x-auto">
          <svg viewBox={`0 0 ${w} ${h}`} className="w-full h-[220px]" onMouseLeave={() => setHover(null)}>
            {/* grid + y ticks */}
            {tickVals.map((tv, i) => {
              const y = yP(tv);
              return (
                <g key={`ptick-${i}`}>
                  <line x1={padL} y1={y} x2={w - padR} y2={y} stroke="#F3F4F6" />
                  <text x={padL - 6} y={y + 3} textAnchor="end" fontSize="10" fill="#6B7280">
                    {primaryFmt ? primaryFmt(tv) : Math.round(tv).toString()}
                  </text>
                </g>
              );
            })}
            {secondary
              ? tickValsS.map((tv, i) => {
                  const y = yS(tv);
                  return (
                    <text key={`stick-${i}`} x={w - padR + 6} y={y + 3} textAnchor="start" fontSize="10" fill="#9CA3AF">
                      {secondaryFmt ? secondaryFmt(tv) : Math.round(tv).toString()}
                    </text>
                  );
                })
              : null}

            {/* axes */}
            <line x1={padL} y1={padT} x2={padL} y2={h - padB} stroke="#E5E7EB" />
            <line x1={padL} y1={h - padB} x2={w - padR} y2={h - padB} stroke="#E5E7EB" />

            {/* bars for shifts when used */}
            {(primary === 'shifts' || secondary === 'shifts') &&
              points.map((p, i) => {
                const v = Number(p.shifts ?? 0);
                const x = xAt(i);
                const barW = Math.max(4, (w - padL - padR) / Math.max(points.length * 2, 24));
                const y0 = h - padB;
                const y1 = primary === 'shifts' ? yP(v) : yS(v);
                const y = Math.min(y0, y1);
                const bh = Math.abs(y0 - y1);
                return <rect key={`bar-${p.label}`} x={x - barW / 2} y={y} width={barW} height={bh} fill="#E5E7EB" />;
              })}

            {/* primary line */}
            <path d={primaryPath} fill="none" stroke="#111827" strokeWidth="2" />
            {/* secondary line */}
            {secondary ? <path d={secondaryPath} fill="none" stroke="#9CA3AF" strokeWidth="2" /> : null}

            {/* points + hover */}
            {points.map((p, i) => {
              const x = xAt(i);
              const y = yP(Number(p[primary] ?? 0));
              const active = hover === i;
              return (
                <g key={`pt-${p.label}`}>
                  <circle cx={x} cy={y} r={active ? 5 : 3} fill={active ? '#111827' : '#6B7280'} onMouseEnter={() => setHover(i)} />
                  <rect x={x - 10} y={padT} width={20} height={h - padT - padB} fill="transparent" onMouseEnter={() => setHover(i)} />
                </g>
              );
            })}

            {/* x labels (sparse) */}
            {points.map((p, i) => {
              if (points.length > 12 && i % 2 !== 0) return null;
              const x = xAt(i);
              return (
                <text key={`xl-${p.label}`} x={x} y={h - 6} textAnchor="middle" fontSize="10" fill="#6B7280">
                  {p.label}
                </text>
              );
            })}
          </svg>
        </div>

        <div className="mt-2 flex flex-wrap gap-2 text-xs text-gray-600">
          <span className="inline-flex items-center gap-1">
            <span className="inline-block w-2 h-2 rounded-sm bg-gray-900" /> {primaryLabel ?? String(primary)}
          </span>
          {secondary ? (
            <span className="inline-flex items-center gap-1">
              <span className="inline-block w-2 h-2 rounded-sm bg-gray-400" /> {secondaryLabel ?? String(secondary)}
            </span>
          ) : null}
        </div>
      </div>
    );
  };

  const [period, setPeriod] = useState<'week' | 'month' | 'quarter' | 'year'>('week');

  const [opMetric, setOpMetric] = useState<'hours' | 'shifts'>('hours');
  const [finMetric, setFinMetric] = useState<'revenue' | 'pay' | 'margin'>('revenue');

  const series = (seriesData as any)?.series ?? [];

  const points: Point[] = useMemo(() => {
    const src = (series as any[]).map((s) => ({
      weekStart: String(s.weekStart),
      hours: Number(s.totalHours ?? 0),
      shifts: Number(s.shiftCount ?? 0),
      revenue: Number(s.toInvoiceCents ?? 0) / 100,
      pay: Number(s.toPayCents ?? 0) / 100,
    }));

    if (period === 'week') {
      return src.slice(-16).map((s) => ({
        label: s.weekStart.slice(5),
        hours: s.hours,
        shifts: s.shifts,
        revenue: s.revenue,
        pay: s.pay,
        margin: Math.round((s.revenue - s.pay) * 100) / 100,
      }));
    }

    const bucketKey = (isoWeekStart: string) => {
      // isoWeekStart is YYYY-MM-DD
      const y = isoWeekStart.slice(0, 4);
      const m = Number(isoWeekStart.slice(5, 7));
      if (period === 'month') return `${y}-${String(m).padStart(2, '0')}`;
      if (period === 'quarter') {
        const q = Math.floor((m - 1) / 3) + 1;
        return `${y}-Q${q}`;
      }
      // year
      return `${y}`;
    };

    const buckets = new Map<string, any>();
    for (const r of src) {
      const key = bucketKey(r.weekStart);
      const cur = buckets.get(key) ?? { key, hours: 0, shifts: 0, revenue: 0, pay: 0 };
      cur.hours += r.hours;
      cur.shifts += r.shifts;
      cur.revenue += r.revenue;
      cur.pay += r.pay;
      buckets.set(key, cur);
    }

    const maxItems = period === 'month' ? 12 : period === 'quarter' ? 12 : 6;

    return Array.from(buckets.values())
      .sort((a, b) => String(a.key).localeCompare(String(b.key)))
      .slice(-maxItems)
      .map((x) => ({
        label: String(x.key).includes('-') ? String(x.key).split('-').slice(1).join('-') : String(x.key),
        hours: Math.round(x.hours * 100) / 100,
        shifts: x.shifts,
        revenue: Math.round(x.revenue * 100) / 100,
        pay: Math.round(x.pay * 100) / 100,
        margin: Math.round((x.revenue - x.pay) * 100) / 100,
      }));
  }, [seriesData, period]);

  const topLocations = (seriesData as any)?.topLocations ?? [];
  const topWorkers = (seriesData as any)?.topWorkers ?? [];
  const shiftCounts = (seriesData as any)?.shiftCounts ?? null;

  return (
    <div className="space-y-4">
      <Card className="p-4">
        <div className="flex flex-wrap items-end gap-3 justify-between">
          <div className="grid gap-3 md:grid-cols-2">
            <div>
              <Label>Start</Label>
              <Input type="date" value={start} onChange={(e) => setStart(e.target.value)} />
            </div>
            <div>
              <Label>Eind</Label>
              <Input type="date" value={end} onChange={(e) => setEnd(e.target.value)} />
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="text-xs text-gray-600">Groepering</div>
            <div className="inline-flex rounded-lg border overflow-hidden">
              <button
                className={`px-3 py-2 text-sm ${period === 'week' ? 'bg-gray-900 text-white' : 'bg-white text-gray-700'}`}
                onClick={() => setPeriod('week')}
                type="button"
              >
                Week
              </button>
              <button
                className={`px-3 py-2 text-sm ${period === 'month' ? 'bg-gray-900 text-white' : 'bg-white text-gray-700'}`}
                onClick={() => setPeriod('month')}
                type="button"
              >
                Maand
              </button>
              <button
                className={`px-3 py-2 text-sm ${period === 'quarter' ? 'bg-gray-900 text-white' : 'bg-white text-gray-700'}`}
                onClick={() => setPeriod('quarter')}
                type="button"
              >
                Kwartaal
              </button>
              <button
                className={`px-3 py-2 text-sm ${period === 'year' ? 'bg-gray-900 text-white' : 'bg-white text-gray-700'}`}
                onClick={() => setPeriod('year')}
                type="button"
              >
                Jaar
              </button>
            </div>
          </div>
          <Button variant="secondary" onClick={() => refetch()} disabled={isLoading}>
            Refresh
          </Button>
        </div>
      </Card>

      <ErrorBanner message={(error as any)?.error ?? (error as any)?.message} />

      <Card className="p-4">
        <div className="font-medium text-gray-900 mb-3">Admin KPI's</div>
        {isLoading ? (
          <div className="text-sm text-gray-600">Laden…</div>
        ) : !kpis ? (
          <div className="text-sm text-gray-600">Geen KPI data.</div>
        ) : (
          <div className="space-y-4">
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
              <div className="rounded-xl border bg-gray-50 p-3">
                <div className="text-xs text-gray-600">Totale uren</div>
                <div className="text-lg font-semibold">{kpis.totalHours != null ? `${Number(kpis.totalHours).toLocaleString('nl-NL')}u` : '—'}</div>
              </div>
              <div className="rounded-xl border bg-gray-50 p-3">
                <div className="text-xs text-gray-600">Omzet (facturatie)</div>
                <div className="text-lg font-semibold">{eur(kpis.toInvoiceCents)}</div>
              </div>
              <div className="rounded-xl border bg-gray-50 p-3">
                <div className="text-xs text-gray-600">Uitbetaling (onderaannemers)</div>
                <div className="text-lg font-semibold">{eur(kpis.toPaySubcontractorsCents)}</div>
              </div>
              <div className="rounded-xl border bg-gray-50 p-3">
                <div className="text-xs text-gray-600">Extra kosten</div>
                <div className="text-lg font-semibold">{eur(kpis.extraCostsCents)}</div>
              </div>
              <div className="rounded-xl border bg-gray-50 p-3">
                <div className="text-xs text-gray-600">Diensten (open/assigned/completed)</div>
                <div className="text-lg font-semibold">
                  {shiftCounts ? `${shiftCounts.open}/${shiftCounts.assigned}/${shiftCounts.completed}` : '—'}
                </div>
              </div>
            </div>

            <div className="grid gap-4 xl:grid-cols-2">
              <div className="space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <div className="text-xs text-gray-600">Operatie metric</div>
                  <div className="inline-flex rounded-lg border overflow-hidden">
                    <button
                      type="button"
                      className={`px-3 py-1.5 text-sm ${opMetric === 'hours' ? 'bg-gray-900 text-white' : 'bg-white text-gray-700'}`}
                      onClick={() => setOpMetric('hours')}
                    >
                      Uren
                    </button>
                    <button
                      type="button"
                      className={`px-3 py-1.5 text-sm ${opMetric === 'shifts' ? 'bg-gray-900 text-white' : 'bg-white text-gray-700'}`}
                      onClick={() => setOpMetric('shifts')}
                    >
                      Diensten
                    </button>
                  </div>
                </div>
                <MultiChart
                  title="Operatie"
                  subtitle={period === 'week' ? 'Per week' : period === 'month' ? 'Per maand' : period === 'quarter' ? 'Per kwartaal' : 'Per jaar'}
                  points={points}
                  primary={opMetric}
                  primaryFmt={metric[opMetric].fmt}
                  primaryLabel={metric[opMetric].label}
                />
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <div className="text-xs text-gray-600">Finance metric</div>
                  <div className="inline-flex rounded-lg border overflow-hidden">
                    <button
                      type="button"
                      className={`px-3 py-1.5 text-sm ${finMetric === 'revenue' ? 'bg-gray-900 text-white' : 'bg-white text-gray-700'}`}
                      onClick={() => setFinMetric('revenue')}
                    >
                      Omzet
                    </button>
                    <button
                      type="button"
                      className={`px-3 py-1.5 text-sm ${finMetric === 'pay' ? 'bg-gray-900 text-white' : 'bg-white text-gray-700'}`}
                      onClick={() => setFinMetric('pay')}
                    >
                      Uitbetaling
                    </button>
                    <button
                      type="button"
                      className={`px-3 py-1.5 text-sm ${finMetric === 'margin' ? 'bg-gray-900 text-white' : 'bg-white text-gray-700'}`}
                      onClick={() => setFinMetric('margin')}
                    >
                      Marge
                    </button>
                  </div>
                </div>
                <MultiChart
                  title="Finance"
                  subtitle={period === 'week' ? 'Per week' : period === 'month' ? 'Per maand' : period === 'quarter' ? 'Per kwartaal' : 'Per jaar'}
                  points={points}
                  primary={finMetric}
                  primaryFmt={metric[finMetric].fmt}
                  primaryLabel={metric[finMetric].label}
                />
              </div>
            </div>

            <div className="grid gap-4 xl:grid-cols-2">
              <MultiChart
                title="Marge"
                subtitle="Facturatie minus uitbetaling (excl. overige kosten)"
                points={points}
                primary="margin"
                primaryFmt={metric.margin.fmt}
                primaryLabel={metric.margin.label}
              />
              <div className="rounded-xl border p-4">
                <div className="font-semibold">Hoe lees je dit?</div>
                <div className="mt-2 text-sm text-gray-600 space-y-2">
                  <div>
                    <span className="font-medium">Operatie</span>: hoeveel uren draaien we en hoeveel diensten zijn er ingepland.
                  </div>
                  <div>
                    <span className="font-medium">Finance</span>: wat we factureren (omzet) vs wat we uitbetalen.
                  </div>
                  <div>
                    <span className="font-medium">Marge</span>: omzet − uitbetaling (indicatief; extra kosten staan apart).
                  </div>
                  <div className="text-xs text-gray-500">
                    Tip: hover over een punt om de exacte waarden te zien.
                  </div>
                </div>
              </div>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <div className="rounded-xl border p-4">
                <div className="font-semibold">Top locaties (uren)</div>
                <div className="mt-3 space-y-2">
                  {(topLocations as any[]).slice(0, 8).map((l) => (
                    <div key={l.id} className="flex items-center justify-between text-sm">
                      <div className="truncate">{l.name}</div>
                      <div className="font-semibold">{l.totalHours}u</div>
                    </div>
                  ))}
                  {!topLocations?.length ? <div className="text-sm text-gray-600">Geen data.</div> : null}
                </div>
              </div>

              <div className="rounded-xl border p-4">
                <div className="font-semibold">Top personeel (uren)</div>
                <div className="mt-3 space-y-2">
                  {(topWorkers as any[]).slice(0, 8).map((u) => (
                    <div key={u.id} className="flex items-center justify-between text-sm">
                      <div className="truncate">{u.name}</div>
                      <div className="font-semibold">{u.totalHours}u</div>
                    </div>
                  ))}
                  {!topWorkers?.length ? <div className="text-sm text-gray-600">Geen data.</div> : null}
                </div>
              </div>
            </div>

            {(seriesLoading || !seriesData) ? (
              <div className="text-xs text-gray-500">(Series laden…)</div>
            ) : null}
          </div>
        )}
      </Card>
    </div>
  );
}
