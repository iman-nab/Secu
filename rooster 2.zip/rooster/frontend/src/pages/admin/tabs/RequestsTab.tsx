import { useEffect, useMemo, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Button, Card, ErrorBanner, Badge, Input, Label } from '../../../components/ui';
import { convertRequestToShift, getRequestActivity, listAllRequests } from '../../../api/client';
import { PaginationControls } from '../../../components/PaginationControls';
import { listLocations } from '../../../api/locations';
import { actionLabel as auditActionLabel, summarizeLog as auditSummarizeLog, fieldLabel as auditFieldLabel, formatValue as auditFormatValue } from '../../../utils/auditHumanize';

function fmtDt(v: any) {
  try {
    if (!v) return '';
    return new Date(v).toLocaleString('nl-NL');
  } catch {
    return String(v ?? '');
  }
}

export default function RequestsTab() {
  const qc = useQueryClient();
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(25);

  const [convertId, setConvertId] = useState<string>('');
  const [convertStartAt, setConvertStartAt] = useState<string>('');
  const [convertEndAt, setConvertEndAt] = useState<string>('');
  const [convertLocationId, setConvertLocationId] = useState<string>('');
  const [convertType, setConvertType] = useState<string>('GENERAL');
  const [convertPassColor, setConvertPassColor] = useState<'GRAY' | 'DARK_BLUE' | 'LIGHT_BLUE' | 'ORANGE' | 'GREEN' | 'BLACK'>('BLACK');
  const [convertWorkers, setConvertWorkers] = useState<number>(1);
  const [actionErr, setActionErr] = useState<string>('');

  const [activityId, setActivityId] = useState<string>('');
  const [activityPage, setActivityPage] = useState(1);
  const [activityPageSize, setActivityPageSize] = useState(25);

  useEffect(() => {
    setPage(1);
  }, [pageSize]);

  const { data, error, isLoading, refetch } = useQuery({
    queryKey: ['admin', 'requests', { page, pageSize }],
    queryFn: () => listAllRequests({ status: 'ALL', page, pageSize }) as any,
  });

  const activityQ = useQuery({
    queryKey: ['admin', 'request-activity', activityId, activityPage, activityPageSize],
    enabled: !!activityId,
    queryFn: () => getRequestActivity(activityId, { page: activityPage, pageSize: activityPageSize }) as any,
  });

  const { data: locationsData } = useQuery({
    queryKey: ['admin', 'locations', 'requests-convert'],
    queryFn: () => listLocations(),
    staleTime: 60_000,
  });

  const locations = (locationsData?.locations ?? []) as any[];

  const convertM = useMutation({
    mutationFn: async () => {
      if (!convertId) throw new Error('No request selected');
      if (!convertStartAt || !convertEndAt || !convertLocationId) throw new Error('Vul start/eind + locatie in');
      return convertRequestToShift(convertId, {
        startAt: new Date(convertStartAt).toISOString(),
        endAt: new Date(convertEndAt).toISOString(),
        locationId: convertLocationId,
        type: convertType.trim() || 'GENERAL',
        requiredPassColor: convertPassColor,
        requiredWorkers: convertWorkers,
      });
    },
    onSuccess: async (res: any) => {
      setActionErr('');
      setConvertId('');
      await qc.invalidateQueries({ queryKey: ['admin', 'requests'] });
      const shiftId = res?.shift?.id;
      if (shiftId) {
        window.location.href = `/diensten/${shiftId}`;
      }
    },
    onError: (e: any) => {
      setActionErr(e?.error || e?.message || 'Omzetten naar dienst mislukt');
    },
  });

  const datetimeLocal = (d: Date) => {
    const pad = (n: number) => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
  };

  const defaultStartEnd = useMemo(() => {
    const start = new Date();
    start.setHours(9, 0, 0, 0);
    const end = new Date(start);
    end.setHours(17, 0, 0, 0);
    return { start: datetimeLocal(start), end: datetimeLocal(end) };
  }, []);

  const requests = (data?.requests ?? []) as any[];
  const totalCount = (data as any)?.totalCount as number | undefined;

  return (
    <div className="space-y-4">
      <Card className="p-4 flex items-center justify-between">
        <div>
          <div className="font-medium text-gray-900">Klant verzoeken</div>
          <div className="text-xs text-gray-600">Met audit info (aangemaakt door / op)</div>
        </div>
        <Button variant="secondary" onClick={() => refetch()} disabled={isLoading}>
          Refresh
        </Button>
      </Card>

      <ErrorBanner message={(error as any)?.error ?? (error as any)?.message} />
      <ErrorBanner message={actionErr} />

      <Card className="p-4">
        <div className="mb-3">
          <PaginationControls
            page={page}
            pageSize={pageSize}
            totalCount={totalCount}
            onPageChange={(p) => setPage(Math.max(1, p))}
            onPageSizeChange={(ps) => {
              setPageSize(ps);
              setPage(1);
            }}
          />
        </div>

        {isLoading ? (
          <div className="text-sm text-gray-600">Laden…</div>
        ) : requests.length === 0 ? (
          <div className="text-sm text-gray-600">Geen verzoeken.</div>
        ) : (
          <div className="space-y-2">
            {requests.map((r) => {
              const subject = r.subject ?? r.title ?? 'Verzoek';
              const msg = r.message ?? r.body ?? '';
              const createdBy = r.createdBy?.fullName ?? r.createdBy?.email ?? r.createdById ?? 'Onbekend';
              const createdAt = r.createdAt ? fmtDt(r.createdAt) : '';
              const handledBy = r.handledBy?.fullName ?? r.handledBy?.email ?? '';
              const handledAt = r.handledAt ? fmtDt(r.handledAt) : '';

              return (
                <div key={r.id} className="rounded-xl border border-gray-100 p-3">
                  <div className="flex items-start justify-between gap-3 flex-wrap">
                    <div className="min-w-0">
                      <div className="font-medium text-gray-900 truncate">{subject}</div>
                      <div className="text-xs text-gray-600 truncate">
                        Aangemaakt door <span className="font-medium">{createdBy}</span>
                        {createdAt ? ` • ${createdAt}` : ''}
                      </div>
                      {r.client?.name ? <div className="text-xs text-gray-600 truncate">Klant: {r.client.name}</div> : null}
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge>{r.status ?? ''}</Badge>
                      <Button
                        variant="secondary"
                        onClick={() => {
                          setActivityId(r.id);
                          setActivityPage(1);
                          setActivityPageSize(25);
                        }}
                      >
                        Log
                      </Button>
                      <Button
                        variant="secondary"
                        onClick={() => {
                          setActionErr('');
                          setConvertId(r.id);
                          setConvertStartAt(defaultStartEnd.start);
                          setConvertEndAt(defaultStartEnd.end);
                          setConvertLocationId(locations[0]?.id ?? '');
                          setConvertType('GENERAL');
                          setConvertPassColor('BLACK');
                          setConvertWorkers(1);
                        }}
                      >
                        Omzetten naar dienst
                      </Button>
                    </div>
                  </div>

                  {handledBy || handledAt ? (
                    <div className="text-xs text-gray-600 mt-2">
                      Behandeld door <span className="font-medium">{handledBy || '—'}</span>
                      {handledAt ? ` • ${handledAt}` : ''}
                    </div>
                  ) : null}

                  <div className="text-sm text-gray-700 mt-2 whitespace-pre-wrap">{msg}</div>
                </div>
              );
            })}
          </div>
        )}

        <div className="mt-3 text-xs text-gray-500">
          Tip: voeg later status-wijzigingen + “laatst gewijzigd door” toe voor volledige audit trail.
        </div>
      </Card>

      {convertId ? (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4"
          role="dialog"
          aria-modal="true"
          onMouseDown={(e) => {
            if (e.target === e.currentTarget && !convertM.isPending) setConvertId('');
          }}
        >
          <Card className="w-full max-w-2xl p-5 space-y-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="text-lg font-semibold">Verzoek omzetten naar dienst</div>
                <div className="text-sm text-gray-600">Titel/omschrijving/klant worden automatisch ingevuld vanuit het verzoek.</div>
              </div>
              <Button variant="secondary" onClick={() => setConvertId('')} disabled={convertM.isPending}>
                Sluiten
              </Button>
            </div>

            <div className="grid gap-3 md:grid-cols-2">
              <div>
                <Label>Start</Label>
                <Input type="datetime-local" value={convertStartAt} onChange={(e) => setConvertStartAt(e.target.value)} />
              </div>
              <div>
                <Label>Einde</Label>
                <Input type="datetime-local" value={convertEndAt} onChange={(e) => setConvertEndAt(e.target.value)} />
              </div>

              <div>
                <Label>Locatie</Label>
                <select
                  className="mt-1 w-full rounded-xl border px-3 py-2 text-sm"
                  value={convertLocationId}
                  onChange={(e) => setConvertLocationId(e.target.value)}
                >
                  <option value="">Kies locatie…</option>
                  {locations.map((l) => (
                    <option key={l.id} value={l.id}>
                      {l.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <Label>Type</Label>
                <Input value={convertType} onChange={(e) => setConvertType(e.target.value)} placeholder="Bijv. GENERAL" />
              </div>

              <div>
                <Label>Kleurpas (eis)</Label>
                <select
                  className="mt-1 w-full rounded-xl border px-3 py-2 text-sm"
                  value={convertPassColor}
                  onChange={(e) => setConvertPassColor(e.target.value as any)}
                >
                  {['GRAY', 'DARK_BLUE', 'LIGHT_BLUE', 'ORANGE', 'GREEN', 'BLACK'].map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <Label>Aantal medewerkers</Label>
                <Input
                  type="number"
                  min={1}
                  max={50}
                  value={String(convertWorkers)}
                  onChange={(e) => setConvertWorkers(Number(e.target.value || 1))}
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2">
              <Button variant="secondary" onClick={() => setConvertId('')} disabled={convertM.isPending}>
                Annuleren
              </Button>
              <Button onClick={() => convertM.mutate()} disabled={convertM.isPending || !convertLocationId}>
                {convertM.isPending ? 'Aanmaken…' : 'Dienst aanmaken'}
              </Button>
            </div>
          </Card>
        </div>
      ) : null}

      {activityId ? (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4"
          role="dialog"
          aria-modal="true"
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) setActivityId('');
          }}
        >
          <Card className="w-full max-w-3xl p-5 space-y-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="text-lg font-semibold">Audit log</div>
                <div className="text-sm text-gray-600">Wie heeft wat gedaan en wanneer.</div>
              </div>
              <Button variant="secondary" onClick={() => setActivityId('')}>
                Sluiten
              </Button>
            </div>

            <ErrorBanner message={(activityQ.error as any)?.error ?? (activityQ.error as any)?.message} />

            <div className="flex items-center justify-between gap-3 flex-wrap">
              <PaginationControls
                page={activityPage}
                pageSize={activityPageSize}
                totalCount={(activityQ.data as any)?.totalCount}
                onPageChange={(p) => setActivityPage(Math.max(1, p))}
                onPageSizeChange={(ps) => {
                  setActivityPageSize(ps);
                  setActivityPage(1);
                }}
              />
              <Button variant="secondary" onClick={() => activityQ.refetch()} disabled={activityQ.isLoading}>
                Refresh
              </Button>
            </div>

            {activityQ.isLoading ? (
              <div className="text-sm text-gray-600">Laden…</div>
            ) : (activityQ.data as any)?.logs?.length ? (
              <div className="max-h-[60vh] overflow-auto space-y-2">
                {(activityQ.data as any).logs.map((l: any) => (
                  <div key={l.id} className="rounded-xl border border-gray-100 p-3">
                    {(() => {
                      const { summary, changes } = auditSummarizeLog(l);
                      const hasDetails = (changes?.length ?? 0) > 0 || l.before || l.after;
                      return (
                        <>
                          <div className="flex flex-wrap items-start justify-between gap-2">
                            <div className="min-w-0">
                              <div className="flex flex-wrap items-center gap-2">
                                <Badge>{auditActionLabel(l.action)}</Badge>
                                <div className="text-xs text-gray-600">{fmtDt(l.createdAt)}</div>
                                <div className="text-xs text-gray-600">
                                  Door: <span className="font-medium">{l.actor?.fullName || l.actor?.email || l.actorId}</span>
                                </div>
                              </div>
                              <div className="mt-2 text-sm text-gray-900 font-medium">{summary}</div>

                              {(changes?.length ?? 0) > 0 ? (
                                <div className="mt-2 text-xs text-gray-700">
                                  {changes.slice(0, 4).map((c: any) => (
                                    <div key={c.key} className="break-words">
                                      <span className="font-medium">{auditFieldLabel(c.key)}</span>: {auditFormatValue(c.key, c.from)} → {auditFormatValue(c.key, c.to)}
                                    </div>
                                  ))}
                                  {changes.length > 4 ? <div className="text-gray-500 mt-1">+{changes.length - 4} meer…</div> : null}
                                </div>
                              ) : null}
                            </div>

                            {hasDetails ? (
                              <div className="flex items-center gap-2">
                                <Button
                                  variant="secondary"
                                  onClick={async () => {
                                    try {
                                      await navigator.clipboard.writeText(JSON.stringify({ before: l.before ?? null, after: l.after ?? null }, null, 2));
                                    } catch {
                                      // ignore
                                    }
                                  }}
                                  title="Kopieer raw JSON"
                                >
                                  Copy JSON
                                </Button>
                              </div>
                            ) : null}
                          </div>

                          {hasDetails ? (
                            <details className="mt-2">
                              <summary className="cursor-pointer text-xs text-gray-700">Details</summary>
                              <pre className="mt-2 rounded-lg bg-gray-50 p-2 text-xs overflow-auto">
{JSON.stringify({ before: l.before ?? null, after: l.after ?? null }, null, 2)}
                              </pre>
                            </details>
                          ) : null}
                        </>
                      );
                    })()}
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-sm text-gray-600">Geen log items.</div>
            )}
          </Card>
        </div>
      ) : null}
    </div>
  );
}
