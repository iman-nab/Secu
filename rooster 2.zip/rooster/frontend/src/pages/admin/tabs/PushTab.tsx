import { useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { Button, Card, ErrorBanner, Input, Label, SuccessBanner } from '../../../components/ui';
import { sendAdminPush } from '../../../api/push';

export default function PushTab() {
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [url, setUrl] = useState('');
  const [targetType, setTargetType] = useState<'shift' | 'passColor' | 'allEmployees'>('passColor');
  const [shiftId, setShiftId] = useState('');
  const [passColor, setPassColor] = useState<'GRAY' | 'DARK_BLUE' | 'LIGHT_BLUE' | 'ORANGE' | 'GREEN' | 'BLACK'>('BLACK');
  const [ok, setOk] = useState<string | undefined>();
  const [err, setErr] = useState<string | undefined>();

  const m = useMutation({
    mutationFn: async () => {
      setOk(undefined);
      setErr(undefined);
      const target =
        targetType === 'shift'
          ? ({ type: 'shift', shiftId: shiftId.trim() } as const)
          : targetType === 'allEmployees'
            ? ({ type: 'allEmployees' } as const)
            : ({ type: 'passColor', passColor } as const);
      return sendAdminPush({ title: title.trim(), message: message.trim(), url: url.trim() || undefined, target });
    },
    onSuccess: (res: any) => {
      setOk(`Verzonden naar ${res?.recipients ?? 0} ontvangers.`);
    },
    onError: (e: any) => setErr(e?.error ?? e?.message ?? 'Actie mislukt'),
  });

  return (
    <div className="space-y-4">
      <Card className="p-4 space-y-3">
        <div className="font-medium text-gray-900">Push bericht</div>

        <div className="grid gap-3 md:grid-cols-2">
          <div>
            <Label>Titel</Label>
            <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Titel" />
          </div>
          <div>
            <Label>URL (optioneel)</Label>
            <Input value={url} onChange={(e) => setUrl(e.target.value)} placeholder="/shifts/123" />
          </div>
        </div>

        <div>
          <Label>Bericht</Label>
          <Input value={message} onChange={(e) => setMessage(e.target.value)} placeholder="Tekst" />
        </div>

        <div className="grid gap-3 md:grid-cols-2">
          <div>
            <Label>Doelgroep</Label>
            <select
              className="w-full rounded border px-3 py-2 text-sm"
              value={targetType}
              onChange={(e) => setTargetType(e.target.value as any)}
            >
              <option value="passColor">Kleurpas groep</option>
              <option value="allEmployees">Alle werknemers</option>
              <option value="shift">Specifieke dienst</option>
            </select>
          </div>

          {targetType === 'shift' ? (
            <div>
              <Label>Shift ID</Label>
              <Input value={shiftId} onChange={(e) => setShiftId(e.target.value)} placeholder="Shift ID" />
            </div>
          ) : targetType === 'allEmployees' ? (
            <div>
              <Label>Info</Label>
              <div className="mt-2 rounded-lg border bg-gray-50 px-3 py-2 text-sm text-gray-700">
                Dit bericht gaat naar alle actieve werknemers.
              </div>
            </div>
          ) : (
            <div>
              <Label>Kleurpas</Label>
              <select
                className="w-full rounded border px-3 py-2 text-sm"
                value={passColor}
                onChange={(e) => setPassColor(e.target.value as any)}
              >
                {['GRAY', 'DARK_BLUE', 'LIGHT_BLUE', 'ORANGE', 'GREEN', 'BLACK'].map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>
          )}
        </div>

        <div className="flex gap-2">
          <Button
            onClick={() => m.mutate()}
            disabled={!title.trim() || !message.trim() || m.isPending || (targetType === 'shift' && !shiftId.trim())}
          >
            Verzenden
          </Button>
          <Button variant="secondary" onClick={() => { setTitle(''); setMessage(''); setUrl(''); setShiftId(''); setOk(undefined); setErr(undefined); }}>
            Reset
          </Button>
        </div>
      </Card>

      <ErrorBanner message={err} />
      <SuccessBanner message={ok} />
    </div>
  );
}
