import { useEffect, useState } from 'react';
import { useMutation, useQuery } from '@tanstack/react-query';
import { Badge, Button, Card, ErrorBanner, Input, Label, SuccessBanner } from '../../../components/ui';
import { onboardClient, listClients, deleteClient, regenerateClientInvite } from '../../../api/clients';
import { PaginationControls } from '../../../components/PaginationControls';

export default function ClientsTab() {
  const [q, setQ] = useState('');
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(25);

  useEffect(() => {
    setPage(1);
  }, [q, pageSize]);

  const { data, error, isLoading, refetch } = useQuery({
    queryKey: ['admin', 'clients', { q, page, pageSize }],
    queryFn: () => listClients({ includeDeleted: true, q: q.trim() || undefined, page, pageSize }),
  });

  const [name, setName] = useState('');
  const [contactName, setContactName] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [msg, setMsg] = useState<string | undefined>();
  const [errMsg, setErrMsg] = useState<string | undefined>();

  const onboardM = useMutation({
    mutationFn: async () => {
      setMsg(undefined);
      setErrMsg(undefined);
      const res = await onboardClient({
        name: name.trim(),
        contactName: contactName.trim() || undefined,
        contactEmail: contactEmail.trim() || undefined,
        createPortalUser: true,
        portalEmail: contactEmail.trim() || undefined,
        portalFullName: contactName.trim() || undefined,
      });
      return res;
    },
    onSuccess: async (res) => {
      setName('');
      setContactName('');
      setContactEmail('');
      const link = (res as any)?.inviteLink;
      setMsg(link ? `Invite link aangemaakt: ${link}` : 'Opdrachtgever aangemaakt.');
      await refetch();
    },
    onError: (e: any) => setErrMsg(e?.error ?? e?.message ?? 'Actie mislukt'),
  });

  const delM = useMutation({
    mutationFn: async (id: string) => deleteClient(id),
    onSuccess: async () => {
      setMsg('Opdrachtgever verwijderd.');
      await refetch();
    },
    onError: (e: any) => setErrMsg(e?.error ?? e?.message ?? 'Actie mislukt'),
  });

  const regenInviteM = useMutation({
    mutationFn: async (clientId: string) => regenerateClientInvite(clientId),
    onSuccess: (res: any) => {
      const link = res?.inviteLink;
      if (link) {
        navigator.clipboard?.writeText(link);
        setMsg('Invite link gekopieerd.');
      } else {
        setMsg('Invite regenerated.');
      }
    },
    onError: (e: any) => setErrMsg(e?.error ?? e?.message ?? 'Actie mislukt'),
  });

  const clients = (data?.clients ?? []) as any[];
  const totalCount = (data as any)?.totalCount as number | undefined;

  return (
    <div className="space-y-4">
      <Card className="p-4">
        <div className="font-medium text-gray-900 mb-3">Nieuwe opdrachtgever</div>
        <div className="grid gap-3 md:grid-cols-3">
          <div>
            <Label>Naam</Label>
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Bedrijfsnaam" />
          </div>
          <div>
            <Label>Contactnaam</Label>
            <Input value={contactName} onChange={(e) => setContactName(e.target.value)} placeholder="Naam" />
          </div>
          <div>
            <Label>Contact e-mail</Label>
            <Input value={contactEmail} onChange={(e) => setContactEmail(e.target.value)} placeholder="mail@bedrijf.nl" />
          </div>
        </div>
        <div className="mt-3 flex gap-2">
          <Button onClick={() => onboardM.mutate()} disabled={!name.trim() || onboardM.isPending}>
            Aanmaken + portal invite
          </Button>
          <Button variant="secondary" onClick={() => refetch()} disabled={isLoading}>
            Refresh
          </Button>
        </div>
      </Card>

      <ErrorBanner message={errMsg ?? (error as any)?.error ?? (error as any)?.message} />
      <SuccessBanner message={msg} />

      <Card className="p-4">
        <div className="flex items-end justify-between gap-3 flex-wrap">
          <div className="min-w-[260px]">
            <Label>Zoeken</Label>
            <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="naam / email" />
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <div className="text-xs text-gray-500">{totalCount ?? clients.length} opdrachtgever(s)</div>
            <PaginationControls
              page={page}
              pageSize={pageSize}
              totalCount={totalCount}
              onPageChange={(p) => setPage(Math.max(1, p))}
              onPageSizeChange={(ps) => {
                setPageSize(ps);
                setPage(1);
              }}
            />
          </div>
        </div>

        <div className="mt-3 space-y-2">
          {isLoading ? (
            <div className="text-sm text-gray-600">Laden…</div>
          ) : clients.length === 0 ? (
            <div className="text-sm text-gray-600">Geen opdrachtgevers.</div>
          ) : (
            clients.map((c) => (
              <div key={c.id} className="rounded-xl border border-gray-100 p-3 flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <div className="font-medium text-gray-900 truncate">{c.name}</div>
                  <div className="text-xs text-gray-600 truncate">
                    {c.contactName ?? ''} {c.contactEmail ? `• ${c.contactEmail}` : ''}
                  </div>
                  {c.isDeleted ? <Badge className="mt-1">DELETED</Badge> : null}
                </div>
                <div className="flex items-center gap-2 flex-wrap justify-end">
                  <Button variant="secondary" onClick={() => regenInviteM.mutate(c.id)} disabled={regenInviteM.isPending}>
                    Kopieer invite
                  </Button>
                  <Button variant="danger" onClick={() => delM.mutate(c.id)} disabled={delM.isPending}>
                    Verwijderen
                  </Button>
                </div>
              </div>
            ))
          )}
        </div>
      </Card>
    </div>
  );
}
