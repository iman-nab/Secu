import type React from 'react';
import { useMemo, useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Badge, Button, Card, ErrorBanner, Input, Label, SuccessBanner } from '../../../components/ui';
import { PaginationControls } from '../../../components/PaginationControls';
import { listClients } from '../../../api/clients';
import { listLocations } from '../../../api/locations';
import { createShift, deleteShift, listCalendarShifts, updateShift, repeatWeeklyShift } from '../../../api/shifts';
import { listUsers } from '../../../api/users';
import { useToast } from '../../../components/toast';
import { formatApiError } from '../../../api/errorMessages';

function Select(props: React.SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <select
      {...props}
      className={'w-full rounded border px-3 py-2 text-sm outline-none focus:ring ' + (props.className ?? '')}
    />
  );
}

function toISOFromLocal(value: string) {
  // value from <input type="datetime-local"> is "YYYY-MM-DDTHH:mm"
  if (!value) return '';
  const d = new Date(value);
  return d.toISOString();
}

function toLocalInputValue(d: Date) {
  // returns YYYY-MM-DDTHH:mm in local time
  const pad = (n: number) => String(n).padStart(2, '0');
  const yyyy = d.getFullYear();
  const mm = pad(d.getMonth() + 1);
  const dd = pad(d.getDate());
  const hh = pad(d.getHours());
  const mi = pad(d.getMinutes());
  return `${yyyy}-${mm}-${dd}T${hh}:${mi}`;
}

function addHoursLocal(startLocal: string, hours: number) {
  const d = new Date(startLocal);
  const ms = d.getTime() + hours * 60 * 60 * 1000;
  return toLocalInputValue(new Date(ms));
}

function normalizeEndAfterStartLocal(startLocal: string, endLocal: string) {
  if (!startLocal || !endLocal) return endLocal;
  const start = new Date(startLocal);
  const end = new Date(endLocal);
  if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime())) return endLocal;
  // If end is not after start, assume the shift runs past midnight and move end to the next day.
  if (end.getTime() <= start.getTime()) {
    end.setDate(end.getDate() + 1);
    return toLocalInputValue(end);
  }
  return endLocal;
}

function statusPillClass(status: string) {
  switch (status) {
    case 'OPEN':
      return 'border-emerald-200 bg-emerald-50 text-emerald-800';
    case 'DRAFT':
      // Legacy: treat DRAFT as OPEN in UI
      return 'border-emerald-200 bg-emerald-50 text-emerald-800';
    case 'CANCELLED':
      return 'border-rose-200 bg-rose-50 text-rose-800';
    default:
      return 'border-gray-200 bg-gray-50 text-gray-700';
  }
}

function passColorPillClass(c: string) {
  switch (c) {
    case 'GRAY':
      return 'border-gray-200 bg-gray-50 text-gray-700';
    case 'DARK_BLUE':
      return 'border-blue-200 bg-blue-50 text-blue-900';
    case 'LIGHT_BLUE':
      return 'border-sky-200 bg-sky-50 text-sky-900';
    case 'ORANGE':
      return 'border-orange-200 bg-orange-50 text-orange-900';
    case 'GREEN':
      return 'border-emerald-200 bg-emerald-50 text-emerald-800';
    case 'BLACK':
      return 'border-neutral-300 bg-neutral-900 text-white';
    default:
      return 'border-gray-200 bg-gray-50 text-gray-700';
  }
}

function occupancyPillClass(assigned: number, required: number) {
  if (!required || required <= 0) return 'border-gray-200 bg-gray-50 text-gray-700';
  if (assigned >= required) return 'border-rose-200 bg-rose-50 text-rose-800';
  const ratio = assigned / required;
  if (ratio >= 0.75) return 'border-amber-200 bg-amber-50 text-amber-900';
  return 'border-emerald-200 bg-emerald-50 text-emerald-800';
}

export default function ShiftsTab() {
  const qc = useQueryClient();
  const toast = useToast();

  const today = new Date();
  const [start, setStart] = useState(() => {
    const d = new Date(today);
    d.setDate(d.getDate() - 7);
    return d.toISOString().slice(0, 10);
  });
  const [end, setEnd] = useState(() => {
    const d = new Date(today);
    d.setDate(d.getDate() + 30);
    return d.toISOString().slice(0, 10);
  });
  const [includeDeleted, setIncludeDeleted] = useState(false);
  const [q, setQ] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('');
  const [locationFilterId, setLocationFilterId] = useState<string>('');
  const [clientFilterId, setClientFilterId] = useState<string>('');
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(50);
  // Input is a lightweight wrapper (no ref forwarding), so we focus via id.
  const focusTitle = () => {
    const el = document.getElementById('admin-shifts-title') as HTMLInputElement | null;
    el?.focus();
    el?.select?.();
  };

  // Create form
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [type, setType] = useState('GENERAL');
  const [requiredPassColor, setRequiredPassColor] = useState<'' | 'GRAY' | 'DARK_BLUE' | 'LIGHT_BLUE' | 'ORANGE' | 'GREEN' | 'BLACK'>('');
  // Product model: no DRAFT shifts; new shifts are OPEN.
  const status: 'OPEN' = 'OPEN';
  const [requiredWorkers, setRequiredWorkers] = useState<number>(1);
  const [locationId, setLocationId] = useState<string>('');
  const [clientId, setClientId] = useState<string>('');
  const [startAt, setStartAt] = useState<string>('');
  const [endAt, setEndAt] = useState<string>('');
  const [manualTimes, setManualTimes] = useState(false);

  // Remember last used defaults (templates-lite)
  const LS_KEY = 'rooster.shiftCreate.defaults.v1';

  // Quick create helpers
  const [quickDate, setQuickDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [quickStartTime, setQuickStartTime] = useState('18:00');
  const [quickDuration, setQuickDuration] = useState<number>(8);
  const [showAdvanced, setShowAdvanced] = useState(false);

  // Bulk selection
  const [selected, setSelected] = useState<Record<string, boolean>>({});

  // Keyboard shortcuts: N = focus title, / = focus search, Esc = clear selection
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (document.activeElement as any)?.tagName?.toLowerCase?.();
      const inInput = tag === 'input' || tag === 'textarea' || tag === 'select';
      if (e.key === '/' && !inInput) {
        e.preventDefault();
        (document.getElementById('admin-shifts-search') as HTMLInputElement | null)?.focus?.();
      }
      if ((e.key === 'n' || e.key === 'N') && !inInput) {
        e.preventDefault();
        (document.getElementById('admin-shifts-title') as HTMLInputElement | null)?.focus?.();
      }
      if (e.key === 'Escape') {
        setSelected({});
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  useEffect(() => {
    // Fill sensible defaults once when page opens
    // Load stored defaults
    try {
      const raw = localStorage.getItem(LS_KEY);
      if (raw) {
        const d = JSON.parse(raw);
        if (d.locationId) setLocationId(String(d.locationId));
        if (d.requiredWorkers) setRequiredWorkers(Number(d.requiredWorkers));
        if (d.requiredPassColor) setRequiredPassColor(d.requiredPassColor);
        if (d.type) setType(String(d.type));
        if (d.clientId) setClientId(String(d.clientId));
        if (d.quickDuration) setQuickDuration(Number(d.quickDuration));
        if (d.quickStartTime) setQuickStartTime(String(d.quickStartTime));
      }
    } catch {
      // ignore
    }
    if (!startAt && !endAt) {
      const startLocal = `${quickDate}T${quickStartTime}`;
      setStartAt(startLocal);
      setEndAt(addHoursLocal(startLocal, quickDuration));
      if (!title.trim()) setTitle('Dienst');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Persist defaults whenever key fields change
  useEffect(() => {
    try {
      localStorage.setItem(
        LS_KEY,
        JSON.stringify({
          locationId,
          requiredWorkers,
          requiredPassColor,
          type,
          clientId,
          quickDuration,
          quickStartTime,
        }),
      );
    } catch {
      // ignore
    }
  }, [locationId, requiredWorkers, requiredPassColor, type, clientId, quickDuration, quickStartTime]);

  // Keep start/end in sync with the quick inputs, unless the user manually edited datetime-local.
  useEffect(() => {
    if (manualTimes) return;
    const startLocal = `${quickDate}T${quickStartTime}`;
    setStartAt(startLocal);
    setEndAt(addHoursLocal(startLocal, quickDuration));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [quickDate, quickStartTime, quickDuration, manualTimes]);

  function applyQuickTimes() {
    setManualTimes(false);
    const startLocal = `${quickDate}T${quickStartTime}`;
    setStartAt(startLocal);
    setEndAt(addHoursLocal(startLocal, quickDuration));
    if (!title.trim()) setTitle('Dienst');
  }

  const [okMsg, setOkMsg] = useState('');
  const [errMsg, setErrMsg] = useState('');

  // Repeat + direct assignment
  const [repeatEnabled, setRepeatEnabled] = useState(false);
  const [repeatUntil, setRepeatUntil] = useState('');
  const [intervalWeeks, setIntervalWeeks] = useState(1);
  const [assigneeIds, setAssigneeIds] = useState<string[]>([]);

  const locQ = useQuery({ queryKey: ['admin', 'locations'], queryFn: () => listLocations() });
  const clientsQ = useQuery({ queryKey: ['admin', 'clients'], queryFn: () => listClients({ includeDeleted: false }) });
  const usersQ = useQuery({ queryKey: ['admin', 'users'], queryFn: () => listUsers(), staleTime: 60_000 });

  const employees = useMemo(() => {
    const all = (usersQ.data as any)?.users ?? [];
    return all
      .filter((u: any) => u.role === 'EMPLOYEE')
      .filter((u: any) => u.isActive !== false)
      .sort((a: any, b: any) => String(a.fullName || a.email).localeCompare(String(b.fullName || b.email), 'nl'));
  }, [usersQ.data]);

  // Reset pagination and selection when filters change
  useEffect(() => {
    setPage(1);
    setSelected({});
  }, [start, end, includeDeleted, q, pageSize, statusFilter, locationFilterId, clientFilterId]);

  const shiftsQ = useQuery({
    queryKey: ['admin', 'shifts', { start, end, includeDeleted, q, page, pageSize, statusFilter, locationFilterId, clientFilterId }],
    // Use lightweight calendar summary endpoint (much faster than full /shifts with relations).
    queryFn: () =>
      listCalendarShifts({
        start,
        end,
        includeDeleted,
        q: q.trim() || undefined,
        page,
        pageSize,
        status: statusFilter || undefined,
        locationId: locationFilterId || undefined,
        clientId: clientFilterId || undefined,
      }),
  });

  const shiftsKeyBase = ['admin', 'shifts'] as const;

  const createM = useMutation({
    mutationFn: async () => {
      if (!locationId) throw { error: 'Kies een locatie.' };
      if (!startAt || !endAt) throw { error: 'Start/eind tijd verplicht.' };

      // Overnight support: if end <= start, automatically roll end to the next day.
      const fixedEndLocal = normalizeEndAfterStartLocal(startAt, endAt);
      const startIso = toISOFromLocal(startAt);
      const endIso = toISOFromLocal(fixedEndLocal);
      if (new Date(endIso).getTime() <= new Date(startIso).getTime()) {
        throw { error: 'Eindtijd moet na starttijd liggen.' };
      }
      const payload: any = {
        title: title.trim(),
        description: description.trim() || undefined,
        type,
        requiredPassColor: requiredPassColor || undefined,
        status,
        requiredWorkers: Number(requiredWorkers) || 1,
        locationId,
        startAt: startIso,
        endAt: endIso,
      };
      if (clientId) payload.clientId = clientId;

      if (assigneeIds.length > 0) payload.assigneeIds = assigneeIds;

      if (repeatEnabled) {
        if (!repeatUntil) throw { error: 'Kies een einddatum voor herhalen.' };
        return repeatWeeklyShift({
          ...payload,
          requiredPassColor: requiredPassColor || null,
          repeatUntil,
          intervalWeeks,
        });
      }

      return createShift(payload);
    },
    onMutate: async () => {
      setOkMsg('');
      setErrMsg('');
    },
    onSuccess: async () => {
      setOkMsg(repeatEnabled ? 'Diensten herhaald aangemaakt.' : 'Dienst aangemaakt.');
      setErrMsg('');
      setTitle('');
      setDescription('');
      setStartAt('');
      setEndAt('');
      setRepeatEnabled(false);
      setRepeatUntil('');
      setIntervalWeeks(1);
      setAssigneeIds([]);
      setPage(1);
      await qc.invalidateQueries({ queryKey: shiftsKeyBase as any });
    },
    onError: (e: any) => {
      setErrMsg(e?.error ?? e?.message ?? 'Aanmaken mislukt');
      setOkMsg('');
    },
  });

  const deleteM = useMutation({
    mutationFn: (id: string) => deleteShift(id),
    onMutate: async () => {
      setOkMsg('');
      setErrMsg('');
    },
    onSuccess: async () => {
      setOkMsg('Dienst verwijderd (soft delete).');
      setErrMsg('');
      await qc.invalidateQueries({ queryKey: shiftsKeyBase as any });
    },
    onError: (e: any) => {
      setErrMsg(e?.error ?? e?.message ?? 'Verwijderen mislukt');
      setOkMsg('');
    },
  });

  const bulkUpdateM = useMutation({
    mutationFn: async (input: { ids: string[]; patch: any }) => {
      const { ids, patch } = input;
      await Promise.all(ids.map((sid) => updateShift(sid, patch)));
      return true;
    },
    onSuccess: async () => {
      toast.success('Bulk update uitgevoerd');
      await qc.invalidateQueries({ queryKey: shiftsKeyBase as any });
      setSelected({});
    },
    onError: (e: any) => {
      toast.error(formatApiError(e) || 'Bulk update mislukt');
    },
  });

  const bulkDeleteM = useMutation({
    mutationFn: async (ids: string[]) => {
      await Promise.all(ids.map((sid) => deleteShift(sid)));
      return true;
    },
    onSuccess: async () => {
      toast.success('Diensten verwijderd');
      await qc.invalidateQueries({ queryKey: shiftsKeyBase as any });
      setSelected({});
    },
    onError: (e: any) => {
      toast.error(formatApiError(e) || 'Bulk verwijderen mislukt');
    },
  });

  const shifts = (shiftsQ.data?.shifts ?? []) as any[];
  const totalCount = (shiftsQ.data as any)?.totalCount as number | undefined;

  const timeError = useMemo(() => {
    if (!startAt || !endAt) return '';
    try {
      const s = new Date(toISOFromLocal(startAt)).getTime();
      const e = new Date(toISOFromLocal(endAt)).getTime();
      if (!Number.isFinite(s) || !Number.isFinite(e)) return 'Ongeldige datum/tijd.';
      if (e <= s) return 'Eindtijd moet na starttijd liggen.';
    } catch {
      return 'Ongeldige datum/tijd.';
    }
    return '';
  }, [startAt, endAt]);

  const canCreate = !!locationId && title.trim().length >= 2 && !!startAt && !!endAt && !timeError && !createM.isPending;

  // Admin keyboard shortcuts (best-effort):
  // - N: focus the "Titel" field
  // - Ctrl/Cmd+S: create shift (when valid)
  useEffect(() => {
    const onNew = (e: Event) => {
      const detailTab = (e as any).detail?.tab;
      if (detailTab && detailTab !== 'shifts') return;
      focusTitle();
    };
    const onSave = (e: Event) => {
      const detailTab = (e as any).detail?.tab;
      if (detailTab && detailTab !== 'shifts') return;
      if (canCreate) createM.mutate();
    };

    window.addEventListener('rooster:admin:new', onNew as any);
    window.addEventListener('rooster:admin:save', onSave as any);
    return () => {
      window.removeEventListener('rooster:admin:new', onNew as any);
      window.removeEventListener('rooster:admin:save', onSave as any);
    };
  }, [canCreate, createM]);

  const filtered = shifts;

  const selectedIds = useMemo(() => Object.keys(selected).filter((k) => selected[k]), [selected]);

  return (
    <div className="space-y-4">
      <Card className="p-4">
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <div className="font-medium text-gray-900">Nieuwe dienst</div>
          <Button variant="secondary" onClick={() => setShowAdvanced((v) => !v)}>
            {showAdvanced ? 'Minder opties' : 'Meer opties'}
          </Button>
        </div>

        {/* Quick create */}
        <div className="grid gap-3 mt-3 md:grid-cols-3">
          <div>
            <Label>Locatie</Label>
            <Select value={locationId} onChange={(e) => setLocationId(e.target.value)}>
              <option value="">— Kies locatie —</option>
              {(locQ.data?.locations ?? []).map((l: any) => (
                <option key={l.id} value={l.id}>
                  {l.name}
                </option>
              ))}
            </Select>
          </div>
          <div>
            <Label>Benodigde bezetting</Label>
            <Input type="number" min={1} max={50} value={requiredWorkers} onChange={(e) => setRequiredWorkers(Number(e.target.value))} />
          </div>
          <div>
            <Label>Kleurpas vereist</Label>
            <Select value={requiredPassColor} onChange={(e) => setRequiredPassColor(e.target.value as any)}>
              <option value="">Geen</option>
              <option value="GRAY">GRIJS</option>
              <option value="DARK_BLUE">DONKERBLAUW</option>
              <option value="LIGHT_BLUE">LICHTBLAUW</option>
              <option value="ORANGE">ORANJE</option>
              <option value="GREEN">GROEN</option>
              <option value="BLACK">ZWART</option>
            </Select>
            <div className="mt-1 text-xs text-gray-500">Laat leeg als iedereen kan werken.</div>
          </div>
        </div>

        <div className="grid gap-3 mt-3 md:grid-cols-5">
          <div>
            <Label>Datum</Label>
            <Input type="date" value={quickDate} onChange={(e) => setQuickDate(e.target.value)} />
          </div>
          <div>
            <Label>Starttijd</Label>
            <Input type="time" value={quickStartTime} onChange={(e) => setQuickStartTime(e.target.value)} />
          </div>
          <div>
            <Label>Duur (uren)</Label>
            <Select value={String(quickDuration)} onChange={(e) => setQuickDuration(Number(e.target.value))}>
              <option value="4">4</option>
              <option value="6">6</option>
              <option value="8">8</option>
              <option value="10">10</option>
              <option value="12">12</option>
            </Select>
          </div>
          <div>
            <Label>Eindtijd</Label>
            <Input type="time" value={(endAt?.split('T')?.[1] ?? '').slice(0, 5)} readOnly />
          </div>
          <div className="flex items-end gap-2">
            <Button variant="secondary" onClick={applyQuickTimes}>
              Zet tijden
            </Button>
            <div className="flex gap-1">
              {[4, 6, 8, 12].map((h) => (
                <button
                  key={h}
                  type="button"
                  onClick={() => {
                    setQuickDuration(h);
                    const startLocal = `${quickDate}T${quickStartTime}`;
                    setStartAt(startLocal);
                    setEndAt(addHoursLocal(startLocal, h));
                  }}
                  className={
                    'rounded-lg border px-2 py-1 text-xs ' +
                    (quickDuration === h ? 'border-gray-300 bg-gray-50 text-gray-900' : 'border-gray-100 hover:bg-gray-50 text-gray-700')
                  }
                >
                  {h}u
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-3 grid gap-3 md:grid-cols-2">
          <div>
            <Label>Titel</Label>
            <Input id="admin-shifts-title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Bijv. Avonddienst" />
          </div>
          <div>
            <Label>Status</Label>
            <div className="mt-1 rounded-xl border bg-gray-50 px-3 py-2 text-sm text-gray-800">
              OPEN
            </div>
            <div className="mt-1 text-xs text-gray-600">Nieuwe diensten worden automatisch als OPEN aangemaakt.</div>
          </div>
        </div>

        <div className="mt-2 text-xs text-gray-600">
          Start: <span className="font-mono">{startAt || '—'}</span> • Eind: <span className="font-mono">{endAt || '—'}</span>
        </div>

        {timeError ? <div className="mt-2 text-sm text-rose-700">{timeError}</div> : null}

        {showAdvanced ? (
          <div className="mt-4 pt-4 border-t border-gray-100 space-y-3">
            <div className="grid gap-3 md:grid-cols-3">
              <div>
                <Label>Type</Label>
                <Input value={type} onChange={(e) => setType(e.target.value)} placeholder="GENERAL" />
              </div>
              <div>
                <Label>Opdrachtgever (optioneel)</Label>
                <Select value={clientId} onChange={(e) => setClientId(e.target.value)}>
                  <option value="">— Geen —</option>
                  {(clientsQ.data?.clients ?? []).map((c: any) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </Select>
              </div>
              <div>
                <Label>Omschrijving (optioneel)</Label>
                <Input value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Extra info" />
              </div>
            </div>

            <div className="grid gap-3 md:grid-cols-2">
              <div>
                <Label>Start (handmatig)</Label>
              <Input
                type="datetime-local"
                value={startAt}
                onChange={(e) => {
                  setManualTimes(true);
                  setStartAt(e.target.value);
                }}
              />
              </div>
              <div>
                <Label>Eind (handmatig)</Label>
              <Input
                type="datetime-local"
                value={endAt}
                onChange={(e) => {
                  setManualTimes(true);
                  const next = normalizeEndAfterStartLocal(startAt, e.target.value);
                  setEndAt(next);
                }}
              />
              <div className="mt-1 text-xs text-gray-500">
                Handmatig aangepast.{' '}
                <button type="button" className="underline" onClick={applyQuickTimes}>
                  Terug naar snelle tijden
                </button>
              </div>
              </div>
            </div>

            <div className="grid gap-3 md:grid-cols-3">
              <div className="md:col-span-2">
                <Label>Personeel direct toewijzen (optioneel)</Label>
                <select
                  multiple
                  value={assigneeIds}
                  onChange={(e) => {
                    const opts = Array.from(e.target.selectedOptions).map((o) => o.value);
                    setAssigneeIds(opts);
                  }}
                  className="w-full rounded border px-3 py-2 text-sm"
                  style={{ minHeight: 120 }}
                >
                  {employees.map((u: any) => (
                    <option key={u.id} value={u.id}>
                      {(u.fullName || u.email) + (u.passColor ? ` (${u.passColor})` : '')}
                    </option>
                  ))}
                </select>
                <div className="mt-1 text-xs text-gray-500">Houd Ctrl/Cmd ingedrukt om meerdere te selecteren.</div>
              </div>

              <div>
                <Label>Herhalen</Label>
                <div className="mt-2 flex items-center gap-2">
                  <input
                    id="repeatEnabled"
                    type="checkbox"
                    checked={repeatEnabled}
                    onChange={(e) => setRepeatEnabled(e.target.checked)}
                  />
                  <label htmlFor="repeatEnabled" className="text-sm text-gray-800">
                    Wekelijks herhalen
                  </label>
                </div>
                {repeatEnabled ? (
                  <div className="mt-2 space-y-2">
                    <div>
                      <Label>Tot en met</Label>
                      <Input type="date" value={repeatUntil} onChange={(e) => setRepeatUntil(e.target.value)} />
                    </div>
                    <div>
                      <Label>Interval (weken)</Label>
                      <Input
                        type="number"
                        min={1}
                        max={12}
                        value={intervalWeeks}
                        onChange={(e) => setIntervalWeeks(Number(e.target.value) || 1)}
                      />
                    </div>
                    <div className="text-xs text-gray-500">Maakt dezelfde dienst aan op dezelfde dag/tijd.</div>
                  </div>
                ) : null}
              </div>
            </div>
          </div>
        ) : null}

        <div className="mt-4">
          <Button onClick={() => createM.mutate()} disabled={!canCreate}>
            Dienst aanmaken
          </Button>
          {!locationId ? <div className="mt-2 text-sm text-rose-700">Kies een locatie om door te gaan.</div> : null}
          {title.trim().length > 0 && title.trim().length < 2 ? <div className="mt-1 text-sm text-rose-700">Titel is te kort.</div> : null}
        </div>
      </Card>

      <ErrorBanner message={errMsg || (shiftsQ.error as any)?.error || (shiftsQ.error as any)?.message} />
      <SuccessBanner message={okMsg} />

      <Card className="p-4">
        <div className="flex flex-wrap gap-3 items-end justify-between">
          <div className="grid gap-3 md:grid-cols-6">
            <div>
              <Label>Vanaf</Label>
              <Input type="date" value={start} onChange={(e) => setStart(e.target.value)} />
            </div>
            <div>
              <Label>Tot</Label>
              <Input type="date" value={end} onChange={(e) => setEnd(e.target.value)} />
            </div>
            <div>
              <Label>Status</Label>
              <select
                className="mt-1 w-full rounded border px-3 py-2 text-sm"
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
              >
                <option value="">Alle</option>
                <option value="OPEN">Open</option>
                <option value="ASSIGNED">Ingepland</option>
                <option value="COMPLETED">Afgerond</option>
                <option value="CANCELLED">Geannuleerd</option>
              </select>
            </div>
            <div>
              <Label>Locatie</Label>
              <select
                className="mt-1 w-full rounded border px-3 py-2 text-sm"
                value={locationFilterId}
                onChange={(e) => setLocationFilterId(e.target.value)}
              >
                <option value="">Alle locaties</option>
                {(locQ.data as any)?.locations?.map((l: any) => (
                  <option key={l.id} value={l.id}>
                    {l.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <Label>Opdrachtgever</Label>
              <select
                className="mt-1 w-full rounded border px-3 py-2 text-sm"
                value={clientFilterId}
                onChange={(e) => setClientFilterId(e.target.value)}
              >
                <option value="">Alle opdrachtgevers</option>
                {(clientsQ.data as any)?.clients?.map((c: any) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <Label>Zoeken</Label>
              <Input id="admin-shifts-search" value={q} onChange={(e) => setQ(e.target.value)} placeholder="titel/type/status" />
            </div>
            <div className="flex items-end gap-2">
              <label className="text-sm text-gray-700 flex items-center gap-2">
                <input type="checkbox" checked={includeDeleted} onChange={(e) => setIncludeDeleted(e.target.checked)} />
                Toon verwijderd
              </label>
            </div>
          </div>
          <Button variant="secondary" onClick={() => shiftsQ.refetch()} disabled={shiftsQ.isLoading}>
            Refresh
          </Button>
        </div>
      </Card>

      <Card className="p-4">
        <div className="flex items-center justify-between gap-3 flex-wrap mb-3">
          <div className="text-sm text-gray-700 font-medium">
            Diensten ({totalCount ?? filtered.length})
          </div>
          <PaginationControls
            page={page}
            pageSize={pageSize}
            totalCount={totalCount}
            onPageChange={(p) => {
              setPage(Math.max(1, p));
              setSelected({});
            }}
            onPageSizeChange={(ps) => {
              setPageSize(ps);
              setPage(1);
              setSelected({});
            }}
          />
        </div>
        {shiftsQ.isLoading ? (
          <div className="space-y-2">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="h-16 rounded-xl border border-gray-100 bg-gray-50 animate-pulse" />
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-sm text-gray-600">
            Geen diensten in deze periode. <span className="text-gray-500">Tip: druk op</span>{' '}
            <span className="font-mono rounded bg-gray-100 px-1">N</span> <span className="text-gray-500">om snel een dienst te maken.</span>
          </div>
        ) : (
          <div className="space-y-2">
            {/* Bulk actions */}
            {selectedIds.length ? (
              <div className="sticky top-0 z-10 rounded-xl border bg-white p-3 flex flex-wrap items-center justify-between gap-2">
                <div className="text-sm text-gray-700">
                  Geselecteerd: <span className="font-semibold">{selectedIds.length}</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  <Button
                    variant="secondary"
                    onClick={() => bulkUpdateM.mutate({ ids: selectedIds, patch: { status: 'OPEN' } })}
                    disabled={bulkUpdateM.isPending}
                  >
                    Zet OPEN
                  </Button>
                  <Button
                    variant="danger"
                    onClick={() => {
                      const ok = window.confirm(`Weet je zeker dat je ${selectedIds.length} diensten wilt verwijderen?`);
                      if (ok) bulkDeleteM.mutate(selectedIds);
                    }}
                    disabled={bulkDeleteM.isPending}
                  >
                    Verwijder
                  </Button>
                  <Button variant="secondary" onClick={() => setSelected({})}>Reset</Button>
                </div>
              </div>
            ) : null}

            {/* Select all row */}
            <div className="flex items-center justify-between rounded-xl border border-gray-100 bg-white p-2">
              <label className="flex items-center gap-2 text-sm text-gray-700">
                <input
                  type="checkbox"
                  checked={filtered.length > 0 && filtered.every((s) => selected[s.id])}
                  onChange={(e) => {
                    const on = e.target.checked;
                    const next: Record<string, boolean> = {};
                    if (on) filtered.forEach((s) => (next[s.id] = true));
                    setSelected(next);
                  }}
                />
                Selecteer alles
              </label>
              <div className="text-xs text-gray-500">Tip: druk op <span className="font-mono rounded bg-gray-100 px-1">Esc</span> om selectie te wissen.</div>
            </div>

            {filtered.map((s) => {
              const startTxt = new Date(s.startAt).toLocaleString();
              const endTxt = new Date(s.endAt).toLocaleString();
              const deleted = !!s.isDeleted;
              const assignedCount = (s?._count?.assignments ?? s.assignments?.length ?? 0) as number;
              const occ = typeof s.requiredWorkers === 'number' ? `${assignedCount}/${s.requiredWorkers}` : '';
              return (
                <div key={s.id} className="rounded-xl border border-gray-100 p-3 flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <input
                      type="checkbox"
                      checked={!!selected[s.id]}
                      onChange={(e) => setSelected((prev) => ({ ...prev, [s.id]: e.target.checked }))}
                      aria-label="Selecteer dienst"
                    />
                  <div className="min-w-0">
                    <div className="font-medium text-gray-900 truncate">{s.title}</div>
                    <div className="text-xs text-gray-600 truncate">
                      {startTxt} – {endTxt} • {s.location?.name ?? s.locationId}
                    </div>
                  </div>
                  </div>
                  <div className="flex items-center gap-2 flex-wrap justify-end">
                    <Badge className={statusPillClass(String(s.status))}>{String(s.status) === 'DRAFT' ? 'OPEN' : s.status}</Badge>
                    <Badge>{s.type}</Badge>
                    <Badge className={passColorPillClass(String(s.requiredPassColor))}>{s.requiredPassColor}</Badge>
                    {typeof s.requiredWorkers === 'number' ? (
                      <Badge
                        className={occupancyPillClass(Number(assignedCount), Number(s.requiredWorkers))}
                      >
                        Bezetting {assignedCount}/{s.requiredWorkers}
                      </Badge>
                    ) : null}
                    {deleted ? <Badge className="border-gray-300 bg-gray-100 text-gray-700">DELETED</Badge> : null}
                    <Link to={`/diensten/${s.id}`} className="text-sm underline text-gray-700">
                      Open
                    </Link>
                    {!deleted ? (
                      <Button variant="danger" onClick={() => deleteM.mutate(s.id)} disabled={deleteM.isPending}>
                        Verwijder
                      </Button>
                    ) : null}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </Card>
    </div>
  );
}
