import { useEffect } from 'react';
import { Circle, MapContainer, Marker, TileLayer, useMap, useMapEvents } from 'react-leaflet';

function MapViewSync({ lat, lng }: { lat: number; lng: number }) {
  const map = useMap();
  useEffect(() => {
    if (!Number.isFinite(lat) || !Number.isFinite(lng)) return;
    map.setView([lat, lng], map.getZoom(), { animate: true });
  }, [lat, lng, map]);
  return null;
}

function ClickHandler({ onPick }: { onPick: (lat: number, lng: number) => void }) {
  useMapEvents({
    click(e) {
      onPick(e.latlng.lat, e.latlng.lng);
    },
  });
  return null;
}

export function LocationMapPicker({
  lat,
  lng,
  radiusM,
  onPick,
}: {
  lat: number;
  lng: number;
  radiusM: number;
  onPick: (lat: number, lng: number) => void;
}) {
  const safeLat = Number.isFinite(lat) ? lat : 52.370216;
  const safeLng = Number.isFinite(lng) ? lng : 4.895168;
  const safeRadius = Number.isFinite(radiusM) && radiusM > 0 ? radiusM : 150;

  return (
    <div className="rounded-xl overflow-hidden border" style={{ height: 320 }}>
      <MapContainer center={[safeLat, safeLng]} zoom={14} style={{ height: '100%', width: '100%' }}>
        <TileLayer
          attribution="&copy; OpenStreetMap contributors"
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        <MapViewSync lat={safeLat} lng={safeLng} />
        <ClickHandler onPick={onPick} />

        <Circle center={[safeLat, safeLng] as [number, number]} radius={safeRadius} />
        <Marker
          position={[safeLat, safeLng] as [number, number]}
          draggable
          eventHandlers={{
            dragend: (e) => {
              const m = e.target;
              const p = m.getLatLng();
              onPick(p.lat, p.lng);
            },
          }}
        />
      </MapContainer>
    </div>
  );
}
