import React from 'react';
import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Badge, Button, Card, ErrorBanner, Input, Label, SuccessBanner } from '../../../components/ui';
import { listUsers, reactivateUser, adminReset2FA, adminResetPassword, updateUserPassColor } from '../../../api/users';
import { createInvite, type InviteRole } from '../../../api/invites';
import {
  listClients,
  onboardClient,
  regenerateClientInvite,
  deleteClient,
  createClientPortalUser,
  type Client,
} from '../../../api/clients';

function Select(props: React.SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <select
      {...props}
      className={'w-full rounded border px-3 py-2 text-sm outline-none focus:ring ' + (props.className ?? '')}
    />
  );
}

type CreateKind = 'USER' | 'CLIENT';
type ListFilter = 'ALL' | 'USERS' | 'SUBCONTRACTORS' | 'CLIENTS';

function rolePillClass(role: string) {
  switch (role) {
    case 'ADMIN':
      return 'border-red-200 bg-red-50 text-red-800';
    case 'SUBCONTRACTOR':
      return 'border-purple-200 bg-purple-50 text-purple-800';
    case 'EMPLOYEE':
      return 'border-blue-200 bg-blue-50 text-blue-800';
    case 'CLIENT':
      return 'border-emerald-200 bg-emerald-50 text-emerald-800';
    default:
      return 'border-gray-200 bg-gray-50 text-gray-800';
  }
}

function statusPillClass(status: string) {
  switch (status) {
    case 'ACTIVE':
      return 'border-emerald-200 bg-emerald-50 text-emerald-800';
    case 'INACTIVE':
      return 'border-amber-200 bg-amber-50 text-amber-900';
    case 'DELETED':
      return 'border-gray-300 bg-gray-100 text-gray-700';
    default:
      return 'border-gray-200 bg-gray-50 text-gray-800';
  }
}

function twofaPillClass(on: boolean) {
  return on ? 'border-emerald-200 bg-emerald-50 text-emerald-800' : 'border-rose-200 bg-rose-50 text-rose-800';
}

function statusLabel(u: any) {
  if (u?.status) return String(u.status);
  if (u?.isActive === false) return 'INACTIVE';
  return 'ACTIVE';
}

/**
 * Eén plek voor:
 * - Opdrachtgevers (aanmaken + portal invite)
 * - Gebruikers (invites + beheer)
 */
export default function AccountsTab() {
  const qc = useQueryClient();

  const [filter, setFilter] = useState<ListFilter>('ALL');
  const [q, setQ] = useState('');

  // Pagination (server-side)
  const [userPage, setUserPage] = useState(1);
  const [userPageSize, setUserPageSize] = useState(25);
  const [subPage, setSubPage] = useState(1);
  const [subPageSize, setSubPageSize] = useState(25);
  const [clientPage, setClientPage] = useState(1);
  const [clientPageSize, setClientPageSize] = useState(25);

  useEffect(() => {
    // Reset paging when search/filter changes
    setUserPage(1);
    setSubPage(1);
    setClientPage(1);
  }, [filter, q]);

  // Users list = internal users only (EMPLOYEE + ADMIN). Subcontractors are listed separately.
  const usersParams = useMemo(() => {
    const s = q.trim();
    return { page: userPage, pageSize: userPageSize, q: s || undefined, roles: ['ADMIN', 'EMPLOYEE'] as any };
  }, [q, userPage, userPageSize]);

  const subsParams = useMemo(() => {
    const s = q.trim();
    return { page: subPage, pageSize: subPageSize, q: s || undefined, role: 'SUBCONTRACTOR' as any };
  }, [q, subPage, subPageSize]);

  const usersQ = useQuery({
    queryKey: ['admin', 'users', usersParams],
    queryFn: () => listUsers({ ...(usersParams as any), includeLastWorked: false }),
  });

  const subsListQ = useQuery({
    queryKey: ['admin', 'subcontractors-list', subsParams],
    queryFn: () => listUsers({ ...(subsParams as any), includeLastWorked: false }),
  });

  const clientsParams = useMemo(() => {
    const s = q.trim();
    return { includeDeleted: true, page: clientPage, pageSize: clientPageSize, q: s || undefined };
  }, [q, clientPage, clientPageSize]);

  const clientsQ = useQuery({
    queryKey: ['admin', 'clients', clientsParams],
    queryFn: () => listClients(clientsParams),
  });

  // Small list for invite flow (subcontractors select)
  const subsQ = useQuery({
    queryKey: ['admin', 'subcontractors'],
    queryFn: () => listUsers({ page: 1, pageSize: 200, role: 'SUBCONTRACTOR' as any, includeLastWorked: false }),
  });

  const users = (usersQ.data?.users ?? []) as any[];
  const usersTotal = (usersQ.data as any)?.totalCount ?? users.length;
  const subsList = ((subsListQ.data as any)?.users ?? []) as any[];
  const subsTotal = (subsListQ.data as any)?.totalCount ?? subsList.length;
  const clients = (clientsQ.data?.clients ?? []) as Client[];
  const clientsTotal = (clientsQ.data as any)?.totalCount ?? clients.length;

  const subcontractors = ((subsQ.data as any)?.users ?? []) as any[];
  const activeSubcontractors = subcontractors.filter((u) => u.role === 'SUBCONTRACTOR' && statusLabel(u) === 'ACTIVE');

  const [createKind, setCreateKind] = useState<CreateKind>('USER');

  // shared notifications
  const [okMsg, setOkMsg] = useState('');
  const [errMsg, setErrMsg] = useState('');

  // result links
  const [resultLink, setResultLink] = useState('');
  const [resultHint, setResultHint] = useState('');

  // USER invite form
  const [inviteRole, setInviteRole] = useState<InviteRole>('EMPLOYEE');
  const [invitePassColor, setInvitePassColor] = useState('');
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteName, setInviteName] = useState('');
  const [inviteSubId, setInviteSubId] = useState('');
  const [expiresInHours, setExpiresInHours] = useState<number>(72);

  // CLIENT form
  const [clientName, setClientName] = useState('');
  const [contactName, setContactName] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [makePortalUser, setMakePortalUser] = useState(true);
  const [portalFullName, setPortalFullName] = useState('');
  const [portalEmail, setPortalEmail] = useState('');

  // Admin reset password result (shown once)
  const [tempPwd, setTempPwd] = useState('');
  const [tempPwdEmail, setTempPwdEmail] = useState('');

  const createUserInviteM = useMutation({
    mutationFn: async () => {
      const payload: any = {
        email: inviteEmail.trim(),
        fullName: inviteName.trim(),
        role: inviteRole,
        passColor: inviteRole === 'EMPLOYEE' ? invitePassColor : null,
        expiresInHours: Number(expiresInHours) || 72,
      };
      if (inviteRole === 'EMPLOYEE' && inviteSubId) payload.subcontractorId = inviteSubId;
      const res = await createInvite(payload);
      return res.invite;
    },
    onSuccess: async (invite) => {
      const link = `${window.location.origin}/signup/${invite.token}`;
      setResultLink(link);
      setResultHint(`Invite gemaakt. Verloopt op ${new Date(invite.expiresAt).toLocaleString()}`);
      setOkMsg('Invite aangemaakt.');
      setErrMsg('');
      await qc.invalidateQueries({ queryKey: ['admin', 'users'] });
    },
    onError: (e: any) => {
      setErrMsg(e?.error ?? e?.message ?? 'Invite maken mislukt');
      setOkMsg('');
    },
  });

  const onboardClientM = useMutation({
    mutationFn: async () => {
      const res = await onboardClient({
        name: clientName.trim(),
        contactName: contactName.trim() || undefined,
        contactEmail: contactEmail.trim() || undefined,
        createPortalUser: !!makePortalUser,
        portalFullName: portalFullName.trim() || undefined,
        portalEmail: portalEmail.trim() || undefined,
      });
      return res;
    },
    onSuccess: async (res) => {
      setOkMsg('Opdrachtgever aangemaakt.');
      setErrMsg('');
      if (res.inviteLink) {
        setResultLink(res.inviteLink);
        setResultHint(`Portal invite gemaakt. Verloopt op ${res.inviteExpiresAt ? new Date(res.inviteExpiresAt).toLocaleString() : '—'}`);
      } else {
        setResultLink('');
        setResultHint('');
      }
      // reset only the create form
      setClientName('');
      setContactName('');
      setContactEmail('');
      setPortalFullName('');
      setPortalEmail('');
      await qc.invalidateQueries({ queryKey: ['admin', 'clients'] });
    },
    onError: (e: any) => {
      setErrMsg(e?.error ?? e?.message ?? 'Opdrachtgever aanmaken mislukt');
      setOkMsg('');
    },
  });

  const regenerateInviteM = useMutation({
    mutationFn: async (clientId: string) => regenerateClientInvite(clientId),
    onSuccess: (res) => {
      if (res.inviteLink) {
        setResultLink(res.inviteLink);
        setResultHint(`Portal invite vernieuwd. Verloopt op ${res.inviteExpiresAt ? new Date(res.inviteExpiresAt).toLocaleString() : '—'}`);
      }
      setOkMsg('Invite vernieuwd.');
      setErrMsg('');
    },
    onError: (e: any) => {
      setErrMsg(e?.error ?? e?.message ?? 'Invite vernieuwen mislukt');
      setOkMsg('');
    },
  });

  const createPortalUserM = useMutation({
    mutationFn: async (input: { clientId: string; portalEmail?: string; portalFullName?: string }) =>
      createClientPortalUser(input.clientId, { portalEmail: input.portalEmail, portalFullName: input.portalFullName }),
    onSuccess: (res) => {
      if (res.inviteLink) {
        setResultLink(res.inviteLink);
        setResultHint(`Portal invite gemaakt. Verloopt op ${res.inviteExpiresAt ? new Date(res.inviteExpiresAt).toLocaleString() : '—'}`);
      }
      setOkMsg('Portal user/invite aangemaakt.');
      setErrMsg('');
    },
    onError: (e: any) => {
      setErrMsg(e?.error ?? e?.message ?? 'Portal user maken mislukt');
      setOkMsg('');
    },
  });

  const deleteClientM = useMutation({
    mutationFn: async (clientId: string) => deleteClient(clientId),
    onSuccess: async () => {
      setOkMsg('Opdrachtgever verwijderd.');
      setErrMsg('');
      await qc.invalidateQueries({ queryKey: ['admin', 'clients'] });
    },
    onError: (e: any) => {
      setErrMsg(e?.error ?? e?.message ?? 'Verwijderen mislukt');
      setOkMsg('');
    },
  });

  const reactivateM = useMutation({
    mutationFn: async (id: string) => reactivateUser(id),
    onSuccess: async () => {
      setOkMsg('User heractiveerd.');
      setErrMsg('');
      await qc.invalidateQueries({ queryKey: ['admin', 'users'] });
    },
    onError: (e: any) => {
      setErrMsg(e?.error ?? e?.message ?? 'Heractiveren mislukt');
      setOkMsg('');
    },
  });

  const reset2faM = useMutation({
    mutationFn: async (id: string) => adminReset2FA(id),
    onSuccess: async () => {
      setOkMsg('2FA reset uitgevoerd.');
      setErrMsg('');
      await qc.invalidateQueries({ queryKey: ['admin', 'users'] });
    },
    onError: (e: any) => {
      setErrMsg(e?.error ?? e?.message ?? '2FA reset mislukt');
      setOkMsg('');
    },
  });

  const resetPasswordM = useMutation({
    mutationFn: async (id: string) => adminResetPassword(id),
    onSuccess: async (res) => {
      setTempPwd(res.tempPassword);
      setTempPwdEmail(res.user?.email ?? '');
      setOkMsg('Wachtwoord hersteld.');
      setErrMsg('');
      await qc.invalidateQueries({ queryKey: ['admin', 'users'] });
    },
    onError: (e: any) => {
      setErrMsg(e?.error ?? e?.message ?? 'Wachtwoord reset mislukt');
      setOkMsg('');
    },
  });

  const setPassColorM = useMutation({
    mutationFn: async (input: { id: string; passColor: string | null }) =>
      updateUserPassColor(input.id, input.passColor),
    onSuccess: async () => {
      setOkMsg('Kleurpas bijgewerkt.');
      setErrMsg('');
      await qc.invalidateQueries({ queryKey: ['admin', 'users'] });
    },
    onError: (e: any) => {
      setErrMsg(e?.error ?? e?.message ?? 'Kleurpas bijwerken mislukt');
      setOkMsg('');
    },
  });

  // Server-side search already applies; keep a light client-side guard for robustness.
  const filteredUsers = useMemo(() => users ?? [], [users]);
  const filteredSubcontractors = useMemo(() => subsList ?? [], [subsList]);
  const filteredClients = useMemo(() => clients ?? [], [clients]);

  async function copy(text: string) {
    try {
      await navigator.clipboard.writeText(text);
      setOkMsg('Gekopieerd naar clipboard.');
      setErrMsg('');
    } catch {
      setErrMsg('Kopiëren niet gelukt (browser permissie).');
      setOkMsg('');
    }
  }

  function clearMessages() {
    setOkMsg('');
    setErrMsg('');
    setTempPwd('');
    setTempPwdEmail('');
  }

  const canSubmitUser = inviteEmail.trim().length > 3 && inviteName.trim().length > 1 && (inviteRole !== 'EMPLOYEE' || !!invitePassColor);
  const canSubmitClient = clientName.trim().length > 1;

  // Admin keyboard shortcuts (best-effort):
  // - N: focus first field of the active create form
  // - Ctrl/Cmd+S: submit the active create form (when valid)
  useEffect(() => {
    const focusFirst = () => {
      const id = createKind === 'USER' ? 'admin-accounts-invite-email' : 'admin-accounts-client-name';
      const el = document.getElementById(id) as HTMLInputElement | null;
      el?.focus();
      el?.select?.();
    };

    const onNew = (e: Event) => {
      const detailTab = (e as any).detail?.tab;
      if (detailTab && detailTab !== 'accounts') return;
      focusFirst();
    };
    const onSave = (e: Event) => {
      const detailTab = (e as any).detail?.tab;
      if (detailTab && detailTab !== 'accounts') return;
      if (createKind === 'USER' && canSubmitUser) createUserInviteM.mutate();
      if (createKind === 'CLIENT' && canSubmitClient) onboardClientM.mutate();
    };

    window.addEventListener('rooster:admin:new', onNew as any);
    window.addEventListener('rooster:admin:save', onSave as any);
    return () => {
      window.removeEventListener('rooster:admin:new', onNew as any);
      window.removeEventListener('rooster:admin:save', onSave as any);
    };
  }, [createKind, canSubmitUser, canSubmitClient, createUserInviteM, onboardClientM]);

  return (
    <div className="space-y-4">
      <Card className="p-4">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <div className="text-sm font-semibold text-gray-900">Gebruikers & Opdrachtgevers</div>
            <div className="text-xs text-gray-600 mt-1">Alles op één plek: aanmaken, invites, overzicht en beheer.</div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant={filter === 'ALL' ? 'primary' : 'secondary'} onClick={() => setFilter('ALL')}>
              Alles
            </Button>
            <Button variant={filter === 'USERS' ? 'primary' : 'secondary'} onClick={() => setFilter('USERS')}>
              Users
            </Button>
            <Button
              variant={filter === 'SUBCONTRACTORS' ? 'primary' : 'secondary'}
              onClick={() => setFilter('SUBCONTRACTORS')}
            >
              Onderaannemers
            </Button>
            <Button variant={filter === 'CLIENTS' ? 'primary' : 'secondary'} onClick={() => setFilter('CLIENTS')}>
              Opdrachtgevers
            </Button>
          </div>
        </div>

        <div className="grid gap-3 mt-4 md:grid-cols-3">
          <div>
            <Label>Zoeken</Label>
            <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="naam / email / id" />
          </div>
          <div>
            <Label>Nieuw aanmaken</Label>
            <Select value={createKind} onChange={(e) => setCreateKind(e.target.value as CreateKind)}>
              <option value="USER">Gebruiker (invite)</option>
              <option value="CLIENT">Opdrachtgever</option>
            </Select>
          </div>
          <div className="flex items-end gap-2">
            <Button
              variant="secondary"
              onClick={() => {
                clearMessages();
                setResultLink('');
                setResultHint('');
                usersQ.refetch();
                subsListQ.refetch();
                clientsQ.refetch();
              }}
            >
              Refresh
            </Button>
          </div>
        </div>
      </Card>

      <ErrorBanner message={errMsg || (usersQ.error as any)?.error || (usersQ.error as any)?.message || (clientsQ.error as any)?.error || (clientsQ.error as any)?.message} />
      <SuccessBanner message={okMsg} />

      {resultLink ? (
        <Card className="p-4">
          <div className="text-sm font-medium text-gray-900">Link</div>
          {resultHint ? <div className="text-xs text-gray-600 mt-1">{resultHint}</div> : null}
          <div className="mt-2 flex flex-wrap items-center gap-2">
            <Input value={resultLink} readOnly />
            <Button variant="secondary" onClick={() => copy(resultLink)}>
              Kopieer
            </Button>
          </div>
        </Card>
      ) : null}

      {tempPwd ? (
        <Card className="p-4">
          <div className="text-sm font-medium text-gray-900">Tijdelijk wachtwoord</div>
          <div className="text-xs text-gray-600 mt-1">Deel dit met {tempPwdEmail || 'de gebruiker'} (wordt niet opnieuw getoond).</div>
          <div className="mt-2 flex flex-wrap items-center gap-2">
            <Input value={tempPwd} readOnly />
            <Button variant="secondary" onClick={() => copy(tempPwd)}>
              Kopieer
            </Button>
            <Button variant="secondary" onClick={() => setTempPwd('')}>
              Verbergen
            </Button>
          </div>
        </Card>
      ) : null}

      {/* CREATE */}
      <Card className="p-4">
        {createKind === 'USER' ? (
          <div className="space-y-3">
            <div className="text-sm font-medium text-gray-900">Gebruiker uitnodigen (invite)</div>
            <div className="grid gap-3 md:grid-cols-3">
              <div>
                <Label>Volledige naam</Label>
                <Input value={inviteName} onChange={(e) => setInviteName(e.target.value)} placeholder="Bijv. Jan Jansen" />
              </div>
              <div>
                <Label>E-mail</Label>
                <Input id="admin-accounts-invite-email" value={inviteEmail} onChange={(e) => setInviteEmail(e.target.value)} placeholder="naam@bedrijf.nl" />
              </div>
              <div>
                <Label>Rol</Label>
                <Select value={inviteRole} onChange={(e) => setInviteRole(e.target.value as InviteRole)}>
                  <option value="EMPLOYEE">Werknemer</option>
                  <option value="SUBCONTRACTOR">Onderaannemer</option>
                  <option value="ADMIN">Admin</option>
                </Select>
              </div>
            </div>

            <div className="grid gap-3 md:grid-cols-3">
              <div>
                <Label>Invite vervalt na (uren)</Label>
                <Input type="number" min={1} max={240} value={expiresInHours} onChange={(e) => setExpiresInHours(Number(e.target.value))} />
              </div>
              {inviteRole === 'EMPLOYEE' ? (
                <div className="md:col-span-2">
                  <Label>Onder aannemer (optioneel)</Label>
                  <Select value={inviteSubId} onChange={(e) => setInviteSubId(e.target.value)}>
                    <option value="">— Algemeen (geen onderaannemer) —</option>
                    {activeSubcontractors.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.fullName ?? s.email}
                      </option>
                    ))}
                  </Select>
                </div>
              ) : null}

            {inviteRole === 'EMPLOYEE' ? (
              <div className="grid gap-3 md:grid-cols-3">
                <div>
                  <Label>Kleurpas</Label>
                  <Select value={invitePassColor} onChange={(e) => setInvitePassColor(e.target.value)}>
                    <option value="">Selecteer...</option>
                    <option value="GRAY">Grijs</option>
                    <option value="DARK_BLUE">Donkerblauw</option>
                    <option value="LIGHT_BLUE">Lichtblauw</option>
                    <option value="ORANGE">Oranje</option>
                    <option value="GREEN">Groen</option>
                    <option value="BLACK">Zwart</option>
                  </Select>
                  <div className="mt-1 text-xs text-gray-600">Verplicht bij werknemers.</div>
                </div>
              </div>
            ) : null}
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <Button
                onClick={() => {
                  clearMessages();
                  setResultLink('');
                  setResultHint('');
                  createUserInviteM.mutate();
                }}
                disabled={createUserInviteM.isPending || !canSubmitUser}
              >
                Maak invite link
              </Button>
              <div className="text-xs text-gray-600">Gebruiker stelt wachtwoord + 2FA in via de signup flow.</div>
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            <div className="text-sm font-medium text-gray-900">Opdrachtgever aanmaken</div>
            <div className="grid gap-3 md:grid-cols-3">
              <div>
                <Label>Naam</Label>
                <Input id="admin-accounts-client-name" value={clientName} onChange={(e) => setClientName(e.target.value)} placeholder="Bijv. Gemeente X" />
              </div>
              <div>
                <Label>Contactnaam (optioneel)</Label>
                <Input value={contactName} onChange={(e) => setContactName(e.target.value)} placeholder="Bijv. Pieter" />
              </div>
              <div>
                <Label>Contact e-mail (optioneel)</Label>
                <Input value={contactEmail} onChange={(e) => setContactEmail(e.target.value)} placeholder="pieter@bedrijf.nl" />
              </div>
            </div>

            <div className="rounded-xl border border-gray-100 p-3">
              <label className="flex items-center gap-2 text-sm text-gray-900">
                <input type="checkbox" checked={makePortalUser} onChange={(e) => setMakePortalUser(e.target.checked)} />
                Maak portal invite
              </label>
              {makePortalUser ? (
                <div className="grid gap-3 mt-3 md:grid-cols-2">
                  <div>
                    <Label>Portal naam</Label>
                    <Input value={portalFullName} onChange={(e) => setPortalFullName(e.target.value)} placeholder="Bijv. Contact persoon" />
                  </div>
                  <div>
                    <Label>Portal e-mail</Label>
                    <Input value={portalEmail} onChange={(e) => setPortalEmail(e.target.value)} placeholder="klant@bedrijf.nl" />
                  </div>
                  <div className="md:col-span-2 text-xs text-gray-600">
                    Als je portal e-mail invult, wordt die gebruikt voor de uitnodiging.
                  </div>
                </div>
              ) : null}
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <Button
                onClick={() => {
                  clearMessages();
                  setResultLink('');
                  setResultHint('');
                  onboardClientM.mutate();
                }}
                disabled={onboardClientM.isPending || !canSubmitClient}
              >
                Opdrachtgever aanmaken
              </Button>
              <div className="text-xs text-gray-600">Portal invite verschijnt hierboven als link.</div>
            </div>
          </div>
        )}
      </Card>

      {/* OVERZICHT (één lijst) */}
      <Card className="p-4">
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <div>
            <div className="text-sm font-medium text-gray-900">Overzicht</div>
            <div className="text-xs text-gray-600">
              {filter === 'USERS'
                ? `Gebruikers (${usersTotal})`
                : filter === 'SUBCONTRACTORS'
                  ? `Onderaannemers (${subsTotal})`
                  : filter === 'CLIENTS'
                    ? `Opdrachtgevers (${clientsTotal})`
                    : `Alles (${usersTotal + subsTotal + clientsTotal})`}
            </div>
          </div>
          <div className="text-xs text-gray-600">Tip: gebruik zoeken + filter bovenaan.</div>
        </div>

        {(usersQ.isLoading || subsListQ.isLoading || clientsQ.isLoading) ? (
          <div className="text-sm text-gray-600 mt-3">Laden…</div>
        ) : (
          <div className="mt-3 space-y-6">
            {(filter === 'ALL' || filter === 'CLIENTS') ? (
              <div>
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="text-sm font-semibold text-gray-900">Opdrachtgevers</div>
                  <div className="flex items-center gap-2">
                    <div className="text-xs text-gray-600">Pagina {clientPage} / {Math.max(1, Math.ceil(clientsTotal / clientPageSize))}</div>
                    <Select value={clientPageSize} onChange={(e) => setClientPageSize(Number(e.target.value))} className="w-auto">
                      <option value={25}>25</option>
                      <option value={50}>50</option>
                      <option value={100}>100</option>
                    </Select>
                    <Button variant="secondary" onClick={() => setClientPage((p) => Math.max(1, p - 1))} disabled={clientPage <= 1}>Vorige</Button>
                    <Button
                      variant="secondary"
                      onClick={() => setClientPage((p) => p + 1)}
                      disabled={clientPage >= Math.max(1, Math.ceil(clientsTotal / clientPageSize))}
                    >
                      Volgende
                    </Button>
                  </div>
                </div>

                <div className="mt-2 space-y-2">
                  {filteredClients.map((c) => (
                    <div key={`client:${c.id}`} className="rounded-xl border border-gray-100 p-3">
                      <div className="flex items-start justify-between gap-3 flex-wrap">
                        <div className="min-w-0">
                          <div className="font-medium text-gray-900 truncate">{c.name}</div>
                          <div className="text-xs text-gray-600 truncate">{c.contactEmail ?? ''}</div>
                          {c.isDeleted ? <div className="text-xs text-gray-600">(verwijderd)</div> : null}
                        </div>
                        <div className="flex items-center gap-2 flex-wrap justify-end">
                          <Badge className={rolePillClass('CLIENT')}>CLIENT</Badge>
                          <Badge className={c.isDeleted ? statusPillClass('DELETED') : statusPillClass('ACTIVE')}>
                            {c.isDeleted ? 'DELETED' : 'ACTIVE'}
                          </Badge>
                        </div>
                      </div>
                      <div className="mt-3 flex flex-wrap gap-2">
                        <Button variant="secondary" onClick={() => regenerateInviteM.mutate(c.id)} disabled={regenerateInviteM.isPending}>
                          Vernieuw portal invite
                        </Button>
                        <Button
                          variant="secondary"
                          onClick={() =>
                            createPortalUserM.mutate({
                              clientId: c.id,
                              portalEmail: c.contactEmail ?? undefined,
                              portalFullName: c.contactName ?? undefined,
                            })
                          }
                          disabled={createPortalUserM.isPending}
                        >
                          Maak portal invite (contact)
                        </Button>
                        <Button
                          variant="danger"
                          onClick={() => {
                            if (confirm('Opdrachtgever verwijderen? (soft delete)')) deleteClientM.mutate(c.id);
                          }}
                          disabled={deleteClientM.isPending}
                        >
                          Verwijderen
                        </Button>
                      </div>
                    </div>
                  ))}

                  {(filter === 'CLIENTS' || filter === 'ALL') && filteredClients.length === 0 ? (
                    <div className="text-sm text-gray-600">Geen opdrachtgevers.</div>
                  ) : null}
                </div>
              </div>
            ) : null}

            {(filter === 'ALL' || filter === 'USERS') ? (
              <div>
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="text-sm font-semibold text-gray-900">Gebruikers</div>
                  <div className="flex items-center gap-2">
                    <div className="text-xs text-gray-600">Pagina {userPage} / {Math.max(1, Math.ceil(usersTotal / userPageSize))}</div>
                    <Select value={userPageSize} onChange={(e) => setUserPageSize(Number(e.target.value))} className="w-auto">
                      <option value={25}>25</option>
                      <option value={50}>50</option>
                      <option value={100}>100</option>
                    </Select>
                    <Button variant="secondary" onClick={() => setUserPage((p) => Math.max(1, p - 1))} disabled={userPage <= 1}>Vorige</Button>
                    <Button
                      variant="secondary"
                      onClick={() => setUserPage((p) => p + 1)}
                      disabled={userPage >= Math.max(1, Math.ceil(usersTotal / userPageSize))}
                    >
                      Volgende
                    </Button>
                  </div>
                </div>

                <div className="mt-2 space-y-2">
                  {filteredUsers.map((u) => (
                    <div key={`user:${u.id}`} className="rounded-xl border border-gray-100 p-3">
                      <div className="flex items-start justify-between gap-3 flex-wrap">
                        <div className="min-w-0">
                          <div className="font-medium text-gray-900 truncate">{u.fullName ?? u.email}</div>
                          <div className="text-xs text-gray-600 truncate">{u.email}</div>
                          {u.subcontractorId ? <div className="text-xs text-gray-600">Subcontractor: {u.subcontractorId}</div> : null}
                        </div>
                        <div className="flex items-center gap-2 flex-wrap justify-end">
                          <Badge className={rolePillClass(String(u.role))}>{String(u.role)}</Badge>
                          <Badge className={statusPillClass(statusLabel(u))}>{statusLabel(u)}</Badge>
                          <Badge className={twofaPillClass(!!u.twoFactorEnabled)}>{u.twoFactorEnabled ? '2FA: ON' : '2FA: OFF'}</Badge>
                        </div>
                      </div>

                      {String(u.role) === 'EMPLOYEE' ? (
                        <div className="mt-3 grid gap-2 md:grid-cols-3 items-end">
                          <div>
                            <Label className="text-xs">Kleurpas</Label>
                            <Select
                              value={u.passColor ?? ''}
                              onChange={(e) => {
                                const v = e.target.value || null;
                                setPassColorM.mutate({ id: u.id, passColor: v });
                              }}
                              disabled={setPassColorM.isPending}
                            >
                              <option value="">—</option>
                              <option value="GRAY">Grijs</option>
                              <option value="DARK_BLUE">Donkerblauw</option>
                              <option value="LIGHT_BLUE">Lichtblauw</option>
                              <option value="ORANGE">Oranje</option>
                              <option value="GREEN">Groen</option>
                              <option value="BLACK">Zwart</option>
                            </Select>
                          </div>
                          <div className="text-xs text-gray-600 md:col-span-2">
                            Kleurpas wordt server-side enforced bij open diensten.
                          </div>
                        </div>
                      ) : null}

                      <div className="mt-3 flex flex-wrap gap-2">
                        {String(u.role) === 'EMPLOYEE' ? (
                          <Link
                            to={`/admin/beschikbaarheid/${u.id}`}
                            className="inline-flex items-center rounded-lg border border-gray-200 bg-white px-3 py-2 text-sm text-gray-800 hover:bg-gray-50"
                          >
                            Bekijk beschikbaarheid
                          </Link>
                        ) : null}
                        {statusLabel(u) !== 'ACTIVE' ? (
                          <Button variant="secondary" onClick={() => reactivateM.mutate(u.id)} disabled={reactivateM.isPending}>
                            Heractiveren
                          </Button>
                        ) : null}
                        <Button
                          variant="secondary"
                          onClick={() => {
                            if (confirm('2FA resetten voor deze gebruiker?')) reset2faM.mutate(u.id);
                          }}
                          disabled={reset2faM.isPending}
                        >
                          Reset 2FA
                        </Button>
                        <Button
                          variant="secondary"
                          onClick={() => {
                            if (confirm('Wachtwoord resetten? Je krijgt een tijdelijk wachtwoord.')) resetPasswordM.mutate(u.id);
                          }}
                          disabled={resetPasswordM.isPending}
                        >
                          Reset wachtwoord
                        </Button>
                      </div>
                    </div>
                  ))}

                  {filteredUsers.length === 0 ? <div className="text-sm text-gray-600">Geen gebruikers.</div> : null}
                </div>
              </div>
            ) : null}

            {(filter === 'ALL' || filter === 'SUBCONTRACTORS') ? (
              <div>
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="text-sm font-semibold text-gray-900">Onderaannemers</div>
                  <div className="flex items-center gap-2">
                    <div className="text-xs text-gray-600">Pagina {subPage} / {Math.max(1, Math.ceil(subsTotal / subPageSize))}</div>
                    <Select value={subPageSize} onChange={(e) => setSubPageSize(Number(e.target.value))} className="w-auto">
                      <option value={25}>25</option>
                      <option value={50}>50</option>
                      <option value={100}>100</option>
                    </Select>
                    <Button variant="secondary" onClick={() => setSubPage((p) => Math.max(1, p - 1))} disabled={subPage <= 1}>Vorige</Button>
                    <Button
                      variant="secondary"
                      onClick={() => setSubPage((p) => p + 1)}
                      disabled={subPage >= Math.max(1, Math.ceil(subsTotal / subPageSize))}
                    >
                      Volgende
                    </Button>
                  </div>
                </div>

                <div className="mt-2 space-y-2">
                  {filteredSubcontractors.map((u) => (
                    <div key={`sub:${u.id}`} className="rounded-xl border border-gray-100 p-3">
                      <div className="flex items-start justify-between gap-3 flex-wrap">
                        <div className="min-w-0">
                          <div className="font-medium text-gray-900 truncate">{u.fullName ?? u.email}</div>
                          <div className="text-xs text-gray-600 truncate">{u.email}</div>
                        </div>
                        <div className="flex items-center gap-2 flex-wrap justify-end">
                          <Badge className={rolePillClass(String(u.role))}>{String(u.role)}</Badge>
                          <Badge className={statusPillClass(statusLabel(u))}>{statusLabel(u)}</Badge>
                          <Badge className={twofaPillClass(!!u.twoFactorEnabled)}>{u.twoFactorEnabled ? '2FA: ON' : '2FA: OFF'}</Badge>
                        </div>
                      </div>

                      <div className="mt-3 flex flex-wrap gap-2">
                        {statusLabel(u) !== 'ACTIVE' ? (
                          <Button variant="secondary" onClick={() => reactivateM.mutate(u.id)} disabled={reactivateM.isPending}>
                            Heractiveren
                          </Button>
                        ) : null}
                        <Button
                          variant="secondary"
                          onClick={() => {
                            if (confirm('2FA resetten voor deze gebruiker?')) reset2faM.mutate(u.id);
                          }}
                          disabled={reset2faM.isPending}
                        >
                          Reset 2FA
                        </Button>
                        <Button
                          variant="secondary"
                          onClick={() => {
                            if (confirm('Wachtwoord resetten? Je krijgt een tijdelijk wachtwoord.')) resetPasswordM.mutate(u.id);
                          }}
                          disabled={resetPasswordM.isPending}
                        >
                          Reset wachtwoord
                        </Button>
                      </div>
                    </div>
                  ))}

                  {filteredSubcontractors.length === 0 ? <div className="text-sm text-gray-600">Geen onderaannemers.</div> : null}
                </div>
              </div>
            ) : null}

            {filter === 'ALL' && filteredUsers.length === 0 && filteredSubcontractors.length === 0 && filteredClients.length === 0 ? (
              <div className="text-sm text-gray-600">Geen resultaten.</div>
            ) : null}
          </div>
        )}
      </Card>
    </div>
  );
}
