import type React from 'react';
import { useMemo, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Badge, Button, Card, ErrorBanner, Input, Label, SuccessBanner } from '../../../components/ui';
import { PaginationControls } from '../../../components/PaginationControls';
import {
  adjustMaterialStock,
  createMaterial,
  createMaterialAssignment,
  deleteMaterial,
  listMaterialAssignments,
  listMaterialHistory,
  listMaterials,
  reportMaterialIssue,
  returnMaterialAssignment,
  updateMaterial,
} from '../../../api/materials';
import { listUsers } from '../../../api/users';

function Select(props: React.SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <select
      {...props}
      className={'w-full rounded border px-3 py-2 text-sm outline-none focus:ring ' + (props.className ?? '')}
    />
  );
}

function stockPillClass(qty: number) {
  if (qty <= 0) return 'border-rose-200 bg-rose-50 text-rose-800';
  if (qty < 5) return 'border-amber-200 bg-amber-50 text-amber-900';
  return 'border-emerald-200 bg-emerald-50 text-emerald-800';
}

function deltaPillClass(delta: number) {
  if (delta > 0) return 'border-emerald-200 bg-emerald-50 text-emerald-800';
  if (delta < 0) return 'border-rose-200 bg-rose-50 text-rose-800';
  return 'border-gray-200 bg-gray-50 text-gray-700';
}

function assignmentStatusPillClass(status: string) {
  switch (status) {
    case 'ASSIGNED':
      return 'border-blue-200 bg-blue-50 text-blue-800';
    case 'RETURNED':
      return 'border-gray-200 bg-gray-50 text-gray-700';
    case 'LOST':
      return 'border-rose-200 bg-rose-50 text-rose-800';
    case 'DEFECT':
      return 'border-amber-200 bg-amber-50 text-amber-900';
    default:
      return 'border-gray-200 bg-gray-50 text-gray-700';
  }
}

export default function MaterialsTab() {
  const qc = useQueryClient();

  const [q, setQ] = useState('');
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(25);

  const materialsQ = useQuery({
    queryKey: ['admin', 'materials', { q, page, pageSize }],
    queryFn: () => listMaterials({ q: q.trim() || undefined, page, pageSize }),
  });

  const usersQ = useQuery({
    queryKey: ['admin', 'users'],
    queryFn: () => listUsers(),
  });

  const materials = (materialsQ.data?.materials ?? []) as any[];
  const totalCount = (materialsQ.data as any)?.totalCount as number | undefined;
  const users = (usersQ.data?.users ?? []) as any[];

  const [activeId, setActiveId] = useState<string>('');
  const active = materials.find((m) => m.id === activeId) ?? null;

  const [okMsg, setOkMsg] = useState('');
  const [errMsg, setErrMsg] = useState('');

  // Create material
  const [newName, setNewName] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newStock, setNewStock] = useState<number>(0);

  // Edit material
  const [editName, setEditName] = useState('');
  const [editDesc, setEditDesc] = useState('');

  // Stock adjust
  const [delta, setDelta] = useState<number>(0);
  const [reason, setReason] = useState<string>('');

  // Assignment
  const [assignUserId, setAssignUserId] = useState<string>('');
  const [assignQty, setAssignQty] = useState<number>(1);
  const [assignNote, setAssignNote] = useState<string>('');

  // Server-side search + pagination: keep the in-memory view as-is.

  const assignmentsQ = useQuery({
    queryKey: ['admin', 'materialAssignments', activeId],
    queryFn: () => (activeId ? listMaterialAssignments({ materialId: activeId, status: 'ASSIGNED' }) : Promise.resolve({ assignments: [] })),
    enabled: !!activeId,
  });

  const historyQ = useQuery({
    queryKey: ['admin', 'materialHistory', activeId],
    queryFn: () => (activeId ? listMaterialHistory({ materialId: activeId }) : Promise.resolve({ history: [] })),
    enabled: !!activeId,
  });

  const createM = useMutation({
    mutationFn: () => createMaterial({ name: newName.trim(), description: newDesc.trim() || undefined, stockQuantity: Number(newStock) || 0 }),
    onSuccess: async () => {
      setOkMsg('Materiaal aangemaakt.');
      setErrMsg('');
      setNewName('');
      setNewDesc('');
      setNewStock(0);
      await qc.invalidateQueries({ queryKey: ['admin', 'materials'] });
    },
    onError: (e: any) => {
      setErrMsg(e?.error ?? e?.message ?? 'Aanmaken mislukt');
      setOkMsg('');
    },
  });

  const updateM = useMutation({
    mutationFn: (id: string) => updateMaterial(id, { name: editName.trim(), description: editDesc.trim() || null }),
    onSuccess: async () => {
      setOkMsg('Materiaal bijgewerkt.');
      setErrMsg('');
      await qc.invalidateQueries({ queryKey: ['admin', 'materials'] });
      await qc.invalidateQueries({ queryKey: ['admin', 'materialHistory', activeId] });
    },
    onError: (e: any) => {
      setErrMsg(e?.error ?? e?.message ?? 'Opslaan mislukt');
      setOkMsg('');
    },
  });

  const stockM = useMutation({
    mutationFn: (id: string) => adjustMaterialStock(id, { delta: Number(delta) || 0, reason: reason.trim() || 'Voorraadcorrectie' }),
    onSuccess: async () => {
      setOkMsg('Voorraad aangepast.');
      setErrMsg('');
      setDelta(0);
      setReason('');
      await qc.invalidateQueries({ queryKey: ['admin', 'materials'] });
      await qc.invalidateQueries({ queryKey: ['admin', 'materialHistory', activeId] });
    },
    onError: (e: any) => {
      setErrMsg(e?.error ?? e?.message ?? 'Voorraad aanpassen mislukt');
      setOkMsg('');
    },
  });

  const assignM = useMutation({
    mutationFn: () => {
      if (!activeId) throw { error: 'Kies eerst een materiaal.' };
      if (!assignUserId) throw { error: 'Kies een gebruiker.' };
      const available = Number(active?.stockQuantity ?? 0);
      const qty = Number(assignQty) || 1;
      if (available < qty) throw { error: 'Onvoldoende voorraad om uit te geven.' };
      return createMaterialAssignment({ materialId: activeId, userId: assignUserId, quantity: qty, note: assignNote.trim() || undefined });
    },
    onSuccess: async () => {
      setOkMsg('Uitgifte geregistreerd.');
      setErrMsg('');
      setAssignQty(1);
      setAssignNote('');
      await qc.invalidateQueries({ queryKey: ['admin', 'materialAssignments', activeId] });
      await qc.invalidateQueries({ queryKey: ['admin', 'materialHistory', activeId] });
      await qc.invalidateQueries({ queryKey: ['admin', 'materials'] });
    },
    onError: (e: any) => {
      if (String(e?.error ?? '') === 'INSUFFICIENT_STOCK') {
        setErrMsg('Onvoldoende voorraad om uit te geven.');
      } else {
        setErrMsg(e?.error ?? e?.message ?? 'Uitgifte mislukt');
      }
      setOkMsg('');
    },
  });

  const actionM = useMutation({
    mutationFn: async (input: { kind: 'RETURN' | 'LOST' | 'DEFECT'; assignmentId: string; note?: string }) => {
      if (input.kind === 'RETURN') return returnMaterialAssignment(input.assignmentId, input.note);
      return reportMaterialIssue(input.assignmentId, input.kind, input.note);
    },
    onSuccess: async () => {
      setOkMsg('Actie opgeslagen.');
      setErrMsg('');
      await qc.invalidateQueries({ queryKey: ['admin', 'materialAssignments', activeId] });
      await qc.invalidateQueries({ queryKey: ['admin', 'materialHistory', activeId] });
      await qc.invalidateQueries({ queryKey: ['admin', 'materials'] });
    },
    onError: (e: any) => {
      setErrMsg(e?.error ?? e?.message ?? 'Actie mislukt');
      setOkMsg('');
    },
  });

  const deleteM = useMutation({
    mutationFn: (input: { id: string; force?: boolean }) => deleteMaterial(input.id, { force: !!input.force }),
    onSuccess: async () => {
      setOkMsg('Materiaal verwijderd.');
      setErrMsg('');
      setActiveId('');
      await qc.invalidateQueries({ queryKey: ['admin', 'materials'] });
    },
    onError: (e: any) => {
      setErrMsg(e?.error ?? e?.message ?? 'Verwijderen mislukt');
      setOkMsg('');
    },
  });

  function selectMaterial(id: string) {
    setActiveId(id);
    const m = materials.find((x) => x.id === id);
    setEditName(m?.name ?? '');
    setEditDesc(m?.description ?? '');
    setErrMsg('');
    setOkMsg('');
  }

  return (
    <div className="space-y-4">
      <Card className="p-4">
        <div className="font-medium text-gray-900 mb-3">Nieuw materiaal</div>
        <div className="grid gap-3 md:grid-cols-3">
          <div>
            <Label>Naam</Label>
            <Input value={newName} onChange={(e) => setNewName(e.target.value)} placeholder="Bijv. Portofoon" />
          </div>
          <div>
            <Label>Omschrijving</Label>
            <Input value={newDesc} onChange={(e) => setNewDesc(e.target.value)} placeholder="Optioneel" />
          </div>
          <div>
            <Label>Start voorraad</Label>
            <Input type="number" value={newStock} onChange={(e) => setNewStock(Number(e.target.value))} />
          </div>
        </div>
        <div className="mt-3">
          <Button onClick={() => createM.mutate()} disabled={createM.isPending || newName.trim().length < 2}>
            Toevoegen
          </Button>
        </div>
      </Card>

      <ErrorBanner message={errMsg || (materialsQ.error as any)?.error || (materialsQ.error as any)?.message} />
      <SuccessBanner message={okMsg} />

      <Card className="p-4">
        <div className="flex items-end justify-between gap-4 flex-wrap">
          <div className="min-w-[260px]">
            <Label>Zoeken</Label>
            <Input
              value={q}
              onChange={(e) => {
                setQ(e.target.value);
                setPage(1);
              }}
              placeholder="naam/omschrijving"
            />
          </div>
          <Button variant="secondary" onClick={() => materialsQ.refetch()} disabled={materialsQ.isLoading}>
            Refresh
          </Button>
        </div>
      </Card>

      <Card className="p-4">
        <div className="text-sm text-gray-700 font-medium mb-3">
          Materialen ({totalCount ?? materials.length})
        </div>
        {materialsQ.isLoading ? (
          <div className="text-sm text-gray-600">Laden…</div>
        ) : materials.length === 0 ? (
          <div className="text-sm text-gray-600">Geen materialen.</div>
        ) : (
          <div className="space-y-2">
            {materials.map((m) => (
              <button
                key={m.id}
                onClick={() => selectMaterial(m.id)}
                className={
                  'w-full text-left rounded-xl border p-3 flex items-center justify-between gap-3 ' +
                  (m.id === activeId ? 'border-gray-300 bg-gray-50' : 'border-gray-100 hover:bg-gray-50')
                }
              >
                <div className="min-w-0">
                  <div className="font-medium text-gray-900 truncate">{m.name}</div>
                  <div className="text-xs text-gray-600 truncate">{m.description ?? ''}</div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge className={stockPillClass(Number(m.stockQuantity ?? 0))}>Stock: {m.stockQuantity ?? 0}</Badge>
                </div>
              </button>
            ))}
          </div>
        )}

        <div className="mt-4">
          <PaginationControls
            page={page}
            pageSize={pageSize}
            totalCount={totalCount}
            onPageChange={(p) => setPage(Math.max(1, p))}
            onPageSizeChange={(ps) => {
              setPageSize(ps);
              setPage(1);
            }}
          />
        </div>
      </Card>

      {active ? (
        <div className="grid gap-4 lg:grid-cols-2">
          <Card className="p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div className="font-medium text-gray-900">Bewerken</div>
              <div className="flex items-center gap-2">
                <Button
                  variant="danger"
                  onClick={() => {
                    if (confirm('Materiaal verwijderen? Dit is een SOFT delete (historie blijft).')) {
                      deleteM.mutate({ id: active.id, force: false });
                    }
                  }}
                  disabled={deleteM.isPending}
                >
                  Verwijderen
                </Button>
                <Button
                  variant="secondary"
                  onClick={() => {
                    if (
                      confirm(
                        '⚠️ Definitief verwijderen? Dit verwijdert ook gekoppelde uitgiftes/historie. Deze actie kan niet ongedaan gemaakt worden.'
                      )
                    ) {
                      deleteM.mutate({ id: active.id, force: true });
                    }
                  }}
                  disabled={deleteM.isPending}
                >
                  Definitief
                </Button>
              </div>
            </div>

            <div>
              <Label>Naam</Label>
              <Input value={editName} onChange={(e) => setEditName(e.target.value)} />
            </div>
            <div>
              <Label>Omschrijving</Label>
              <Input value={editDesc} onChange={(e) => setEditDesc(e.target.value)} />
            </div>
            <Button onClick={() => updateM.mutate(active.id)} disabled={updateM.isPending || editName.trim().length < 2}>
              Opslaan
            </Button>

            <div className="pt-3 border-t border-gray-100">
              <div className="font-medium text-gray-900 mb-2">Voorraad aanpassen</div>
              <div className="grid gap-3 md:grid-cols-2">
                <div>
                  <Label>Delta (+/-)</Label>
                  <Input type="number" value={delta} onChange={(e) => setDelta(Number(e.target.value))} />
                </div>
                <div>
                  <Label>Reden</Label>
                  <Input value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Bijv. inventaris" />
                </div>
              </div>
              <div className="mt-2">
                <Button variant="secondary" onClick={() => stockM.mutate(active.id)} disabled={stockM.isPending || delta === 0}>
                  Pas voorraad aan
                </Button>
              </div>
            </div>
          </Card>

          <Card className="p-4 space-y-3">
            <div className="font-medium text-gray-900">Uitgifte aan werknemer</div>
            <div className="grid gap-3 md:grid-cols-2">
              <div>
                <Label>Werknemer</Label>
                <Select value={assignUserId} onChange={(e) => setAssignUserId(e.target.value)}>
                  <option value="">— Kies user —</option>
                  {users
                    // Materials are issued to workers; subcontractor accounts are not workers.
                    .filter((u) => u.role === 'EMPLOYEE')
                    .map((u) => (
                      <option key={u.id} value={u.id}>
                        {u.fullName ?? u.email} ({u.role})
                      </option>
                    ))}
                </Select>
              </div>
              <div>
                <Label>Aantal</Label>
                <Input type="number" min={1} value={assignQty} onChange={(e) => setAssignQty(Number(e.target.value))} />
              </div>
            </div>
            <div>
              <Label>Notitie</Label>
              <Input value={assignNote} onChange={(e) => setAssignNote(e.target.value)} placeholder="Optioneel" />
            </div>
            <div className="flex items-center gap-3 flex-wrap">
              <Button
                onClick={() => assignM.mutate()}
                disabled={
                  assignM.isPending ||
                  !assignUserId ||
                  (active ? Number(active.stockQuantity ?? 0) < (Number(assignQty) || 1) : true)
                }
              >
                Uitgeven
              </Button>
              {active ? (
                <span className="text-xs text-gray-600">
                  Beschikbaar: <b>{active.stockQuantity ?? 0}</b>
                </span>
              ) : null}
            </div>

            <div className="pt-3 border-t border-gray-100">
              <div className="font-medium text-gray-900 mb-2">Actieve uitgiftes</div>
              {assignmentsQ.isLoading ? (
                <div className="text-sm text-gray-600">Laden…</div>
              ) : (assignmentsQ.data?.assignments ?? []).length === 0 ? (
                <div className="text-sm text-gray-600">Geen actieve uitgiftes.</div>
              ) : (
                <div className="space-y-2">
                  {(assignmentsQ.data?.assignments ?? []).map((a: any) => (
                    <div key={a.id} className="rounded-xl border border-gray-100 p-3">
                      <div className="flex items-center justify-between gap-2">
                        <div className="min-w-0">
                          <div className="font-medium text-gray-900 truncate">{a.user?.fullName ?? a.userId}</div>
                          <div className="text-xs text-gray-600">Aantal: {a.quantity}</div>
                        </div>
                        <div className="flex gap-2 flex-wrap justify-end items-center">
                          <Badge className={assignmentStatusPillClass(String(a.status ?? 'ASSIGNED'))}>
                            {String(a.status ?? 'ASSIGNED')}
                          </Badge>
                          <Button variant="secondary" onClick={() => actionM.mutate({ kind: 'RETURN', assignmentId: a.id })} disabled={actionM.isPending}>
                            Retour
                          </Button>
                          <Button variant="secondary" onClick={() => actionM.mutate({ kind: 'LOST', assignmentId: a.id })} disabled={actionM.isPending}>
                            Verloren
                          </Button>
                          <Button variant="secondary" onClick={() => actionM.mutate({ kind: 'DEFECT', assignmentId: a.id })} disabled={actionM.isPending}>
                            Defect
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </Card>

          <Card className="p-4 lg:col-span-2">
            <div className="font-medium text-gray-900 mb-2">Historie</div>
            {historyQ.isLoading ? (
              <div className="text-sm text-gray-600">Laden…</div>
            ) : (historyQ.data?.history ?? []).length === 0 ? (
              <div className="text-sm text-gray-600">Geen historie.</div>
            ) : (
              <div className="space-y-2">
                {(historyQ.data?.history ?? []).slice(0, 20).map((h: any) => (
                  <div key={h.id} className="rounded-xl border border-gray-100 p-3 flex items-center justify-between gap-3">
                    <div className="min-w-0">
                      <div className="font-medium text-gray-900 truncate">{h.action}</div>
                      <div className="text-xs text-gray-600 truncate">
                        {new Date(h.createdAt).toLocaleString()} • {h.actor?.fullName ?? '—'}
                        {h.user?.fullName ? ` • Target: ${h.user.fullName}` : ''}
                      </div>
                      {h.note ? <div className="text-xs text-gray-700 mt-1">{h.note}</div> : null}
                    </div>
                    <Badge className={deltaPillClass(Number(h.quantityDelta ?? 0))}>
                      {h.quantityDelta > 0 ? `+${h.quantityDelta}` : String(h.quantityDelta)}
                    </Badge>
                  </div>
                ))}
              </div>
            )}
          </Card>
        </div>
      ) : null}
    </div>
  );
}
