import { useMemo, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Badge, Button, Card, ErrorBanner, Input, Label, SuccessBanner } from '../../../components/ui';
import { createLocation, deleteLocation, listLocations, updateLocation } from '../../../api/locations';
import { apiFetch } from '../../../api/apiClient';
import { LocationMapPicker } from './components/LocationMapPicker';

export default function LocationsTab() {
  const qc = useQueryClient();

  const qLocations = useQuery({
    queryKey: ['admin', 'locations'],
    queryFn: () => listLocations(),
  });

  const locations = (qLocations.data?.locations ?? []) as any[];

  const [okMsg, setOkMsg] = useState('');
  const [errMsg, setErrMsg] = useState('');

  const [q, setQ] = useState('');
  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return locations;
    return locations.filter((l) => (l.name ?? '').toLowerCase().includes(s) || (l.address ?? '').toLowerCase().includes(s));
  }, [locations, q]);

  // Create
  const [name, setName] = useState('');
  const [address, setAddress] = useState('');
  const [latitude, setLatitude] = useState<string>('52.370216'); // AMS default
  const [longitude, setLongitude] = useState<string>('4.895168');
  const [radiusM, setRadiusM] = useState<string>('150');

  // Address search (Nominatim via backend proxy)
  const [searchQ, setSearchQ] = useState('');
  const [searchResults, setSearchResults] = useState<{ displayName: string; lat: number; lon: number }[]>([]);

  const searchM = useMutation({
    mutationFn: async () => {
      const q = searchQ.trim();
      if (!q) return { results: [] as any[] };
      return apiFetch<{ results: { displayName: string; lat: number; lon: number }[] }>(
        `/geo/search?q=${encodeURIComponent(q)}`,
      );
    },
    onSuccess: (data) => {
      setSearchResults(data?.results ?? []);
    },
    onError: () => {
      setSearchResults([]);
    },
  });

  const reverseM = useMutation({
    mutationFn: async ({ lat, lon }: { lat: number; lon: number }) =>
      apiFetch<{ displayName?: string; street?: string; postcode?: string; city?: string }>(
        `/geo/reverse?lat=${encodeURIComponent(String(lat))}&lon=${encodeURIComponent(String(lon))}`,
      ),
  });

  const createM = useMutation({
    mutationFn: () =>
      createLocation({
        name: name.trim(),
        address: address.trim(),
        latitude: Number(latitude),
        longitude: Number(longitude),
        radiusM: Number(radiusM),
      } as any),
    onSuccess: async () => {
      setOkMsg('Locatie aangemaakt.');
      setErrMsg('');
      setName('');
      setAddress('');
      await qc.invalidateQueries({ queryKey: ['admin', 'locations'] });
    },
    onError: (e: any) => {
      setErrMsg(e?.error || 'Aanmaken mislukt');
      setOkMsg('');
    },
  });

  // Edit
  const [activeId, setActiveId] = useState<string>('');
  const active = locations.find((l) => l.id === activeId) ?? null;

  const [editName, setEditName] = useState('');
  const [editAddress, setEditAddress] = useState('');
  const [editLat, setEditLat] = useState<string>('');
  const [editLng, setEditLng] = useState<string>('');
  const [editRadius, setEditRadius] = useState<string>('');

  const [editSearchQ, setEditSearchQ] = useState('');
  const [editSearchResults, setEditSearchResults] = useState<{ displayName: string; lat: number; lon: number }[]>([]);

  const editSearchM = useMutation({
    mutationFn: async () => {
      const q = editSearchQ.trim();
      if (!q) return { results: [] as any[] };
      return apiFetch<{ results: { displayName: string; lat: number; lon: number }[] }>(
        `/geo/search?q=${encodeURIComponent(q)}`,
      );
    },
    onSuccess: (data) => {
      setEditSearchResults(data?.results ?? []);
    },
    onError: () => {
      setEditSearchResults([]);
    },
  });

  const loadActive = (id: string) => {
    setActiveId(id);
    const l = locations.find((x) => x.id === id);
    if (!l) return;
    setEditName(l.name ?? '');
    setEditAddress(l.address ?? '');
    setEditLat(String(l.latitude ?? ''));
    setEditLng(String(l.longitude ?? ''));
    setEditRadius(String(l.radiusM ?? ''));
    setEditSearchQ('');
    setEditSearchResults([]);
  };

  const updateM = useMutation({
    mutationFn: () =>
      updateLocation(activeId, {
        name: editName.trim(),
        address: editAddress.trim(),
        latitude: Number(editLat),
        longitude: Number(editLng),
        radiusM: Number(editRadius),
      } as any),
    onSuccess: async () => {
      setOkMsg('Locatie bijgewerkt.');
      setErrMsg('');
      await qc.invalidateQueries({ queryKey: ['admin', 'locations'] });
    },
    onError: (e: any) => {
      setErrMsg(e?.error || 'Bijwerken mislukt');
      setOkMsg('');
    },
  });

  const deleteM = useMutation({
    mutationFn: (id: string) => deleteLocation(id),
    onSuccess: async () => {
      setOkMsg('Locatie verwijderd.');
      setErrMsg('');
      setActiveId('');
      await qc.invalidateQueries({ queryKey: ['admin', 'locations'] });
    },
    onError: (e: any) => {
      if (e?.code === 'LOCATION_IN_USE') {
        const n = e?.details?.activeShiftCount ?? e?.activeShiftCount;
        setErrMsg(`Locatie kan niet verwijderd worden: er zijn nog ${n ?? 'actieve'} diensten gekoppeld.`);
        setOkMsg('');
        return;
      }
      setErrMsg(e?.error || 'Verwijderen mislukt');
      setOkMsg('');
    },
  });

  return (
    <div className="space-y-4">
      <Card className="p-4 space-y-3">
        <div className="flex items-center justify-between gap-3">
          <div>
            <div className="text-lg font-semibold">Locaties</div>
            <div className="text-sm opacity-70">Maak locaties aan voor diensten + geofence.</div>
          </div>
          <Badge className="border-gray-200 bg-gray-50 text-gray-700">{locations.length} totaal</Badge>
        </div>

        {okMsg ? <SuccessBanner>{okMsg}</SuccessBanner> : null}
        {errMsg ? <ErrorBanner>{errMsg}</ErrorBanner> : null}

        <div className="grid gap-3 md:grid-cols-2">
          <div className="space-y-2">
            <div className="font-medium">Nieuwe locatie</div>

            <div className="grid gap-2">
              <div>
                <Label>Naam</Label>
                <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Bijv. AFAS Live" />
              </div>
              <div>
                <Label>Adres</Label>
                <Input value={address} onChange={(e) => setAddress(e.target.value)} placeholder="Straat + plaats" />
              </div>

              <div>
                <Label>Zoek adres (kaart)</Label>
                <div className="flex gap-2">
                  <Input
                    value={searchQ}
                    onChange={(e) => setSearchQ(e.target.value)}
                    placeholder="Bijv. Ziggo Dome Amsterdam"
                  />
                  <Button
                    variant="secondary"
                    onClick={() => searchM.mutate()}
                    disabled={searchM.isPending || !searchQ.trim()}
                  >
                    Zoek
                  </Button>
                </div>
                {searchResults.length ? (
                  <div className="mt-2 rounded border max-h-40 overflow-auto">
                    {searchResults.map((r, idx) => (
                      <button
                        key={idx}
                        className="w-full text-left px-3 py-2 border-b hover:bg-gray-50"
                        onClick={async () => {
                          setLatitude(String(r.lat));
                          setLongitude(String(r.lon));
                          setAddress(r.displayName);
                          setSearchResults([]);
                          try {
                            const rev = await reverseM.mutateAsync({ lat: r.lat, lon: r.lon });
                            const best = rev?.displayName || r.displayName;
                            setAddress(best);
                          } catch {
                            // ignore
                          }
                        }}
                      >
                        <div className="text-sm">{r.displayName}</div>
                      </button>
                    ))}
                  </div>
                ) : null}
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label>Latitude</Label>
                  <Input value={latitude} onChange={(e) => setLatitude(e.target.value)} />
                </div>
                <div>
                  <Label>Longitude</Label>
                  <Input value={longitude} onChange={(e) => setLongitude(e.target.value)} />
                </div>
              </div>
              <div>
                <Label>Radius (meters)</Label>
                <Input value={radiusM} onChange={(e) => setRadiusM(e.target.value)} />
              </div>

              <div>
                <Label>Kaart (klik of sleep pin)</Label>
                <LocationMapPicker
                  lat={Number(latitude)}
                  lng={Number(longitude)}
                  radiusM={Number(radiusM)}
                  onPick={async (lat, lng) => {
                    setLatitude(String(lat));
                    setLongitude(String(lng));
                    try {
                      const rev = await reverseM.mutateAsync({ lat, lon: lng });
                      const best = rev?.displayName;
                      if (best) setAddress(best);
                    } catch {
                      // ignore
                    }
                  }}
                />
                <div className="mt-1 text-xs opacity-70">
                  Tip: radius wordt als cirkel getoond (geofence).
                </div>
              </div>
            </div>

            <Button
              variant="primary"
              onClick={() => createM.mutate()}
              disabled={createM.isPending || !name.trim() || !address.trim()}
            >
              Locatie aanmaken
            </Button>
          </div>

          <div className="space-y-2">
            <div className="font-medium">Overzicht</div>
            <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Zoek naam/adres..." />

            <div className="max-h-[360px] overflow-auto rounded border">
              {filtered.map((l) => (
                <button
                  key={l.id}
                  className={
                    'w-full text-left px-3 py-2 border-b hover:bg-gray-50 ' +
                    (activeId === l.id ? 'bg-gray-50' : '')
                  }
                  onClick={() => loadActive(l.id)}
                >
                  <div className="flex items-center justify-between gap-2">
                    <div className="font-medium">{l.name}</div>
                    <Badge className="border-gray-200 bg-gray-50 text-gray-700">{l.radiusM}m</Badge>
                  </div>
                  <div className="text-sm opacity-70">{l.address}</div>
                </button>
              ))}
              {!filtered.length ? <div className="p-3 text-sm opacity-70">Geen locaties gevonden.</div> : null}
            </div>
          </div>
        </div>
      </Card>

      {active ? (
        <Card className="p-4 space-y-3">
          <div className="flex items-center justify-between gap-3">
            <div>
              <div className="text-lg font-semibold">Locatie bewerken</div>
              <div className="text-sm opacity-70">{active.name}</div>
            </div>
            <div className="flex gap-2">
              <Button
                variant="secondary"
                onClick={() => updateM.mutate()}
                disabled={updateM.isPending || !activeId}
              >
                Opslaan
              </Button>
              <Button
                variant="danger"
                onClick={() => {
                  if (confirm('Locatie verwijderen? Dit kan invloed hebben op bestaande diensten.')) {
                    deleteM.mutate(activeId);
                  }
                }}
                disabled={deleteM.isPending || !activeId}
              >
                Verwijderen
              </Button>
            </div>
          </div>

          <div className="grid gap-3 md:grid-cols-2">
            <div>
              <Label>Naam</Label>
              <Input value={editName} onChange={(e) => setEditName(e.target.value)} />
            </div>
            <div>
              <Label>Adres</Label>
              <Input value={editAddress} onChange={(e) => setEditAddress(e.target.value)} />
            </div>

            <div className="md:col-span-2">
              <Label>Zoek adres (kaart)</Label>
              <div className="flex gap-2">
                <Input
                  value={editSearchQ}
                  onChange={(e) => setEditSearchQ(e.target.value)}
                  placeholder="Zoek een adres en klik resultaat"
                />
                <Button
                  variant="secondary"
                  onClick={() => editSearchM.mutate()}
                  disabled={editSearchM.isPending || !editSearchQ.trim()}
                >
                  Zoek
                </Button>
              </div>
              {editSearchResults.length ? (
                <div className="mt-2 rounded border max-h-40 overflow-auto">
                  {editSearchResults.map((r, idx) => (
                    <button
                      key={idx}
                      className="w-full text-left px-3 py-2 border-b hover:bg-gray-50"
                      onClick={async () => {
                        setEditLat(String(r.lat));
                        setEditLng(String(r.lon));
                        setEditAddress(r.displayName);
                        setEditSearchResults([]);
                        try {
                          const rev = await reverseM.mutateAsync({ lat: r.lat, lon: r.lon });
                          const best = rev?.displayName || r.displayName;
                          setEditAddress(best);
                        } catch {
                          // ignore
                        }
                      }}
                    >
                      <div className="text-sm">{r.displayName}</div>
                    </button>
                  ))}
                </div>
              ) : null}
            </div>
            <div>
              <Label>Latitude</Label>
              <Input value={editLat} onChange={(e) => setEditLat(e.target.value)} />
            </div>
            <div>
              <Label>Longitude</Label>
              <Input value={editLng} onChange={(e) => setEditLng(e.target.value)} />
            </div>
            <div>
              <Label>Radius (meters)</Label>
              <Input value={editRadius} onChange={(e) => setEditRadius(e.target.value)} />
            </div>

            <div className="md:col-span-2">
              <Label>Kaart (klik of sleep pin)</Label>
              <LocationMapPicker
                lat={Number(editLat)}
                lng={Number(editLng)}
                radiusM={Number(editRadius)}
                onPick={async (lat, lng) => {
                  setEditLat(String(lat));
                  setEditLng(String(lng));
                  try {
                    const rev = await reverseM.mutateAsync({ lat, lon: lng });
                    const best = rev?.displayName;
                    if (best) setEditAddress(best);
                  } catch {
                    // ignore
                  }
                }}
              />
            </div>
          </div>
        </Card>
      ) : null}
    </div>
  );
}
