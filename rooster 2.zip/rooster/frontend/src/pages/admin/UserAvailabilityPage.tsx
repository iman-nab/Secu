import { useParams, Link } from 'react-router-dom';
import { useMemo, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Badge, Button, Card, Input, Label } from '../../components/ui';
import { createUserAvailability, deleteAvailability, listUserAvailability, updateAvailability } from '../../api/availability';
import { listUsers } from '../../api/users';
import { nlFullDate, nlTime } from '../../utils/datetime';

export default function UserAvailabilityPage() {
  const { userId } = useParams();
  const id = String(userId ?? '');
  const [mode, setMode] = useState<'week' | 'list'>('week');
  const qc = useQueryClient();

  const usersQuery = useQuery({ queryKey: ['users'], queryFn: () => listUsers() });
  const user = usersQuery.data?.users?.find((u) => u.id === id);

  const availabilityQuery = useQuery({
    queryKey: ['availability', 'user', id],
    enabled: !!id,
    queryFn: () => listUserAvailability(id),
  });

  const items = availabilityQuery.data?.items ?? [];

  const [createForm, setCreateForm] = useState({
    type: 'UNAVAILABLE',
    startAt: '',
    endAt: '',
    note: '',
  });

  const createM = useMutation({
    mutationFn: async () => {
      if (!createForm.startAt || !createForm.endAt) throw new Error('Start/eind verplicht');
      const startIso = new Date(createForm.startAt).toISOString();
      const endIso = new Date(createForm.endAt).toISOString();
      return createUserAvailability(id, {
        type: createForm.type as any,
        startAt: startIso,
        endAt: endIso,
        note: createForm.note.trim() || undefined,
      });
    },
    onSuccess: async () => {
      setCreateForm({ type: 'UNAVAILABLE', startAt: '', endAt: '', note: '' });
      await qc.invalidateQueries({ queryKey: ['availability', 'user', id] });
    },
  });

  const updateM = useMutation({
    mutationFn: async (input: { id: string; type: string; startAt: string; endAt: string; note?: string }) =>
      updateAvailability(input.id, {
        type: input.type as any,
        startAt: new Date(input.startAt).toISOString(),
        endAt: new Date(input.endAt).toISOString(),
        note: input.note ?? null,
      }),
    onSuccess: async () => {
      await qc.invalidateQueries({ queryKey: ['availability', 'user', id] });
    },
  });

  const delM = useMutation({
    mutationFn: async (availabilityId: string) => deleteAvailability(availabilityId),
    onSuccess: async () => {
      await qc.invalidateQueries({ queryKey: ['availability', 'user', id] });
    },
  });

  const [edit, setEdit] = useState<Record<string, { type: string; startAt: string; endAt: string; note: string }>>({});

  const toLocal = (iso: string) => {
    const d = new Date(iso);
    const pad = (n: number) => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
  };

  const weeks = useMemo(() => {
    const start = new Date();
    // Monday start
    const day = start.getDay();
    const diff = (day === 0 ? -6 : 1) - day;
    start.setDate(start.getDate() + diff);
    start.setHours(0, 0, 0, 0);

    const days: Date[] = [];
    for (let i = 0; i < 14; i++) {
      const d = new Date(start);
      d.setDate(start.getDate() + i);
      days.push(d);
    }
    return days;
  }, []);

  const overlapsForDay = (d: Date) => {
    const dayStart = new Date(d);
    dayStart.setHours(0, 0, 0, 0);
    const dayEnd = new Date(d);
    dayEnd.setHours(23, 59, 59, 999);
    return items.filter((a: any) => {
      const s = new Date(a.startAt);
      const e = new Date(a.endAt);
      return s < dayEnd && e > dayStart;
    });
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold">Beschikbaarheid</h1>
          <p className="text-sm text-gray-600">{user ? `${user.fullName} (${user.email})` : id}</p>
        </div>
        <Link to="/admin" className="text-sm underline text-gray-700">
          Terug naar admin
        </Link>
      </div>

      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold">Periodes</h2>
        <Badge>{items.length} totaal</Badge>
      </div>

      <Card className="p-4">
        <div className="text-sm font-semibold">Beschikbaarheid toevoegen</div>
        <div className="mt-2 grid grid-cols-1 md:grid-cols-4 gap-3">
          <div>
            <Label>Type</Label>
            <select
              className="mt-1 w-full rounded border px-3 py-2 text-sm"
              value={createForm.type}
              onChange={(e) => setCreateForm((p) => ({ ...p, type: e.target.value }))}
            >
              <option value="UNAVAILABLE">Niet beschikbaar</option>
              <option value="VACATION">Vakantie</option>
              <option value="SICK">Ziek</option>
            </select>
          </div>
          <div>
            <Label>Start</Label>
            <Input type="datetime-local" value={createForm.startAt} onChange={(e) => setCreateForm((p) => ({ ...p, startAt: e.target.value }))} />
          </div>
          <div>
            <Label>Eind</Label>
            <Input type="datetime-local" value={createForm.endAt} onChange={(e) => setCreateForm((p) => ({ ...p, endAt: e.target.value }))} />
          </div>
          <div>
            <Label>Notitie</Label>
            <Input value={createForm.note} onChange={(e) => setCreateForm((p) => ({ ...p, note: e.target.value }))} placeholder="Optioneel" />
          </div>
        </div>
        <div className="mt-3">
          <Button onClick={() => createM.mutate()} disabled={createM.isPending || !id}>
            Toevoegen
          </Button>
        </div>
      </Card>

      <div className="flex items-center gap-2">
        <button
          type="button"
          onClick={() => setMode('week')}
          className={`rounded-full px-3 py-1 text-xs font-medium border ${mode === 'week' ? 'bg-gray-900 text-white border-gray-900' : 'bg-white text-gray-700 border-gray-200'}`}
        >
          Weekoverzicht
        </button>
        <button
          type="button"
          onClick={() => setMode('list')}
          className={`rounded-full px-3 py-1 text-xs font-medium border ${mode === 'list' ? 'bg-gray-900 text-white border-gray-900' : 'bg-white text-gray-700 border-gray-200'}`}
        >
          Lijst
        </button>
      </div>

      {availabilityQuery.isLoading && <div className="text-sm text-gray-600">Loading…</div>}
      {!availabilityQuery.isLoading && items.length === 0 && (
        <div className="text-sm text-gray-600">Geen periodes gevonden.</div>
      )}

      {mode === 'week' ? (
        <div className="grid grid-cols-2 sm:grid-cols-7 gap-2">
          {weeks.map((d) => {
            const list = overlapsForDay(d);
            const label = d.toLocaleDateString('nl-NL', { weekday: 'short' });
            const dayNr = d.getDate();
            const isBlocked = list.length > 0;
            return (
              <Card key={d.toISOString()} className="p-3">
                <div className="flex items-center justify-between">
                  <div className="text-xs text-gray-500">{label}</div>
                  <div className="text-xs font-semibold">{dayNr}</div>
                </div>
                <div className="mt-2">
                  {isBlocked ? (
                    <div className="space-y-1">
                      {list.slice(0, 2).map((a: any) => (
                        <div key={a.id} className="text-xs">
                          <span className="inline-flex rounded-full border px-2 py-0.5">{a.type}</span>
                        </div>
                      ))}
                      {list.length > 2 ? <div className="text-xs text-gray-500">+{list.length - 2} meer</div> : null}
                    </div>
                  ) : (
                    <div className="text-xs text-emerald-700">Beschikbaar</div>
                  )}
                </div>
              </Card>
            );
          })}
        </div>
      ) : (
        <div className="space-y-2">
          {items.map((a) => (
            <Card key={a.id} className="p-4">
              {!edit[a.id] ? (
                <>
                  <div className="flex items-center justify-between gap-2">
                    <div className="font-semibold">{a.type}</div>
                    <div className="flex gap-2">
                      <Button
                        variant="secondary"
                        onClick={() =>
                          setEdit((p) => ({
                            ...p,
                            [a.id]: {
                              type: a.type,
                              startAt: toLocal(a.startAt),
                              endAt: toLocal(a.endAt),
                              note: a.note ?? '',
                            },
                          }))
                        }
                      >
                        Bewerk
                      </Button>
                      <Button
                        variant="danger"
                        onClick={() => {
                          if (window.confirm('Periode verwijderen?')) delM.mutate(a.id);
                        }}
                        disabled={delM.isPending}
                      >
                        Verwijder
                      </Button>
                    </div>
                  </div>
                  <div className="text-sm text-gray-600">
                    {nlFullDate(a.startAt)} {nlTime(a.startAt)} – {nlFullDate(a.endAt)} {nlTime(a.endAt)}
                  </div>
                  {a.note ? <div className="text-sm text-gray-700 mt-1">{a.note}</div> : null}
                </>
              ) : (
                <>
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                    <div>
                      <Label>Type</Label>
                      <select
                        className="mt-1 w-full rounded border px-3 py-2 text-sm"
                        value={edit[a.id].type}
                        onChange={(e) => setEdit((p) => ({ ...p, [a.id]: { ...p[a.id], type: e.target.value } }))}
                      >
                        <option value="UNAVAILABLE">Niet beschikbaar</option>
                        <option value="VACATION">Vakantie</option>
                        <option value="SICK">Ziek</option>
                      </select>
                    </div>
                    <div>
                      <Label>Start</Label>
                      <Input
                        type="datetime-local"
                        value={edit[a.id].startAt}
                        onChange={(e) => setEdit((p) => ({ ...p, [a.id]: { ...p[a.id], startAt: e.target.value } }))}
                      />
                    </div>
                    <div>
                      <Label>Eind</Label>
                      <Input
                        type="datetime-local"
                        value={edit[a.id].endAt}
                        onChange={(e) => setEdit((p) => ({ ...p, [a.id]: { ...p[a.id], endAt: e.target.value } }))}
                      />
                    </div>
                    <div>
                      <Label>Notitie</Label>
                      <Input
                        value={edit[a.id].note}
                        onChange={(e) => setEdit((p) => ({ ...p, [a.id]: { ...p[a.id], note: e.target.value } }))}
                      />
                    </div>
                  </div>
                  <div className="mt-3 flex gap-2">
                    <Button
                      onClick={() => {
                        const st = edit[a.id];
                        updateM.mutate({ id: a.id, ...st });
                        setEdit((p) => {
                          const n = { ...p };
                          delete n[a.id];
                          return n;
                        });
                      }}
                      disabled={updateM.isPending}
                    >
                      Opslaan
                    </Button>
                    <Button
                      variant="secondary"
                      onClick={() =>
                        setEdit((p) => {
                          const n = { ...p };
                          delete n[a.id];
                          return n;
                        })
                      }
                    >
                      Annuleer
                    </Button>
                  </div>
                </>
              )}
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
