import { useEffect, useState } from 'react';
import { Button, Card } from '../../components/ui';

import AccountsTab from './tabs/AccountsTab';
import LocationsTab from './tabs/LocationsTab';
import MaterialsTab from './tabs/MaterialsTab';
import ShiftsTab from './tabs/ShiftsTab';
import RequestsTab from './tabs/RequestsTab';
import KpisTab from './tabs/KpisTab';
import PushTab from './tabs/PushTab';

type Tab = 'accounts' | 'locations' | 'materials' | 'shifts' | 'requests' | 'kpis' | 'push';

export default function AdminPage() {
  const [tab, setTab] = useState<Tab>('accounts');

  // Admin shortcuts:
  // - N: create new (focus the create form for the active tab)
  // - Ctrl/Cmd + S: save/submit (best-effort for create/edit forms)
  useEffect(() => {
    const isTypingTarget = (el: EventTarget | null) => {
      const node = el as HTMLElement | null;
      if (!node) return false;
      const tag = (node.tagName || '').toLowerCase();
      if (tag === 'input' || tag === 'textarea' || tag === 'select') return true;
      if ((node as any).isContentEditable) return true;
      return false;
    };

    const onKeyDown = (e: KeyboardEvent) => {
      // Ctrl/Cmd+S should work even while typing (common muscle memory)
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
        e.preventDefault();
        window.dispatchEvent(new CustomEvent('rooster:admin:save', { detail: { tab } }));
        return;
      }

      if (isTypingTarget(e.target)) return;

      if (e.key.toLowerCase() === 'n' && !e.altKey && !e.ctrlKey && !e.metaKey) {
        e.preventDefault();
        window.dispatchEvent(new CustomEvent('rooster:admin:new', { detail: { tab } }));
      }
    };

    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [tab]);

  return (
    <div className="space-y-4">
      <Card className="p-4">
        <div className="flex flex-wrap gap-2">
          {(
            [
              { key: 'accounts', label: 'Gebruikers & Opdrachtgevers' },
              { key: 'locations', label: 'Locaties' },
              { key: 'materials', label: 'Materialen' },
              { key: 'shifts', label: 'Diensten' },
              { key: 'requests', label: 'Verzoeken' },
              { key: 'kpis', label: "KPI's" },
              { key: 'push', label: 'Push' },
            ] as Array<{ key: Tab; label: string }>
          ).map((t) => (
            <Button
              key={t.key}
              variant={tab === t.key ? 'primary' : 'secondary'}
              onClick={() => setTab(t.key)}
            >
              {t.label}
            </Button>
          ))}
        </div>
      </Card>

      {tab === 'accounts' && <AccountsTab />}
      {tab === 'locations' && <LocationsTab />}
      {tab === 'materials' && <MaterialsTab />}
      {tab === 'shifts' && <ShiftsTab />}
      {tab === 'requests' && <RequestsTab />}
      {tab === 'kpis' && <KpisTab />}
      {tab === 'push' && <PushTab />}
    </div>
  );
}
