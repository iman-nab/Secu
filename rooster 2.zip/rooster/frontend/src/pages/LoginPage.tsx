import { useMemo, useState } from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { useLogin, useMe } from '../hooks/useAuth';
import { Navigate, useNavigate } from 'react-router-dom';
import { Button, Card, ErrorBanner, Input, Label } from '../components/ui';

const TFA_TEMP_STORAGE_KEY = 'tfa_temp_token';

const schema = z.object({
  email: z.string().min(1, 'Required').email('Invalid email'),
  password: z.string().min(1, 'Required'),
});

type LoginValues = z.infer<typeof schema>;

export default function LoginPage() {
  const { data: me } = useMe();
  const login = useLogin();
  const [err, setErr] = useState<string | undefined>();
  const nav = useNavigate();

  const form = useForm<LoginValues>({
    resolver: zodResolver(schema),
    defaultValues: { email: '', password: '' },
    mode: 'onSubmit',
  });

  const submit = form.handleSubmit(async (values) => {
    setErr(undefined);
    try {
      const result = await login.mutateAsync(values);
      if (result.twoFactorRequired) {
        sessionStorage.setItem(TFA_TEMP_STORAGE_KEY, result.tempToken);
        nav('/2fa/verify', { replace: true });
      }
    } catch (e: any) {
      setErr(e?.error ?? e?.message ?? 'Login failed');
    }
  });

  const demo = useMemo(
    () => ({
      admin: { email: 'admin@example.com', password: 'Admin123!' },
      employee: { email: 'employee@example.com', password: 'Employee123!' },
    }),
    [],
  );

  if (me) return <Navigate to="/dashboard" replace />;

  return (
    <div className="mx-auto flex min-h-screen max-w-6xl items-center justify-center px-4">
      <Card className="w-full max-w-md p-6">
        <h1 className="text-xl font-semibold">Inloggen</h1>
        <p className="mt-1 text-sm text-gray-600">
          Gebruik HTTPS in productie (vereist voor Geolocation API).
        </p>

        <div className="mt-4">
          <ErrorBanner message={err} />
        </div>

        <form onSubmit={submit} className="mt-4 space-y-4">
          <div>
            <Label htmlFor="email">E-mail</Label>
            <Input
              id="email"
              type="email"
              autoComplete="email"
              {...form.register('email')}
            />
            {form.formState.errors.email?.message && (
              <div className="mt-1 text-xs text-red-600">
                {form.formState.errors.email.message}
              </div>
            )}
          </div>

          <div>
            <Label htmlFor="password">Wachtwoord</Label>
            <Input
              id="password"
              type="password"
              autoComplete="current-password"
              {...form.register('password')}
            />
            {form.formState.errors.password?.message && (
              <div className="mt-1 text-xs text-red-600">
                {form.formState.errors.password.message}
              </div>
            )}
          </div>

          <Button className="w-full" type="submit" disabled={login.isPending}>
            {login.isPending ? 'Bezig…' : 'Login'}
          </Button>
        </form>

        <div className="mt-6 rounded-xl border bg-gray-50 p-4 text-xs text-gray-700">
          <div className="font-semibold">Demo accounts (na seed)</div>
          <div className="mt-2 flex flex-col gap-2">
            <button
              className="text-left underline"
              onClick={() => {
                form.setValue('email', demo.admin.email, { shouldValidate: true });
                form.setValue('password', demo.admin.password, { shouldValidate: true });
              }}
              type="button"
            >
              Admin: {demo.admin.email}
            </button>

            <button
              className="text-left underline"
              onClick={() => {
                form.setValue('email', demo.employee.email, { shouldValidate: true });
                form.setValue('password', demo.employee.password, { shouldValidate: true });
              }}
              type="button"
            >
              Employee: {demo.employee.email}
            </button>
          </div>
        </div>
      </Card>
    </div>
  );
}
