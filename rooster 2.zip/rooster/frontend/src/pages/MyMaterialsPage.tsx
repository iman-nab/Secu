import { useEffect, useMemo, useState } from 'react';
import { Badge, Button, Card, ErrorBanner, Input, Label } from '../components/ui';
import { listMyMaterialAssignments, reportMaterialIssue, type MaterialAssignment } from '../api/materials';

export default function MyMaterialsPage() {
  const [items, setItems] = useState<MaterialAssignment[]>([]);
  const [error, setError] = useState<string | undefined>();
  const [busyId, setBusyId] = useState<string | null>(null);
  const [note, setNote] = useState<Record<string, string>>({});

  async function refresh() {
    setError(undefined);
    const res = await listMyMaterialAssignments();
    setItems(res.assignments);
  }

  useEffect(() => {
    refresh().catch((e) => setError(e?.message ?? 'Fout bij laden'));
  }, []);

  const active = useMemo(
    () => items.filter((a) => a.status === 'ASSIGNED' || a.status === 'LOST' || a.status === 'DEFECT'),
    [items]
  );

  async function report(id: string, kind: 'LOST' | 'DEFECT') {
    try {
      setBusyId(id);
      setError(undefined);
      await reportMaterialIssue(id, kind, note[id]);
      await refresh();
    } catch (e: any) {
      setError(e?.message ?? 'Fout bij melden');
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div className="space-y-4">
      <Card className="p-4">
        <div className="flex items-center justify-between gap-4">
          <div>
            <h1 className="text-lg font-semibold">Mijn materialen</h1>
            <p className="text-sm text-gray-600">Hier zie je welke materialen aan jou zijn uitgegeven.</p>
          </div>
          <Button variant="secondary" onClick={() => refresh()} disabled={!!busyId}>
            Verversen
          </Button>
        </div>
      </Card>

      <ErrorBanner message={error} />

      {active.length === 0 ? (
        <Card className="p-4">
          <p className="text-sm text-gray-700">Je hebt momenteel geen toegewezen materialen.</p>
        </Card>
      ) : (
        <div className="space-y-3">
          {active.map((a) => (
            <Card key={a.id} className="p-4 space-y-2">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="space-y-1">
                  <div className="text-sm font-semibold">{a.material?.name ?? 'Materiaal'}</div>
                  <div className="text-xs text-gray-600">
                    Aantal: <span className="font-medium">{a.quantity}</span>
                    {a.material?.description ? ` • ${a.material.description}` : ''}
                  </div>
                </div>
                <Badge>{a.status}</Badge>
              </div>

              {(a.status === 'ASSIGNED') && (
                <>
                  <div className="grid gap-2">
                    <Label>Opmerking (optioneel)</Label>
                    <Input
                      placeholder="Bijv. verloren tijdens dienst..."
                      value={note[a.id] ?? ''}
                      onChange={(e) => setNote((s) => ({ ...s, [a.id]: e.target.value }))}
                    />
                  </div>

                  <div className="flex flex-wrap gap-2 pt-2">
                    <Button
                      variant="danger"
                      onClick={() => report(a.id, 'LOST')}
                      disabled={busyId === a.id}
                      title="Markeer als verloren"
                    >
                      Verloren
                    </Button>
                    <Button
                      variant="secondary"
                      onClick={() => report(a.id, 'DEFECT')}
                      disabled={busyId === a.id}
                      title="Markeer als defect"
                    >
                      Defect
                    </Button>
                  </div>
                  <p className="text-xs text-gray-500">
                    Let op: na melden wordt dit zichtbaar voor de admin in de historie.
                  </p>
                </>
              )}

              {a.status !== 'ASSIGNED' && (
                <p className="text-xs text-gray-600">
                  Status is gemeld als <span className="font-medium">{a.status}</span>.
                </p>
              )}
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
