import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { createClientRequest, listClientRequests, type ClientRequestStatus } from '../../api/client';
import { Badge, Button, Card, ErrorBanner, Input, Label, SuccessBanner } from '../../components/ui';

function getErrorMessage(err: unknown): string | undefined {
  if (!err) return undefined;
  if (typeof err === 'string') return err;
  if (err instanceof Error) return err.message;
  return (err as any)?.message || (err as any)?.error;
}

function statusLabel(s: ClientRequestStatus) {
  if (s === 'OPEN') return 'Open';
  if (s === 'IN_PROGRESS') return 'In behandeling';
  return 'Afgerond';
}

export default function ClientRequestsPage() {
  const qc = useQueryClient();
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [success, setSuccess] = useState<string | undefined>();

  const q = useQuery({
    queryKey: ['client', 'requests'],
    queryFn: async () => (await listClientRequests()).requests,
  });

  const m = useMutation({
    mutationFn: async () => createClientRequest({ subject, message }),
    onSuccess: async () => {
      setSubject('');
      setMessage('');
      setSuccess('Verzoek verzonden.');
      await qc.invalidateQueries({ queryKey: ['client', 'requests'] });
      setTimeout(() => setSuccess(undefined), 2500);
    },
  });

  const submit = async () => {
    setSuccess(undefined);
    await m.mutateAsync();
  };

  const requests = q.data ?? [];

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-semibold">Verzoeken</h1>
        <p className="mt-1 text-sm text-gray-600">Stuur een verzoek naar de admin (inbox) en volg de status.</p>
      </div>

      <SuccessBanner message={success} />
      <ErrorBanner message={getErrorMessage(q.error) || getErrorMessage(m.error)} />

      <Card className="p-4">
        <div className="text-sm font-semibold">Nieuw verzoek</div>
        <div className="mt-3 grid gap-3">
          <div>
            <Label htmlFor="subject">Onderwerp</Label>
            <Input id="subject" value={subject} onChange={(e) => setSubject(e.target.value)} placeholder="Bijv. extra beveiliging op datum X" />
          </div>
          <div>
            <Label htmlFor="message">Bericht</Label>
            <textarea
              id="message"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              rows={4}
              className="w-full rounded border px-3 py-2 text-sm outline-none focus:ring"
              placeholder="Beschrijf je verzoek zo concreet mogelijk..."
            />
          </div>
          <div className="flex justify-end">
            <Button type="button" onClick={submit} disabled={m.isPending || !subject.trim() || !message.trim()}>
              {m.isPending ? 'Verzenden…' : 'Verzenden'}
            </Button>
          </div>
        </div>
      </Card>

      <Card className="p-4">
        <div className="flex items-center justify-between gap-2">
          <div className="text-sm font-semibold">Mijn verzoeken</div>
          <div className="text-xs text-gray-500">{q.isLoading ? 'Laden…' : `${requests.length} totaal`}</div>
        </div>

        {requests.length === 0 && !q.isLoading ? (
          <div className="mt-3 text-sm text-gray-600">Nog geen verzoeken.</div>
        ) : (
          <div className="mt-4 space-y-3">
            {requests.map((r) => (
              <div key={r.id} className="rounded-2xl border bg-white p-3">
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div>
                    <div className="text-sm font-semibold">{r.subject}</div>
                    <div className="mt-1 text-xs text-gray-500">{new Date(r.createdAt).toLocaleString()}</div>
                  </div>
                  <Badge>{statusLabel(r.status)}</Badge>
                </div>
                <div className="mt-2 whitespace-pre-wrap text-sm text-gray-800">{r.message}</div>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}
