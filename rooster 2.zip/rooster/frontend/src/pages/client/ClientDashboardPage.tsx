import { useMemo, useState, type FC } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { listClientShifts, createShiftNote } from '../../api/clientPortal';
import { pinShiftNote } from '../../api/shifts';
import { getShiftReport } from '../../api/shifts';
import type { Shift } from '../../api/types';
import { Badge, Button, Card, ErrorBanner, Input, Label } from '../../components/ui';
import { formatDateTimeNL, hoursBetween } from '../../utils/format';

function getErrorMessage(err: unknown): string | undefined {
  if (!err) return undefined;
  if (typeof err === 'string') return err;
  if (err instanceof Error) return err.message;
  const anyErr = err as any;
  return anyErr?.message ?? anyErr?.error;
}

function toISODate(d: Date) {
  return d.toISOString().slice(0, 10);
}

export default function ClientDashboardPage() {
  const qc = useQueryClient();
  const [start, setStart] = useState(() => toISODate(new Date()));
  const [end, setEnd] = useState(() => toISODate(new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)));

  const shiftsQ = useQuery({
    queryKey: ['client', 'shifts', start, end],
    queryFn: async () => (await listClientShifts({ start, end })).shifts,
  });

  const noteM = useMutation({
    mutationFn: async (input: { shiftId: string; content: string }) =>
      createShiftNote(input.shiftId, { content: input.content, visibleToEmployees: true }),
    onSuccess: async () => {
      await qc.invalidateQueries({ queryKey: ['client', 'shifts'] });
      await qc.invalidateQueries({ queryKey: ['client', 'notes'] });
    },
  });

  const pinM = useMutation({
    mutationFn: async (input: { shiftId: string; noteId: string; pinned: boolean }) =>
      pinShiftNote(input.shiftId, input.noteId, input.pinned),
    onSuccess: async () => {
      await qc.invalidateQueries({ queryKey: ['client', 'shifts'] });
      await qc.invalidateQueries({ queryKey: ['client', 'notes'] });
    },
  });

  const shifts = shiftsQ.data ?? [];

  const nextShift = useMemo(() => {
    const now = Date.now();
    return shifts
      .slice()
      .filter((s) => new Date(s.endAt).getTime() > now)
      .sort((a, b) => new Date(a.startAt).getTime() - new Date(b.startAt).getTime())[0];
  }, [shifts]);

  const totalPlannedHours = useMemo(() => {
    return shifts.reduce((sum, s) => sum + hoursBetween(new Date(s.startAt), new Date(s.endAt)), 0);
  }, [shifts]);

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-semibold">Opdrachtgever portal</h1>
        <p className="mt-1 text-sm text-gray-600">
          Bekijk ingeplande diensten voor jouw opdrachtgever en laat notities achter (zichtbaar voor medewerkers).
        </p>
      </div>

      <Card className="p-4">
        <div className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
          <div className="grid gap-3 md:grid-cols-2">
            <div>
              <Label htmlFor="filter-start">Van</Label>
              <Input id="filter-start" type="date" value={start} onChange={(e) => setStart(e.target.value)} />
            </div>
            <div>
              <Label htmlFor="filter-end">Tot</Label>
              <Input id="filter-end" type="date" value={end} onChange={(e) => setEnd(e.target.value)} />
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            <Button type="button" variant="secondary" onClick={() => {
              const d = new Date();
              setStart(toISODate(d));
              setEnd(toISODate(new Date(d.getTime() + 7 * 24 * 60 * 60 * 1000)));
            }}>7 dagen</Button>
            <Button type="button" variant="secondary" onClick={() => {
              const d = new Date();
              setStart(toISODate(d));
              setEnd(toISODate(new Date(d.getTime() + 30 * 24 * 60 * 60 * 1000)));
            }}>30 dagen</Button>
          </div>
        </div>
      </Card>

      <div className="grid gap-3 md:grid-cols-3">
        <Card className="p-4">
          <div className="text-sm text-gray-600">Periode</div>
          <div className="mt-1 text-sm font-medium">
            {start} → {end}
          </div>
        </Card>
        <Card className="p-4">
          <div className="text-sm text-gray-600">Ingeplande uren</div>
          <div className="mt-1 text-2xl font-semibold">{totalPlannedHours.toFixed(1)}</div>
        </Card>
        <Card className="p-4">
          <div className="text-sm text-gray-600">Eerstvolgende dienst</div>
          <div className="mt-1 text-sm font-medium">
            {nextShift ? formatDateTimeNL(nextShift.startAt) : '—'}
          </div>
          {nextShift?.title && <div className="mt-1 text-xs text-gray-500">{nextShift.title}</div>}
        </Card>
      </div>

  <ErrorBanner message={getErrorMessage(shiftsQ.error)} />

      <div className="space-y-3">
        {shifts.length === 0 && !shiftsQ.isLoading && (
          <Card className="p-4">
            <div className="text-sm text-gray-600">Geen diensten in deze periode.</div>
          </Card>
        )}

        {shifts.map((s: Shift) => (
          <ClientShiftCard
            key={s.id}
            shift={s}
            onAddNote={async (content) => noteM.mutateAsync({ shiftId: s.id, content })}
            onPinNote={async (noteId, pinned) => pinM.mutateAsync({ shiftId: s.id, noteId, pinned })}
            isSaving={noteM.isPending}
            isPinning={pinM.isPending}
          />
        ))}
      </div>
    </div>
  );
}

type ClientShiftCardProps = {
  shift: Shift;
  onAddNote: (content: string) => Promise<unknown>;
  onPinNote: (noteId: string, pinned: boolean) => Promise<unknown>;
  isSaving: boolean;
  isPinning: boolean;
};

const ClientShiftCard: FC<ClientShiftCardProps> = ({ shift, onAddNote, onPinNote, isSaving, isPinning }) => {
  const [content, setContent] = useState('');
  const [err, setErr] = useState<string | undefined>();
  const [showReport, setShowReport] = useState(false);

  const reportQ = useQuery({
    queryKey: ['client', 'shift-report', shift.id],
    queryFn: async () => (await getShiftReport(shift.id)).report,
    enabled: showReport,
  });

  const submit = async () => {
    setErr(undefined);
    const text = content.trim();
    if (!text) return setErr('Schrijf eerst een notitie.');
    try {
      await onAddNote(text);
      setContent('');
    } catch (e: any) {
      setErr(e?.error ?? e?.message ?? 'Opslaan mislukt');
    }
  };

  return (
    <Card className="p-4">
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div>
          <div className="text-sm font-semibold">{shift.title}</div>
          <div className="mt-1 text-xs text-gray-600">
            {formatDateTimeNL(shift.startAt)} → {formatDateTimeNL(shift.endAt)}
          </div>
          <div className="mt-1 text-xs text-gray-500">
            {shift.location?.name} · {shift.location?.address}
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Badge>{shift.status}</Badge>
          {shift.requiredWorkers ? <Badge>{shift.requiredWorkers}×</Badge> : null}
        </div>
      </div>

      {shift.notes && shift.notes.length > 0 && (
        <div className="mt-4">
          <div className="text-xs font-semibold text-gray-700">Notities</div>
          <div className="mt-2 space-y-2">
            {shift.notes.map((n) => (
              <div key={n.id} className="rounded-xl border bg-gray-50 px-3 py-2 text-sm">
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-gray-500">
                  <div className="flex items-center gap-2">
                    <span>{n.author?.fullName ?? 'Klant'} · {formatDateTimeNL(n.createdAt)}</span>
                    {(n as any).isPinned ? (
                      <span className="rounded-full bg-yellow-50 px-2 py-0.5 text-xs font-medium text-yellow-800 border border-yellow-200">Vastgezet</span>
                    ) : null}
                  </div>
                  <Button
                    type="button"
                    variant="secondary"
                    className="px-2 py-1 text-xs"
                    disabled={isPinning}
                    onClick={async () => {
                      await onPinNote(n.id, !(n as any).isPinned);
                    }}
                  >
                    {(n as any).isPinned ? 'Losmaken' : 'Vastzetten'}
                  </Button>
                </div>
                <div className="mt-1 whitespace-pre-wrap">{n.content}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="mt-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="text-xs font-semibold text-gray-700">Dagrapportage</div>
          <div className="flex gap-2">
            <a href={`/shifts/${shift.id}/report/pdf`} target="_blank" rel="noreferrer">
              <Button type="button" variant="secondary" className="px-2 py-1 text-xs">PDF</Button>
            </a>
            <Button
              type="button"
              variant="secondary"
              className="px-2 py-1 text-xs"
              onClick={() => setShowReport((v) => !v)}
            >
              {showReport ? 'Verberg' : 'Toon'}
            </Button>
          </div>
        </div>

        {showReport && (
          <div className="mt-2 rounded-xl border bg-gray-50 px-3 py-2 text-sm">
            {reportQ.isLoading ? (
              <div className="text-sm text-gray-600">Laden…</div>
            ) : reportQ.error ? (
              <div className="text-sm text-red-700">Rapport laden mislukt</div>
            ) : reportQ.data ? (
              <div className="space-y-2">
                <div className="text-xs text-gray-600">Locatie: <span className="font-medium text-gray-900">{reportQ.data.locationText || '—'}</span></div>
                <div>
                  <div className="text-xs font-semibold text-gray-700">Incidenten</div>
                  <div className="text-xs text-gray-600">
                    {reportQ.data.incidents.filter((i) => i.checked).length === 0
                      ? 'Geen incidenten.'
                      : reportQ.data.incidents.filter((i) => i.checked).map((i) => i.label).join(', ')}
                  </div>
                </div>
                <div>
                  <div className="text-xs font-semibold text-gray-700">Acties</div>
                  <div className="text-xs text-gray-600">
                    {reportQ.data.actions.length === 0 ? 'Geen acties.' : `${reportQ.data.actions.length} item(s)`}
                  </div>
                </div>
                <div className="text-xs text-gray-600">Bijlagen: <span className="font-medium text-gray-900">{reportQ.data.attachments.length}</span></div>
                {reportQ.data.summary ? (
                  <div>
                    <div className="text-xs font-semibold text-gray-700">Opmerkingen</div>
                    <div className="mt-1 whitespace-pre-wrap text-sm">{reportQ.data.summary}</div>
                  </div>
                ) : null}
              </div>
            ) : (
              <div className="text-sm text-gray-600">Geen rapport.</div>
            )}
          </div>
        )}
      </div>

      <div className="mt-4">
        <Label htmlFor={`note-${shift.id}`}>Nieuwe notitie</Label>
        <Input
          id={`note-${shift.id}`}
          value={content}
          onChange={(e) => setContent(e.target.value)}
          placeholder="Bijv. stadionverbod: ..."
        />
        {err && <div className="mt-1 text-xs text-red-600">{err}</div>}
        <div className="mt-2 flex justify-end">
          <Button type="button" onClick={submit} disabled={isSaving}>
            {isSaving ? 'Opslaan…' : 'Notitie opslaan'}
          </Button>
        </div>
      </div>
    </Card>
  );
};
