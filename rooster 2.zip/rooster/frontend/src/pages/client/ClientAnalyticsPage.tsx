import { useMemo, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { getClientIncidentAnalytics } from '../../api/client';
import { Button, Card, ErrorBanner, Input, Label } from '../../components/ui';

function toISODate(d: Date) {
  return d.toISOString().slice(0, 10);
}

function getErrorMessage(err: unknown): string | undefined {
  if (!err) return undefined;
  if (typeof err === 'string') return err;
  if (err instanceof Error) return err.message;
  return (err as any)?.message || (err as any)?.error;
}

export default function ClientAnalyticsPage() {
  const [start, setStart] = useState(() => toISODate(new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)));
  const [end, setEnd] = useState(() => toISODate(new Date(Date.now() + 1 * 24 * 60 * 60 * 1000)));

  const q = useQuery({
    queryKey: ['client', 'analytics', 'incidents', start, end],
    queryFn: async () => getClientIncidentAnalytics({ start, end, limit: 12 }),
  });

  const items = q.data?.items ?? [];
  const max = useMemo(() => (items.length ? Math.max(...items.map((i) => i.count)) : 0), [items]);

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-semibold">Incident analytics</h1>
        <p className="mt-1 text-sm text-gray-600">Meest voorkomende incidenten op basis van dagrapportages in de gekozen periode.</p>
      </div>

      <Card className="p-4">
        <div className="grid gap-3 md:grid-cols-3 md:items-end">
          <div>
            <Label htmlFor="start">Van</Label>
            <Input id="start" type="date" value={start} onChange={(e) => setStart(e.target.value)} />
          </div>
          <div>
            <Label htmlFor="end">Tot</Label>
            <Input id="end" type="date" value={end} onChange={(e) => setEnd(e.target.value)} />
          </div>
          <div className="flex flex-wrap gap-2">
            <Button
              type="button"
              variant="secondary"
              onClick={() => {
                const d = new Date();
                setStart(toISODate(new Date(d.getTime() - 7 * 24 * 60 * 60 * 1000)));
                setEnd(toISODate(new Date(d.getTime() + 1 * 24 * 60 * 60 * 1000)));
              }}
            >
              7 dagen
            </Button>
            <Button
              type="button"
              variant="secondary"
              onClick={() => {
                const d = new Date();
                setStart(toISODate(new Date(d.getTime() - 30 * 24 * 60 * 60 * 1000)));
                setEnd(toISODate(new Date(d.getTime() + 1 * 24 * 60 * 60 * 1000)));
              }}
            >
              30 dagen
            </Button>
          </div>
        </div>
      </Card>

      <ErrorBanner message={getErrorMessage(q.error)} />

      <Card className="p-4">
        <div className="flex items-center justify-between gap-2">
          <div className="text-sm font-semibold">Top incidenten</div>
          <div className="text-xs text-gray-500">{q.isLoading ? 'Laden…' : `${items.length} items`}</div>
        </div>

        {items.length === 0 && !q.isLoading ? (
          <div className="mt-3 text-sm text-gray-600">Geen incidenten gevonden in deze periode.</div>
        ) : (
          <div className="mt-4 space-y-3">
            {items.map((it) => {
              const pct = max ? Math.round((it.count / max) * 100) : 0;
              return (
                <div key={it.label} className="space-y-1">
                  <div className="flex items-center justify-between gap-2 text-sm">
                    <div className="font-medium">{it.label}</div>
                    <div className="text-xs text-gray-500">{it.count}</div>
                  </div>
                  <div className="h-2 w-full rounded-full bg-gray-100">
                    <div className="h-2 rounded-full bg-gray-900" style={{ width: `${pct}%` }} />
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </Card>
    </div>
  );
}
