import { useQuery, useQueryClient } from '@tanstack/react-query';
import { listOpenShifts, requestShift } from '../api/shifts';
import { listLocations } from '../api/locations';
import { Button, Card, ErrorBanner, Input, Label } from '../components/ui';
import { PaginationControls } from '../components/PaginationControls';
import { useMemo, useState } from 'react';

function fmtDayLabel(d: Date) {
  return d.toLocaleDateString('nl-NL', { weekday: 'long', year: 'numeric', month: '2-digit', day: '2-digit' });
}

function fmtTimeRange(startAt: string, endAt: string) {
  const s = new Date(startAt);
  const e = new Date(endAt);
  const ss = s.toLocaleTimeString('nl-NL', { hour: '2-digit', minute: '2-digit' });
  const ee = e.toLocaleTimeString('nl-NL', { hour: '2-digit', minute: '2-digit' });
  return `${ss}–${ee}`;
}

export default function OpenShiftsPage() {
  const qc = useQueryClient();
  const [err, setErr] = useState<string | undefined>();
  const [search, setSearch] = useState('');
  const [pendingId, setPendingId] = useState<string>('');

  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(25);

  const [eligibility, setEligibility] = useState<'all' | 'eligible' | 'ineligible'>('eligible');
  const [occupancy, setOccupancy] = useState<'all' | 'free' | 'full'>('free');
  const [type, setType] = useState<string>('');
  const [locationId, setLocationId] = useState<string>('');

  const { data: locationsData } = useQuery({ queryKey: ['locations'], queryFn: () => listLocations() });

  const { data, isLoading } = useQuery({
    queryKey: ['openShifts', { eligibility, occupancy, type, locationId, search, page, pageSize }],
    queryFn: () => listOpenShifts({
      eligibility,
      occupancy,
      ...(type.trim() ? { type: type.trim() } : {}),
      ...(locationId ? { locationId } : {}),
      ...(search.trim() ? { q: search.trim() } : {}),
      page,
      pageSize,
    }),
  });

  const grouped = useMemo(() => {
    const filtered = (data?.shifts ?? []) as any[];
    const map = new Map<string, any[]>();
    for (const s of filtered) {
      const key = fmtDayLabel(new Date(s.startAt));
      if (!map.has(key)) map.set(key, []);
      map.get(key)!.push(s);
    }
    return Array.from(map.entries()).map(([dayLabel, items]) => ({
      dayLabel,
      items: items.sort((a, b) => new Date(a.startAt).getTime() - new Date(b.startAt).getTime()),
    }));
  }, [data]);

  const totalCount = (data as any)?.totalCount as number | undefined;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-lg font-semibold">Open diensten</h1>
      </div>

      <ErrorBanner message={err} />

      <div className="grid gap-3 md:grid-cols-12">
        <div className="md:col-span-6">
          <Label>Zoeken</Label>
          <Input
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setPage(1);
            }}
            placeholder="Zoek op titel, locatie of opdrachtgever"
          />
        </div>
        <div className="md:col-span-6 flex items-end">
          <div className="text-sm opacity-80">
            {totalCount ?? (data?.shifts?.length ?? 0)} open diensten
          </div>
        </div>
      </div>

      <div className="grid gap-3 md:grid-cols-12">
        <div className="md:col-span-3">
          <Label>Kleurpas-geschiktheid</Label>
          <select
            className="w-full border rounded-xl px-3 py-2"
            value={eligibility}
            onChange={(e) => {
              setEligibility(e.target.value as any);
              setPage(1);
            }}
          >
            <option value="eligible">Geschikt</option>
            <option value="ineligible">Ongeschikt</option>
            <option value="all">Alle</option>
          </select>
        </div>
        <div className="md:col-span-3">
          <Label>Bezetting</Label>
          <select
            className="w-full border rounded-xl px-3 py-2"
            value={occupancy}
            onChange={(e) => {
              setOccupancy(e.target.value as any);
              setPage(1);
            }}
          >
            <option value="free">Vrij</option>
            <option value="full">Vol</option>
            <option value="all">Alle</option>
          </select>
        </div>
        <div className="md:col-span-3">
          <Label>Type</Label>
          <Input value={type} onChange={(e) => { setType(e.target.value); setPage(1); }} placeholder="Bijv. GENERAL" />
        </div>
        <div className="md:col-span-3">
          <Label>Locatie</Label>
          <select
            className="w-full border rounded-xl px-3 py-2"
            value={locationId}
            onChange={(e) => {
              setLocationId(e.target.value);
              setPage(1);
            }}
          >
            <option value="">Alle locaties</option>
            {(locationsData?.locations ?? []).map((l: any) => (
              <option key={l.id} value={l.id}>
                {l.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="space-y-3">
        {grouped.map((g) => (
          <details key={g.dayLabel} open className="border rounded-xl">
            <summary className="cursor-pointer select-none px-4 py-3 font-semibold flex items-center justify-between">
              <span>{g.dayLabel}</span>
              <span className="text-sm opacity-70">{g.items.length} diensten</span>
            </summary>
            <div className="px-4 pb-4 space-y-2">
              {g.items.map((s: any) => {
                const occ = s.occupancy ?? {
                  approved: 0,
                  required: s.requiredWorkers ?? 1,
                  remaining: Math.max(0, (s.requiredWorkers ?? 1) - 0),
                  filled: false,
                };
                const eligible = s.eligible !== false;
                return (
                  <Card key={s.id} className="p-4">
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <div className="font-semibold truncate">{s.title}</div>
                        <div className="text-sm text-gray-600">
                          {fmtTimeRange(s.startAt, s.endAt)} • {s.location?.name ?? '—'}
                          {s.client?.name ? ` • ${s.client.name}` : ''}
                        </div>
                        <div className="text-xs opacity-80 mt-1">
                          Bezetting: {occ.approved}/{occ.required} {occ.remaining > 0 ? `(nog ${occ.remaining})` : '(vol)'}
                          {typeof s.requiredPassColor === 'string' ? ` • Kleurpas: ${s.requiredPassColor}` : ''}
                          {typeof s.type === 'string' ? ` • Type: ${s.type}` : ''}
                          {eligible ? '' : s.availabilityConflict ? ' • Niet beschikbaar' : ' • Niet geschikt'}
                        </div>
                      </div>
                      <Button
                        onClick={async () => {
                          setErr(undefined);
                          setPendingId(s.id);
                          try {
                            await requestShift(s.id);
                            await qc.invalidateQueries({ queryKey: ['openShifts'] });
                            setErr('Aanvraag verstuurd (wacht op goedkeuring).');
                          } catch (e: any) {
                            if (e?.code === 'PASSCOLOR_MISMATCH') {
                              setErr('Je kleurpas is niet geschikt voor deze open dienst.');
                            } else if (e?.code === 'AVAILABILITY_OVERLAP') {
                              setErr('Je bent in deze periode niet beschikbaar (beschikbaarheid overlapt).');
                            } else {
                              setErr(e?.error ?? 'Aanvraag mislukt');
                            }
                          } finally {
                            setPendingId('');
                          }
                        }}
                        disabled={pendingId === s.id || !eligible}
                      >
                        {pendingId === s.id ? 'Versturen…' : 'Reageer'}
                      </Button>
                    </div>
                  </Card>
                );
              })}
            </div>
          </details>
        ))}

        {isLoading && <div className="text-sm text-gray-600">Loading…</div>}
        {!isLoading && grouped.length === 0 && <div className="text-sm text-gray-600">Geen open diensten.</div>}
      </div>

      <PaginationControls
        page={page}
        pageSize={pageSize}
        totalCount={totalCount}
        onPageChange={(p) => setPage(Math.max(1, p))}
        onPageSizeChange={(ps) => {
          setPageSize(ps);
          setPage(1);
        }}
      />
    </div>
  );
}
