import { useCallback, useMemo, useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { listNotifications, markNotificationRead, markAllNotificationsRead } from '../api/notifications';
import { reviewShiftRequest } from '../api/shifts';
import { useMe } from '../hooks/useAuth';
import { useNotificationsSocket } from '../hooks/useNotificationsSocket';
import { usePushNotifications } from '../hooks/usePushNotifications';
import clsx from 'clsx';
import { Button, Card, Skeleton } from '../components/ui';
import { PaginationControls } from '../components/PaginationControls';
import { formatDateTimeNL } from '../utils/format';

function metaForType(type: string) {
  if (type === 'OPEN_SHIFT_REQUEST') {
    return {
      emoji: '⚡️',
      text: 'Actie nodig',
      badgeClass: 'bg-[#FAFAFA] text-[#424242] border border-[#C6A84E]/40',
      accentClass: 'bg-[#C6A84E]',
    };
  }
  if (type === 'OPEN_SHIFT_REVIEW') {
    return {
      emoji: '✅',
      text: 'Beslissing',
      badgeClass: 'bg-[#FAFAFA] text-[#424242] border border-[#3E6B52]/35',
      accentClass: 'bg-[#3E6B52]',
    };
  }
  if (type.startsWith('CLOCK_')) {
    return {
      emoji: '⏱️',
      text: 'Uren',
      badgeClass: 'bg-[#FAFAFA] text-[#424242] border border-[#3E6B52]/35',
      accentClass: 'bg-[#3E6B52]',
    };
  }
  return {
    emoji: 'ℹ️',
    text: 'Info',
    badgeClass: 'bg-[#FAFAFA] text-[#424242] border border-[#E0E0E0]',
    accentClass: 'bg-[#E0E0E0]',
  };
}

export default function NotificationsPage() {
  const { data: me } = useMe();
  const push = usePushNotifications();
  const qc = useQueryClient();
  const [toast, setToast] = useState<string | undefined>();
  const [actioningId, setActioningId] = useState<string | null>(null);
  const [resolvedIds, setResolvedIds] = useState<Record<string, boolean>>({});
  const [tab, setTab] = useState<'all' | 'action'>('all');
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(25);

  const markLocalRead = (id: string) => {
    // Optimistic UI: make sure action-buttons disappear immediately.
    setResolvedIds((s) => ({ ...s, [id]: true }));
    qc.setQueriesData({ queryKey: ['notifications'] }, (old: any) => {
      const arr = old?.notifications ?? [];
      const now = new Date().toISOString();
      return {
        ...old,
        notifications: arr.map((n: any) => (n.id === id ? { ...n, readAt: n.readAt ?? now } : n)),
      };
    });
  };

  const { data, isLoading } = useQuery({
    queryKey: ['notifications', { tab, page, pageSize }],
    queryFn: () => listNotifications({ tab, page, pageSize }),
  });

  const filtered = useMemo(() => data?.notifications ?? [], [data?.notifications]);
  const totalCount = (data as any)?.totalCount as number | undefined;

  const onSocket = useCallback(
    async (_payload: any) => {
      await qc.invalidateQueries({ queryKey: ['notifications'] });
      setToast('Nieuwe notificatie ontvangen');
      setTimeout(() => setToast(undefined), 2500);
    },
    [qc],
  );

  useNotificationsSocket(me, onSocket);

  return (
    <div className="space-y-4">
      <Card className="p-5">
        <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
          <div className="flex items-center gap-2">
            <h1 className="text-lg font-semibold">Notificaties</h1>
            {typeof totalCount === 'number' ? (
              <span className="text-xs text-gray-500">({totalCount} totaal)</span>
            ) : null}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              className={`rounded-full px-3 py-1 text-xs font-medium border ${tab === 'all' ? 'bg-[#3E6B52] text-white border-[#3E6B52]' : 'bg-[#FAFAFA] text-[#424242] border-[#E0E0E0]'}`}
              onClick={() => {
                setTab('all');
                setPage(1);
              }}
              type="button"
            >
              Alles
            </button>
            <button
              className={`rounded-full px-3 py-1 text-xs font-medium border ${tab === 'action' ? 'bg-[#3E6B52] text-white border-[#3E6B52]' : 'bg-[#FAFAFA] text-[#424242] border-[#E0E0E0]'}`}
              onClick={() => {
                setTab('action');
                setPage(1);
              }}
              type="button"
            >
              Actie nodig
            </button>

            <Button
              variant="secondary"
              onClick={async () => {
                await markAllNotificationsRead();
                await qc.invalidateQueries({ queryKey: ['notifications'] });
                setToast('Alles gemarkeerd als gelezen.');
                setTimeout(() => setToast(undefined), 2500);
              }}
            >
              Alles gelezen
            </Button>
          </div>
        </div>

        {push.supported && (
          <div className="mt-3 flex flex-col gap-2 md:flex-row md:items-center md:justify-between">
            <div className="text-sm text-gray-700">
              Push-notificaties: <span className="font-medium">{push.enabled ? 'Aan' : 'Uit'}</span>
            </div>
            <div className="flex gap-2">
              {!push.enabled ? (
                <Button disabled={push.busy} onClick={push.enable}>
                  Inschakelen
                </Button>
              ) : (
                <Button variant="secondary" disabled={push.busy} onClick={push.disable}>
                  Uitschakelen
                </Button>
              )}
            </div>
          </div>
        )}
        {push.error && <div className="mt-2 text-sm text-red-700">{push.error}</div>}

        {toast && (
          <div className="fixed bottom-4 right-4 z-50">
            <div className="rounded-2xl border border-gray-200 bg-white px-4 py-3 text-sm text-gray-800 shadow-lg">
              {toast}
            </div>
          </div>
        )}
      </Card>

      <PaginationControls
        page={page}
        pageSize={pageSize}
        totalCount={totalCount}
        onPageChange={(p) => setPage(Math.max(1, p))}
        onPageSizeChange={(ps) => {
          setPageSize(ps);
          setPage(1);
        }}
      />

      <div className="grid gap-3">
        {filtered.map((n) => {
          const meta = metaForType(n.type);
          const isUnread = !n.readAt;
          const isActionable =
            me?.role === 'ADMIN' &&
            isUnread &&
            n.type === 'OPEN_SHIFT_REQUEST' &&
            n.data?.shiftId &&
            n.data?.userId &&
            !resolvedIds[n.id];

          return (
            <Card
              key={n.id}
              className={clsx('p-4 relative overflow-hidden', isUnread && 'bg-gray-50')}
            >
              <div className={clsx('absolute left-0 top-0 h-full w-1', meta.accentClass)} />

              <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
                <div className="min-w-0 flex gap-3">
                  <div className="mt-0.5 flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-white border border-gray-200 text-lg shadow-sm">
                    {meta.emoji}
                  </div>

                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <span
                        className={clsx(
                          'inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium',
                          meta.badgeClass,
                        )}
                      >
                        {meta.text}
                      </span>
                      {isUnread && (
                        <span className="inline-flex items-center rounded-full bg-red-100 px-2 py-0.5 text-xs font-medium text-red-800">
                          Nieuw
                        </span>
                      )}
                      <span className="text-xs text-gray-500" title={formatDateTimeNL(n.createdAt)}>
                        {formatDateTimeNL(n.createdAt)}
                      </span>
                      {n.sender?.fullName && (
                        <span className="text-xs text-gray-500">
                          • {n.sender.fullName}
                        </span>
                      )}
                    </div>

                    <div className="mt-2 font-medium break-words">{n.message}</div>
                    <div className="mt-1 text-xs text-gray-500 font-mono">{n.type}</div>

                    {n.data?.shiftTitle && (
                      <div className="mt-2 text-sm text-gray-700">
                        <span className="font-medium">Dienst:</span> {n.data.shiftTitle}
                      </div>
                    )}
                    {n.data?.startAt && n.data?.endAt && (
                      <div className="mt-1 text-sm text-gray-700">
                        <span className="font-medium">Tijd:</span> {formatDateTimeNL(n.data.startAt)} – {formatDateTimeNL(n.data.endAt)}
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex flex-col gap-2 md:items-end">
                  {isActionable && (
                    <div className="flex gap-2">
                      <Button
                        disabled={actioningId === n.id}
                        onClick={async () => {
                          setActioningId(n.id);
                          markLocalRead(n.id);
                          try {
                            await reviewShiftRequest(String(n.data.shiftId), { userId: String(n.data.userId), approve: true });
                            try { await markNotificationRead(n.id); } catch { /* ignore */ }
                            await qc.invalidateQueries({ queryKey: ['notifications'] });
                            setToast('Open dienst goedgekeurd.');
                          } catch (e: any) {
                            // If it was already reviewed, treat it as resolved.
                            if (e?.code === 'REQUEST_ALREADY_REVIEWED' || e?.status === 409) {
                              try { await markNotificationRead(n.id); } catch { /* ignore */ }
                              await qc.invalidateQueries({ queryKey: ['notifications'] });
                              setToast('Deze aanvraag is al beoordeeld.');
                            } else {
                              setToast(e?.error || 'Goedkeuren mislukt.');
                            }
                          } finally {
                            setActioningId(null);
                            setTimeout(() => setToast(undefined), 2500);
                          }
                        }}
                      >
                        Goedkeuren
                      </Button>
                      <Button
                        variant="secondary"
                        disabled={actioningId === n.id}
                        onClick={async () => {
                          setActioningId(n.id);
                          markLocalRead(n.id);
                          try {
                            await reviewShiftRequest(String(n.data.shiftId), { userId: String(n.data.userId), approve: false });
                            try { await markNotificationRead(n.id); } catch { /* ignore */ }
                            await qc.invalidateQueries({ queryKey: ['notifications'] });
                            setToast('Open dienst afgewezen.');
                          } catch (e: any) {
                            if (e?.code === 'REQUEST_ALREADY_REVIEWED' || e?.status === 409) {
                              try { await markNotificationRead(n.id); } catch { /* ignore */ }
                              await qc.invalidateQueries({ queryKey: ['notifications'] });
                              setToast('Deze aanvraag is al beoordeeld.');
                            } else {
                              setToast(e?.error || 'Afwijzen mislukt.');
                            }
                          } finally {
                            setActioningId(null);
                            setTimeout(() => setToast(undefined), 2500);
                          }
                        }}
                      >
                        Afwijzen
                      </Button>
                    </div>
                  )}

                  {!n.readAt && !isActionable && (
                    <Button
                      variant="secondary"
                      onClick={async () => {
                        await markNotificationRead(n.id);
                        await qc.invalidateQueries({ queryKey: ['notifications'] });
                      }}
                    >
                      Markeer gelezen
                    </Button>
                  )}
                </div>
              </div>
            </Card>
          );
        })}

        {isLoading && (
          <div className="space-y-3">
            {[0, 1, 2].map((i) => (
              <Card key={i} className="p-4">
                <div className="flex items-start gap-3">
                  <Skeleton className="h-10 w-10 rounded-full" />
                  <div className="flex-1">
                    <Skeleton className="h-4 w-56" />
                    <div className="mt-2">
                      <Skeleton className="h-4 w-72" />
                    </div>
                    <div className="mt-3 flex gap-2">
                      <Skeleton className="h-8 w-24" rounded="lg" />
                      <Skeleton className="h-8 w-24" rounded="lg" />
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}

        {!isLoading && (filtered.length ?? 0) > 0 && (
          <div className="pt-2">
            <PaginationControls
              page={page}
              pageSize={pageSize}
              totalCount={totalCount}
              onPageChange={(p) => setPage(Math.max(1, p))}
              onPageSizeChange={(ps) => {
                setPageSize(ps);
                setPage(1);
              }}
            />
          </div>
        )}
        {!isLoading && (data?.notifications?.length ?? 0) === 0 && <div className="text-sm text-gray-600">Geen notificaties.</div>}
      </div>
    </div>
  );
}
