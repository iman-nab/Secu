import { useEffect, useMemo, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { apiFetch } from '../api/apiClient';
import { Button, Card, ErrorBanner, Input, Label } from '../components/ui';

type InviteInfo = {
  email: string;
  fullName: string;
  role: string;
  expiresAt: string;
  passColor?: string | null;
};

export default function InviteAcceptPage() {
  const { token = '' } = useParams();
  const nav = useNavigate();

  const [loading, setLoading] = useState(true);
  const [invite, setInvite] = useState<InviteInfo | null>(null);
  const [error, setError] = useState<string | undefined>(undefined);

  const [password, setPassword] = useState('');
  const [password2, setPassword2] = useState('');
  const [phone, setPhone] = useState('');
  const [birthDate, setBirthDate] = useState('');
  const [passColor, setPassColor] = useState('');
  const [saving, setSaving] = useState(false);

  const pwChecks = useMemo(() => {
    const p = password;
    return {
      len: p.length >= 12,
      lower: /[a-z]/.test(p),
      upper: /[A-Z]/.test(p),
      digit: /\d/.test(p),
      special: /[^A-Za-z0-9]/.test(p),
    };
  }, [password]);

  const passColorRequired = invite?.role === 'EMPLOYEE';

  const canSubmit = useMemo(() => {
    if (!password || !password2) return false;
    if (!pwChecks.len || !pwChecks.lower || !pwChecks.upper || !pwChecks.digit || !pwChecks.special) return false;
    if (password !== password2) return false;
    if (passColorRequired && !passColor) return false;
    return true;
  }, [password, password2, pwChecks, passColorRequired, passColor]);

  useEffect(() => {
    let mounted = true;
    (async () => {
      setLoading(true);
      setError(undefined);
      try {
        const v2 = await apiFetch<any>(`/auth/invites/${encodeURIComponent(token)}`);
        if (!mounted) return;
        setInvite({ email: v2.email, fullName: v2.fullName, role: v2.role ?? 'CLIENT', expiresAt: v2.expiresAt });
      } catch (e: any) {
        if (!mounted) return;
        setInvite(null);
        setError(e?.error || 'Invite link is ongeldig of verlopen.');
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => {
      mounted = false;
    };
  }, [token]);

  async function submit() {
    if (!canSubmit) return;
    setSaving(true);
    setError(undefined);
    try {
      // Prefer v2 signup
      await apiFetch<{ ok: true }>(`/auth/signup`, {
        method: 'POST',
        body: JSON.stringify({
          token,
          password,
          ...(phone ? { phone } : {}),
          ...(birthDate ? { birthDate } : {}),
          ...(passColor ? { passColor } : {}),
        }),
      });
      nav('/login', { replace: true });
    } catch (e: any) {
      setError(e?.error || 'Kon account niet activeren.');
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gray-50">
      <Card className="w-full max-w-md p-6 space-y-4">
        <div>
          <div className="text-xl font-semibold">Account activeren</div>
          <div className="text-sm text-gray-600">Kies een wachtwoord en rond je registratie af.</div>
        </div>

        <ErrorBanner message={error} />

        {loading ? (
          <div className="text-sm text-gray-600">Laden…</div>
        ) : !invite ? (
          <div className="space-y-2">
            <div className="text-sm text-gray-700">Deze invite link is niet meer geldig.</div>
            <Button variant="secondary" onClick={() => nav('/login')}>Naar login</Button>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="rounded-lg border bg-white p-3 text-sm">
              <div><span className="font-medium">E-mail:</span> {invite.email}</div>
              <div><span className="font-medium">Naam:</span> {invite.fullName}</div>
              <div><span className="font-medium">Rol:</span> {invite.role}</div>
              <div className="text-xs text-gray-600 mt-1">Geldig tot: {new Date(invite.expiresAt).toLocaleString()}</div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1">
                <Label>Telefoon (optioneel)</Label>
                <Input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="06..." />
              </div>

              <div className="space-y-1">
                <Label>Geboortedatum (optioneel)</Label>
                <Input type="date" value={birthDate} onChange={(e) => setBirthDate(e.target.value)} />
              </div>

              {invite.role === 'EMPLOYEE' ? (
                <div className="space-y-1 md:col-span-2">
                  <Label>Kleurpas {passColorRequired ? '(verplicht)' : '(optioneel)'}</Label>
                  <select
                    className="w-full rounded border px-3 py-2 text-sm outline-none focus:ring"
                    value={passColor}
                    onChange={(e) => setPassColor(e.target.value)}
                  >
                    <option value="">— Kies —</option>
                    <option value="GRAY">Grijs</option>
                    <option value="DARK_BLUE">Donkerblauw</option>
                    <option value="LIGHT_BLUE">Lichtblauw</option>
                    <option value="ORANGE">Oranje</option>
                    <option value="GREEN">Groen</option>
                    <option value="BLACK">Zwart</option>
                  </select>
                  {passColorRequired && !passColor ? (
                    <div className="text-xs text-rose-600">Kleurpas is verplicht voor medewerkers.</div>
                  ) : null}
                </div>
              ) : null}
            </div>

            <div className="space-y-1">
              <Label>Wachtwoord</Label>
              <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Minimaal 12 tekens" />
              <div className="mt-1 grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-1 text-xs">
                <div className={pwChecks.len ? 'text-green-700' : 'text-gray-600'}>• Min. 12 tekens</div>
                <div className={pwChecks.lower ? 'text-green-700' : 'text-gray-600'}>• Kleine letter</div>
                <div className={pwChecks.upper ? 'text-green-700' : 'text-gray-600'}>• Hoofdletter</div>
                <div className={pwChecks.digit ? 'text-green-700' : 'text-gray-600'}>• Cijfer</div>
                <div className={pwChecks.special ? 'text-green-700' : 'text-gray-600'}>• Speciaal teken</div>
              </div>
            </div>

            <div className="space-y-1">
              <Label>Herhaal wachtwoord</Label>
              <Input type="password" value={password2} onChange={(e) => setPassword2(e.target.value)} placeholder="Herhaal" />
              {password && password2 && password !== password2 && (
                <div className="text-xs text-red-600">Wachtwoorden komen niet overeen.</div>
              )}
            </div>

            <Button onClick={submit} disabled={!canSubmit || saving}>
              {saving ? 'Opslaan…' : 'Activeer account'}
            </Button>
          </div>
        )}
      </Card>
    </div>
  );
}
