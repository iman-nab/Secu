import { useEffect, useMemo, useState } from 'react';
import FullCalendar from '@fullcalendar/react';
import timeGridPlugin from '@fullcalendar/timegrid';
import dayGridPlugin from '@fullcalendar/daygrid';
import interactionPlugin from '@fullcalendar/interaction';
import nlLocale from '@fullcalendar/core/locales/nl';
import { useQuery } from '@tanstack/react-query';
import { listCalendarShifts } from '../api/shifts';
import { getMyCalendarFeed } from '../api/calendar';
import { listClients } from '../api/clients';
import { listLocations } from '../api/locations';
import { useNavigate } from 'react-router-dom';
import { Button, Card, Input, Label } from '../components/ui';
import { useIsMobile } from '../hooks/useIsMobile';
import { useMe } from '../hooks/useAuth';
import { useToast } from '../components/toast';

export default function AgendaPage() {
  const isMobile = useIsMobile();
  const toast = useToast();
  const [range, setRange] = useState<{ start?: string; end?: string }>({});
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [search, setSearch] = useState('');
  const [filters, setFilters] = useState<{
    clientId?: string;
    locationId?: string;
    passColor?: 'GRAY' | 'DARK_BLUE' | 'LIGHT_BLUE' | 'ORANGE' | 'GREEN' | 'BLACK';
    type?: string;
    status?: string;
  }>({});
  const nav = useNavigate();
  const me = useMe();
  const isAdmin = me.data?.role === 'ADMIN';

  const { data: clientsData } = useQuery({
    queryKey: ['clients', { includeDeleted: false }],
    queryFn: () => listClients({ includeDeleted: false }),
    enabled: isAdmin,
    staleTime: 60_000,
  });

  const { data: locationsData } = useQuery({
    queryKey: ['locations'],
    queryFn: () => listLocations(),
    enabled: isAdmin,
    staleTime: 60_000,
  });

  // On mobile we don't want a calendar; load a simple fixed range (next 14 days)
  useEffect(() => {
    if (!isMobile) return;
    const start = new Date();
    const end = new Date();
    end.setDate(end.getDate() + 14);
    setRange({ start: start.toISOString(), end: end.toISOString() });
  }, [isMobile]);

  const { data, isFetching } = useQuery({
    queryKey: ['shiftsCalendar', range, filters],
    queryFn: () => listCalendarShifts({ ...range, ...(isAdmin ? filters : {}) }),
    // Avoid calling /shifts without a range: we always set a range via FullCalendar datesSet
    // (desktop) or fixed next-14-days range (mobile).
    enabled: !!range.start && !!range.end,
  });

  const clients = clientsData?.clients ?? [];
  const locations = locationsData?.locations ?? [];

  function clearFilters() {
    setFilters({});
  }

  const { data: feed } = useQuery({
    queryKey: ['calendarFeed'],
    queryFn: () => getMyCalendarFeed(),
  });

  const events = useMemo(() => {
    const q = search.trim().toLowerCase();
    const list = (data?.shifts ?? []) as any[];
    const filtered = !q
      ? list
      : list.filter((s: any) =>
          [s.title, s.type, s.status, s.location?.name, s.client?.name]
            .filter(Boolean)
            .some((v: any) => String(v).toLowerCase().includes(q)),
        );
    return filtered.map((s: any) => ({
      // FullCalendar expects a stable string id; this also powers the "Open detail" action.
      id: String(s.id),
      title: s.title,
      start: s.startAt,
      end: s.endAt,
      classNames: [`shift-${String(s.status || '').toLowerCase()}`],
      extendedProps: {
        shiftId: s.id,
        status: s.status,
        locationName: s.location?.name ?? '—',
        requiredWorkers: s.requiredWorkers ?? 0,
        assignedCount: (s._count?.assignments ?? 0) as number,
        passColor: (s.passColor ?? '') as string,
        clientName: s.client?.name ?? '',
        type: s.type ?? '',
      },
    }));
  }, [data, search]);

  // Keyboard shortcuts: / focuses search, Esc clears
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (document.activeElement as any)?.tagName?.toLowerCase?.();
      const inInput = tag === 'input' || tag === 'textarea' || tag === 'select';
      if (e.key === '/' && !inInput) {
        e.preventDefault();
        (document.getElementById('agenda-search') as HTMLInputElement | null)?.focus?.();
      }
      if (e.key === 'Escape') {
        setSearch('');
        setFiltersOpen(false);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  function statusLabel(status: string) {
    if (status === 'OPEN') return 'Open';
    if (status === 'ASSIGNED') return 'Ingepland';
    // Legacy: treat DRAFT as OPEN
    if (status === 'DRAFT') return 'Open';
    if (status === 'COMPLETED') return 'Afgerond';
    if (status === 'CANCELLED') return 'Geannuleerd';
    return status;
  }

  // Mobile: simple list (much easier than a calendar on small screens)
  if (isMobile) {
    const list = (data?.shifts ?? []).slice().sort((a: any, b: any) => +new Date(a.startAt) - +new Date(b.startAt));

    return (
      <div className="space-y-4">
        <Card className="p-5">
          <div className="flex items-start justify-between gap-3">
            <div>
              <h1 className="text-lg font-semibold">Agenda</h1>
              <div className="mt-1 text-sm text-gray-600">Komende 14 dagen</div>
            </div>
            {isAdmin && (
              <div className="relative">
                <Button variant="secondary" onClick={() => setFiltersOpen((v) => !v)}>
                  Filters
                </Button>
              </div>
            )}
          </div>

          {isAdmin && filtersOpen && (
            <div className="mt-3 rounded-xl border bg-white p-3">
              <div className="grid grid-cols-1 gap-3">
                <div>
                  <Label>Opdrachtgever</Label>
                  <select
                    className="mt-1 w-full rounded border px-3 py-2 text-sm"
                    value={filters.clientId ?? ''}
                    onChange={(e) => setFilters((f) => ({ ...f, clientId: e.target.value || undefined }))}
                  >
                    <option value="">Alle opdrachtgevers</option>
                    {clients.map((c: any) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label>Locatie</Label>
                    <select
                      className="mt-1 w-full rounded border px-3 py-2 text-sm"
                      value={filters.locationId ?? ''}
                      onChange={(e) => setFilters((f) => ({ ...f, locationId: e.target.value || undefined }))}
                    >
                      <option value="">Alle locaties</option>
                      {locations.map((l: any) => (
                        <option key={l.id} value={l.id}>
                          {l.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <Label>Kleurpas</Label>
                    <select
                      className="mt-1 w-full rounded border px-3 py-2 text-sm"
                      value={filters.passColor ?? ''}
                      onChange={(e) => setFilters((f) => ({ ...f, passColor: (e.target.value || undefined) as any }))}
                    >
                      <option value="">Alle kleuren</option>
                      <option value="GRAY">Grijs</option>
                      <option value="DARK_BLUE">Donkerblauw</option>
                      <option value="LIGHT_BLUE">Lichtblauw</option>
                      <option value="ORANGE">Oranje</option>
                      <option value="GREEN">Groen</option>
                      <option value="BLACK">Zwart</option>
                    </select>
                  </div>
                  <div>
                    <Label>Status</Label>
                    <select
                      className="mt-1 w-full rounded border px-3 py-2 text-sm"
                      value={filters.status ?? ''}
                      onChange={(e) => setFilters((f) => ({ ...f, status: e.target.value || undefined }))}
                    >
                      <option value="">Alle statussen</option>
                      <option value="OPEN">Open</option>
                      <option value="ASSIGNED">Ingepland</option>
                      <option value="COMPLETED">Afgerond</option>
                      <option value="CANCELLED">Geannuleerd</option>
                    </select>
                  </div>
                </div>

                <div>
                  <Label>Type</Label>
                  <Input
                    placeholder="Bijv. GENERAL, EVENT..."
                    value={filters.type ?? ''}
                    onChange={(e) => setFilters((f) => ({ ...f, type: e.target.value || undefined }))}
                  />
                </div>

                <div className="flex items-center justify-end gap-2">
                  <Button variant="secondary" onClick={clearFilters}>
                    Reset
                  </Button>
                  <Button onClick={() => setFiltersOpen(false)}>Toepassen</Button>
                </div>
              </div>
            </div>
          )}
          {feed?.url && (
            <div className="mt-3 rounded-xl border bg-white p-3">
              <div className="text-sm font-semibold">Agenda-sync (ICS)</div>
              <div className="mt-1 text-xs text-gray-600">Plak deze link in Google/Apple/Android agenda.</div>
              <div className="mt-2 flex items-center gap-2">
                <div className="flex-1 truncate rounded-lg bg-gray-50 px-2 py-1 text-xs text-gray-700">{feed.url}</div>
                <Button
                  variant="secondary"
                  onClick={async () => {
                    await navigator.clipboard.writeText(feed.url);
                    toast.success('ICS link gekopieerd');
                  }}
                >
                  Kopieer
                </Button>
              </div>
            </div>
          )}
        </Card>

        <div className="grid gap-3">
          {list.map((s: any) => (
            <button
              key={s.id}
              type="button"
              className="text-left"
              onClick={() => nav(`/diensten/${s.id}`)}
            >
              <Card className="p-4">
                <div className="font-semibold">{s.title}</div>
                <div className="mt-1 text-sm text-gray-600">
                  {new Date(s.startAt).toLocaleString('nl-NL', { dateStyle: 'medium', timeStyle: 'short' })} –{' '}
                  {new Date(s.endAt).toLocaleString('nl-NL', { dateStyle: 'medium', timeStyle: 'short' })}
                </div>
                <div className="mt-1 text-sm text-gray-600">{s.location?.name ?? '—'}</div>
              </Card>
            </button>
          ))}

          {!list.length && <div className="text-sm text-gray-600">Geen diensten in deze periode.</div>}
        </div>

      </div>
    );
  }

  return (
    <div className="space-y-4">
      <Card className="p-5">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h1 className="text-lg font-semibold">Agenda</h1>
            <div className="mt-1 text-sm text-gray-600">Weekoverzicht. Klik op een dienst voor details.</div>
          </div>
          <div className="flex items-center gap-2">
            <div className="hidden md:block">
              <Input
                id="agenda-search"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Zoek… (druk /)"
              />
            </div>
            {isAdmin && (
              <div className="relative">
                <Button variant="secondary" onClick={() => setFiltersOpen((v) => !v)}>
                  Filters
                </Button>
              </div>
            )}
            <div className="text-xs text-gray-600">Week / maand</div>
          </div>
        </div>

        {isAdmin && filtersOpen && (
          <div className="mt-4 rounded-2xl border bg-white p-4">
            <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
              <div>
                <Label>Opdrachtgever</Label>
                <select
                  className="mt-1 w-full rounded border px-3 py-2 text-sm"
                  value={filters.clientId ?? ''}
                  onChange={(e) => setFilters((f) => ({ ...f, clientId: e.target.value || undefined }))}
                >
                  <option value="">Alle opdrachtgevers</option>
                  {clients.map((c: any) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <Label>Locatie</Label>
                <select
                  className="mt-1 w-full rounded border px-3 py-2 text-sm"
                  value={filters.locationId ?? ''}
                  onChange={(e) => setFilters((f) => ({ ...f, locationId: e.target.value || undefined }))}
                >
                  <option value="">Alle locaties</option>
                  {locations.map((l: any) => (
                    <option key={l.id} value={l.id}>
                      {l.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <Label>Kleurpas</Label>
                <select
                  className="mt-1 w-full rounded border px-3 py-2 text-sm"
                  value={filters.passColor ?? ''}
                  onChange={(e) => setFilters((f) => ({ ...f, passColor: (e.target.value || undefined) as any }))}
                >
                  <option value="">Alle kleuren</option>
                  <option value="GRAY">Grijs</option>
                  <option value="DARK_BLUE">Donkerblauw</option>
                  <option value="LIGHT_BLUE">Lichtblauw</option>
                  <option value="ORANGE">Oranje</option>
                  <option value="GREEN">Groen</option>
                  <option value="BLACK">Zwart</option>
                </select>
              </div>

              <div>
                <Label>Type</Label>
                <Input
                  placeholder="Bijv. GENERAL, EVENT..."
                  value={filters.type ?? ''}
                  onChange={(e) => setFilters((f) => ({ ...f, type: e.target.value || undefined }))}
                />
              </div>

              <div>
                <Label>Status</Label>
                <select
                  className="mt-1 w-full rounded border px-3 py-2 text-sm"
                  value={filters.status ?? ''}
                  onChange={(e) => setFilters((f) => ({ ...f, status: e.target.value || undefined }))}
                >
                  <option value="">Alle statussen</option>
                  <option value="OPEN">Open</option>
                  <option value="ASSIGNED">Ingepland</option>
                  <option value="COMPLETED">Afgerond</option>
                  <option value="CANCELLED">Geannuleerd</option>
                </select>
              </div>
            </div>

            <div className="mt-4 flex items-center justify-end gap-2">
              <Button variant="secondary" onClick={clearFilters}>
                Reset
              </Button>
              <Button onClick={() => setFiltersOpen(false)}>Toepassen</Button>
            </div>
          </div>
        )}

        {feed?.url && (
          <div className="mt-4 rounded-xl border bg-white p-3">
            <div className="text-sm font-semibold">Agenda-sync (ICS)</div>
            <div className="mt-1 text-xs text-gray-600">Plak deze link in je agenda-app om geaccepteerde diensten te syncen.</div>
            <div className="mt-2 flex items-center gap-2">
              <div className="flex-1 truncate rounded-lg bg-gray-50 px-2 py-1 text-xs text-gray-700">{feed.url}</div>
              <Button
                variant="secondary"
                onClick={async () => {
                  await navigator.clipboard.writeText(feed.url);
                  toast.success('ICS link gekopieerd');
                }}
              >
                Kopieer
              </Button>
            </div>
          </div>
        )}
      </Card>

      <Card className="p-3">
        <div className="fc-nl">
          <div className="relative">
            {isFetching ? (
              <div className="pointer-events-none absolute inset-0 z-10 flex items-center justify-center">
                <div className="rounded-xl border bg-white/80 px-3 py-2 text-sm shadow-sm">Laden…</div>
              </div>
            ) : null}

            <FullCalendar
            plugins={[timeGridPlugin, dayGridPlugin, interactionPlugin]}
            initialView="timeGridWeek"
            locale={nlLocale}
            firstDay={1}
            buttonText={{ today: 'Vandaag', month: 'Maand', week: 'Week', day: 'Dag' }}
            headerToolbar={{
              left: 'prev,next today',
              center: 'title',
              right: 'timeGridWeek,dayGridMonth',
            }}
            height="auto"
            nowIndicator
            allDaySlot={false}
            slotMinTime="06:00:00"
            slotMaxTime="23:00:00"
            slotLabelFormat={{ hour: '2-digit', minute: '2-digit', hour12: false }}
            eventTimeFormat={{ hour: '2-digit', minute: '2-digit', hour12: false }}
            events={events}
            eventContent={(arg) => {
              const p: any = arg.event.extendedProps as any;
              const required = Number(p.requiredWorkers || 0);
              const assigned = Number(p.assignedCount || 0);
              const under = required > 0 && assigned < required;
              return (
                <div className="fc-event-card">
                  <div className="fc-event-top">
                    <div className="flex min-w-0 items-center gap-2">
                      <span className="fc-dot" aria-hidden />
                      <div className="fc-event-title" title={arg.event.title}>{arg.event.title}</div>
                    </div>
                    {under ? <span className="fc-event-warn" aria-label="Open">⚠︎</span> : null}
                  </div>
                  <div className="fc-event-sub">{p.locationName}</div>
                  <div className="fc-event-meta">
                    <span className="fc-pill">{statusLabel(String(p.status || ''))}</span>
                    {required ? (
                      <span className={'fc-pill ' + (under ? 'fc-pill-warn' : '')}>
                        {assigned}/{required}
                      </span>
                    ) : null}
                  </div>
                </div>
              );
            }}
            datesSet={(arg) => {
              setRange({ start: arg.start.toISOString(), end: arg.end.toISOString() });
            }}
            // Clicking an event should always open the shift detail page.
            eventClick={(info) => {
              const p: any = info.event.extendedProps as any;
              const shiftId = String(info.event.id || p.shiftId || p.id || '');
              if (!shiftId) {
                toast.error('Kon deze dienst niet openen (missing id).');
                return;
              }
              nav(`/diensten/${shiftId}`);
            }}
            />
          </div>
        </div>
      </Card>

      {/* Note: We used to show a quick-view modal here. To eliminate issues where
          a shift would not open, clicking an event now navigates directly to the
          detail page. */}
    </div>
  );
}
