import { useMemo, useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Card, Button, Input, Label, ErrorBanner, SuccessBanner, Badge, Skeleton } from '../components/ui';
import { createMyAvailability, deleteAvailability, listMyAvailability, updateAvailability, type AvailabilityType } from '../api/availability';
import { nlFullDate, nlTime, toLocalDateTimeInputValue } from '../utils/datetime';

function typeLabel(t: AvailabilityType) {
  if (t === 'VACATION') return 'Vakantie';
  if (t === 'SICK') return 'Ziek';
  return 'Niet beschikbaar';
}

export default function AvailabilityPage() {
  const qc = useQueryClient();
  const now = useMemo(() => new Date(), []);
  const [type, setType] = useState<AvailabilityType>('UNAVAILABLE');
  const [startAt, setStartAt] = useState<string>(toLocalDateTimeInputValue(now));
  const [endAt, setEndAt] = useState<string>(toLocalDateTimeInputValue(new Date(now.getTime() + 2 * 60 * 60 * 1000)));
  const [note, setNote] = useState<string>('');
  const [err, setErr] = useState<string | undefined>();
  const [ok, setOk] = useState<string | undefined>();
  const [saving, setSaving] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  const { data, isLoading } = useQuery({
    queryKey: ['availability', 'me'],
    queryFn: () => listMyAvailability(),
  });

  const items = data?.items ?? [];

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-semibold">Beschikbaarheid</h1>
        <p className="text-sm text-gray-600">
          Voeg periodes toe waarin je niet ingepland kunt worden. Dit blokkeert reageren op open diensten én toewijzen.
        </p>
      </div>

      <Card className="p-4 space-y-3">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div>
            <Label>Type</Label>
            <select
              className="mt-1 w-full rounded border px-3 py-2 text-sm"
              value={type}
              onChange={(e) => setType(e.target.value as AvailabilityType)}
            >
              <option value="VACATION">Vakantie</option>
              <option value="SICK">Ziek</option>
              <option value="UNAVAILABLE">Niet beschikbaar</option>
            </select>
          </div>
          <div>
            <Label>Notitie (optioneel)</Label>
            <Input className="mt-1" value={note} onChange={(e) => setNote(e.target.value)} placeholder="Bijv. reis, afspraak…" />
          </div>

          <div>
            <Label>Start</Label>
            <Input className="mt-1" type="datetime-local" value={startAt} onChange={(e) => setStartAt(e.target.value)} />
          </div>
          <div>
            <Label>Einde</Label>
            <Input className="mt-1" type="datetime-local" value={endAt} onChange={(e) => setEndAt(e.target.value)} />
          </div>
        </div>

        <ErrorBanner message={err} />
        <SuccessBanner message={ok} />

        <div className="flex gap-2">
          <Button
            onClick={async () => {
              setErr(undefined);
              setOk(undefined);
              setSaving(true);
              try {
                const payload = {
                  type,
                  startAt: new Date(startAt).toISOString(),
                  endAt: new Date(endAt).toISOString(),
                  note: note.trim() ? note.trim() : null,
                } as any;

                if (editingId) {
                  await updateAvailability(editingId, payload);
                  setOk('Periode bijgewerkt.');
                } else {
                  await createMyAvailability({
                    type,
                    startAt: payload.startAt,
                    endAt: payload.endAt,
                    ...(note.trim() ? { note: note.trim() } : {}),
                  });
                  setOk('Periode opgeslagen.');
                }

                setEditingId(null);
                setNote('');
                await qc.invalidateQueries({ queryKey: ['availability', 'me'] });
              } catch (e: any) {
                if (e?.code === 'AVAILABILITY_OVERLAP') {
                  setErr('Deze periode overlapt met een bestaande beschikbaarheid.');
                } else {
                  setErr(e?.error ?? 'Opslaan mislukt');
                }
              } finally {
                setSaving(false);
              }
            }}
            disabled={saving}
          >
            {saving ? (editingId ? 'Bijwerken…' : 'Opslaan…') : (editingId ? 'Bijwerken' : 'Opslaan')}
          </Button>

          {editingId ? (
            <Button
              variant="secondary"
              onClick={() => {
                setEditingId(null);
                setErr(undefined);
                setOk(undefined);
                setNote('');
                const n = new Date();
                setType('UNAVAILABLE');
                setStartAt(toLocalDateTimeInputValue(n));
                setEndAt(toLocalDateTimeInputValue(new Date(n.getTime() + 2 * 60 * 60 * 1000)));
              }}
              disabled={saving}
            >
              Annuleer
            </Button>
          ) : null}
        </div>
      </Card>

      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold">Mijn periodes</h2>
          <Badge>{items.length} totaal</Badge>
        </div>

        {isLoading && (
          <div className="space-y-3">
            {[0, 1, 2].map((i) => (
              <Card key={i} className="p-4">
                <Skeleton className="h-4 w-40" />
                <div className="mt-2">
                  <Skeleton className="h-4 w-64" />
                </div>
                <div className="mt-3">
                  <Skeleton className="h-8 w-24" rounded="lg" />
                </div>
              </Card>
            ))}
          </div>
        )}

        {!isLoading && items.length === 0 && (
          <div className="text-sm text-gray-600">Nog geen periodes toegevoegd.</div>
        )}

        {items.map((a) => (
          <Card key={a.id} className="p-4">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <div className="font-semibold">{typeLabel(a.type)}</div>
                <div className="text-sm text-gray-600">
                  {nlFullDate(a.startAt)} {nlTime(a.startAt)} – {nlFullDate(a.endAt)} {nlTime(a.endAt)}
                </div>
                {a.note ? <div className="text-sm text-gray-700 mt-1">{a.note}</div> : null}
              </div>

              <div className="flex gap-2">
                <Button
                  variant="secondary"
                  onClick={() => {
                    setErr(undefined);
                    setOk(undefined);
                    setEditingId(a.id);
                    setType(a.type);
                    setStartAt(toLocalDateTimeInputValue(new Date(a.startAt)));
                    setEndAt(toLocalDateTimeInputValue(new Date(a.endAt)));
                    setNote(a.note ?? '');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                >
                  Bewerk
                </Button>
                <Button
                  variant="danger"
                  onClick={async () => {
                    setErr(undefined);
                    setOk(undefined);
                    try {
                      await deleteAvailability(a.id);
                      await qc.invalidateQueries({ queryKey: ['availability', 'me'] });
                      setOk('Periode verwijderd.');
                      if (editingId === a.id) setEditingId(null);
                    } catch (e: any) {
                      setErr(e?.error ?? 'Verwijderen mislukt');
                    }
                  }}
                >
                  Verwijder
                </Button>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
