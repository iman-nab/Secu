import React from 'react';
import ReactDOM from 'react-dom/client';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { BrowserRouter } from 'react-router-dom';
import App from './routes/App';
// FullCalendar styles (v6)
// FullCalendar styles are loaded via <link> tags in index.html.
// Reason: some FullCalendar packages do not expose CSS files through "exports",
// which causes Vite dep-scan to fail on deep CSS imports.
import './styles.css';

import { ToastProvider } from './components/toast';
import { ErrorBoundary } from './components/ErrorBoundary';

// Leaflet (maps) styles + marker icon fix
import 'leaflet/dist/leaflet.css';
import './lib/leafletFix';

// Register service worker for PWA + Push notifications
if ('serviceWorker' in navigator) {
  window.addEventListener('load', async () => {
    try {
      await navigator.serviceWorker.register('/sw.js');
    } catch {
      // ignore
    }
  });

  // Handle navigation messages from the service worker notification click
  navigator.serviceWorker.addEventListener('message', (event) => {
    if (event.data?.type === 'NAVIGATE' && typeof event.data.url === 'string') {
      window.location.href = event.data.url;
    }
  });
}

const qc = new QueryClient({
  defaultOptions: {
    queries: { retry: 1, refetchOnWindowFocus: false },
    mutations: { retry: 0 },
  },
});

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <QueryClientProvider client={qc}>
      <ToastProvider>
        {/*
          React Router v7 future flags:
          - v7_startTransition: wraps router state updates in React.startTransition
          - v7_relativeSplatPath: changes relative resolution in splat routes
          Opting in early removes the dev warnings and makes v7 upgrades smoother.
        */}
        <BrowserRouter future={{ v7_startTransition: true, v7_relativeSplatPath: true }}>
          <ErrorBoundary>
            <App />
          </ErrorBoundary>
        </BrowserRouter>
      </ToastProvider>
    </QueryClientProvider>
  </React.StrictMode>,
);
