import { useEffect, useMemo, useRef, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { getShift, listShifts } from '../api/shifts';
import type { Shift, User } from '../api/types';

const REMINDER_MINUTES = (() => {
  const raw = (import.meta as any)?.env?.VITE_CLOCK_OUT_REMINDER_MINUTES;
  const n = Number(raw ?? 15);
  return Number.isFinite(n) && n > 0 ? n : 15;
})();

function toISODate(d: Date) {
  return d.toISOString().slice(0, 10);
}

function formatTimeNL(date: string | Date) {
  const d = typeof date === 'string' ? new Date(date) : date;
  return d.toLocaleTimeString('nl-NL', { hour: '2-digit', minute: '2-digit' });
}

function storageKey(userId: string, shiftId: string) {
  return `clockout-reminder-sent:${userId}:${shiftId}`;
}

function markSent(userId: string, shiftId: string) {
  try {
    sessionStorage.setItem(storageKey(userId, shiftId), '1');
  } catch {
    // ignore
  }
}

function wasSent(userId: string, shiftId: string) {
  try {
    return sessionStorage.getItem(storageKey(userId, shiftId)) === '1';
  } catch {
    return false;
  }
}

type Candidate = {
  shift: Shift;
  remindAtMs: number;
  endAtMs: number;
};

export function useClockOutReminder(user: User | undefined) {
  const [toast, setToast] = useState<string | undefined>();
  const timeoutRef = useRef<number | null>(null);

  const enabled = !!user && user.role === 'EMPLOYEE';

  const { data: shifts } = useQuery({
    queryKey: ['clockout-reminder', 'shifts'],
    queryFn: async () => {
      const now = new Date();
      const start = new Date(now);
      start.setDate(start.getDate() - 1);
      const end = new Date(now);
      end.setDate(end.getDate() + 2);
      const res = await listShifts({ start: toISODate(start), end: toISODate(end) });
      return res.shifts ?? [];
    },
    enabled,
    staleTime: 60_000,
    refetchInterval: 60_000,
  });

  const candidate = useMemo<Candidate | null>(() => {
    if (!enabled || !user || !Array.isArray(shifts) || shifts.length === 0) return null;

    const nowMs = Date.now();
    const windowEndMs = nowMs + 48 * 60 * 60 * 1000;

    const cands: Candidate[] = [];
    for (const s of shifts) {
      const endAtMs = new Date(s.endAt).getTime();
      if (!Number.isFinite(endAtMs) || endAtMs <= nowMs) continue;

      const remindAtMs = endAtMs - REMINDER_MINUTES * 60 * 1000;
      if (remindAtMs > windowEndMs) continue;
      if (wasSent(user.id, s.id)) continue;

      cands.push({ shift: s, remindAtMs, endAtMs });
    }

    cands.sort((a, b) => a.remindAtMs - b.remindAtMs);
    return cands[0] ?? null;
  }, [enabled, shifts, user]);

  useEffect(() => {
    if (!enabled || !user || !candidate) return;

    if (timeoutRef.current) {
      window.clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }

    const nowMs = Date.now();
    const delay = Math.max(0, candidate.remindAtMs - nowMs);

    const fire = async () => {
      markSent(user.id, candidate.shift.id);

      try {
        const full = await getShift(candidate.shift.id);
        const shift: any = full.shift;
        const timeEntries = shift?.timeEntries ?? [];
        const active = timeEntries.find((t: any) => t.userId === user.id && !t.clockOutAt);
        if (!active) return;

        const endTime = formatTimeNL(candidate.shift.endAt);
        const title = candidate.shift.title ?? 'dienst';
        const msg = `Herinnering: je dienst "${title}" eindigt om ${endTime}. Vergeet niet uit te klokken.`;

        setToast(msg);
        window.setTimeout(() => setToast(undefined), 8000);

        // No browser Notification here: server-side Web Push handles desktop notifications.
      } catch {
        // ignore
      }
    };

    if (delay === 0 && nowMs <= candidate.endAtMs) {
      void fire();
    } else {
      timeoutRef.current = window.setTimeout(() => {
        void fire();
      }, delay);
    }

    return () => {
      if (timeoutRef.current) {
        window.clearTimeout(timeoutRef.current);
        timeoutRef.current = null;
      }
    };
  }, [candidate, enabled, user]);

  return { toast };
}
