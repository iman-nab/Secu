import { useEffect, useRef } from 'react';

type Options = {
  /** Enable the inactivity timer (typically only when the user is logged in). */
  enabled: boolean;
  /** Minutes of inactivity after which we should log out. */
  timeoutMinutes: number;
  /** Called once when the timeout is reached. */
  onTimeout: () => void;
};

// Activity events that should reset the inactivity timer.
const EVENTS: (keyof WindowEventMap)[] = [
  'mousemove',
  'mousedown',
  'keydown',
  'scroll',
  'touchstart',
  'pointerdown',
  'wheel',
];

/**
 * Logs the user out after a period of inactivity.
 *
 * Note: this uses client-side activity only. It complements server-side session expiry.
 */
export function useInactivityLogout({ enabled, timeoutMinutes, onTimeout }: Options) {
  const timerRef = useRef<number | null>(null);
  const firedRef = useRef(false);

  useEffect(() => {
    if (!enabled) return;
    if (!Number.isFinite(timeoutMinutes) || timeoutMinutes <= 0) return;

    const timeoutMs = Math.round(timeoutMinutes * 60_000);

    const clear = () => {
      if (timerRef.current) {
        window.clearTimeout(timerRef.current);
        timerRef.current = null;
      }
    };

    const arm = () => {
      clear();
      timerRef.current = window.setTimeout(() => {
        if (firedRef.current) return;
        firedRef.current = true;
        onTimeout();
      }, timeoutMs);
    };

    const onActivity = () => {
      if (firedRef.current) return;
      arm();
    };

    // Start immediately
    arm();

    // Listen for activity
    EVENTS.forEach((evt) => window.addEventListener(evt, onActivity, { passive: true }));

    // Reset when tab becomes visible again
    const onVisibility = () => {
      if (document.visibilityState === 'visible') onActivity();
    };
    document.addEventListener('visibilitychange', onVisibility);

    return () => {
      clear();
      EVENTS.forEach((evt) => window.removeEventListener(evt, onActivity));
      document.removeEventListener('visibilitychange', onVisibility);
      firedRef.current = false;
    };
  }, [enabled, timeoutMinutes, onTimeout]);
}
