import { useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

// Minimal, dependency-free global hotkeys.
// Uses Alt + key to avoid clashing with normal typing.
// - Alt + D: Dashboard
// - Alt + A: Agenda
// - Alt + U: Uren
// - Alt + N: Notificaties
//
// NOTE: We intentionally skip Alt+S (global search) for now because search is page-specific.

function isTypingTarget(el: EventTarget | null): boolean {
  const node = el as HTMLElement | null;
  if (!node) return false;
  const tag = (node.tagName || '').toLowerCase();
  if (tag === 'input' || tag === 'textarea' || tag === 'select') return true;
  if ((node as any).isContentEditable) return true;
  return false;
}

export function useGlobalHotkeys(options: { enabled?: boolean } = {}) {
  const enabled = options.enabled ?? true;
  const nav = useNavigate();
  const location = useLocation();

  useEffect(() => {
    if (!enabled) return;

    const onKeyDown = (e: KeyboardEvent) => {
      // Allow normal typing in fields.
      if (isTypingTarget(e.target)) return;

      if (!e.altKey) return;
      const k = e.key.toLowerCase();

      // Prevent browser menu focus in some environments.
      if (['d', 'a', 'u', 'n'].includes(k)) e.preventDefault();

      // Keep the UX predictable: do not re-navigate if you're already there.
      const go = (path: string) => {
        if (location.pathname === path) return;
        nav(path);
      };

      if (k === 'd') return go('/dashboard');
      if (k === 'a') return go('/agenda');
      if (k === 'u') return go('/uren');
      if (k === 'n') return go('/notificaties');
    };

    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [enabled, nav, location.pathname]);
}
