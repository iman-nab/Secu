import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { apiFetch } from '../api/apiClient';
import type { User } from '../api/types';

export function useMe() {
  return useQuery({
    queryKey: ['me'],
    queryFn: async () => (await apiFetch<{ user: User }>('/auth/me')).user,
    staleTime: 30_000,
    // Avoid noisy loops on 401 during boot / 2FA setup.
    // We handle auth transitions explicitly (login / logout / enable 2FA) via invalidateQueries.
    retry: false,
    refetchOnWindowFocus: false,
    refetchOnReconnect: false,
  });
}

export type LoginResult =
  | { twoFactorRequired: true; tempToken: string; user: User }
  | { twoFactorRequired: false; user: User };

export function useLogin() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (input: { email: string; password: string }) =>
      apiFetch<LoginResult>('/auth/login', { method: 'POST', body: JSON.stringify(input) }),
    onSuccess: async (data) => {
      // Only invalidate /me when cookies were actually set.
      if (!data.twoFactorRequired) {
        await qc.invalidateQueries({ queryKey: ['me'] });
      }
    },
  });
}

export function useLogout() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async () => apiFetch<{ ok: boolean }>('/auth/logout', { method: 'POST', body: '{}' }),
    onSuccess: async () => {
      await qc.cancelQueries();
      qc.removeQueries({ queryKey: ['me'] });
      qc.clear();
      window.location.href = '/login';
    },
  });
}
