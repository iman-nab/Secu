import { useEffect } from 'react';
import { io, Socket } from 'socket.io-client';
import { API_URL } from '../config';
import type { User } from '../api/types';

export function useNotificationsSocket(user: User | undefined, onMessage: (payload: any) => void) {
  useEffect(() => {
    if (!user) return;

    // If API_URL is empty, Socket.IO will connect to the current origin.
    // In dev, Vite proxies /socket.io (see vite.config.ts), so this avoids CORS and port mismatches.
    const s: Socket = io(API_URL || undefined, {
      withCredentials: true,
      transports: ['websocket', 'polling'],
    });

    // Keep the app behavior the same; just surface the reason in devtools when debugging.
    s.on('connect_error', (err) => {
      if (import.meta.env.DEV) {
        // eslint-disable-next-line no-console
        console.warn('[socket] connect_error', err?.message || err);
      }
    });
    s.on('notification', onMessage);

    return () => {
      s.disconnect();
    };
  }, [user, onMessage]);
}
