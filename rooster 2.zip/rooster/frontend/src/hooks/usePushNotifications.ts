import { useEffect, useMemo, useState } from 'react';
import { getVapidPublicKey, subscribePush, unsubscribePush } from '../api/push';

function urlBase64ToUint8Array(base64String: string) {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
  const rawData = atob(base64);
  const outputArray = new Uint8Array(rawData.length);
  for (let i = 0; i < rawData.length; ++i) outputArray[i] = rawData.charCodeAt(i);
  return outputArray;
}

export function usePushNotifications() {
  const supported = useMemo(
    () => 'serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window,
    [],
  );

  const [permission, setPermission] = useState<NotificationPermission>(() =>
    typeof Notification !== 'undefined' ? Notification.permission : 'default',
  );
  const [enabled, setEnabled] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | undefined>();

  useEffect(() => {
    if (!supported) return;
    (async () => {
      try {
        const reg = await navigator.serviceWorker.getRegistration();
        if (!reg) return;
        const sub = await reg.pushManager.getSubscription();
        setEnabled(!!sub);
      } catch {
        // ignore
      }
    })();
  }, [supported]);

  async function enable() {
    if (!supported) return;
    setBusy(true);
    setError(undefined);
    try {
      if (!window.isSecureContext) {
        throw new Error('Push notificaties werken alleen via HTTPS (of localhost). Open de app via https:// en voeg daarna toe aan je beginscherm.');
      }
      const perm = await Notification.requestPermission();
      setPermission(perm);
      if (perm !== 'granted') throw new Error('Toestemming geweigerd');

      const { publicKey } = await getVapidPublicKey();
      const reg = (await navigator.serviceWorker.getRegistration()) || (await navigator.serviceWorker.register('/sw.js'));

      const sub = await reg.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(publicKey),
      });

      await subscribePush(sub.toJSON());
      setEnabled(true);
    } catch (e: any) {
      setError(e?.message ?? 'Push inschakelen mislukt');
    } finally {
      setBusy(false);
    }
  }

  async function disable() {
    if (!supported) return;
    setBusy(true);
    setError(undefined);
    try {
      const reg = await navigator.serviceWorker.getRegistration();
      if (!reg) return;
      const sub = await reg.pushManager.getSubscription();
      if (sub) {
        const endpoint = sub.endpoint;
        await sub.unsubscribe();
        await unsubscribePush(endpoint);
      }
      setEnabled(false);
    } catch (e: any) {
      setError(e?.message ?? 'Push uitschakelen mislukt');
    } finally {
      setBusy(false);
    }
  }

  return { supported, enabled, permission, busy, error, enable, disable };
}
