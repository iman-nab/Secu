import { useEffect, useState } from 'react';

/**
 * Small helper to simplify responsive rendering.
 * We treat < md (Tailwind) as mobile.
 */
export function useIsMobile() {
  const [isMobile, setIsMobile] = useState(() => {
    if (typeof window === 'undefined') return false;
    return window.matchMedia('(max-width: 767px)').matches;
  });

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const mq = window.matchMedia('(max-width: 767px)');
    const onChange = () => setIsMobile(mq.matches);
    // Safari supports addListener
    if ('addEventListener' in mq) mq.addEventListener('change', onChange);
    else (mq as any).addListener(onChange);
    return () => {
      if ('removeEventListener' in mq) mq.removeEventListener('change', onChange);
      else (mq as any).removeListener(onChange);
    };
  }, []);

  return isMobile;
}
