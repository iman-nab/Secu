export type GeoPayload = { lat: number; lng: number; accuracyM: number };

export async function getCurrentGeo(): Promise<GeoPayload> {
  if (!navigator.geolocation) {
    throw { error: 'Geolocation is not supported by this browser.' };
  }

  const pos = await new Promise<GeolocationPosition>((resolve, reject) => {
    navigator.geolocation.getCurrentPosition(resolve, reject, {
      enableHighAccuracy: true,
      timeout: 10_000,
      maximumAge: 0,
    });
  }).catch((e: GeolocationPositionError) => {
    const msg =
      e.code === e.PERMISSION_DENIED
        ? 'Location permission denied.'
        : e.code === e.POSITION_UNAVAILABLE
          ? 'Location unavailable.'
          : 'Location request timed out.';
    throw { error: msg };
  });

  return {
    lat: pos.coords.latitude,
    lng: pos.coords.longitude,
    accuracyM: pos.coords.accuracy,
  };
}
