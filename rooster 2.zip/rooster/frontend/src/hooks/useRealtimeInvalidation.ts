import { useCallback } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import type { User } from '../api/types';
import { useNotificationsSocket } from './useNotificationsSocket';

/**
 * Listens to Socket.IO realtime "notification" messages from the backend and
 * invalidates relevant React Query caches.
 *
 * This keeps the app feeling realtime (clock-in/out, notes, materials, ...)
 * without adding extra polling.
 */
export function useRealtimeInvalidation(me: User | undefined) {
  const qc = useQueryClient();

  const onMessage = useCallback(
    (payload: any) => {
      const type = String(payload?.type || '');
      const shiftId = payload?.shiftId ? String(payload.shiftId) : null;

      // Shift-level updates
      if (shiftId) {
        // Detail + activity
        qc.invalidateQueries({ queryKey: ['shift', shiftId] });
        qc.invalidateQueries({ queryKey: ['shift-activity', shiftId] });
      }

      // Lists / dashboards often show the same data and should refresh too
      if (
        shiftId ||
        ['SHIFT_CREATE', 'SHIFT_UPDATE', 'SHIFT_DELETE', 'CLOCK_IN', 'CLOCK_OUT', 'NOTE_CREATE', 'NOTE_PIN', 'NOTE_UNPIN', 'TIMEENTRY_RESET', 'TIMEENTRY_CORRECT', 'OPEN_SHIFT_REVIEW'].includes(type)
      ) {
        qc.invalidateQueries({ queryKey: ['shifts'] });
        qc.invalidateQueries({ queryKey: ['dashboard'] });
        qc.invalidateQueries({ queryKey: ['client-shifts'] });
        qc.invalidateQueries({ queryKey: ['hours'] });
      }
    },
    [qc],
  );

  useNotificationsSocket(me, onMessage);
}
