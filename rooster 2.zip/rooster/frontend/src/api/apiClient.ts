import { API_URL } from '../config';

export type ApiError = { error: string; code?: string; details?: any };

type ApiEnvelope<T> = {
  success: boolean;
  data?: T;
  error?: { message: string; code?: string; details?: any };
  meta?: any;
};

function isJsonResponse(res: Response) {
  const ct = res.headers.get('content-type') || '';
  return ct.includes('application/json') || ct.includes('+json');
}

let redirectingToLogin = false;

function redirectToLogin() {
  // Avoid redirect loops if we are already on the login page.
  if (typeof window !== 'undefined' && window.location?.pathname?.startsWith('/login')) return;

  if (redirectingToLogin) return;
  redirectingToLogin = true;

  try {
    const next = encodeURIComponent(window.location.pathname + window.location.search);
    window.location.assign(`/login?expired=1&next=${next}`);
  } catch {
    window.location.href = '/login';
  }
}

async function tryRefresh(): Promise<boolean> {
  try {
    const res = await fetch(`${API_URL}/auth/refresh`, {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
    });
    return res.ok;
  } catch {
    return false;
  }
}

async function readErrorPayload(res: Response): Promise<any> {
  try {
    if (isJsonResponse(res)) {
      const json = (await res.json()) as any;
      // New API envelope
      if (json && typeof json === 'object' && json.success === false && json.error) {
        return { error: json.error.message, code: json.error.code, details: json.error.details };
      }
      // Legacy
      if (json && typeof json === 'object' && typeof json.error === 'string') return json;
      return { error: `Request failed (${res.status})`, details: json };
    }
  } catch {
    // ignore
  }
  const text = await res.text().catch(() => '');
  return { error: text ? text.slice(0, 200) : `Request failed (${res.status})` };
}

export async function apiFetch<T>(path: string, init: RequestInit = {}, attempt = 0): Promise<T> {
  const res = await fetch(`${API_URL}${path}`, {
    ...init,
    credentials: 'include',
    headers: {
      'Content-Type': 'application/json',
      ...(init.headers ?? {}),
    },
  });

  // Handle non-OK with best-effort JSON
  if (!res.ok) {
    // 401: try refresh once. If refresh fails, send user back to login.
    if (
      res.status === 401 &&
      attempt === 0 &&
      !path.startsWith('/auth/login') &&
      !path.startsWith('/auth/refresh')
    ) {
      const refreshed = await tryRefresh();
      if (refreshed) {
        return apiFetch<T>(path, init, 1);
      }

      redirectToLogin();
    }

    throw await readErrorPayload(res);
  }

  if (res.status === 204) return undefined as T;

  // If backend returns HTML by mistake (proxy not applied), give a clearer error
  if (!isJsonResponse(res)) {
    const text = await res.text();
    throw {
      error:
        `Server response is not JSON. ` +
        `Got content-type="${res.headers.get('content-type') || 'unknown'}". ` +
        `First chars: ${JSON.stringify(text.slice(0, 40))}. ` +
        `This usually means the request hit the frontend (index.html) instead of the API.`,
    };
  }

  const json = (await res.json()) as ApiEnvelope<T> | T;

  // New API envelope (success)
  if (json && typeof json === 'object' && (json as any).success === true && 'data' in (json as any)) {
    return (json as ApiEnvelope<T>).data as T;
  }

  // Legacy response
  return json as T;
}