import { apiFetch } from './apiClient';

export type AvailabilityType = 'VACATION' | 'SICK' | 'UNAVAILABLE';

export type UserAvailability = {
  id: string;
  userId: string;
  type: AvailabilityType;
  startAt: string;
  endAt: string;
  note?: string | null;
  createdAt?: string;
  updatedAt?: string;
};

export async function listMyAvailability(params?: { startAt?: string; endAt?: string }) {
  const qs = new URLSearchParams();
  if (params?.startAt) qs.set('startAt', params.startAt);
  if (params?.endAt) qs.set('endAt', params.endAt);
  const q = qs.toString() ? `?${qs.toString()}` : '';
  return apiFetch<{ items: UserAvailability[] }>(`/availability/me${q}`);
}

export async function createMyAvailability(input: {
  type: AvailabilityType;
  startAt: string;
  endAt: string;
  note?: string;
}) {
  return apiFetch<UserAvailability>(`/availability/me`, {
    method: 'POST',
    body: JSON.stringify(input),
  });
}

export async function deleteAvailability(id: string) {
  return apiFetch<{ ok: true }>(`/availability/${id}`, { method: 'DELETE' });
}

export async function updateAvailability(
  id: string,
  input: Partial<{ type: AvailabilityType; startAt: string; endAt: string; note?: string | null }>,
) {
  return apiFetch<UserAvailability>(`/availability/${id}`, {
    method: 'PATCH',
    body: JSON.stringify(input),
  });
}

export async function listUserAvailability(userId: string, params?: { startAt?: string; endAt?: string }) {
  const qs = new URLSearchParams();
  if (params?.startAt) qs.set('startAt', params.startAt);
  if (params?.endAt) qs.set('endAt', params.endAt);
  const q = qs.toString() ? `?${qs.toString()}` : '';
  return apiFetch<{ items: UserAvailability[] }>(`/availability/user/${userId}${q}`);
}

// Admin: create availability for any user
export async function createUserAvailability(
  userId: string,
  input: { type: AvailabilityType; startAt: string; endAt: string; note?: string },
) {
  return apiFetch<UserAvailability>(`/availability/user/${userId}`, {
    method: 'POST',
    body: JSON.stringify(input),
  });
}
