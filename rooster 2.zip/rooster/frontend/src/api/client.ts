import { apiFetch } from './apiClient';

export type IncidentCount = { label: string; count: number };

export function getClientIncidentAnalytics(params?: { start?: string; end?: string; limit?: number }) {
  const qs = new URLSearchParams();
  if (params?.start) qs.set('start', params.start);
  if (params?.end) qs.set('end', params.end);
  if (params?.limit) qs.set('limit', String(params.limit));
  const suffix = qs.toString() ? `?${qs.toString()}` : '';
  return apiFetch<{ start: string; end: string; items: IncidentCount[] }>(`/client/analytics/incidents${suffix}`);
}

export type ClientRequestStatus = 'OPEN' | 'IN_PROGRESS' | 'DONE';

export type ClientRequest = {
  id: string;
  subject: string;
  message: string;
  status: ClientRequestStatus;
  createdAt: string;
  updatedAt: string;
  handledAt?: string | null;
  createdBy?: { id: string; fullName: string; email: string };
  handledBy?: { id: string; fullName: string; email: string } | null;
  client?: { id: string; name: string };
};

export function listClientRequests() {
  return apiFetch<{ requests: ClientRequest[] }>(`/client/requests`);
}

export function createClientRequest(input: { subject: string; message: string }) {
  return apiFetch<ClientRequest>(`/client/requests`, {
    method: 'POST',
    body: JSON.stringify(input),
  });
}

// Admin inbox
export function listAllRequests(params?: { status?: ClientRequestStatus | 'ALL'; page?: number; pageSize?: number }) {
  const qs = new URLSearchParams();
  if (params?.status && params.status !== 'ALL') qs.set('status', params.status);
  if (params?.page) qs.set('page', String(params.page));
  if (params?.pageSize) qs.set('pageSize', String(params.pageSize));
  const suffix = qs.toString() ? `?${qs.toString()}` : '';
  return apiFetch<{ requests: ClientRequest[]; totalCount?: number; page?: number; pageSize?: number }>(`/requests${suffix}`);
}

export function updateRequestStatus(id: string, status: ClientRequestStatus) {
  return apiFetch<ClientRequest>(`/requests/${id}`, {
    method: 'PATCH',
    body: JSON.stringify({ status }),
  });
}

// Admin: convert a request into a shift
export function convertRequestToShift(
  id: string,
  input: {
    startAt: string;
    endAt: string;
    locationId: string;
    type?: string;
    requiredPassColor?: 'GRAY' | 'DARK_BLUE' | 'LIGHT_BLUE' | 'ORANGE' | 'GREEN' | 'BLACK';
    requiredWorkers?: number;
  },
) {
  return apiFetch<{ shift: any }>(`/requests/${id}/convert-to-shift`, {
    method: 'POST',
    body: JSON.stringify(input),
  });
}

// Admin: request audit/activity
export function getRequestActivity(id: string, opts?: { page?: number; pageSize?: number }) {
  const qs = new URLSearchParams();
  if (opts?.page) qs.set('page', String(opts.page));
  if (opts?.pageSize) qs.set('pageSize', String(opts.pageSize));
  const suffix = qs.toString() ? `?${qs.toString()}` : '';
  return apiFetch<{ logs: any[]; totalCount?: number; page?: number; pageSize?: number }>(`/requests/${id}/activity${suffix}`);
}
