import { apiFetch } from './apiClient';

export async function getMyCalendarFeed() {
  return apiFetch<{ token: string; url: string }>('/calendar/me');
}
