import { apiFetch } from './apiClient';
import type { Notification } from './types';

export function listNotifications(params?: { page?: number; pageSize?: number; tab?: 'all' | 'action' }) {
  const qs = new URLSearchParams();
  if (params?.page) qs.set('page', String(params.page));
  if (params?.pageSize) qs.set('pageSize', String(params.pageSize));
  if (params?.tab) qs.set('tab', String(params.tab));
  const suffix = qs.toString() ? `?${qs.toString()}` : '';
  return apiFetch<{ notifications: Notification[]; totalCount?: number; page?: number; pageSize?: number }>(`/notifications${suffix}`);
}

export function markNotificationRead(id: string) {
  return apiFetch('/notifications/' + id + '/read', { method: 'POST', body: '{}' });
}


export function markAllNotificationsRead() {
  return apiFetch('/notifications/read-all', { method: 'POST', body: '{}' });
}

export function getUnreadNotificationsCount() {
  return apiFetch<{ count: number }>('/notifications/unread-count');
}
