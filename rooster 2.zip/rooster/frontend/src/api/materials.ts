import { apiFetch } from './apiClient';

export type Material = {
  id: string;
  name: string;
  description?: string | null;
  stockQuantity: number;
};

export type MaterialAssignmentStatus = 'ASSIGNED' | 'RETURNED' | 'LOST' | 'DEFECT';

export type MaterialAssignment = {
  id: string;
  materialId: string;
  userId: string;
  quantity: number;
  status: MaterialAssignmentStatus;
  note?: string | null;
  assignedAt: string;
  returnedAt?: string | null;
  material?: { id: string; name: string; description?: string | null };
  user?: { id: string; fullName: string; email?: string };
  createdBy?: { id: string; fullName: string };
};

export type MaterialHistoryAction =
  | 'CREATE'
  | 'UPDATE'
  | 'STOCK_ADJUST'
  | 'ASSIGN'
  | 'RETURN'
  | 'LOST'
  | 'DEFECT'
  | 'DELETE';

export type MaterialHistory = {
  id: string;
  materialId: string;
  action: MaterialHistoryAction;
  quantityDelta: number;
  note?: string | null;
  createdAt: string;
  material?: { id: string; name: string };
  actor?: { id: string; fullName: string };
  user?: { id: string; fullName: string } | null;
};

export async function listMaterials(params?: {
  page?: number;
  pageSize?: number;
  q?: string;
}): Promise<{ materials: Material[]; totalCount?: number; page?: number; pageSize?: number }> {
  const qs = new URLSearchParams();
  if (params?.page) qs.set('page', String(params.page));
  if (params?.pageSize) qs.set('pageSize', String(params.pageSize));
  if (params?.q) qs.set('q', String(params.q));
  const suffix = qs.toString() ? `?${qs.toString()}` : '';
  return apiFetch(`/materials${suffix}`);
}

export async function createMaterial(input: {
  name: string;
  description?: string;
  stockQuantity?: number;
}): Promise<{ material: Material }> {
  return apiFetch('/materials', { method: 'POST', body: JSON.stringify(input) });
}

export async function updateMaterial(
  id: string,
  input: { name?: string; description?: string | null; stockQuantity?: number }
): Promise<{ material: Material }> {
  return apiFetch(`/materials/${id}`, { method: 'PATCH', body: JSON.stringify(input) });
}

export async function adjustMaterialStock(
  id: string,
  input: { delta: number; reason: string }
): Promise<{ material: Material }> {
  return apiFetch(`/materials/${id}/stock`, { method: 'POST', body: JSON.stringify(input) });
}

export async function deleteMaterial(id: string, opts?: { force?: boolean }): Promise<void> {
  const qs = opts?.force ? '?force=1' : '';
  await apiFetch(`/materials/${id}${qs}`, { method: 'DELETE' });
}

// Assignments
export async function listMaterialAssignments(params?: {
  userId?: string;
  materialId?: string;
  status?: string;
}): Promise<{ assignments: MaterialAssignment[] }> {
  const qs = new URLSearchParams();
  if (params?.userId) qs.set('userId', params.userId);
  if (params?.materialId) qs.set('materialId', params.materialId);
  if (params?.status) qs.set('status', params.status);
  const suffix = qs.toString() ? `?${qs.toString()}` : '';
  return apiFetch(`/materials/assignments${suffix}`);
}

export async function listMyMaterialAssignments(): Promise<{ assignments: MaterialAssignment[] }> {
  return apiFetch('/materials/assignments/me');
}

export async function createMaterialAssignment(input: {
  materialId: string;
  userId: string;
  quantity: number;
  note?: string;
}): Promise<{ assignment: MaterialAssignment }> {
  return apiFetch('/materials/assignments', { method: 'POST', body: JSON.stringify(input) });
}

export async function returnMaterialAssignment(id: string, note?: string): Promise<{ assignment: MaterialAssignment }> {
  return apiFetch(`/materials/assignments/${id}/return`, {
    method: 'POST',
    body: JSON.stringify({ note }),
  });
}

export async function reportMaterialIssue(
  id: string,
  kind: 'LOST' | 'DEFECT',
  note?: string
): Promise<{ assignment: MaterialAssignment }> {
  return apiFetch(`/materials/assignments/${id}/report`, {
    method: 'POST',
    body: JSON.stringify({ kind, note }),
  });
}

// History
export async function listMaterialHistory(params?: {
  materialId?: string;
  userId?: string;
}): Promise<{ history: MaterialHistory[] }> {
  const qs = new URLSearchParams();
  if (params?.materialId) qs.set('materialId', params.materialId);
  if (params?.userId) qs.set('userId', params.userId);
  const suffix = qs.toString() ? `?${qs.toString()}` : '';
  return apiFetch(`/materials/history${suffix}`);
}
