import { apiFetch } from './apiClient';
import type { User, Role } from './types';

export function listUsers(opts?: {
  page?: number;
  pageSize?: number;
  q?: string;
  role?: Role;
  excludeRole?: Role;
  roles?: Role[];
  excludeRoles?: Role[];
  includeLastWorked?: boolean;
}) {
  const qs = new URLSearchParams();
  if (opts?.page) qs.set('page', String(opts.page));
  if (opts?.pageSize) qs.set('pageSize', String(opts.pageSize));
  if (opts?.q) qs.set('q', opts.q);
  if (opts?.role) qs.set('role', String(opts.role));
  if (opts?.excludeRole) qs.set('excludeRole', String(opts.excludeRole));
  if (opts?.roles && opts.roles.length) qs.set('roles', opts.roles.join(','));
  if (opts?.excludeRoles && opts.excludeRoles.length) qs.set('excludeRoles', opts.excludeRoles.join(','));
  if (opts?.includeLastWorked) qs.set('includeLastWorked', '1');
  const url = qs.toString() ? `/users?${qs.toString()}` : '/users';
  return apiFetch<{ users: User[]; totalCount?: number; page?: number; pageSize?: number }>(url);
}

export function createUser(input: { email: string; fullName: string; role: Role; clientId?: string; password: string }) {
  return apiFetch<{ user: User }>('/users', { method: 'POST', body: JSON.stringify(input) });
}

export function updateUser(id: string, input: Partial<{ fullName: string; role: Role; clientId: string | null; isActive: boolean; password: string }>) {
  return apiFetch<{ user: User }>(`/users/${id}`, { method: 'PATCH', body: JSON.stringify(input) });
}

export function deleteUser(id: string) {
  return apiFetch<{ user: User }>(`/users/${id}`, { method: 'DELETE' });
}

export function reactivateUser(id: string) {
  return apiFetch<{ user: User }>(`/users/${id}/reactivate`, { method: 'POST' });
}

export function adminReset2FA(id: string) {
  return apiFetch<{ user: User }>(`/users/${id}/reset-2fa`, { method: 'POST' });
}

export function adminResetPassword(id: string) {
  return apiFetch<{ user: User; tempPassword: string }>(`/users/${id}/reset-password`, { method: 'POST' });
}


export function updateUserPassColor(id: string, passColor: string | null) {
  return apiFetch<{ user: User }>(`/users/${id}`, { method: 'PATCH', body: JSON.stringify({ passColor }) });
}
