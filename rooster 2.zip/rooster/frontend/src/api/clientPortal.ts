import { apiFetch } from './apiClient';
import type { Shift, ShiftNote } from './types';

// Standardized client API prefix (Phase cleanup):
// Client portal endpoints now live under /client (older /client-portal remains as deprecated alias on backend).
const BASE = '/client';

export function listClientShifts(params?: { start?: string; end?: string }) {
  const qs = new URLSearchParams();
  if (params?.start) qs.set('start', params.start);
  if (params?.end) qs.set('end', params.end);
  const suffix = qs.toString() ? `?${qs.toString()}` : '';
  return apiFetch<{ shifts: Shift[] }>(`${BASE}/shifts${suffix}`);
}

export function listShiftNotes(shiftId: string) {
  return apiFetch<{ notes: ShiftNote[] }>(`${BASE}/shifts/${shiftId}/notes`);
}

export function createShiftNote(shiftId: string, input: { content: string; visibleToEmployees?: boolean }) {
  return apiFetch<ShiftNote>(`${BASE}/shifts/${shiftId}/notes`, {
    method: 'POST',
    body: JSON.stringify(input),
  });
}
