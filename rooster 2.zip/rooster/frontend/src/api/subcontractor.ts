import { apiFetch } from './apiClient';

export async function subcontractorMe() {
  return apiFetch<{ user: any }>(`/subcontractor/me`);
}

export async function listSubcontractorWorkers() {
  return apiFetch<{ workers: any[] }>(`/subcontractor/workers`);
}

export async function updateSubcontractorWorkerPassColor(workerId: string, passColor: string) {
  return apiFetch<{ user: any }>(`/subcontractor/workers/${workerId}`, {
    method: 'PATCH',
    body: JSON.stringify({ passColor }),
  });
}

export async function listSubcontractorShifts(params?: { start?: string; end?: string }) {
  const qs = new URLSearchParams();
  if (params?.start) qs.set('start', params.start);
  if (params?.end) qs.set('end', params.end);
  const suffix = qs.toString() ? `?${qs.toString()}` : '';
  return apiFetch<{ shifts: any[] }>(`/subcontractor/shifts${suffix}`);
}

export async function listSubcontractorReports(params?: { start?: string; end?: string }) {
  const qs = new URLSearchParams();
  if (params?.start) qs.set('start', params.start);
  if (params?.end) qs.set('end', params.end);
  const suffix = qs.toString() ? `?${qs.toString()}` : '';
  return apiFetch<{ reports: any[] }>(`/subcontractor/reports${suffix}`);
}

export async function subcontractorHours(params?: { start?: string; end?: string }) {
  const qs = new URLSearchParams();
  if (params?.start) qs.set('start', params.start);
  if (params?.end) qs.set('end', params.end);
  const suffix = qs.toString() ? `?${qs.toString()}` : '';
  return apiFetch<{ rows: any[]; totalMinutes: number }>(`/subcontractor/hours${suffix}`);
}

export async function downloadWeeklyHoursPdf(params?: { weekStart?: string }) {
  const qs = new URLSearchParams();
  if (params?.weekStart) qs.set('weekStart', params.weekStart);
  const url = `/subcontractor/exports/weekly${qs.toString() ? `?${qs.toString()}` : ''}`;

  const res = await fetch(url, {
    method: 'POST',
    credentials: 'include',
  });

  if (!res.ok) {
    let payload: any = null;
    try {
      payload = await res.json();
    } catch {
      // ignore
    }
    throw payload ?? { error: `Request failed (${res.status})` };
  }

  const blob = await res.blob();
  const week = params?.weekStart ?? new Date().toISOString().slice(0, 10);
  const fileName = `weekly_hours_${week}.pdf`;

  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}
