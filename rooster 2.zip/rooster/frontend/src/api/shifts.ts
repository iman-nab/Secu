import { apiFetch } from './apiClient';
import type { Shift, TimeEntry } from './types';

export function listShifts(params?: {
  start?: string;
  end?: string;
  includeDeleted?: boolean;
  clientId?: string;
  locationId?: string;
  type?: string;
  passColor?: 'GRAY' | 'DARK_BLUE' | 'LIGHT_BLUE' | 'ORANGE' | 'GREEN' | 'BLACK';
}) {
  const qs = new URLSearchParams();
  if (params?.start) qs.set('start', params.start);
  if (params?.end) qs.set('end', params.end);
  if (params?.includeDeleted) qs.set('includeDeleted', '1');
  if (params?.clientId) qs.set('clientId', params.clientId);
  if (params?.locationId) qs.set('locationId', params.locationId);
  if (params?.type) qs.set('type', params.type);
  if (params?.passColor) qs.set('passColor', params.passColor);
  const q = qs.toString() ? `?${qs.toString()}` : '';
  return apiFetch<{ shifts: Shift[] }>(`/shifts${q}`);
}

export type CalendarShiftSummary = {
  id: string;
  title: string;
  type?: string | null;
  status: string;
  startAt: string;
  endAt: string;
  requiredWorkers?: number | null;
  requiredPassColor?: any;
  location?: { id: string; name: string } | null;
  client?: { id: string; name: string } | null;
  _count?: { assignments: number };
};

// Lightweight endpoint for calendar rendering (summary only).
export function listCalendarShifts(params?: {
  start?: string;
  end?: string;
  includeDeleted?: boolean;
  clientId?: string;
  locationId?: string;
  type?: string;
  passColor?: 'GRAY' | 'DARK_BLUE' | 'LIGHT_BLUE' | 'ORANGE' | 'GREEN' | 'BLACK';
  status?: string;
  assigneeId?: string;
  q?: string;
  page?: number;
  pageSize?: number;
}) {
  const qs = new URLSearchParams();
  if (params?.start) qs.set('start', params.start);
  if (params?.end) qs.set('end', params.end);
  if (params?.includeDeleted) qs.set('includeDeleted', '1');
  if (params?.clientId) qs.set('clientId', params.clientId);
  if (params?.locationId) qs.set('locationId', params.locationId);
  if (params?.type) qs.set('type', params.type);
  if (params?.passColor) qs.set('passColor', params.passColor);
  if (params?.status) qs.set('status', params.status);
  if (params?.assigneeId) qs.set('assigneeId', params.assigneeId);
  if (params?.q) qs.set('q', params.q);
  if (params?.page) qs.set('page', String(params.page));
  if (params?.pageSize) qs.set('pageSize', String(params.pageSize));
  const q = qs.toString() ? `?${qs.toString()}` : '';
  return apiFetch<{ shifts: CalendarShiftSummary[]; totalCount?: number; page?: number; pageSize?: number }>(`/shifts/calendar${q}`);
}

export function listOpenShifts(params?: {
  start?: string;
  end?: string;
  type?: string;
  locationId?: string;
  occupancy?: 'free' | 'full' | 'all';
  eligibility?: 'eligible' | 'ineligible' | 'all';
  q?: string;
  page?: number;
  pageSize?: number;
}) {
  const qs = new URLSearchParams();
  if (params?.start) qs.set('start', params.start);
  if (params?.end) qs.set('end', params.end);
  if (params?.type) qs.set('type', params.type);
  if (params?.locationId) qs.set('locationId', params.locationId);
  if (params?.occupancy && params.occupancy !== 'all') qs.set('occupancy', params.occupancy);
  if (params?.eligibility && params.eligibility !== 'all') qs.set('eligibility', params.eligibility);
  if (params?.q) qs.set('q', params.q);
  if (params?.page) qs.set('page', String(params.page));
  if (params?.pageSize) qs.set('pageSize', String(params.pageSize));
  const q = qs.toString() ? `?${qs.toString()}` : '';
  return apiFetch<{ shifts: Shift[]; totalCount?: number; page?: number; pageSize?: number }>(`/shifts/open${q}`);
}

export function getShift(id: string) {
  return apiFetch<{ shift: any }>(`/shifts/${id}`);
}

export function getShiftActivity(id: string, opts?: { page?: number; pageSize?: number }) {
  const qs = new URLSearchParams();
  if (opts?.page) qs.set('page', String(opts.page));
  if (opts?.pageSize) qs.set('pageSize', String(opts.pageSize));
  const q = qs.toString() ? `?${qs.toString()}` : '';
  return apiFetch<{ logs: any[]; totalCount?: number; page?: number; pageSize?: number }>(`/shifts/${id}/activity${q}`);
}

export function pinShiftNote(shiftId: string, noteId: string, pinned: boolean) {
  return apiFetch<{ note: any }>(`/shifts/${shiftId}/notes/${noteId}/pin`, {
    method: 'PATCH',
    body: JSON.stringify({ pinned }),
  });
}

export function requestShift(id: string) {
  return apiFetch(`/shifts/${id}/request`, { method: 'POST', body: '{}' });
}

export function reviewShiftRequest(id: string, input: { userId: string; approve: boolean }) {
  return apiFetch(`/shifts/${id}/review`, { method: 'POST', body: JSON.stringify(input) });
}

// Admin: direct assign/unassign employees
export function adminAssignShift(id: string, input: { userId?: string; userIds?: string[] }) {
  return apiFetch(`/shifts/${id}/assign`, { method: 'POST', body: JSON.stringify(input) });
}

export function adminUnassignShift(id: string, input: { userId?: string; userIds?: string[] }) {
  return apiFetch(`/shifts/${id}/unassign`, { method: 'POST', body: JSON.stringify(input) });
}

export function clockIn(
  id: string,
  geo: { lat: number; lng: number; accuracyM: number; geoReason?: string | null; bypassGeofence?: boolean; distanceM?: number },
) {
  return apiFetch<{ timeEntry: TimeEntry }>(`/shifts/${id}/clock-in`, { method: 'POST', body: JSON.stringify(geo) });
}

export function clockOut(
  id: string,
  geo: { lat: number; lng: number; accuracyM: number; geoReason?: string | null; bypassGeofence?: boolean; distanceM?: number },
) {
  return apiFetch<{ timeEntry: TimeEntry }>(`/shifts/${id}/clock-out`, { method: 'POST', body: JSON.stringify(geo) });
}

export function bulkCreateWeek(input: {
  weekStart: string;
  locationId: string;
  clientId?: string;
  repeatUntil?: string;
  entries: { dow: number; title: string; startTime: string; endTime: string; status?: 'DRAFT' | 'OPEN'; requiredWorkers?: number; assigneeIds?: string[] }[];
  // Backwards compatible
  repeat?: { mode: 'none' | 'weekly'; weeks?: number };
}) {
  return apiFetch<{ data: any[] }>(`/shifts/bulk-week`, { method: 'POST', body: JSON.stringify(input) });
}

// Admin: repeat a single shift weekly until repeatUntil (date-only).
export function repeatWeeklyShift(input: {
  title: string;
  locationId: string;
  clientId?: string;
  type?: string;
  status?: 'DRAFT' | 'OPEN';
  requiredWorkers?: number;
  requiredPassColor?: string | null;
  startAt: string;
  endAt: string;
  repeatUntil: string;
  intervalWeeks?: number;
  assigneeIds?: string[];
}) {
  return apiFetch(`/shifts/repeat-weekly`, { method: 'POST', body: JSON.stringify(input) });
}

export function createShift(input: any) {
  return apiFetch(`/shifts`, { method: 'POST', body: JSON.stringify(input) });
}

export function updateShift(id: string, input: any) {
  return apiFetch(`/shifts/${id}`, { method: 'PATCH', body: JSON.stringify(input) });
}

export function deleteShift(id: string) {
  return apiFetch(`/shifts/${id}`, { method: 'DELETE' });
}

export function resetTimeEntry(shiftId: string, timeEntryId: string) {
  return apiFetch(`/shifts/${shiftId}/time-entries/${timeEntryId}`, { method: 'DELETE' });
}

export function correctTimeEntry(
  shiftId: string,
  timeEntryId: string,
  input: { clockInAt?: string; clockOutAt?: string; reason: string },
) {
  return apiFetch<{ timeEntry: TimeEntry }>(`/shifts/${shiftId}/time-entries/${timeEntryId}`, {
    method: 'PATCH',
    body: JSON.stringify(input),
  });
}

export function adminRemoteClockIn(
  shiftId: string,
  input: { userId: string; reason: string; clockInAt?: string },
) {
  return apiFetch<{ timeEntry: TimeEntry }>(`/shifts/${shiftId}/admin-clock-in`, {
    method: 'POST',
    body: JSON.stringify(input),
  });
}

export function adminRemoteClockOut(
  shiftId: string,
  input: { userId: string; reason: string; clockOutAt?: string },
) {
  return apiFetch<{ timeEntry: TimeEntry }>(`/shifts/${shiftId}/admin-clock-out`, {
    method: 'POST',
    body: JSON.stringify(input),
  });
}

// Phase 4: shift day report / dagrapportage
export type ShiftReport = {
  id: string | null;
  shiftId: string;
  locationText: string;
  summary: string | null;
  incidents: { label: string; checked: boolean; notes?: string; timeText?: string }[];
  actions: { label: string; checked: boolean; notes?: string }[];
  attachments: { id: string; fileName: string; mimeType: string; sizeBytes: number; createdAt: string; uploadedById: string }[];
  createdAt: string | null;
  updatedAt: string | null;
};

export function getShiftReport(shiftId: string) {
  return apiFetch<{ report: ShiftReport }>(`/shifts/${shiftId}/report`);
}

export function upsertShiftReport(shiftId: string, input: {
  locationText: string;
  summary?: string | null;
  incidents: { label: string; checked: boolean; notes?: string | null; timeText?: string | null }[];
  actions: { label: string; checked: boolean; notes?: string | null }[];
}) {
  return apiFetch<{ report: ShiftReport }>(`/shifts/${shiftId}/report`, {
    method: 'PUT',
    body: JSON.stringify(input),
  });
}

export function uploadShiftReportAttachment(shiftId: string, input: { fileName: string; mimeType: string; base64: string }) {
  return apiFetch<{ attachment: any }>(`/shifts/${shiftId}/report/attachments`, {
    method: 'POST',
    body: JSON.stringify(input),
  });
}

export async function downloadShiftReportAttachment(shiftId: string, attachmentId: string) {
  const res = await fetch(`/shifts/${shiftId}/report/attachments/${attachmentId}`, {
    credentials: 'include',
  });
  if (!res.ok) {
    const text = await res.text().catch(() => '');
    throw { error: text ? text.slice(0, 200) : `Request failed (${res.status})` };
  }
  const blob = await res.blob();
  const fileName = res.headers.get('content-disposition')?.match(/filename="?([^";]+)"?/i)?.[1];
  return { blob, fileName };
}

export function deleteShiftReportAttachment(shiftId: string, attachmentId: string) {
  return apiFetch(`/shifts/${shiftId}/report/attachments/${attachmentId}`, { method: 'DELETE' });
}


// Phase 7: rates + extra costs (admin)
export function updateShiftRates(shiftId: string, input: { employerRateCents?: number; workerRateCents?: number }) {
  return apiFetch<{ shift: any }>(`/shifts/${shiftId}/rates`, { method: 'PATCH', body: JSON.stringify(input) });
}

export function addShiftExtraCost(shiftId: string, input: { description: string; amountCents: number }) {
  return apiFetch<{ cost: any }>(`/shifts/${shiftId}/extra-costs`, { method: 'POST', body: JSON.stringify(input) });
}

export function updateShiftExtraCost(
  shiftId: string,
  costId: string,
  input: { description?: string; amountCents?: number },
) {
  return apiFetch<{ cost: any }>(`/shifts/${shiftId}/extra-costs/${costId}`, { method: 'PATCH', body: JSON.stringify(input) });
}

export function deleteShiftExtraCost(shiftId: string, costId: string) {
  return apiFetch(`/shifts/${shiftId}/extra-costs/${costId}`, { method: 'DELETE' });
}
