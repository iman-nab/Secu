import { apiFetch } from './apiClient';

export type Client = {
  id: string;
  name: string;
  contactName?: string | null;
  contactEmail?: string | null;
  isDeleted?: boolean;
  deletedAt?: string | null;
  users?: { id: string; email: string; fullName: string; inviteExpiresAt?: string | null; isActive?: boolean }[];
};

export type ClientOnboardResult = {
  client: Client;
  portalUser?: { id: string; email: string; fullName: string } | null;
  inviteToken?: string | null;
  inviteExpiresAt?: string | null;
  inviteLink?: string | null;
};

export async function listClients(opts?: { includeDeleted?: boolean; page?: number; pageSize?: number; q?: string }) {
  const qs = new URLSearchParams();
  if (opts?.includeDeleted) qs.set('includeDeleted', '1');
  if (opts?.page) qs.set('page', String(opts.page));
  if (opts?.pageSize) qs.set('pageSize', String(opts.pageSize));
  if (opts?.q) qs.set('q', opts.q);
  const url = qs.toString() ? `/clients?${qs.toString()}` : '/clients';
  const res = (await apiFetch(url)) as any;
  return {
    clients: (res.clients ?? res.data ?? []) as Client[],
    totalCount: res.totalCount as number | undefined,
    page: res.page as number | undefined,
    pageSize: res.pageSize as number | undefined,
  };
}

export async function onboardClient(input: {
  name: string;
  contactName?: string;
  contactEmail?: string;
  createPortalUser?: boolean;
  portalEmail?: string;
  portalFullName?: string;
}) {
  const res = await apiFetch('/clients/onboard', { method: 'POST', body: JSON.stringify(input) });
  return res as ClientOnboardResult;
}

export async function deleteClient(id: string) {
  return apiFetch(`/clients/${id}`, { method: 'DELETE' });
}

// Backwards compatible naming (used by UI)
export async function regenerateClientInvite(clientId: string) {
  const res = await apiFetch(`/clients/${clientId}/regenerate-invite`, { method: 'POST' });
  return res as ClientOnboardResult;
}

// Backwards compatible naming (used by UI)
export async function createClientPortalUser(clientId: string, input: { portalEmail?: string; portalFullName?: string }) {
  const res = await apiFetch(`/clients/${clientId}/create-portal-user`, { method: 'POST', body: JSON.stringify(input) });
  return res as ClientOnboardResult;
}
