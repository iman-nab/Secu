export type Role = 'ADMIN' | 'EMPLOYEE' | 'CLIENT' | 'SUBCONTRACTOR';

export type User = {
  id: string;
  email: string;
  fullName: string;
  role: Role;
  clientId?: string | null;
  subcontractorId?: string | null;
  isActive: boolean;
  twoFactorEnabled?: boolean;
  passColor?: string | null;
  status?: string;
  lastWorked?: null | {
    timeEntryId: string;
    shiftId: string;
    shiftTitle: string;
    startAt: string;
    endAt: string;
    locationName?: string | null;
    clockInAt: string;
    clockOutAt?: string | null;
    minutesWorked: number;
  };
  createdAt: string;
};

export type ShiftNote = {
  id: string;
  shiftId: string;
  authorId: string;
  content: string;
  visibleToEmployees: boolean;
  isPinned?: boolean;
  pinnedAt?: string | null;
  createdAt: string;
  author?: { id: string; fullName: string; email: string };
};

export type Location = {
  id: string;
  name: string;
  address: string;
  latitude: number;
  longitude: number;
  radiusM: number;
};

export type ShiftStatus = 'DRAFT' | 'OPEN' | 'ASSIGNED' | 'COMPLETED' | 'CANCELLED';

export type Shift = {
  // Phase 7 (optional)
  employerRateCents?: number;
  workerRateCents?: number;
  extraCosts?: { id: string; description: string; amountCents: number; createdAt: string; createdById: string }[];
  id: string;
  title: string;
  description?: string | null;
  locationId: string;
  clientId?: string | null;
  client?: { id: string; name: string } | null;
  requiredWorkers?: number;
  startAt: string;
  endAt: string;
  status: ShiftStatus;
  location: Location;
  assignments?: any[];
  timeEntries?: TimeEntry[];
  notes?: ShiftNote[];
  createdBy?: { id: string; fullName: string; email: string; role: Role };
};

export type TimeEntry = {
  id: string;
  shiftId: string;
  userId: string;
  clockInAt: string;
  clockOutAt?: string | null;
  minutesWorked: number;
  adminOverride?: boolean;
  correctedById?: string | null;
  correctionReason?: string | null;
  correctedAt?: string | null;
};

export type Notification = {
  id: string;
  type: string;
  message: string;
  data?: any;
  createdAt: string;
  readAt?: string | null;
  sender?: { id: string; fullName: string; email: string; role: Role } | null;
};

export type Material = { id: string; name: string; description?: string | null };
