// Centralized API error -> user-friendly message mapping.
// The backend uses an API envelope and domain error codes.

function fmtTime(iso?: string): string {
  if (!iso) return '';
  try {
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return '';
    return d.toLocaleString('nl-NL', { dateStyle: 'medium', timeStyle: 'short' });
  } catch {
    return '';
  }
}

export function formatApiError(err: any): string {
  if (!err) return '';

  const code: string | undefined = err.code;
  const details: any = err.details;

  if (code === 'GEOFENCE_OUTSIDE') {
    const distanceM = Math.round(Number(details?.distanceM ?? 0));
    const radiusM = Math.round(Number(details?.radiusM ?? 0));
    if (distanceM && radiusM) {
      return `Je bent ${distanceM}m buiten de zone (max ${radiusM}m).`;
    }
    return 'Je bent buiten de geofence-zone.';
  }

  if (code === 'SHIFT_OVERLAP') {
    const start = fmtTime(details?.conflictStartAt);
    const end = fmtTime(details?.conflictEndAt);
    const when = start && end ? `${start} – ${end}` : '';
    return when
      ? `Overlap: deze medewerker heeft al een andere dienst (${when}).`
      : 'Overlap: deze medewerker heeft al een andere dienst.';
  }

  if (code === 'LOCKED_OUT') {
    const until = fmtTime(details?.until);
    const retry = Number(details?.retryAfterSeconds);
    if (until) return `Te veel pogingen. Probeer opnieuw om ${until}.`;
    if (Number.isFinite(retry)) return `Te veel pogingen. Probeer opnieuw over ${retry} seconden.`;
    return 'Te veel pogingen. Probeer later opnieuw.';
  }

  // Legacy / generic
  if (typeof err.error === 'string' && err.error.trim()) return err.error;
  if (typeof err.message === 'string' && err.message.trim()) return err.message;

  try {
    return JSON.stringify(err);
  } catch {
    return 'Er ging iets mis.';
  }
}
