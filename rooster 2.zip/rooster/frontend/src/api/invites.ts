import { apiFetch } from './apiClient';

export type InviteRole = 'ADMIN' | 'EMPLOYEE' | 'CLIENT' | 'SUBCONTRACTOR';

export type Invite = {
  token: string;
  expiresAt: string;
  role: InviteRole;
  email: string;
  fullName: string;
  passColor?: string | null;
};

export async function createInvite(input: {
  email: string;
  fullName: string;
  role: InviteRole;
  clientId?: string | null;
  subcontractorId?: string | null;
  expiresInHours?: number;
  passColor?: string | null;
}): Promise<{ invite: Invite }> {
  return apiFetch('/auth/invites', { method: 'POST', body: JSON.stringify(input) });
}
