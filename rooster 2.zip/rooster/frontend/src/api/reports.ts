import { apiFetch } from './apiClient';

function toQuery(params: Record<string, any>) {
  const qs = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) {
    if (v === undefined || v === null) continue;
    if (v === '' || v === 'undefined') continue;
    qs.set(k, String(v));
  }
  return qs.toString();
}

export function hoursReport(params: {
  start: string;
  end: string;
  userId?: string;
  clientId?: string;
  subcontractorId?: string;
  rounding?: 'none' | '15';
  page?: number;
  pageSize?: number;
}) {
  const qs = toQuery(params as any);
  return apiFetch<{ rows: any[]; totalMinutes: number; totalMinutesRounded?: number; totalExtraCostsCents?: number; totalCount?: number; page?: number; pageSize?: number; allowedRateViews?: any; kpis?: any }>(`/reports/hours?${qs}`, { cache: 'no-store' });
}

export function exportHoursUrl(params: {
  start: string;
  end: string;
  userId?: string;
  clientId?: string;
  subcontractorId?: string;
  format: 'csv' | 'xlsx' | 'pdf';
  mode?: 'entries' | 'summary' | 'payroll';
  rounding?: 'none' | '15';
}) {
  const qs = toQuery(params as any);
  return `/reports/hours/export?${qs}`;
}
