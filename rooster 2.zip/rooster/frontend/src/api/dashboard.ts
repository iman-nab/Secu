import { apiFetch } from './apiClient';

export function getNextRequestedShift() {
  return apiFetch<{ data: any }>(`/dashboard/next-requested`, { cache: 'no-store' });
}

export function getMyNextReactedShift() {
  return apiFetch<{ data: any }>(`/dashboard/me/next-reacted`, { cache: 'no-store' });
}


export function getAdminKpis(params: { start: string; end: string }) {
  const qs = new URLSearchParams();
  qs.set('start', params.start);
  qs.set('end', params.end);
  return apiFetch<{ kpis: any }>(`/dashboard/admin/kpis?${qs.toString()}`, { cache: 'no-store' });
}

export function getAdminKpisSeries(params: { start: string; end: string }) {
  const qs = new URLSearchParams();
  qs.set('start', params.start);
  qs.set('end', params.end);
  return apiFetch<{ range: any; series: any[]; topLocations: any[]; topWorkers: any[]; shiftCounts: any }>(
    `/dashboard/admin/kpis/series?${qs.toString()}`,
    { cache: 'no-store' },
  );
}
