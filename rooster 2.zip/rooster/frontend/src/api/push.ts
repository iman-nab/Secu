import { apiFetch } from './apiClient';

export type VapidKeyResponse = { publicKey: string };

export function getVapidPublicKey() {
  return apiFetch<VapidKeyResponse>('/push/vapid-public-key');
}

export function subscribePush(sub: PushSubscriptionJSON) {
  // Keep only what backend needs
  return apiFetch('/push/subscribe', {
    method: 'POST',
    body: JSON.stringify({
      endpoint: sub.endpoint,
      keys: sub.keys,
      userAgent: navigator.userAgent,
    }),
  });
}

export function unsubscribePush(endpoint: string) {
  return apiFetch('/push/unsubscribe', {
    method: 'POST',
    body: JSON.stringify({ endpoint }),
  });
}

export type AdminPushTarget =
  | { type: 'shift'; shiftId: string }
  | { type: 'passColor'; passColor: 'GRAY' | 'DARK_BLUE' | 'LIGHT_BLUE' | 'ORANGE' | 'GREEN' | 'BLACK' }
  | { type: 'allEmployees' };

export function sendAdminPush(input: {
  title: string;
  message: string;
  url?: string;
  target: AdminPushTarget;
}) {
  return apiFetch<{ sent: boolean; recipients: number }>('/push/send', {
    method: 'POST',
    body: JSON.stringify(input),
  });
}
