import { apiFetch } from './apiClient';
import type { Location } from './types';

export function listLocations() {
  return apiFetch<{ locations: Location[] }>('/locations');
}

export function createLocation(input: Omit<Location, 'id'>) {
  return apiFetch<{ location: Location }>('/locations', { method: 'POST', body: JSON.stringify(input) });
}

export function updateLocation(id: string, input: Partial<Omit<Location, 'id'>>) {
  return apiFetch<{ location: Location }>(`/locations/${id}`, { method: 'PATCH', body: JSON.stringify(input) });
}

export function deleteLocation(id: string) {
  return apiFetch(`/locations/${id}`, { method: 'DELETE' });
}
