import { Routes, Route, Navigate } from 'react-router-dom';
import Protected, { AdminOnly, SubcontractorOnly } from './Protected';
import Layout from '../components/Layout';
import LoginPage from '../pages/LoginPage';
import InviteAcceptPage from '../pages/InviteAcceptPage';
import TwoFASetupPage from '../pages/TwoFASetupPage';
import TwoFAVerifyPage from '../pages/TwoFAVerifyPage';
import DashboardPage from '../pages/DashboardPage';
import AgendaPage from '../pages/AgendaPage';
import OpenShiftsPage from '../pages/OpenShiftsPage';
import ShiftDetailPage from '../pages/ShiftDetailPage';
import HoursPage from '../pages/HoursPage';
import NotificationsPage from '../pages/NotificationsPage';
import AvailabilityPage from '../pages/AvailabilityPage';
import MyMaterialsPage from '../pages/MyMaterialsPage';
import AdminPage from '../pages/admin/AdminPage';
import UserAvailabilityPage from '../pages/admin/UserAvailabilityPage';
import ClientDashboardPage from '../pages/client/ClientDashboardPage';
import ClientAnalyticsPage from "../pages/client/ClientAnalyticsPage";
import ClientRequestsPage from "../pages/client/ClientRequestsPage";
import SubcontractorPage from '../pages/subcontractor/SubcontractorPage';

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />

      {/* Invite / Signup */}
      <Route path="/signup/:token" element={<InviteAcceptPage />} />
      <Route path="/invite/:token" element={<InviteAcceptPage />} />

      {/* 2FA verify is public (no cookies yet) */}
      <Route path="/2fa/verify" element={<TwoFAVerifyPage />} />

      <Route element={<Protected />}>
        <Route element={<Layout />}>
          <Route path="/" element={<Navigate to="/dashboard" replace />} />

          <Route path="/dashboard" element={<DashboardPage />} />
          <Route path="/agenda" element={<AgendaPage />} />
          <Route path="/open-diensten" element={<OpenShiftsPage />} />
          <Route path="/diensten/:id" element={<ShiftDetailPage />} />
          <Route path="/uren" element={<HoursPage />} />
          <Route path="/beschikbaarheid" element={<AvailabilityPage />} />
          <Route path="/materialen" element={<MyMaterialsPage />} />
          <Route path="/notificaties" element={<NotificationsPage />} />

          <Route path="/client" element={<ClientDashboardPage />} />
          <Route path="/client/analytics" element={<ClientAnalyticsPage />} />
          <Route path="/client/requests" element={<ClientRequestsPage />} />


          <Route element={<SubcontractorOnly />}>
            <Route path="/subcontractor" element={<SubcontractorPage />} />
          </Route>

          <Route path="/2fa/setup" element={<TwoFASetupPage />} />

          <Route element={<AdminOnly />}>
            <Route path="/admin" element={<AdminPage />} />
            <Route path="/admin/beschikbaarheid/:userId" element={<UserAvailabilityPage />} />
          </Route>
        </Route>
      </Route>

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
