import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { useMe } from '../hooks/useAuth';

export default function Protected() {
  const { data: me, isLoading } = useMe();
  const location = useLocation();
  if (isLoading) return <div className="text-sm text-gray-600">Loading…</div>;
  if (!me) return <Navigate to="/login" replace />;

  // Enforce mandatory 2FA setup.
  const in2fa = location.pathname.startsWith('/2fa');
  if (!me.twoFactorEnabled && !in2fa) {
    return <Navigate to="/2fa/setup" replace />;
  }

  // Client portal users should stay inside /client.
  if (me.role === 'CLIENT' && !location.pathname.startsWith('/client') && !in2fa) {
    // Allow global pages that are useful in portal context.
    const allowed = location.pathname.startsWith('/notificaties') || location.pathname.startsWith('/diensten/');
    if (!allowed) return <Navigate to="/client" replace />;
  }
  // Employees/Admins/Subcontractors should not enter /client.
  if (me.role !== 'CLIENT' && location.pathname.startsWith('/client')) {
    return <Navigate to="/dashboard" replace />;
  }

  // Subcontractors: default landing is /subcontractor.
  const inSubcontractorPortal = location.pathname.startsWith('/subcontractor');
  const inShiftDetail = location.pathname.startsWith('/diensten/');
  const inNotifications = location.pathname.startsWith('/notificaties');
  if (me.role === 'SUBCONTRACTOR' && !inSubcontractorPortal && !inShiftDetail && !inNotifications && !in2fa) {
    return <Navigate to="/subcontractor" replace />;
  }
  // Non-subcontractors should not enter /subcontractor.
  if (me.role !== 'SUBCONTRACTOR' && inSubcontractorPortal) {
    return <Navigate to="/dashboard" replace />;
  }

  return <Outlet />;
}

export function AdminOnly() {
  const { data: me, isLoading } = useMe();
  if (isLoading) return <div className="text-sm text-gray-600">Loading…</div>;
  if (!me) return <Navigate to="/login" replace />;
  if (!me.twoFactorEnabled) return <Navigate to="/2fa/setup" replace />;
  if (me.role !== 'ADMIN') return <Navigate to="/dashboard" replace />;
  return <Outlet />;
}

export function SubcontractorOnly() {
  const { data: me, isLoading } = useMe();
  if (isLoading) return <div className="text-sm text-gray-600">Loading…</div>;
  if (!me) return <Navigate to="/login" replace />;
  if (!me.twoFactorEnabled) return <Navigate to="/2fa/setup" replace />;
  if (me.role !== 'SUBCONTRACTOR') return <Navigate to="/dashboard" replace />;
  return <Outlet />;
}
