// Minimal typing so TypeScript doesn't complain about Leaflet being loaded via CDN.
// Leaflet is injected as a global "L" script tag in frontend/index.html.
// eslint-disable-next-line @typescript-eslint/no-explicit-any
declare const L: any;
