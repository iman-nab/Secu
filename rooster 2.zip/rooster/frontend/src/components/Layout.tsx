import { Link, NavLink, Outlet, useLocation } from 'react-router-dom';
import { useCallback, useMemo, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useMe, useLogout } from '../hooks/useAuth';
import { useRealtimeInvalidation } from '../hooks/useRealtimeInvalidation';
import { useClockOutReminder } from '../hooks/useClockOutReminder';
import { useInactivityLogout } from '../hooks/useInactivityLogout';
import { useGlobalHotkeys } from '../hooks/useGlobalHotkeys';
import { Button } from './ui';
import { useToast } from './toast';
import { getUnreadNotificationsCount } from '../api/notifications';

type NavItem = {
  to: string;
  label: string;
  shortLabel?: string;
  icon: string;
};

export default function Layout() {
  const { data: me } = useMe();
  const logout = useLogout();
  const toast = useToast();

  // Employee-only: best-effort reminder 15 minutes before scheduled end time.
  const clockOutReminder = useClockOutReminder(me);

  // Keep key screens realtime via Socket.IO notifications
  useRealtimeInvalidation(me);

  // Auto-logout on inactivity (defaults to 30 minutes)
  const inactivityMinutes = Number((import.meta as any).env?.VITE_INACTIVITY_LOGOUT_MINUTES ?? 30);
  const onInactivity = useCallback(() => {
    // Best-effort UX feedback
    toast.info('Je bent automatisch uitgelogd wegens inactiviteit.');
    logout.mutate();
  }, [logout, toast]);

  useInactivityLogout({ enabled: !!me && !logout.isPending, timeoutMinutes: inactivityMinutes, onTimeout: onInactivity });

  // Global navigation hotkeys (Alt + D/A/U/N)
  useGlobalHotkeys({ enabled: !!me });

  const location = useLocation();
  const homeTo = me?.role === 'CLIENT' ? '/client' : me?.role === 'SUBCONTRACTOR' ? '/subcontractor' : '/dashboard';
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const { data: unread } = useQuery({
    queryKey: ['notifications', 'unreadCount', me?.id],
    queryFn: () => getUnreadNotificationsCount(),
    enabled: !!me,
    staleTime: 30_000,
    refetchInterval: 30_000,
  });
  const unreadCount = unread?.count ?? 0;

  const nav = useMemo<NavItem[]>(() => {
    if (me?.role === 'CLIENT') {
      return [
        { to: '/client', label: 'Dashboard', shortLabel: 'Home', icon: '🏠' },
        { to: '/client/analytics', label: 'Analytics', shortLabel: 'Stats', icon: '📊' },
        { to: '/client/requests', label: 'Verzoeken', shortLabel: 'Verzoeken', icon: '✉️' },
      ];
    }
    if (me?.role === 'SUBCONTRACTOR') {
      return [
        { to: '/subcontractor', label: 'Portaal', shortLabel: 'Portaal', icon: '🧩' },
        { to: '/notificaties', label: 'Notificaties', shortLabel: 'Inbox', icon: '🔔' },
      ];
    }
    return [
      { to: '/dashboard', label: 'Dashboard', shortLabel: 'Home', icon: '🏠' },
      { to: '/agenda', label: 'Agenda', shortLabel: 'Agenda', icon: '🗓️' },
      { to: '/open-diensten', label: 'Open diensten', shortLabel: 'Open', icon: '📌' },
      { to: '/uren', label: 'Uren', shortLabel: 'Uren', icon: '⏱️' },
      { to: '/beschikbaarheid', label: 'Beschikbaarheid', shortLabel: 'Beschik', icon: '💤' },
      { to: '/materialen', label: 'Materialen', shortLabel: 'Mater', icon: '🎒' },
      { to: '/notificaties', label: 'Notificaties', shortLabel: 'Inbox', icon: '🔔' },
      ...(me?.role === 'ADMIN'
        ? ([{ to: '/admin', label: 'Admin', shortLabel: 'Admin', icon: '🛠️' }] satisfies NavItem[])
        : []),
    ];
  }, [me?.role]);

  // Primary nav items are always visible on mobile (bottom bar)
  const primaryMobileNav = nav.filter((n) =>
    me?.role === 'CLIENT'
      ? ['/client', '/client/analytics', '/client/requests'].includes(n.to)
      : me?.role === 'SUBCONTRACTOR'
      ? ['/subcontractor', '/notificaties'].includes(n.to)
      : ['/dashboard', '/agenda', '/open-diensten', '/uren'].includes(n.to)
  );

  const isRouteActive = (to: string) => {
    // Shift detail page should still highlight the Agenda-ish area; but keep it simple
    if (to === '/agenda' && location.pathname.startsWith('/diensten/')) return true;
    return location.pathname === to;
  };

  return (
    <div className="min-h-screen bg-[#F5F5F5]">
      {/* Desktop sidebar */}
      <aside className="hidden md:fixed md:inset-y-0 md:left-0 md:flex md:w-64 md:flex-col md:border-r md:border-[#E0E0E0] bg-[#2F4F3E] text-white">
        <div className="flex items-center justify-between border-b border-white/10 px-4 py-4">
          <Link to={homeTo} className="text-base font-semibold tracking-tight text-white">
            Rooster
          </Link>
        </div>

        <nav className="flex-1 space-y-1 p-3">
          {nav.map((n) => (
            <NavLink
              key={n.to}
              to={n.to}
              className={() =>
                `flex items-center gap-3 rounded-xl px-3 py-2 text-sm transition ${
                  isRouteActive(n.to)
                    ? 'bg-[#3E6B52] text-white'
                    : 'text-white/90 hover:bg-[#2A4638]'
                }`
              }
            >
              <span className="text-base" aria-hidden>
                {n.icon}
              </span>
              <span className="flex items-center gap-2">
                {n.label}
                {n.to === '/notificaties' && unreadCount > 0 && (
                  <span
                    className="relative inline-flex h-2 w-2"
                    aria-label={`${unreadCount} ongelezen notificaties`}
                    title={`${unreadCount} ongelezen notificaties`}
                  >
                    <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-red-500 opacity-40" />
                    <span className="relative inline-flex h-2 w-2 rounded-full bg-red-500" />
                  </span>
                )}
              </span>
            </NavLink>
          ))}
        </nav>

        <div className="border-t border-white/10 p-3">
          <div className="mb-3 rounded-xl bg-white/10 px-3 py-2 text-sm text-white/90">
            <div className="font-medium text-white">{me?.fullName}</div>
            <div className="text-xs text-white/70">{me?.role}</div>
          </div>
          <Button
            variant="outline"
            className="w-full"
            onClick={() => logout.mutate()}
            disabled={logout.isPending}
            title="Logout"
          >
            Logout
          </Button>
        </div>
      </aside>

      {/* Mobile top bar */}
      <header className="sticky top-0 z-20 border-b border-[#E0E0E0] bg-white/90 backdrop-blur md:hidden">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
          <Link to={homeTo} className="font-semibold tracking-tight text-[#2F4F3E]">
            Rooster
          </Link>
          <button
            type="button"
            className="rounded-xl border border-[#E0E0E0] bg-white px-3 py-2 text-sm text-[#424242]"
            onClick={() => setMobileMenuOpen(true)}
            aria-label="Open menu"
          >
            ☰
          </button>
        </div>
      </header>

      {/* Mobile drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-30 md:hidden">
          <div
            className="absolute inset-0 bg-black/40"
            onClick={() => setMobileMenuOpen(false)}
            aria-hidden
          />
          <div className="absolute inset-y-0 right-0 w-80 max-w-[85%] bg-white shadow-xl">
            <div className="flex items-center justify-between border-b px-4 py-4">
              <div>
                <div className="text-sm font-semibold">{me?.fullName}</div>
                <div className="text-xs text-gray-500">{me?.role}</div>
              </div>
              <button
                type="button"
                className="rounded-xl border border-[#E0E0E0] bg-white px-3 py-2 text-sm text-[#424242]"
                onClick={() => setMobileMenuOpen(false)}
                aria-label="Close menu"
              >
                ✕
              </button>
            </div>

            <nav className="space-y-1 p-3">
              {nav.map((n) => (
                <NavLink
                  key={n.to}
                  to={n.to}
                  onClick={() => setMobileMenuOpen(false)}
                  className={() =>
                    `flex items-center gap-3 rounded-xl px-3 py-3 text-sm transition ${
                      isRouteActive(n.to)
                        ? 'bg-[#3E6B52] text-white'
                        : 'text-[#424242] hover:bg-[#FAFAFA]'
                    }`
                  }
                >
                  <span className="text-base" aria-hidden>
                    {n.icon}
                  </span>
              <span>{n.label}</span>
                </NavLink>
              ))}
            </nav>

            <div className="border-t p-3">
              <Button
                variant="secondary"
                className="w-full"
                onClick={() => logout.mutate()}
                disabled={logout.isPending}
                title="Logout"
              >
                Logout
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Content */}
      <div className="md:pl-64">
        <main className="mx-auto max-w-6xl px-4 py-5 md:py-8">
          <Outlet />
        </main>
      </div>

      {clockOutReminder.toast && (
        <div className="fixed bottom-4 right-4 z-50">
          <div className="max-w-md rounded-2xl border border-gray-200 bg-white px-4 py-3 text-sm text-gray-800 shadow-lg">
            {clockOutReminder.toast}
          </div>
        </div>
      )}

      {/* Mobile bottom nav */}
      <nav className="fixed bottom-0 left-0 right-0 z-20 border-t bg-white md:hidden">
        <div className="mx-auto flex max-w-6xl items-stretch">
          {primaryMobileNav.map((n) => (
            <NavLink
              key={n.to}
              to={n.to}
              className={() =>
                `flex flex-1 flex-col items-center justify-center gap-0.5 py-2 text-xs ${
                  isRouteActive(n.to) ? 'text-gray-900' : 'text-gray-500'
                }`
              }
            >
              <span className="relative text-lg" aria-hidden>
                {n.icon}
                {n.to === '/notificaties' && unreadCount > 0 && (
                  <span className="absolute -right-0.5 -top-0.5 inline-flex h-2 w-2 rounded-full bg-red-500" />
                )}
              </span>
              <span className="truncate">{n.shortLabel ?? n.label}</span>
            </NavLink>
          ))}
          <button
            type="button"
            onClick={() => setMobileMenuOpen(true)}
            className="flex flex-1 flex-col items-center justify-center gap-0.5 py-2 text-xs text-gray-500"
            aria-label="More"
          >
            <span className="text-lg" aria-hidden>
              ⋯
            </span>
            <span className="truncate">Meer</span>
          </button>
        </div>

        {/* (intentionally no extra hint row; keep mobile UI quiet) */}
      </nav>

      {/* Add spacing so content isn't hidden behind bottom nav on mobile */}
      <div className="h-16 md:hidden" />
    </div>
  );
}
