import React, { createContext, useCallback, useContext, useMemo, useRef, useState } from 'react';

export type ToastKind = 'success' | 'error' | 'info';

export type ToastItem = {
  id: string;
  kind: ToastKind;
  title?: string;
  message: string;
  timeoutMs?: number;
};

type ToastCtx = {
  push: (t: Omit<ToastItem, 'id'>) => void;
  success: (message: string, title?: string) => void;
  error: (message: string, title?: string) => void;
  info: (message: string, title?: string) => void;
};

const Ctx = createContext<ToastCtx | null>(null);

function uid() {
  return Math.random().toString(36).slice(2) + Date.now().toString(36);
}

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<ToastItem[]>([]);
  const timers = useRef<Record<string, number>>({});

  const remove = useCallback((id: string) => {
    setItems((xs) => xs.filter((x) => x.id !== id));
    const t = timers.current[id];
    if (t) window.clearTimeout(t);
    delete timers.current[id];
  }, []);

  const push = useCallback(
    (t: Omit<ToastItem, 'id'>) => {
      const id = uid();
      const toast: ToastItem = { id, timeoutMs: 3200, ...t };
      setItems((xs) => [toast, ...xs].slice(0, 4));
      timers.current[id] = window.setTimeout(() => remove(id), toast.timeoutMs);
    },
    [remove],
  );

  const api = useMemo<ToastCtx>(
    () => ({
      push,
      success: (message, title) => push({ kind: 'success', message, title }),
      error: (message, title) => push({ kind: 'error', message, title, timeoutMs: 4500 }),
      info: (message, title) => push({ kind: 'info', message, title }),
    }),
    [push],
  );

  return (
    <Ctx.Provider value={api}>
      {children}
      <div className="fixed right-3 top-3 z-50 flex w-[min(420px,calc(100vw-1.5rem))] flex-col gap-2">
        {items.map((t) => (
          <div
            key={t.id}
            role="status"
            className={
              'rounded-2xl border bg-white px-4 py-3 shadow-lg transition ' +
              (t.kind === 'success'
                ? 'border-green-200'
                : t.kind === 'error'
                  ? 'border-red-200'
                  : 'border-gray-200')
            }
          >
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <span aria-hidden className="text-base">
                    {t.kind === 'success' ? '✅' : t.kind === 'error' ? '⚠️' : 'ℹ️'}
                  </span>
                  <div className="truncate text-sm font-semibold text-gray-900">
                    {t.title ?? (t.kind === 'success' ? 'Gelukt' : t.kind === 'error' ? 'Let op' : 'Info')}
                  </div>
                </div>
                <div className="mt-1 text-sm text-gray-700">{t.message}</div>
              </div>
              <button
                type="button"
                className="rounded-lg px-2 py-1 text-sm text-gray-500 hover:bg-gray-100"
                onClick={() => remove(t.id)}
                aria-label="Sluit"
              >
                ✕
              </button>
            </div>
          </div>
        ))}
      </div>
    </Ctx.Provider>
  );
}

export function useToast() {
  const ctx = useContext(Ctx);
  if (!ctx) {
    return {
      push: () => undefined,
      success: () => undefined,
      error: () => undefined,
      info: () => undefined,
    } as ToastCtx;
  }
  return ctx;
}
