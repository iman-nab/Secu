import { Button } from './ui';

export function PaginationControls(props: {
  page: number;
  pageSize: number;
  totalCount?: number;
  pageSizeOptions?: number[];
  onPageChange: (page: number) => void;
  onPageSizeChange: (pageSize: number) => void;
  className?: string;
}) {
  const pageSizeOptions = props.pageSizeOptions ?? [25, 50, 100];
  const totalPages = props.totalCount !== undefined ? Math.max(1, Math.ceil(props.totalCount / props.pageSize)) : undefined;
  const canPrev = props.page > 1;
  const canNext = totalPages !== undefined ? props.page < totalPages : true;

  return (
    <div className={props.className ?? ''}>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="text-xs text-gray-600">
          Pagina <span className="font-semibold">{props.page}</span>
          {totalPages !== undefined ? (
            <>
              {' '}van <span className="font-semibold">{totalPages}</span>
              {props.totalCount !== undefined ? (
                <>
                  {' '}• <span className="font-semibold">{props.totalCount}</span> items
                </>
              ) : null}
            </>
          ) : null}
        </div>

        <div className="flex items-center gap-2">
          <select
            className="rounded-xl border px-2 py-1 text-xs"
            value={String(props.pageSize)}
            onChange={(e) => props.onPageSizeChange(Number(e.target.value))}
          >
            {pageSizeOptions.map((n) => (
              <option key={n} value={String(n)}>
                {n} / pagina
              </option>
            ))}
          </select>

          <Button variant="secondary" onClick={() => props.onPageChange(props.page - 1)} disabled={!canPrev}>
            Vorige
          </Button>
          <Button variant="secondary" onClick={() => props.onPageChange(props.page + 1)} disabled={!canNext}>
            Volgende
          </Button>
        </div>
      </div>
    </div>
  );
}
