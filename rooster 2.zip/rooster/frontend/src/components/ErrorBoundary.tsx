import React from 'react';

type Props = {
  children: React.ReactNode;
};

type State = {
  hasError: boolean;
  error?: unknown;
};

/**
 * Simple app-level error boundary so a single component crash
 * doesn't blank the whole UI.
 */
export class ErrorBoundary extends React.Component<Props, State> {
  state: State = { hasError: false };

  static getDerivedStateFromError(error: unknown): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: unknown, info: unknown) {
    // Keep this lightweight; avoid throwing from the boundary.
    // eslint-disable-next-line no-console
    console.error('[ErrorBoundary] Uncaught error', error, info);
  }

  render() {
    if (!this.state.hasError) return this.props.children;

    const message =
      this.state.error instanceof Error
        ? this.state.error.message
        : typeof this.state.error === 'string'
          ? this.state.error
          : 'Something went wrong.';

    return (
      <div style={{ padding: 16, maxWidth: 720, margin: '0 auto' }}>
        <h1 style={{ fontSize: 20, fontWeight: 700, marginBottom: 8 }}>Er ging iets mis</h1>
        <p style={{ marginBottom: 12, opacity: 0.9 }}>{message}</p>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          <button
            onClick={() => window.location.reload()}
            style={{ padding: '8px 12px', borderRadius: 8, border: '1px solid #ccc' }}
          >
            Pagina opnieuw laden
          </button>
          <button
            onClick={() => this.setState({ hasError: false, error: undefined })}
            style={{ padding: '8px 12px', borderRadius: 8, border: '1px solid #ccc' }}
          >
            Probeer opnieuw
          </button>
        </div>
      </div>
    );
  }
}
