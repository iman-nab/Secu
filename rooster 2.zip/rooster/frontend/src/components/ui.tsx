import React from 'react';
import clsx from 'clsx';

type ButtonVariant = 'primary' | 'secondary' | 'danger' | 'outline';

type ButtonProps = React.ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: ButtonVariant;
  /**
   * Allows using Button styles on another element (e.g. Link).
   * Usage: <Button asChild><Link .../></Button>
   */
  asChild?: boolean;
  children?: React.ReactNode;
};

export function Button(props: ButtonProps) {
  const { variant = 'primary', className, asChild, children, ...rest } = props;

  const base =
    'inline-flex items-center justify-center rounded-lg px-4 py-2 text-sm font-medium transition border focus:outline-none focus:ring-2 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed';

  const v =
    variant === 'primary'
      ? 'bg-[#3E6B52] text-white border-[#3E6B52] hover:bg-[#5F8F6F] focus:ring-[#3E6B52]'
      : variant === 'danger'
        ? 'bg-red-600 text-white border-red-600 hover:bg-red-500 focus:ring-red-600'
        : variant === 'outline'
          ? 'bg-white text-[#2F4F3E] border-[#2F4F3E] hover:bg-[#FAFAFA] focus:ring-[#3E6B52]'
          : 'bg-white text-[#424242] border-[#E0E0E0] hover:bg-[#FAFAFA] focus:ring-[#3E6B52]';

  const mergedClassName = clsx(base, v, className);

  if (asChild) {
    // Minimal Slot-like behavior without extra deps.
    // We only support a single valid React element child.
    const onlyChild = React.Children.only(children);
    if (!React.isValidElement(onlyChild)) {
      throw new Error('Button with asChild expects a single React element child.');
    }

    const childProps: any = {
      className: clsx((onlyChild as any).props?.className, mergedClassName),
    };

    // Forward common button-ish props when possible (e.g. disabled, onClick)
    // so <Link> can still react.
    for (const k of Object.keys(rest)) {
      (childProps as any)[k] = (rest as any)[k];
    }

    return React.cloneElement(onlyChild as any, childProps);
  }

  return (
    <button className={mergedClassName} {...rest}>
      {children}
    </button>
  );
}

export const Input = React.forwardRef<
  HTMLInputElement,
  React.InputHTMLAttributes<HTMLInputElement>
>(function Input(props, ref) {
  const { className, ...rest } = props;
  return (
    <input
      ref={ref}
      className={clsx(
        'w-full rounded-lg border border-[#E0E0E0] bg-white px-3 py-2 text-sm text-[#424242] outline-none focus:ring-2 focus:ring-[#3E6B52]/25',
        className,
      )}
      {...rest}
    />
  );
});

export function Label(props: React.LabelHTMLAttributes<HTMLLabelElement>) {
  return (
    <label
      {...props}
      className={clsx('text-sm font-medium text-[#424242]', props.className)}
    />
  );
}

export function Card(props: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      {...props}
      className={clsx(
        'rounded-xl bg-white shadow-sm transition-shadow hover:shadow-md border border-[#E0E0E0]',
        props.className,
      )}
    />
  );
}

export function Badge(props: React.HTMLAttributes<HTMLSpanElement>) {
  return (
    <span
      {...props}
      className={clsx(
        'inline-flex items-center rounded-full border border-[#E0E0E0] bg-[#FAFAFA] px-2 py-0.5 text-xs font-medium text-[#424242]',
        props.className,
      )}
    />
  );
}

type BannerProps = {
  message?: string;
  children?: React.ReactNode;
};

export function ErrorBanner({ message, children }: BannerProps) {
  const content = message ?? children;
  if (!content) return null;
  return (
    <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800">
      {content}
    </div>
  );
}

export function SuccessBanner({ message, children }: BannerProps) {
  const content = message ?? children;
  if (!content) return null;
  return (
    <div className="rounded-xl border border-green-200 bg-green-50 px-4 py-3 text-sm text-green-800">
      {content}
    </div>
  );
}

export function Skeleton(props: React.HTMLAttributes<HTMLDivElement> & { rounded?: 'md' | 'lg' | 'xl' }) {
  const roundedClass = props.rounded === 'md' ? 'rounded-md' : props.rounded === 'lg' ? 'rounded-lg' : 'rounded-xl';
  return (
    <div
      {...props}
      className={clsx(
        'animate-pulse bg-[#E0E0E0]/60',
        roundedClass,
        props.className,
      )}
    />
  );
}
