import { useEffect, useMemo, useRef, useState } from 'react';

type Props = {
  latitude: number;
  longitude: number;
  radiusM: number;
  onPick: (lat: number, lng: number) => void;
};

/**
 * Lightweight Leaflet map picker.
 * - Click on map to set location
 * - Drag marker to refine
 * - Shows radius circle
 *
 * Leaflet is loaded via CDN in index.html, so we don't need extra npm deps.
 */
export default function LocationMapPicker({ latitude, longitude, radiusM, onPick }: Props) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<any>(null);
  const markerRef = useRef<any>(null);
  const circleRef = useRef<any>(null);

  // Leaflet wordt via CDN geladen. Soms is window.L nét iets later beschikbaar.
  // Dit zorgt voor een re-render zodra Leaflet klaar is.
  const [leafletReady, setLeafletReady] = useState<boolean>(() => typeof (window as any).L !== 'undefined');

  const center = useMemo(() => [latitude, longitude] as [number, number], [latitude, longitude]);

  useEffect(() => {
    if (!containerRef.current) return;
    if (mapRef.current) return; // already created

    if (!leafletReady) return;
    const L = (window as any).L;
    if (typeof L === 'undefined') return;

    const map = L.map(containerRef.current, {
      center,
      zoom: 14,
      zoomControl: true,
    });

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap contributors',
      maxZoom: 19,
    }).addTo(map);

    const marker = L.marker(center, { draggable: true }).addTo(map);
    const circle = L.circle(center, { radius: radiusM }).addTo(map);

    marker.on('dragend', () => {
      const p = marker.getLatLng();
      onPick(p.lat, p.lng);
    });

    map.on('click', (e: any) => {
      onPick(e.latlng.lat, e.latlng.lng);
    });

    mapRef.current = map;
    markerRef.current = marker;
    circleRef.current = circle;

    // Fix "grey tiles" when container is initially hidden (tabs)
    setTimeout(() => map.invalidateSize(), 50);

    return () => {
      map.remove();
      mapRef.current = null;
      markerRef.current = null;
      circleRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [leafletReady]);

  useEffect(() => {
    if (leafletReady) return;

    const t = window.setInterval(() => {
      if (typeof (window as any).L !== 'undefined') {
        setLeafletReady(true);
        window.clearInterval(t);
      }
    }, 100);

    return () => window.clearInterval(t);
  }, [leafletReady]);

  useEffect(() => {
    if (!mapRef.current || !markerRef.current || !circleRef.current) return;

    markerRef.current.setLatLng(center);
    circleRef.current.setLatLng(center);
    circleRef.current.setRadius(Number.isFinite(radiusM) ? radiusM : 0);

    // keep view roughly centered on updates (no animation to avoid jitter)
    mapRef.current.panTo(center, { animate: false });
  }, [center, radiusM]);

  if (!leafletReady) {
    return (
      <div className="rounded-xl border border-dashed p-4 text-sm text-gray-600">
        Kaart kan niet laden (Leaflet script ontbreekt). Check of je internet hebt en refresh de pagina.
      </div>
    );
  }

  return (
    <div className="rounded-xl border bg-white overflow-hidden">
      <div ref={containerRef} className="h-[320px] w-full" />
      <div className="border-t px-3 py-2 text-xs text-gray-600 flex flex-wrap gap-2 justify-between">
        <div>
          Klik op de kaart of sleep de marker.
        </div>
        <div className="font-mono">
          {latitude.toFixed(6)}, {longitude.toFixed(6)}
        </div>
      </div>
    </div>
  );
}
