import { nlFullDate, nlTime } from './datetime';

/**
 * Audit helpers used across admin pages.
 *
 * The backend stores actions in a few different formats over time
 * (e.g. "shift.update", "SHIFT_UPDATE", "ShiftUpdate").
 * We normalize to SCREAMING_SNAKE_CASE.
 */
export function normalizeAction(action: any): string {
  const raw = String(action ?? '').trim();
  if (!raw) return '';
  // Already SNAKE_CASE
  if (/^[A-Z0-9_]+$/.test(raw)) return raw;

  // dot / slash / space separated -> snake
  const dotted = raw.replace(/[\/\.\s-]+/g, '_');

  // camelCase / PascalCase -> snake
  const withUnderscores = dotted
    .replace(/([a-z0-9])([A-Z])/g, '$1_$2')
    .replace(/([A-Z]+)([A-Z][a-z])/g, '$1_$2');

  return withUnderscores.toUpperCase();
}

export function actionLabel(action: any): string {
  const a = normalizeAction(action);
  const map: Record<string, string> = {
    SHIFT_CREATE: 'Dienst aangemaakt',
    SHIFT_UPDATE: 'Dienst aangepast',
    SHIFT_DELETE: 'Dienst verwijderd',
    SHIFT_CREATE_BULK: 'Bulk diensten aangemaakt',
    SHIFT_ASSIGN: 'Medewerker toegewezen',
    SHIFT_UNASSIGN: 'Medewerker ontkoppeld',
    OPEN_SHIFT_APPROVE: 'Open dienst goedgekeurd',
    OPEN_SHIFT_REJECT: 'Open dienst geweigerd',
    CLOCK_IN: 'Ingeklokt',
    CLOCK_OUT: 'Uitgeklokt',
    ADMIN_CLOCK_IN: 'Admin klokactie (in)',
    ADMIN_CLOCK_OUT: 'Admin klokactie (uit)',
    TIMEENTRY_RESET: 'Tijdregistratie gereset',
    TIMEENTRY_CORRECT: 'Tijdregistratie gecorrigeerd',
    NOTE_PIN: 'Notitie gepind',
    NOTE_UNPIN: 'Notitie ontpind',
    SHIFT_RATES_UPDATE: 'Tarieven aangepast',
    SHIFT_EXTRA_COST_ADD: 'Extra kosten toegevoegd',
    SHIFT_EXTRA_COST_UPDATE: 'Extra kosten aangepast',
    SHIFT_EXTRA_COST_DELETE: 'Extra kosten verwijderd',
    REQUEST_CREATE: 'Verzoek aangemaakt',
    REQUEST_UPDATE: 'Verzoek aangepast',
    REQUEST_STATUS_UPDATE: 'Verzoekstatus aangepast',
    REQUEST_CONVERT_TO_SHIFT: 'Verzoek omgezet naar dienst',
  };
  if (map[a]) return map[a];
  // Fallback: pretty snake case
  return a
    .split('_')
    .filter(Boolean)
    .map((p) => p.charAt(0) + p.slice(1).toLowerCase())
    .join(' ');
}

export function fieldLabel(key: string): string {
  const k = String(key ?? '');
  const map: Record<string, string> = {
    title: 'Naam',
    subject: 'Onderwerp',
    description: 'Omschrijving',
    message: 'Bericht',
    body: 'Bericht',
    startAt: 'Start',
    endAt: 'Einde',
    status: 'Status',
    locationId: 'Locatie',
    clientId: 'Klant',
    requiredWorkers: 'Benodigd personeel',
    requiredPassColor: 'Kleurpas',
    workerRateCents: 'Uitbetaling tarief',
    employerRateCents: 'Facturatie tarief',
    amountCents: 'Bedrag',
    descriptionText: 'Omschrijving',
    handledAt: 'Behandeld op',
    handledById: 'Behandeld door',
  };
  if (map[k]) return map[k];
  const last = k.split('.').slice(-1)[0];
  return map[last] ?? last;
}

function fmtIso(dt: string): string {
  return `${nlFullDate(dt)} ${nlTime(dt)}`;
}

function eur(cents: any): string {
  const n = Number(cents ?? 0);
  if (!Number.isFinite(n)) return String(cents ?? '—');
  return (n / 100).toLocaleString('nl-NL', { style: 'currency', currency: 'EUR' });
}

function statusLabel(s: any): string {
  const v = String(s ?? '').toUpperCase();
  const map: Record<string, string> = {
    OPEN: 'Open',
    ASSIGNED: 'Toegewezen',
    COMPLETED: 'Completed',
    CANCELLED: 'Geannuleerd',
    DELETED: 'Verwijderd',
    DRAFT: 'Open',
    NEW: 'Nieuw',
    PENDING: 'In behandeling',
    APPROVED: 'Goedgekeurd',
    REJECTED: 'Afgewezen',
  };
  return map[v] ?? String(s ?? '—');
}

export function formatValue(key: string, v: any): string {
  const k = String(key ?? '');
  const low = k.toLowerCase();

  if (low.includes('ratecents') || low.includes('amountcents')) return eur(v);
  if (low.endsWith('status')) return statusLabel(v);
  if ((low.endsWith('at') || low.includes('date')) && typeof v === 'string' && v.includes('T')) {
    try {
      return fmtIso(v);
    } catch {
      return String(v ?? '—');
    }
  }
  if (typeof v === 'boolean') return v ? 'Ja' : 'Nee';
  if (v === null || v === undefined) return '—';
  if (Array.isArray(v)) return v.length ? v.map((x) => String(x)).join(', ') : '—';
  if (typeof v === 'object') {
    try {
      return JSON.stringify(v);
    } catch {
      return String(v);
    }
  }
  return String(v);
}

type Change = { key: string; from: any; to: any };

function isPlainObject(v: any) {
  return v && typeof v === 'object' && !Array.isArray(v);
}

function safeJson(v: any) {
  try {
    return JSON.stringify(v);
  } catch {
    return String(v);
  }
}

function flatten(obj: any, prefix = '', out: Record<string, any> = {}) {
  if (!isPlainObject(obj)) return out;
  for (const [k, v] of Object.entries(obj)) {
    const path = prefix ? `${prefix}.${k}` : k;
    // Keep it readable: flatten only 2 levels.
    if (isPlainObject(v) && prefix === '') {
      flatten(v, path, out);
    } else {
      out[path] = v;
    }
  }
  return out;
}

function buildChanges(before: any, after: any): Change[] {
  const b = flatten(before ?? {});
  const a = flatten(after ?? {});
  const keys = new Set([...Object.keys(b), ...Object.keys(a)]);
  const ignore = new Set(['id', 'createdAt', 'updatedAt']);

  const changes: Change[] = [];
  for (const k of keys) {
    const last = k.split('.').slice(-1)[0];
    if (ignore.has(last)) continue;
    const from = (b as any)[k];
    const to = (a as any)[k];

    const same =
      from === to ||
      (typeof from === 'object' || typeof to === 'object' ? safeJson(from) === safeJson(to) : false);
    if (!same) changes.push({ key: k, from, to });
  }
  changes.sort((x, y) => x.key.localeCompare(y.key));
  return changes;
}

function actorName(l: any) {
  return l?.actor?.fullName || l?.actor?.email || l?.actorId || 'Onbekend';
}

function summaryFromAction(l: any, changes: Change[]): string {
  const a = normalizeAction(l?.action);
  const who = actorName(l);

  if (a === 'SHIFT_UPDATE') {
    const status = changes.find((c) => c.key.endsWith('status'));
    if (status) return `${who} heeft de status aangepast van ${statusLabel(status.from)} naar ${statusLabel(status.to)}.`;
    const title = changes.find((c) => c.key.endsWith('title'));
    if (title) return `${who} heeft de naam aangepast.`;
    return changes.length ? `${who} heeft dienstgegevens aangepast.` : `${who} heeft een wijziging gedaan.`;
  }

  if (a === 'REQUEST_CONVERT_TO_SHIFT') return `${who} heeft het verzoek omgezet naar een dienst.`;
  if (a === 'REQUEST_STATUS_UPDATE') {
    const status = changes.find((c) => c.key.endsWith('status'));
    if (status) return `${who} heeft de status aangepast van ${statusLabel(status.from)} naar ${statusLabel(status.to)}.`;
  }
  if (a.startsWith('REQUEST_')) return `${who} heeft een verzoek bijgewerkt.`;

  return `${who}: ${actionLabel(a)}`;
}

export function summarizeLog(l: any): { summary: string; changes: Change[] } {
  const changes = buildChanges(l?.before, l?.after);
  const summary = summaryFromAction(l, changes);
  return { summary, changes };
}
