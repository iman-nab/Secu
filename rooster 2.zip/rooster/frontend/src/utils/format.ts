// frontend/src/utils/format.ts

export function formatDateTimeNL(date: string | Date) {
  const d = typeof date === "string" ? new Date(date) : date;

  return d.toLocaleString("nl-NL", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function hoursBetween(start: string | Date, end: string | Date) {
  const s = typeof start === "string" ? new Date(start) : start;
  const e = typeof end === "string" ? new Date(end) : end;

  const diffMs = e.getTime() - s.getTime();
  if (diffMs <= 0) return 0;

  return Math.round((diffMs / 36e5) * 100) / 100; // uren met 2 decimalen
}
