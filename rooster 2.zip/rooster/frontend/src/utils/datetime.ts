export function pad2(n: number) {
  return String(n).padStart(2, '0');
}

/**
 * Format a date to a Dutch "full" date string used across the UI.
 *
 * NOTE: We intentionally keep this numeric (dd-mm-yyyy) to match existing
 * formatting in the app (see formatDateTimeNL).
 */
export function nlFullDate(date: string | Date) {
  const d = typeof date === 'string' ? new Date(date) : date;
  return d.toLocaleDateString('nl-NL', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
  });
}

/**
 * Format a date to a Dutch time string (HH:mm).
 */
export function nlTime(date: string | Date) {
  const d = typeof date === 'string' ? new Date(date) : date;
  return d.toLocaleTimeString('nl-NL', {
    hour: '2-digit',
    minute: '2-digit',
  });
}

/**
 * Format a Date for <input type="date"> in the user's local timezone.
 */
export function toLocalDateInputValue(d: Date) {
  const year = d.getFullYear();
  const month = pad2(d.getMonth() + 1);
  const day = pad2(d.getDate());
  return `${year}-${month}-${day}`;
}

/**
 * Format a Date for <input type="datetime-local"> in the user's local timezone.
 */
export function toLocalDateTimeInputValue(d: Date) {
  const year = d.getFullYear();
  const month = pad2(d.getMonth() + 1);
  const day = pad2(d.getDate());
  const hours = pad2(d.getHours());
  const mins = pad2(d.getMinutes());
  return `${year}-${month}-${day}T${hours}:${mins}`;
}
