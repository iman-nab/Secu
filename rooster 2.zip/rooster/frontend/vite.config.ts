import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import fs from 'node:fs';

// In Docker, "localhost" would point to the frontend container itself.
// Fall back to the docker-compose service name when no explicit proxy target is set.
const runningInDocker = fs.existsSync('/.dockerenv') || fs.existsSync('/run/.containerenv');

const proxyTarget =
  process.env.VITE_PROXY_TARGET || (runningInDocker ? 'http://backend:4000' : 'http://localhost:4000');

const mk = (target: string) => ({
  target,
  changeOrigin: true,
});

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    strictPort: true,
    host: true,
    allowedHosts: 'all',
    proxy: {
      '/client': mk(proxyTarget),
      '/requests': mk(proxyTarget),
      '/auth': mk(proxyTarget),
      '/clients': mk(proxyTarget),
      '/materials': mk(proxyTarget),
      '/users': mk(proxyTarget),
      '/locations': mk(proxyTarget),
      '/shifts': mk(proxyTarget),
      '/reports': mk(proxyTarget),
      '/notifications': mk(proxyTarget),
      '/push': mk(proxyTarget),
      '/dashboard': mk(proxyTarget),
      '/calendar': mk(proxyTarget),
      '/subcontractor': mk(proxyTarget),
      '/health': mk(proxyTarget),
      '/geo': mk(proxyTarget),
      '/socket.io': {
        target: proxyTarget,
        ws: true,
        changeOrigin: true,
      },
    },
  },
});
