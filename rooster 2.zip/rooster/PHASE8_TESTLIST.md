# Phase 8 — Beschikbaarheid (vakantie/ziek/niet beschikbaar)

## Wat is toegevoegd
- Prisma model: `UserAvailability` + enum `AvailabilityType`.
- Backend API:
  - `GET /availability/me`
  - `POST /availability/me`
  - `PATCH /availability/:id`
  - `DELETE /availability/:id`
  - `GET /availability/user/:userId` (admin + subcontractor binnen scope)
- Enforced op backend:
  - Reageren op open dienst (apply) wordt geblokkeerd bij overlap met beschikbaarheid.
  - Admin approve van aanvraag wordt geblokkeerd bij overlap.
  - Admin direct assign wordt geblokkeerd bij overlap.
- Frontend:
  - Pagina `/beschikbaarheid` voor werknemers om periodes te beheren.
  - Admin view `/admin/beschikbaarheid/:userId`.
  - In open diensten wordt “Niet beschikbaar” getoond wanneer een dienst overlapt.

## Handmatige testlijst
### 1) Werknemer: beschikbaarheid instellen
1. Login als werknemer.
2. Ga naar **Beschikbaarheid**.
3. Voeg een periode toe (bijv. vandaag 10:00–18:00, type **Niet beschikbaar**).
4. Verwacht: periode verschijnt in lijst.

### 2) Werknemer: reageren op open dienst geblokkeerd bij overlap
1. Zorg dat er een **open dienst** bestaat die overlapt met de periode.
2. Open **Open diensten**.
3. Verwacht:
   - Dienst toont “Niet beschikbaar”.
   - Reageer-knop is disabled.
4. Forceer via API: `POST /shifts/:id/request` (zelfde user).
5. Verwacht: 409 met code `AVAILABILITY_OVERLAP`.

### 3) Admin: approve/assign blokkeert bij overlap
1. Login als admin.
2. Laat werknemer een request doen op een open dienst.
3. Approve in admin.
4. Verwacht: 409 `AVAILABILITY_OVERLAP` wanneer beschikbaarheid overlapt.
5. Probeer direct assign (admin actie) → verwacht dezelfde blokkade.

### 4) Admin: beschikbaarheid inzien
1. Login als admin.
2. Ga naar **Admin → Users**.
3. Klik bij een werknemer op **Beschikbaarheid**.
4. Verwacht: overzicht met periodes.
