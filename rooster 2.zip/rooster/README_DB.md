# Database & Prisma (belangrijk)

Dit project is getest met **Prisma 6.x**.

Als je lokaal **Prisma 7** hebt (globaal geïnstalleerd), en je runt `prisma migrate ...` direct, dan krijg je errors zoals:

- `P1012: datasource property url is no longer supported`

## ✅ Gebruik daarom altijd de project-commando's

### Met Docker (aanrader)

Start alles:
```bash
docker compose up --build
```

Database reset + seed (wist data):
```bash
npm run db:reset
```

### Zonder Docker
In `backend/`:
```bash
npm install
npx prisma generate
npx prisma migrate dev
npx prisma db seed
```

> Tip: gebruik **`npm run prisma:migrate`** of **`npx prisma`** vanuit de `backend` map.
> Gebruik **niet** een globale `prisma` command.
