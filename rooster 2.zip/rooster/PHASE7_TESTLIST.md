# Fase 7 — Tarieven + Extra kosten + Admin KPI dashboard (Testlijst)

## 1) Tarieven per dienst (Shift)
1. Log in als **Admin**
2. Open een **Shift detail**
3. Ga naar **Tarieven & extra kosten**
4. Vul in:
   - Werkgever tarief (€/uur)
   - Werknemer tarief (€/uur)
5. Klik **Opslaan**
✅ Verwacht: melding “Tarieven opgeslagen” + na refresh zie je de badges met juiste bedragen.

## 2) Extra kosten regels
1. Log in als **Admin**
2. Open een Shift detail
3. Onder **Extra kosten**:
   - Omschrijving (bv. parkeerkosten)
   - Bedrag (bv. 12.50)
4. Klik **Toevoegen**
✅ Verwacht: regel verschijnt in lijst + totaal extra kosten wordt bijgewerkt.

5. Klik **Verwijderen** op een regel
✅ Verwacht: regel verdwijnt.

## 3) Rate visibility (rollen)
- **Admin** ziet:
  - werkgever tarief + werknemer tarief + extra kosten
- **Werknemer** ziet:
  - alleen werknemer tarief (geen werkgever tarief, geen extra kosten)
- **Onderaannemer** ziet:
  - werknemer tarief (geen werkgever tarief, geen extra kosten)
- **Klant** ziet:
  - geen tarieven

## 4) Admin KPI dashboard
1. Log in als **Admin**
2. Ga naar Admin → tab **KPI's**
3. Kies start/eind datum en klik **Verversen**
✅ Verwacht:
- Totale uren
- Te factureren (incl. extra kosten)
- Te betalen (onderaannemers)

> KPI’s gebruiken time entries (minutesWorked) binnen de gekozen periode. Extra kosten worden opgeteld per shift (startdatum binnen periode).
