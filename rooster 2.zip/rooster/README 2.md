# Rooster & Agenda Webapp (React + Node + Prisma + PostgreSQL)

## Architectuur (kort)
- **Frontend:** React + TypeScript + Tailwind + React Router + React Query + FullCalendar.  
  De frontend praat met de API via `fetch` met `credentials: 'include'` zodat **httpOnly cookies** (JWT) gebruikt worden.
- **Backend:** Node.js + TypeScript + **Express** + Prisma + Socket.IO.  
  Ik kies **Express** i.p.v. NestJS omdat:
  - je expliciet vroeg om een structuur met `controllers / services / routes / middleware` (klassiek Express),
  - het licht is en makkelijk te deployen op elk managed platform,
  - Prisma + Express + Socket.IO blijft overzichtelijk en production-ready met strikte TS + tests.

- **Database:** PostgreSQL met Prisma schema en migrations.
- **Realtime notificaties:** Socket.IO WebSockets. Admins joinen automatisch de `admins` room; bij clock-in/clock-out wordt een notificatie opgeslagen + realtime gepusht.

## Features (MVP + v1)
- Auth (JWT access + refresh) via **httpOnly cookies**
- Agenda (admin ziet alles; medewerker alleen eigen goedgekeurde diensten)
- Open diensten + reageren + admin approve/reject
- Clock-in/clock-out met **GPS geofence**:
  - afstand <= locatie radius
  - GPS accuracy <= threshold (default 50m)
  - clock-in tijdvenster (default 15 min vóór start t/m 60 min na start)
  - locatie wordt alleen opgeslagen bij clock-in en clock-out
- Urenberekening (minutesWorked)
- Urenrapport (JSON) + export (CSV / Excel)
- Admin correcties op time entries + auditlog
- Unit tests (geofence distance, overlap-regel, clock-in window regel)

## Repo structuur
```
/frontend
/backend
/prisma
docker-compose.yml
.env.example
README.md
```

---

## Lokaal draaien (zonder VPS)
> Tip: als je de repo-root open hebt, kun je één keer `npm install` in de **root** draaien; dit installeert automatisch de dependencies in zowel `backend/` als `frontend/`.

### Optie A: Docker Compose (aanbevolen)
1. Kopieer `.env.example` naar `.env` (optioneel)
2. Start:
```bash
docker compose up --build
```
3. In een aparte terminal (eerste keer):
```bash
cd backend
npm install
npm run prisma:generate
npm run prisma:migrate
npm run prisma:seed
```

- Frontend: `http://localhost:5173`
- Backend: `http://localhost:4000/health`
- Postgres: `localhost:5432`

### Optie B: Zonder Docker
1. Start Postgres lokaal.
2. Backend:
```bash
cd backend
cp .env.example .env
npm install
npm run prisma:generate
npm run prisma:migrate
npm run prisma:seed
npm run dev
```
3. Frontend:
```bash
cd frontend
cp .env.example .env
npm install
npm run dev
```

### Demo accounts (na seed)
- Admin: `admin@example.com` / `Admin123!ChangeMe`
- Employee: `employee@example.com` / `Employee123!`

### E-mail invites (SMTP)
De opdrachtgever-invite flow kan een uitnodiging mailen. Zonder SMTP werkt het ook: de backend logt de invite-link in de console.

Voor echte e-mails zet je in de backend env vars:
- `SMTP_HOST`
- `SMTP_PORT` (meestal 587)
- `SMTP_USER`
- `SMTP_PASS`
- `SMTP_FROM` (bijv. `no-reply@jouwdomein.nl`)
- `APP_BASE_URL` (bijv. `https://app.jouwdomein.nl`)

---

## Productie deployment op domein (geen VPS)
Je hebt 3 onderdelen:
1) **Managed Postgres** (Neon, Supabase, Render Postgres, etc.)  
2) **Backend API** (Render, Fly.io, Railway, etc.)  
3) **Frontend** (Vercel of Netlify)

### Aanbevolen domein setup
- `app.jouwdomein.nl` -> frontend
- `api.jouwdomein.nl` -> backend

### Backend (Express) deploy checklist
- Zet env vars (platform secret manager):
  - `DATABASE_URL` (managed Postgres connection string)
  - `JWT_ACCESS_SECRET`, `JWT_REFRESH_SECRET`
  - `CORS_ORIGIN=https://app.jouwdomein.nl`
  - `COOKIE_DOMAIN=.jouwdomein.nl` (zodat cookies werken op subdomains)
  - `NODE_ENV=production`
  - `PORT` (platform bepaalt soms automatisch)
  - GPS rules: `GPS_ACCURACY_THRESHOLD_M`, `CLOCK_IN_EARLY_MINUTES`, `CLOCK_IN_LATE_MINUTES`
  - Clock-out reminder: `CLOCK_OUT_REMINDER_MINUTES` (default 15)
- Run migrations in CI of via platform:
  - `npm run prisma:generate`
  - `npm run prisma:deploy`
  - (optioneel) `npm run prisma:seed` voor demo

### Frontend deploy checklist
- Zet `VITE_API_URL=https://api.jouwdomein.nl`
- (optioneel) Zet `VITE_CLOCK_OUT_REMINDER_MINUTES` om de in-app uitklok-toast gelijk te houden met de backend reminder window.
- Build command: `npm run build`
- Output: `dist/`

### HTTPS (vereist voor Geolocation API)
- Vercel/Netlify/Render/Fly regelen HTTPS standaard.  
- Belangrijk: geolocation werkt **alleen** op HTTPS (of `localhost`).

---

## Tests
Backend unit tests:
```bash
cd backend
npm test
```

---

## Security notes
- JWT tokens in **httpOnly cookies** (niet leesbaar door JS).
- Rate limiting op auth endpoints.
- CORS met whitelist + `credentials: true`.
- Locatie wordt alleen opgeslagen bij clock-in/out (AVG/privacy vriendelijk).


---

## Refactor notes
- Deze ZIP bevat geen `node_modules/` (bewust), zodat installs/builds op elk OS consistent werken.
- Zie `CHANGELOG.md` voor de refactor-overzicht.
