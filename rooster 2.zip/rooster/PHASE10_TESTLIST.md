# PHASE10_TESTLIST.md — Materialen (voorraad + bezit + historie)

## Voorwaarden
- Log in als **ADMIN** met 2FA.
- Log in als **EMPLOYEE** met 2FA (tweede account).

## 1) Admin — voorraadbeheer
1. Ga naar **Admin → Materialen**
2. Voeg nieuw materiaal toe (bijv. “Portofoon”) met start voorraad `5`
3. Controleer dat voorraad badge `5` toont
4. Pas voorraad aan:
   - Delta `+3`, reden “Nieuwe levering”
   - Controleer voorraad badge `8`
5. Probeer delta `-999` → verwacht fout `INSUFFICIENT_STOCK`

## 2) Admin — uitgifte (vast bezit)
1. Kies bij materiaal een werknemer en geef `2` uit
2. Controleer:
   - voorraad is verminderd (bijv. van 8 naar 6)
   - in “Uitgiftes” staat status `ASSIGNED`

## 3) Werknemer — eigen materialen zien + verlies/defect melden
1. Ga naar **Materialen**
2. Zie toegewezen materiaal met status `ASSIGNED`
3. Klik **Verloren** (optioneel met notitie)
4. Controleer status verandert naar `LOST`

## 4) Admin — historie (audit)
1. Ga naar Admin → Materialen → Historie tabel
2. Controleer dat je events ziet zoals:
   - `CREATE`, `STOCK_ADJUST`, `ASSIGN`, `LOST` of `DEFECT`
3. Controleer dat “Door” en “Voor” zijn ingevuld (actor/target)

## 5) Admin — retour
1. In Admin → Materialen → Uitgiftes: klik **Retour** bij een `ASSIGNED` item
2. Controleer:
   - status wordt `RETURNED`
   - voorraad gaat omhoog
   - historie bevat `RETURN`
