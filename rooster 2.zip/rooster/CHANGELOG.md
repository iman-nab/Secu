# Changelog (Quality Refactor)

## 2026-01-08
### Frontend
- Split `frontend/src/pages/admin/tabs/ShiftsTab.tsx` into focused modules under `frontend/src/pages/admin/tabs/shifts/`:
  - `ShiftsTab.tsx` (main component)
  - `MaterialsEditor.tsx` (materials rows UI)
  - `utils.ts` (time-range formatting helper)
  - `types.ts` (shared types)
  - Kept `frontend/src/pages/admin/tabs/ShiftsTab.tsx` as a re-export so imports/routes stay identical.

- Split `frontend/src/pages/HoursPage.tsx` into `frontend/src/pages/hours/`:
  - `HoursPage.tsx` (main component)
  - `utils.ts` (date/time helpers)
  - `types.ts` (Row type)
  - Kept `frontend/src/pages/HoursPage.tsx` as a re-export to preserve existing imports/routes.

### Backend
- Extracted Zod schemas from `backend/src/controllers/shiftsController.ts` into `backend/src/controllers/shifts.schemas.ts`
  to reduce controller size and keep concerns separated, without changing validation behavior.

## 2026-01-08 (round 2)

### Frontend
- Moved `ShiftDetailPage` into a dedicated folder (`pages/shiftDetail/`) and kept the original route import stable via re-export.
- Extracted `StatusBadge` from the Admin Shifts tab into `pages/admin/tabs/shifts/components/StatusBadge.tsx` (no UI/behaviour change).

## 2026-01-08 (round 3)

### Frontend
- Further split Admin `ShiftsTab` into view components under `frontend/src/pages/admin/tabs/shifts/views/`:
  - `CreateShiftView.tsx`
  - `WeekPlannerView.tsx`
  - `OverviewView.tsx`
  This keeps the rendered markup and behaviour identical, while reducing the main file size and improving readability.

## 2026-01-08 (round 4)

### Frontend
- Split `frontend/src/pages/shiftDetail/ShiftDetailPage.tsx` into focused presentational components under
  `frontend/src/pages/shiftDetail/components/` (header, client notes, employee status, admin sections) while keeping
  the rendered markup, behaviour and styling identical.


## 2026-01-09 (round 5)

### Backend
- Refactored `backend/src/controllers/clientsController.ts` by extracting:
  - Zod schemas into `backend/src/controllers/clients.schemas.ts`
  - Invite-link helper into `backend/src/controllers/clients.helpers.ts`
  This keeps validation and behaviour identical while reducing controller responsibilities.

- Refactored `backend/src/controllers/reportsController.ts` by extracting:
  - Query schema into `backend/src/controllers/reports.schemas.ts`
  - Date parsing helper into `backend/src/controllers/reports.helpers.ts`
  No route/response changes; purely structural.

## 2026-01-09 (round 6)

### Backend
- Refactored `backend/src/controllers/shiftsController.ts` by extracting its internal date parsing helper into
  `backend/src/controllers/shifts.helpers.ts`.
  This is a structural split only; query parsing and error messages remain identical.

## 2026-01-09 (round 7)

### Dev experience
- Added a root-level `postinstall` script so running `npm install` in the repo root installs dependencies for both
  `backend/` and `frontend/`. This prevents editor/TypeScript "cannot find module 'react'" squiggles when only the
  root install is executed.
- Added `.vscode/settings.json` and `.vscode/extensions.json` to improve TypeScript/TSX detection and recommend ESLint/Prettier.
- Updated `README.md` with an install tip.

## 2026-01-09 (round 8)

### Frontend
- Fixed build-breaking JSX/props issues introduced during the `ShiftsTab` view split:
  - Restored the full sub-navigation button group (Overzicht/Nieuwe dienst/Weekplanner) and properly closed the wrapper `<div>`.
  - Corrected prop wiring to `CreateShiftView` and `WeekPlannerView` (e.g. `materialsList`, `repeatUntil`, `locationId/clientId`, `setLastSubmittedKey`) so the split matches the original implementation.
  - Corrected `OverviewView` to consume the grouped shifts data passed from `ShiftsTab`.
- Fixed `ShiftDetailPage` relative import paths after moving it under `pages/shiftDetail/`.

## 2026-01-09 (round 9)

### Frontend
- Fixed the Admin "Diensten" overview view crash by replacing references to an undefined local variable with the
  `grouped` prop passed into `OverviewView`.

## 2026-01-09 (round 10)

### Frontend
- Fixed the Admin "Opdrachtgevers" list rendering by reading the correct query result field (`data.clients`).
  This restores the ability to view existing clients and use actions like delete and invite regeneration.

## 2026-01-09 (round 11)

### Frontend
- Improved Vite dev server proxy robustness for Socket.IO in Docker environments:
  - Added an automatic in-container fallback so the proxy target defaults to `http://backend:4000` when running in Docker.
  - Enabled `changeOrigin` for the `/socket.io` proxy to reduce handshake issues.
  No runtime behavior changes intended—this only affects dev proxy routing.

## 2026-01-09 (round 12)

### Frontend
- Fixed dev Socket.IO connectivity when the Vite WebSocket proxy does not successfully upgrade by adding a safe
  fallback in `useNotificationsSocket`: when `VITE_API_URL` is empty and the app runs on port 5173, the notifications
  socket connects directly to `http(s)://<hostname>:4000` while keeping API calls on the existing proxy path.

## 2026-01-09 (round 13)

### Frontend
- Improved the visual presentation of the Notifications page (`frontend/src/pages/NotificationsPage.tsx`) without changing underlying notification logic:
  - Added a type-specific icon indicator and a subtle left accent bar per notification type.
  - Used consistent Dutch date-time formatting via `formatDateTimeNL`.
  - Rendered the “Nieuwe notificatie ontvangen” message as a small floating toast for better visibility.
- Enhanced desktop push notification presentation in the service worker (`frontend/public/sw.js`) by adding a notification `tag` (grouping) and optional actions (Open/Sluiten).

## 2026-01-09 (round 14)

## 2026-01-27 (opschoonfase vervolg)

### Frontend
- Admin: stub/duplicated tabs verwijderd (Locaties/Diensten/Rapporten) — admin bevat nu alleen tabs met echte functionaliteit.
- Admin → Opdrachtgevers: volledige ClientsTab toegevoegd (overzicht + aanmaken + portal invite + kopieer link + soft delete).
- Client portal API calls gestandaardiseerd van `/client-portal` naar `/client`.

### Backend
- Client portal endpoints gestandaardiseerd onder `/client` (oude `/client-portal` blijft als deprecated alias).

### DevOps
- Added persistent Web Push (VAPID) environment variables to `docker-compose.yml` under the `backend` service (`VAPID_SUBJECT`, `VAPID_PUBLIC_KEY`, `VAPID_PRIVATE_KEY`) so push subscriptions remain valid across restarts.

## 2026-01-09 (round 15)

### Admin UI improvements
- Extended `GET /notifications` to include minimal `sender` user info (id/fullName/email/role) so the frontend can show who triggered a notification.
- Updated the Notifications page to display the sender name next to the timestamp when available.
- Updated the Admin “Diensten” overview list to show extra context per shift (planner + a compact list of assigned employees) without changing existing actions or filtering.

## 2026-01-09 (round 16)

### Hours UI improvements
- Enriched the Hours page entry rows by showing planned shift time range (start/end) alongside each time entry.
  This helps answer “who worked where and for how long” by combining actual clock-in/out with scheduled shift times.

## 2026-01-09 (round 17)

### Employee reminder
- Added a best-effort “Uitklok-reminder” for employees: when you are clocked-in for a shift, the app will show a toast
  and (when browser permission is granted) a desktop notification roughly 15 minutes before the shift end time.
  This runs client-side while the app is open.

## 2026-01-09 (round 18)

### Employee reminder (server-side)
- Added a server-side clock-out reminder scheduler so employees can receive a push notification even when the app is not open.
  - Configurable via `CLOCK_OUT_REMINDER_MINUTES` (default 15).
  - Uses a new `TimeEntry.clockOutReminderSentAt` field to prevent duplicate reminders.
  - The reminder is only sent for active (not clocked-out) time entries when the shift end time is within the configured window.

### Frontend
- Added optional `VITE_CLOCK_OUT_REMINDER_MINUTES` for the in-app toast so it can stay aligned with the backend reminder window.
- Removed the local `new Notification(...)` call from `useClockOutReminder` to avoid duplicate desktop notifications (server-side Web Push now handles that).

## 2026-01-09 (round 19)

### Archive flow (Admin)
- Made “verwijderen” one-time-only by enforcing idempotent archiving:
  - `DELETE /shifts/:id` now returns **409** (`SHIFT_ALREADY_ARCHIVED`) if the shift is already archived.
  - `DELETE /clients/:id` now returns **409** (`CLIENT_ALREADY_ARCHIVED`) if the client is already archived.
- Added support for listing archived records for Admin via `?includeDeleted=1`:
  - `GET /shifts?includeDeleted=1`
  - `GET /clients?includeDeleted=1`
- Updated the Admin UI to treat delete as **Archiveren** and to show **Actief** vs **Gearchiveerd** sections.
  The archived section is collapsed by default (option 1).

### Hours (mobile)
- On the Hours page mobile view, Admin now always sees the employee name (“wie”) for each entry, even when filtering by a specific employee.

## 2026-01-09 (round 20)

### Build fix
- Fixed a missing export mismatch introduced in round 19 by adding `nlFullDate` and `nlTime` helpers to `frontend/src/utils/datetime.ts`.
  This restores the frontend build without changing runtime behavior beyond the intended date/time formatting.

## 2026-01-09 (round 21)

### Admin UX: soft delete clarity
- Switched the Admin “Diensten” and “Opdrachtgevers” delete wording back to **Verwijderen (soft delete)** and removed the separate “Gearchiveerd” sections to avoid confusion.
  Deleted items simply disappear from the default overview.
- Made the shift overview “extra info” (medewerkers/planner) less header-heavy by rendering it as compact labeled lines.

### Frontend bugfix
- Fixed incorrect `useMe()` usage in:
  - `frontend/src/pages/DashboardPage.tsx`
  - `frontend/src/pages/hours/HoursPage.tsx`
  These pages now correctly read `const { data: me } = useMe()` so role-gated queries/filters work as intended.

## 2026-01-09 (round 23)

### Admin safety: portal users vs opdrachtgevers
- The Admin **Opdrachtgevers** list now receives the latest portal user for each client **including inactive accounts**, so the UI can show “Portal inactief” instead of looking like no portal exists.
- The Admin **Gebruikers** list now shows which opdrachtgever a **CLIENT** portal user belongs to.
- Deactivating a CLIENT user now shows a clearer confirmation message explaining that only the **portal account** is disabled and the opdrachtgever record remains.

## 2026-01-09 (round 24)

### Portal reactivation
- Updated `POST /clients/:id/portal-user` to **reuse/reactivate** the latest inactive portal user record for the opdrachtgever (soft-delete reversal) instead of creating a brand new portal user. A fresh invite is generated and emailed as before.
  - Safety: if there is already any active portal user for that opdrachtgever, the endpoint still returns **409**.
- Updated the Admin **Opdrachtgevers** tab UI to show a dedicated **Heractiveer portal account** button when the portal user exists but is inactive.

## 2026-01-09 (round 25)

### UsersTab reactivation (reuse existing account)
- Added `POST /users/:id/reactivate` for Admins. This reactivates a soft-deleted (inactive) user and **best-effort restores the original email** if it was tagged with `.deleted.<ts>` and the original email is available.
- Updated the Admin **Gebruikers** tab to show a **Heractiveer** button for inactive users:
  - For opdrachtgever portal users (`role=CLIENT`), it uses the opdrachtgever reactivation flow (regenerates an invite).
  - For normal users (ADMIN/EMPLOYEE), it calls `/users/:id/reactivate`.

## 2026-01-27 (phase 8)

### Availability (vacation/sick/unavailable)
- Added Prisma `UserAvailability` model + `AvailabilityType` enum.
- Added backend `/availability/*` endpoints to manage/view availability periods.
- Server-side enforced overlap checks:
  - Employee cannot apply for open shifts when unavailable (`AVAILABILITY_OVERLAP`).
  - Admin cannot approve or assign a worker when unavailable.
- Added worker UI page `/beschikbaarheid`.
- Added admin view page `/admin/beschikbaarheid/:userId` + a link from Admin → Users.

## Phase 9 (ICS + Push targeting)
- ICS feed per gebruiker: /calendar/:token.ics + UI copy link in Agenda
- Admin push composer: target naar dienst of kleurpas groep, auditlog PUSH_SENT
