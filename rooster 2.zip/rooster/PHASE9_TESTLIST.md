# PHASE 9 — Testlijst (ICS + Push targeting)

## 1) ICS agenda-sync
1. Log in als werknemer (2FA moet al aan staan).
2. Ga naar **Agenda**.
3. Kopieer de **Agenda-sync (ICS)** link.
4. Open de link in je browser:
   - Je moet een response krijgen met `BEGIN:VCALENDAR`.
5. Voeg de link toe in:
   - Google Calendar: *Instellingen → Toevoegen van agenda → Via URL*
   - Apple Calendar: *Bestand → Nieuwe agenda-abonnement*

**Verwachting:**
- Alleen **geaccepteerde** diensten (APPROVED) verschijnen.
- Cancelled diensten verschijnen niet.

## 2) Push targeting — naar dienst
1. Log in als **Admin**.
2. Ga naar **Admin → Push**.
3. Kies **Naar dienst** en selecteer een dienst met 1+ goedgekeurde werknemers.
4. Vul titel + bericht in en klik **Verstuur**.

**Verwachting:**
- Bevestiging toont `Verzonden naar X ontvanger(s)`.
- Ontvangers krijgen een melding (push + notificatie in app).
- Auditlog bevat action `PUSH_SENT` met target `shift`.

## 3) Push targeting — naar kleurpas groep
1. Log in als **Admin**.
2. Ga naar **Admin → Push**.
3. Kies **Naar kleurpas groep** en selecteer een kleurpas.
4. Verstuur bericht.

**Verwachting:**
- Alleen actieve werknemers met die `passColor` ontvangen bericht.
- Auditlog bevat action `PUSH_SENT` met target `passColor`.
