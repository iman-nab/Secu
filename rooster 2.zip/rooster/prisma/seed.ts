import { prisma } from '../src/db/prisma.js';
import bcrypt from 'bcryptjs';

/**
 * Deterministic dev seed.
 * - Admin: admin@example.com / Admin123!ChangeMe
 * - Employee: employee@example.com / Employee123!ChangeMe
 *
 * Override via env:
 *  - SEED_ADMIN_EMAIL, SEED_ADMIN_PASSWORD
 *  - SEED_EMPLOYEE_EMAIL, SEED_EMPLOYEE_PASSWORD
 */
async function main() {
  const adminEmail = process.env.SEED_ADMIN_EMAIL ?? 'admin@example.com';
  const adminPassword = process.env.SEED_ADMIN_PASSWORD ?? 'Admin123!ChangeMe';
  const employeeEmail = process.env.SEED_EMPLOYEE_EMAIL ?? 'employee@example.com';
  const employeePassword = process.env.SEED_EMPLOYEE_PASSWORD ?? 'Employee123!ChangeMe';

  // Upsert admin
  await prisma.user.upsert({
    where: { email: adminEmail },
    update: {
      fullName: 'Admin',
      role: 'ADMIN',
      isActive: true,
      passwordHash: await bcrypt.hash(adminPassword, 12),
    },
    create: {
      email: adminEmail,
      fullName: 'Admin',
      role: 'ADMIN',
      isActive: true,
      passwordHash: await bcrypt.hash(adminPassword, 12),
    },
  });

  // Upsert demo employee
  await prisma.user.upsert({
    where: { email: employeeEmail },
    update: {
      fullName: 'Employee',
      role: 'EMPLOYEE',
      isActive: true,
      passwordHash: await bcrypt.hash(employeePassword, 12),
    },
    create: {
      email: employeeEmail,
      fullName: 'Employee',
      role: 'EMPLOYEE',
      isActive: true,
      passwordHash: await bcrypt.hash(employeePassword, 12),
    },
  });

  // Create demo location (Amsterdam)
  const location = await prisma.location
    .upsert({
      where: { name_address: { name: 'HQ', address: 'Main street 1' } } as any,
      update: {},
      create: {
        name: 'HQ',
        address: 'Main street 1',
        latitude: 52.370216,
        longitude: 4.895168,
        radiusM: 150,
      },
    })
    .catch(async () => {
      // Upsert composite not supported without @@unique; do a simple find/create
      const existing = await prisma.location.findFirst({ where: { name: 'HQ' } });
      if (existing) return existing;
      return prisma.location.create({
        data: {
          name: 'HQ',
          address: 'Main street 1',
          latitude: 52.370216,
          longitude: 4.895168,
          radiusM: 150,
        },
      });
    });

  // Create an open shift tomorrow (idempotent-ish)
  const admin = await prisma.user.findUnique({ where: { email: adminEmail } });
  if (admin) {
    const now = new Date();
    const start = new Date(now.getTime() + 24 * 60 * 60 * 1000);
    start.setHours(9, 0, 0, 0);
    const end = new Date(start.getTime() + 8 * 60 * 60 * 1000);

    await prisma.shift
      .create({
        data: {
          title: 'Open day shift',
          description: 'Demo open shift',
          locationId: location.id,
          startAt: start,
          endAt: end,
          status: 'OPEN',
          createdById: admin.id,
        },
      })
      .catch(() => {
        // ignore duplicates in dev seed
      });
  }

  // Seed a few materials for testing (idempotent)
  const materials = [
    { name: 'Sleutelset', description: 'Sleutels / toegang' },
    { name: 'iPad', description: 'Tablet voor registratie' },
    { name: 'Werkkleding', description: 'Uniform / kleding' },
  ];
  for (const m of materials) {
    await prisma.material.upsert({
      where: { name: m.name },
      update: { description: m.description, isDeleted: false, deletedAt: null },
      create: m,
    });
  }

  // Seed a demo opdrachtgever + client portal user
  // NOTE: Prisma upsert requires a UNIQUE selector; Client.name is indexed but not unique.
  // Keep schema as-is and make seed idempotent via find-first + update/create.
  const existingClient = await prisma.client.findFirst({ where: { name: 'Voetbalclub Demo' } });
  const client = existingClient
    ? await prisma.client.update({
        where: { id: existingClient.id },
        data: { isDeleted: false, deletedAt: null, contactName: 'Club Admin', contactEmail: 'club@example.com' },
      })
    : await prisma.client.create({
        data: { name: 'Voetbalclub Demo', contactName: 'Club Admin', contactEmail: 'club@example.com' },
      });

  const clientEmail = process.env.SEED_CLIENT_EMAIL ?? 'club@example.com';
  const clientPassword = process.env.SEED_CLIENT_PASSWORD ?? 'Club123!ChangeMe';
  await prisma.user.upsert({
    where: { email: clientEmail },
    update: {
      fullName: 'Klant (Voetbalclub)',
      role: 'CLIENT',
      clientId: client.id,
      isActive: true,
      passwordHash: await bcrypt.hash(clientPassword, 12),
    },
    create: {
      email: clientEmail,
      fullName: 'Klant (Voetbalclub)',
      role: 'CLIENT',
      clientId: client.id,
      isActive: true,
      passwordHash: await bcrypt.hash(clientPassword, 12),
    },
  });

  // eslint-disable-next-line no-console
  console.log(`\nSeeded credentials:`);
  // eslint-disable-next-line no-console
  console.log(`Admin    : ${adminEmail} / ${adminPassword}`);
  // eslint-disable-next-line no-console
  console.log(`Employee : ${employeeEmail} / ${employeePassword}`);
  console.log(`Client   : ${clientEmail} / ${clientPassword}\n`);
}

main()
  .then(async () => {
    await prisma.$disconnect();
  })
  .catch(async (e) => {
    // eslint-disable-next-line no-console
    console.error(e);
    await prisma.$disconnect();
    process.exit(1);
  });

