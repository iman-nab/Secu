-- Add soft delete fields to Location and Shift
ALTER TABLE "Location" ADD COLUMN IF NOT EXISTS "isDeleted" BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE "Location" ADD COLUMN IF NOT EXISTS "deletedAt" TIMESTAMP(3);

ALTER TABLE "Shift" ADD COLUMN IF NOT EXISTS "isDeleted" BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE "Shift" ADD COLUMN IF NOT EXISTS "deletedAt" TIMESTAMP(3);

UPDATE "Location" SET "isDeleted" = false WHERE "isDeleted" IS NULL;
UPDATE "Shift" SET "isDeleted" = false WHERE "isDeleted" IS NULL;
