-- Phase 7: Tarieven + Extra kosten + Admin KPI dashboard

ALTER TABLE "Shift" ADD COLUMN "employerRateCents" INTEGER NOT NULL DEFAULT 0;
ALTER TABLE "Shift" ADD COLUMN "workerRateCents" INTEGER NOT NULL DEFAULT 0;

CREATE TABLE "ShiftExtraCost" (
  "id" TEXT NOT NULL,
  "shiftId" TEXT NOT NULL,
  "description" TEXT NOT NULL,
  "amountCents" INTEGER NOT NULL,
  "createdById" TEXT NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,

  CONSTRAINT "ShiftExtraCost_pkey" PRIMARY KEY ("id")
);

CREATE INDEX "ShiftExtraCost_shiftId_idx" ON "ShiftExtraCost"("shiftId");
CREATE INDEX "ShiftExtraCost_createdById_idx" ON "ShiftExtraCost"("createdById");

ALTER TABLE "ShiftExtraCost" ADD CONSTRAINT "ShiftExtraCost_shiftId_fkey"
  FOREIGN KEY ("shiftId") REFERENCES "Shift"("id") ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE "ShiftExtraCost" ADD CONSTRAINT "ShiftExtraCost_createdById_fkey"
  FOREIGN KEY ("createdById") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
