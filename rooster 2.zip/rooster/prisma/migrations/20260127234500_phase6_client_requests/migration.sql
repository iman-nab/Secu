-- Phase 6: Client portal analytics + requests

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'ClientRequestStatus') THEN
    CREATE TYPE "ClientRequestStatus" AS ENUM ('OPEN','IN_PROGRESS','DONE');
  END IF;
END $$;

CREATE TABLE IF NOT EXISTS "ClientRequest" (
  "id" TEXT NOT NULL,
  "clientId" TEXT NOT NULL,
  "createdById" TEXT NOT NULL,
  "subject" TEXT NOT NULL,
  "message" TEXT NOT NULL,
  "status" "ClientRequestStatus" NOT NULL DEFAULT 'OPEN',
  "handledById" TEXT,
  "handledAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT "ClientRequest_pkey" PRIMARY KEY ("id")
);

CREATE INDEX IF NOT EXISTS "ClientRequest_clientId_status_idx" ON "ClientRequest"("clientId", "status");
CREATE INDEX IF NOT EXISTS "ClientRequest_createdById_idx" ON "ClientRequest"("createdById");
CREATE INDEX IF NOT EXISTS "ClientRequest_handledById_idx" ON "ClientRequest"("handledById");

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'ClientRequest_clientId_fkey') THEN
    ALTER TABLE "ClientRequest" ADD CONSTRAINT "ClientRequest_clientId_fkey"
      FOREIGN KEY ("clientId") REFERENCES "Client"("id") ON DELETE CASCADE ON UPDATE CASCADE;
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'ClientRequest_createdById_fkey') THEN
    ALTER TABLE "ClientRequest" ADD CONSTRAINT "ClientRequest_createdById_fkey"
      FOREIGN KEY ("createdById") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'ClientRequest_handledById_fkey') THEN
    ALTER TABLE "ClientRequest" ADD CONSTRAINT "ClientRequest_handledById_fkey"
      FOREIGN KEY ("handledById") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;
  END IF;
END $$;
