-- Phase 9: ICS calendar token per user
ALTER TABLE "User" ADD COLUMN IF NOT EXISTS "calendarToken" TEXT;

-- Allow multiple NULLs, enforce uniqueness when set
CREATE UNIQUE INDEX IF NOT EXISTS "User_calendarToken_key" ON "User"("calendarToken");
