-- Phase 3: admin overrides & corrections for time entries

ALTER TABLE "TimeEntry"
  ADD COLUMN IF NOT EXISTS "adminOverride" BOOLEAN NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS "correctedById" TEXT,
  ADD COLUMN IF NOT EXISTS "correctionReason" TEXT,
  ADD COLUMN IF NOT EXISTS "correctedAt" TIMESTAMP(3);

-- Foreign key to User for correctedById
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_constraint
    WHERE conname = 'TimeEntry_correctedById_fkey'
  ) THEN
    ALTER TABLE "TimeEntry"
      ADD CONSTRAINT "TimeEntry_correctedById_fkey"
      FOREIGN KEY ("correctedById") REFERENCES "User"("id")
      ON DELETE SET NULL ON UPDATE CASCADE;
  END IF;
END $$;

-- Index for admin reporting
CREATE INDEX IF NOT EXISTS "TimeEntry_correctedById_idx" ON "TimeEntry"("correctedById");
