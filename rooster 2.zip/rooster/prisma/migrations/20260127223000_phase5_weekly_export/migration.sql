-- Phase 5: Weekly PDF urenexport quota (subcontractor)

CREATE TABLE IF NOT EXISTS "WeeklyExportLog" (
  "id" TEXT NOT NULL,
  "subcontractorId" TEXT NOT NULL,
  "weekStart" TIMESTAMP(3) NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT "WeeklyExportLog_pkey" PRIMARY KEY ("id")
);

-- One export per subcontractor per week
CREATE UNIQUE INDEX IF NOT EXISTS "WeeklyExportLog_subcontractorId_weekStart_key" ON "WeeklyExportLog"("subcontractorId", "weekStart");

CREATE INDEX IF NOT EXISTS "WeeklyExportLog_subcontractorId_weekStart_idx" ON "WeeklyExportLog"("subcontractorId", "weekStart");

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'WeeklyExportLog_subcontractorId_fkey') THEN
    ALTER TABLE "WeeklyExportLog" ADD CONSTRAINT "WeeklyExportLog_subcontractorId_fkey"
      FOREIGN KEY ("subcontractorId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
  END IF;
END $$;
