-- Phase 10: Materials inventory + assignments + history

DO $$ BEGIN
  CREATE TYPE "MaterialAssignmentStatus" AS ENUM ('ASSIGNED','RETURNED','LOST','DEFECT');
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
  CREATE TYPE "MaterialHistoryAction" AS ENUM ('CREATE','UPDATE','STOCK_ADJUST','ASSIGN','RETURN','LOST','DEFECT','DELETE');
EXCEPTION
  WHEN duplicate_object THEN null;
END $$;

ALTER TABLE "Material" ADD COLUMN IF NOT EXISTS "stockQuantity" INTEGER NOT NULL DEFAULT 0;

CREATE TABLE IF NOT EXISTS "MaterialAssignment" (
  "id" TEXT NOT NULL,
  "materialId" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "quantity" INTEGER NOT NULL DEFAULT 1,
  "status" "MaterialAssignmentStatus" NOT NULL DEFAULT 'ASSIGNED',
  "note" TEXT,
  "assignedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "returnedAt" TIMESTAMP(3),
  "createdById" TEXT NOT NULL,
  "updatedById" TEXT,
  CONSTRAINT "MaterialAssignment_pkey" PRIMARY KEY ("id")
);

CREATE INDEX IF NOT EXISTS "MaterialAssignment_materialId_idx" ON "MaterialAssignment"("materialId");
CREATE INDEX IF NOT EXISTS "MaterialAssignment_userId_idx" ON "MaterialAssignment"("userId");
CREATE INDEX IF NOT EXISTS "MaterialAssignment_status_idx" ON "MaterialAssignment"("status");

ALTER TABLE "MaterialAssignment"
  ADD CONSTRAINT "MaterialAssignment_materialId_fkey" FOREIGN KEY ("materialId") REFERENCES "Material"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "MaterialAssignment"
  ADD CONSTRAINT "MaterialAssignment_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "MaterialAssignment"
  ADD CONSTRAINT "MaterialAssignment_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "MaterialAssignment"
  ADD CONSTRAINT "MaterialAssignment_updatedById_fkey" FOREIGN KEY ("updatedById") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;

CREATE TABLE IF NOT EXISTS "MaterialHistory" (
  "id" TEXT NOT NULL,
  "materialId" TEXT NOT NULL,
  "action" "MaterialHistoryAction" NOT NULL,
  "quantityDelta" INTEGER NOT NULL DEFAULT 0,
  "note" TEXT,
  "userId" TEXT,
  "actorId" TEXT NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "assignmentId" TEXT,
  CONSTRAINT "MaterialHistory_pkey" PRIMARY KEY ("id")
);

CREATE INDEX IF NOT EXISTS "MaterialHistory_materialId_createdAt_idx" ON "MaterialHistory"("materialId","createdAt");
CREATE INDEX IF NOT EXISTS "MaterialHistory_actorId_createdAt_idx" ON "MaterialHistory"("actorId","createdAt");
CREATE INDEX IF NOT EXISTS "MaterialHistory_userId_createdAt_idx" ON "MaterialHistory"("userId","createdAt");

ALTER TABLE "MaterialHistory"
  ADD CONSTRAINT "MaterialHistory_materialId_fkey" FOREIGN KEY ("materialId") REFERENCES "Material"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "MaterialHistory"
  ADD CONSTRAINT "MaterialHistory_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "MaterialHistory"
  ADD CONSTRAINT "MaterialHistory_actorId_fkey" FOREIGN KEY ("actorId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "MaterialHistory"
  ADD CONSTRAINT "MaterialHistory_assignmentId_fkey" FOREIGN KEY ("assignmentId") REFERENCES "MaterialAssignment"("id") ON DELETE CASCADE ON UPDATE CASCADE;
